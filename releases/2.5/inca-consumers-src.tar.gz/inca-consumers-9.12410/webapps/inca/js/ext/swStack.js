document.write("<h1>* swStack</h1><p>Some description of the swStack.xml file and how to edit...</p>");

Ext.onReady(function() {
  Ext.Ajax.request({
    url: '/inca/xml/swStack.xml',
    success: createTreeStack
  });
});

function saveTreeStack(tree) {
  var xml = tree.toXmlString();
  Ext.Ajax.request( { url: 'admin.jsp', params: {xml: xml, file: 'swStack'}, method: 'POST',
                      success: function(){ window.location.reload(true); } });
}

function newPackage(text) {
  var package = new Ext.tree.TreeNode({text:'package', leaf:false, expandable:true });
  package.appendChild( new Ext.tree.TreeNode({text:'id', leaf:false, expandable:true }) );
  package.firstChild.appendChild( new Ext.tree.TreeNode({text:text, leaf:true, expandable:false }) );
  package.appendChild( new Ext.tree.TreeNode({text:'version', leaf:false, expandable:true }) );
  package.item(1).appendChild( new Ext.tree.TreeNode({text:'any', leaf:true, expandable:false }) ); 
  package.appendChild( new Ext.tree.TreeNode({text:'tests', leaf:false, expandable:true }) );
  var tests = package.item(2);
  tests.appendChild( new Ext.tree.TreeNode({text:'version', leaf:false, expandable:true }) ); 
  tests.firstChild.appendChild( new Ext.tree.TreeNode({text:text+'_version', leaf:true, expandable:false }) );
  tests.appendChild( new Ext.tree.TreeNode({text:'unitalias', leaf:false, expandable:true }) ); 
  tests.item(1).appendChild( new Ext.tree.TreeNode({text:text+'_unit', leaf:true, expandable:false }) );
  return package;
}

function createTreeStack(response) {
  var root = response.responseXML.documentElement || response.responseXML;
  var tree = new Ext.tree.TreePanel({
    el:'swStack',
    width:600,
    autoHeight:true,
    autoScroll:true,
    expandable:false,
    enableDD:true,
    title: 'swStack.xml Configuration',
    loader: new Ext.ux.XmlTreeLoader({ preloadChildren: true }),
    root: new Ext.tree.AsyncTreeNode({
      text: root.tagName,
      xmlNode: root
    }),
    listeners: {
      'textchange' : function(){ saveTreeStack(tree); } 
    },
    tbar: [{
      text:'Add Category',
      listeners: {
        'click' : function(){
          handleCreate = function (btn, text, cBoxes){
            if(btn == 'ok' && text) {
              var cat = new Ext.tree.TreeNode({text:'category', leaf:false, expandable:true });
              cat.appendChild( new Ext.tree.TreeNode({text:'id', leaf:false, expandable:true }) );
              cat.firstChild.appendChild( new Ext.tree.TreeNode({text:text, leaf:true, expandable:false }) );
              var root = tree.getRootNode();
              root.insertBefore(cat, root.item(1)); 
              saveTreeStack(tree);
            }
          }
          Ext.MessageBox.show({ title:'Add Category', msg: 'Name of Category:', buttons: Ext.MessageBox.OKCANCEL, prompt:true, fn: handleCreate });
        } 
      }
    },{ xtype:'tbseparator' },{
      text:'Add Package',
      listeners: {
        'click' : function(){
          var root = tree.getRootNode();
          var selected = tree.getSelectionModel().getSelectedNode();
          if (!selected || (selected.parentNode.getPath() != root.getPath()) || (selected.text != "category")){
            Ext.Msg.alert("You must first select a 'category' folder to add a package.");
          } else {
            handleCreate = function (btn, text, cBoxes){
              if(btn == 'ok' && text) {
                var package = newPackage(text);
                selected.insertBefore(package, selected.item(1)); 
                saveTreeStack(tree);
              }
            }
            Ext.MessageBox.show({ title:'Add Package', msg: 'Name of Package:', buttons: Ext.MessageBox.OKCANCEL, prompt:true, fn: handleCreate });
          }
        } 
      }
    },{ xtype:'tbseparator' },{
      text:'Add Unit Test',
      listeners: {
        'click' : function(){
          var selected = tree.getSelectionModel().getSelectedNode();
          if (!selected || selected.parentNode.text != "package" || selected.text != "tests"){
            Ext.Msg.alert("You must first select a package 'tests' folder to add a unit test.");
          } else {
            handleCreate = function (btn, text, cBoxes){
              if(btn == 'ok' && text) {
                var test = new Ext.tree.TreeNode({text:'unitalias', leaf:false, expandable:true });
                test.appendChild( new Ext.tree.TreeNode({text:text, leaf:true, expandable:false }) );
                selected.appendChild(test);
                saveTreeStack(tree);
              }
            }
            Ext.MessageBox.show({ title:'Add Unit Test', msg: 'Name of Unit Test:', buttons: Ext.MessageBox.OKCANCEL, prompt:true, fn: handleCreate });
          }
        } 
      }
    },{ xtype:'tbseparator' },{
      text:'Add Version Test',
      listeners: {
        'click' : function(){
          var selected = tree.getSelectionModel().getSelectedNode();
          if (!selected || selected.parentNode.text != "package" || selected.text != "tests"){
            Ext.Msg.alert("You must first select a package 'tests' folder to add a version test.");
          } else {
            handleCreate = function (btn, text, cBoxes){
              if(btn == 'ok' && text) {
                var test = new Ext.tree.TreeNode({text:'version', leaf:false, expandable:true });
                test.appendChild( new Ext.tree.TreeNode({text:text, leaf:true, expandable:false }) );
                selected.appendChild(test);
                saveTreeStack(tree);
              }
            }
            Ext.MessageBox.show({ title:'Add Version Test', msg: 'Name of Version Test:', buttons: Ext.MessageBox.OKCANCEL, prompt:true, fn: handleCreate });
          }
        } 
      }
    },{ xtype:'tbseparator' },{
      text:'Delete',
      listeners: {
        'click' : function(){
          var selectedItem = tree.getSelectionModel().getSelectedNode();
          if (!selectedItem) {
            Ext.Msg.alert('Warning', 'Please select an Item to delete.');
            return false;
          }
          handleDelete = function (btn){
            if(btn == 'ok') { 
              selectedItem.remove(); 
              saveTreeStack(tree);
            }
          }
          var text = selectedItem.text;
          Ext.MessageBox.show({
            title:'Confirm your action',
            msg: "Are you sure you want to delete '"+text+"' and everything under it?",
            buttons: Ext.MessageBox.OKCANCEL,
            fn: handleDelete
          });
        } 
      }
    },{ xtype:'tbseparator' },{
      text: 'Restore to Defaults',
      listeners: {
        'click' : function(){
          handleDefault = function (btn){
            if(btn == 'ok') {  
              Ext.Ajax.request({ 
                url: 'admin.jsp', 
                params: {defaults: 'swStack'}, 
                method: 'POST', 
                success: function(){ window.location.reload(true); } 
              });
            }
          }
          Ext.MessageBox.show({
            title:'Confirm your action',
            msg: 'Are you sure you want to restore defaults?',
            buttons: Ext.MessageBox.OKCANCEL,
            fn: handleDefault
          });
        } 
      }
    }]
  });
  tree.render();
  //hack to force reload
  tree.expandAll();
  tree.collapseAll();
  tree.root.expand();
  var te = new Ext.tree.TreeEditor(tree, null, {
    editDelay: 0,
    beforeNodeClick : Ext.emptyFn,
    onNodeDblClick : function(node, e){
      e.stopEvent();
      this.triggerEdit(node);
    }
  });
}
