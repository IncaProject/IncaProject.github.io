package edu.sdsc.inca.consumer;

import de.laures.cewolf.DatasetProduceException;
import de.laures.cewolf.DatasetProducer;
import de.laures.cewolf.links.XYItemLinkGenerator;
import de.laures.cewolf.tooltips.XYToolTipGenerator;
import edu.sdsc.inca.dataModel.queryResults.ObjectDocument;
import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlCalendar;
import org.apache.xmlbeans.impl.values.XmlObjectBase;
import org.jfree.data.time.Minute;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;


import java.util.Date;
import java.util.Map;

/**
 * A dataset producer for graphing time series data based on an xpath values
 * in a xml document.  This is implemented by extending the time series dataset
 * to pull values from xpaths.  There is a main xpath expression used to pick
 * out filter the document.  Relative xpath expressions are used for the
 * xaxis value, yaxis value, tooltip, and url.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */

public class TimeSeriesBean extends TimeSeriesCollection
                            implements DatasetProducer, XYToolTipGenerator,
                                       XYItemLinkGenerator  {

  public static final String NAMESPACE_DECLS = SeriesHistoryBean.NAMESPACE_DECLS;


  private static Logger logger = Logger.getLogger(TimeSeriesBean.class);
  private String id = null;
  private String label = "aLabel";
  private String[] links = new String[0];
  private String linkXpath;
  private String[] tooltips = new String[0];
  private String tooltipXpath;
  private String timestampXpath;
  private String xml;
  private String xpath;
  private String valueXpath;

  /**
   * Create a new time series collection with the specified id
   *
   * @param id a unique identifier for identifying this time series collection
   */
  public TimeSeriesBean( String id ) {
    this.id = id;
  }

  /**
   * Return the link to use when the cursor is hovered over a data point
   *
   * @param data  This object.
   *
   * @param series  The series index containing the data point
   *
   * @param item  The index of the data point in the series
  *
   * @return  A string containing a url
   */
  public String generateLink( Object data, int series, int item ) {
    return ((TimeSeriesBean)data).generateLink(item);
  }

  /**
   * Return the link to use when the given date point index is moused over
   *
   * @param index  The index of the data point that was moused over
   *
   * @return  A url for the given datapoint
   */
  public String generateLink( int index ) {
    return this.links[index];
  }

  /**
   * Return the text to display when the cursor is hovered a data point
    *
    * @param data  This object.
    *
    * @param series  The series index containing the data point
    *
    * @param item  The index of the data point in the series
    *
    * @return  A string containing a url
    */
  public String generateToolTip( XYDataset data, int series, int item ) {
    return ((TimeSeriesBean)data).generateToolTip(item);
  }

  /**
   * Return the link to use when the given date point index is moused over
   *
   * @param index  The index of the data point that was moused over
   *
   * @return  A url for the given datapoint
   */

  public String generateToolTip( int index ) {
    return tooltips[index];
  }

  /**
   * Return label description to be used in legend
   *
   * @return A string containing a short description of the series
   */
  public String getLabel() {
    return this.label;
  }

  /**
   * Returns a unique ID for this DatasetProducer
   */
  public String getProducerId() {
    return this.id;
  }

  /**
   * This method influences Cewolf's caching behaviour.
   *
   * Example of invalid data after a day (86,400 seconds):
   *   log.debug(getClass().getName() + "hasExpired()");
   *   return (System.currentTimeMillis() - since.getTime()) > 86400000;
   */
  public boolean hasExpired(Map params, Date since) {
    return true;
  }

  /**
   * Return a time series collection using data supplied from the
   * provided xpaths
   *
   * @param params  Additional params for the dataset production.
  *
   * @return A  TimeSeriesCollection object with data and timeestamps.
   *
   * @throws DatasetProduceException if trouble generating data
   */
  public Object produceDataset(Map params) throws DatasetProduceException {

    // process data for each test and resource
    ObjectDocument doc;
    logger.debug( "Generating data for time series " + this.id );
    try {
      doc = ObjectDocument.Factory.parse( this.xml );
    } catch (XmlException e) {
      throw new DatasetProduceException( "Unable to parse xml" );
    }
    XmlObject[] tsObjects = doc.selectPath( NAMESPACE_DECLS + this.xpath );

    logger.debug("Processing " + tsObjects.length + " objects for " + this.id);
    TimeSeries series = new TimeSeries( this.label, Minute.class );
    long startTime = Util.getTimeNow();
    tooltips = new String[ tsObjects.length ];
    links = new String[ tsObjects.length ];
    for ( int i = 0; i < tsObjects.length; i++ ) {
      // Get timestamp and value
      XmlObjectBase timestampObject =
        (XmlObjectBase)tsObjects[i].selectPath(this.timestampXpath)[0];
      XmlObjectBase valueObject =
        (XmlObjectBase)tsObjects[i].selectPath(this.valueXpath)[0];

      // Get tooltip if a tooltip xpath exists
      XmlObjectBase tooltipObject = null;
      XmlObject[] tObjects = tsObjects[i].selectPath(this.tooltipXpath);
      if ( tObjects != null && tObjects.length == 1 ) {
        tooltipObject = (XmlObjectBase)tObjects[0];
      }

      // Get link if a link xpath exists
      XmlObjectBase lValue = null;
      XmlObject[] lObjects = tsObjects[i].selectPath(this.linkXpath);
      if ( lObjects != null || lObjects.length == 1 ) {
        lValue = (XmlObjectBase)lObjects[0];
      }
      
      Date date = new XmlCalendar( timestampObject.stringValue() ).getTime();
      float value = 0;
      try{
        value = new Float(valueObject.stringValue());
        series.add( new Minute(date), value );
        tooltips[i] = "("+date.toString()+") ";
        if ( tooltipObject != null ) {
          tooltips[i] = tooltips[i] +
            Util.formatStringAsTooltip(tooltipObject.stringValue());
        }
        if ( lValue != null ) links[i] = lValue.stringValue();
     } catch(Exception e) {
         logger.debug( "Problem adding value (" + date + "," + value + ")", e );
      }
    }
    this.addSeries(series);
    Util.printElapsedTime( startTime, "time series " + this.id );
    return this;
  }

  /**
   * Set description of series to be used in graph legend
   *
   * @param label  A string containing a label
   */
  public void setLabel( String label ) {
    this.label = label;
  }

  /**
   * Set the xpath to retrieve the link to use for a given data point
   *
   * @param linkXpath  A relative xpath
   */
  public void setLinkXpath(String linkXpath) {
    logger.debug( "link xpath: " + linkXpath + " for " + this.id );
    this.linkXpath = linkXpath;
  }

  /**
   * Set the xpath to retrieve the tooltip text to use for a given data point
   *
   * @param tooltipXpath  A relative xpath
   */
  public void setTooltipXpath(String tooltipXpath) {
    logger.debug( "tooltip xpath: " + tooltipXpath);
    this.tooltipXpath = tooltipXpath;
  }

  /**
   * Set the xpath to retrieve the timestamp to use for a given data point
   *
   * @param timestampXpath   A relative xpath
   */
  public void setTimestampXpath(String timestampXpath) {
    logger.debug( "timestamp xpath: " + timestampXpath);
    this.timestampXpath = timestampXpath;
  }

  /**
   * Set the xpath to retrieve the a data point value
   *
   * @param valueXpath   A relative xpath
   */
  public void setValueXpath(String valueXpath) {
    logger.debug( "value xpath: " + valueXpath);
    this.valueXpath = valueXpath;
  }

  /**
   * Set the xml document to extract time series from
   *
   * @param xml A string containing a xml document
   */
  public void setXml(String xml) {
    this.xml = xml;
  }
  
  /**
   * Set the absolute xpath to a datapoint
   *
   * @param xpath An absolute xpath
   */
  public void setXpath(String xpath) {
    this.xpath = xpath;
  }

}