package edu.sdsc.inca.consumer;

import edu.sdsc.inca.dataModel.graphSeries.GraphInstance;
import edu.sdsc.inca.dataModel.graphSeries.GraphSeries;
import edu.sdsc.inca.dataModel.queryResults.ObjectDocument;
import edu.sdsc.inca.dataModel.queryResults.Rows;
import edu.sdsc.inca.dataModel.queryResults.Row;
import edu.sdsc.inca.dataModel.util.AnyXmlSequence;
import edu.sdsc.inca.util.XmlWrapper;
import edu.sdsc.inca.util.StringMethods;
import edu.sdsc.inca.util.Constants;
import org.apache.log4j.Logger;
import org.apache.xmlbeans.impl.values.XmlAnyTypeImpl;
import org.apache.xmlbeans.XmlObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.Pattern;

/**
 * Retrieve the history of one or more series and return the values as an
 * xml document.
 */
public class SeriesHistoryBean extends Hashtable {
  final static public String NAMESPACE_DECLS =
    "declare namespace q='http://inca.sdsc.edu/dataModel/queryResults_2.0';";

  private static String ignorePattern = null;
  private static Logger logger = Logger.getLogger(SeriesHistoryBean.class);
  private Date endDate = null;
  private String[] resource = new String[0];
  private Date startDate = null;
  private String [] nickname = new String[0];

  /**
   * Get the regular expression pattern to mark neutrally if an error matches it
   *
   * @return ignorePattern  The pattern to mark neutrally in error msgs
   */
  public String getIgnorePattern() {
    return ignorePattern;
  }

  /**
   * Return the list of series nicknames that will be queried
   *
   * @return  a list of series nicknames
   */
  public String[] getNickname() {
    return nickname;
  }

  /**
   * Return a list of series resource names that will be queried
   *
   * @return a list of series resource names
   */
  public String[] getResource() {
    return resource;
  }

  /**
   * Determine pass/fail/unknown status for a series report based on error
   * message and comparison result.
   *
   * @param exitStatus true or false indicating whether the reporter completed
   *
   * @param err the exit message if exitStatus is false
   *
   * @param cr the comparison result if it exists
   *
   * @return  1 if completed is true or the comparison result is Success.
   * -1 if comparison is Failure or completed is false.  Neutral (0) if
   * err message indicates downtime or Inca error
   */
  static public String getResult( boolean exitStatus, String err, String cr ) {
    String result;
    if (ignorePattern != null &&
        Pattern.compile(ignorePattern, Pattern.MULTILINE).matcher(err).find()) {
      result = "0";
    }else if (cr != null && Pattern.matches("^Success.*$", cr)){
      result = "1";
    }else if (cr != null && Pattern.matches("^Failure.*$", cr)){
      result = "-1";
    }else{
      result = exitStatus ? "1" : "-1";
    }
    return result;
  }

  /**
   * Query the depot for series histories and return the results in as a
   * string containing an XML document.  Does the query in 4 parts:
   *
   * 1) gets all the series config and series ids
   *
   * 2) gets all reports
   *
   * 3) gets all comparison results
   *
   * 4) gets all instances
   *
   * The results are concatenated together and is more efficient that
   * doing joins.
   *
   * @return A string containing an XML document complying to the query
   * results schema.
   */
  public String getXml() {
    SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");

    ObjectDocument doc = ObjectDocument.Factory.newInstance();
    ObjectDocument.Object object = doc.addNewObject();
    if ( this.nickname.length < 1 || this.resource.length < 1 ) {
      return XmlWrapper.prettyPrint( doc.xmlText(), "  " );
    }

    String query =
      "SELECT sc.id AS id, " +
        "     sc.series.id AS seriesId, " +
        "     sc.nickname AS nickname, " +
        "     sc.series.resource AS resource, " +
        "     sc.latestInstanceId AS latestInstanceId " +
        "FROM SeriesConfig sc " +
        "WHERE ";
    for ( int i = 0; i < this.resource.length; i++ ) {
      if ( i > 0 ) query += " OR ";
      query += " ( sc.nickname = " + this.nickname[i] + " AND " +
               "   sc.series.resource = " + this.resource[i] + ")";
    }
    query += " ORDER BY sc.latestInstanceId";
    String[][] seriesInfo = queryAndParse( query, "id", "seriesId", "nickname", "resource", "latestInstanceId" );
    if ( seriesInfo.length < 1 ) {
      return null;
    }
    String seriesIdList = StringMethods.join( ",", seriesInfo[1] );
    String configIdList = StringMethods.join( ",", seriesInfo[0] );
    String latestIdList = StringMethods.join( ",", seriesInfo[4] );
    Properties seriesNicknames = new Properties();
    Properties seriesResources = new Properties();
    Properties seriesConfigIds = new Properties();
    for( int i = 0; i < seriesInfo[0].length; i++ ) {
      seriesNicknames.setProperty( seriesInfo[1][i],seriesInfo[2][i] );
      seriesResources.setProperty( seriesInfo[1][i],seriesInfo[3][i] );
      seriesConfigIds.setProperty( seriesInfo[1][i],seriesInfo[0][i] );
    }

    // if we have a start date, trim series configs that are not relevant
    if ( startDate != null ) {
      query =
        "SELECT ii.id AS id, " +
          "     ii.collected AS collected " +
          "FROM InstanceInfo ii " +
          "WHERE ii.id IN (" + latestIdList + ")" +
          " ORDER BY ii.id";
      String[][] latestInfo = queryAndParse( query, "id", "collected" );
      int k = 0;
      for ( ; k < latestInfo[0].length; k++ ) {
        Date latestDate = StringMethods.convertDateString
          ( latestInfo[1][k], "yyyy-MM-dd HH:mm:ss.S" );
        if ( startDate.before(latestDate) ) {
          break;
        }
        logger.debug
          ( "Throwing away series config " + latestInfo[0][k] +
            " with latest instance " + latestDate );
      }
      if ( k > 0 ) {
        logger.debug( "Trimming series configs based on start date from " + k );
        int origLength = seriesInfo[0].length;
        seriesIdList = StringMethods.join
          ( ",", subArray(seriesInfo[1],k, origLength) );
        configIdList = StringMethods.join
          ( ",", subArray(seriesInfo[0], k, origLength) );
        seriesNicknames = new Properties();
        seriesResources = new Properties();
        seriesConfigIds = new Properties();
        for( int j = k; j < origLength; j++ ) {
          seriesNicknames.setProperty( seriesInfo[1][j],seriesInfo[2][j] );
          seriesResources.setProperty( seriesInfo[1][j],seriesInfo[3][j] );
          seriesConfigIds.setProperty( seriesInfo[1][j],seriesInfo[0][j] );
        }
      }
    }

    query =
      "SELECT r.id AS id, " +
        "     r.body AS body, " +
        "     r.exit_status AS status, " +
        "     r.exit_message AS message, " +
        "     r.series.id AS seriesId " +
      "FROM Report r " +
      "WHERE r.series.id IN (" + seriesIdList + ")";
    String[][] reportInfo =
      queryAndParse( query, "id", "body", "status", "message", "seriesId" );

    String reportIdList = StringMethods.join( ",", reportInfo[0] );
    Properties reportBodies = new Properties();
    Properties reportMessages = new Properties();
    HashMap<String,Boolean> reportStatuses = new HashMap<String,Boolean>();
    Properties reportSeriesIds = new Properties();
    for( int i = 0; i < reportInfo[0].length; i++ ) {
      reportBodies.setProperty( reportInfo[0][i], reportInfo[1][i] );
      reportStatuses.put( reportInfo[0][i], Boolean.parseBoolean(reportInfo[2][i]) );
      reportMessages.setProperty( reportInfo[0][i], reportInfo[3][i] );
      reportSeriesIds.setProperty( reportInfo[0][i], reportInfo[4][i] );
    }

    query =
      "SELECT cr.reportId as reportId, "  +
        "     cr.result as result " +
      "FROM ComparisonResult cr " +
      "WHERE cr.seriesConfigId IN (" + configIdList + ")";
    String[][] comparisonInfo = queryAndParse( query, "reportId", "result" );

    Properties reportComparisons = new Properties();
    for( int i = 0; i < comparisonInfo[0].length; i++ ) {
      reportComparisons.setProperty(comparisonInfo[0][i], comparisonInfo[1][i]);
    }

    query =
      "SELECT ii.id AS id, " +
        "     ii.reportId AS reportId, " +
        "     ii.collected AS collected " +
      "FROM InstanceInfo ii " +
      "WHERE ii.reportId IN (" + reportIdList + ")";
    if(startDate != null) {
      query += " AND ii.collected >= '" + fmt.format(startDate) + "' ";
    }
    if(endDate != null) {
      Calendar cal = Calendar.getInstance();
      cal.setTime(endDate);
      // to get the query to be inclusive of the end date, we add 1 day
      cal.add(Calendar.DATE, 1);
      endDate = cal.getTime();
      query += " AND ii.collected <= '" + fmt.format(endDate) + "' ";
    }
    query += " ORDER BY ii.collected";

    String[][] instanceInfo = queryAndParse
      ( query, "id", "reportId", "collected" );

    Vector<GraphInstance> gis = new Vector<GraphInstance>();
    long queryHqlTime = Util.getTimeNow();
    HashMap<String,Date> prevs = new HashMap<String,Date>();
    int numInstances = 0;
    if ( instanceInfo.length > 0 ) { // instances now
      numInstances = instanceInfo[0].length;
    }
    for( int i = 0; i < numInstances; i++ ) {
      String reportId = instanceInfo[1][i];
      String seriesId = reportSeriesIds.getProperty(reportId);

      Date curr = StringMethods.convertDateString
        (instanceInfo[2][i], "yyyy-MM-dd HH:mm:ss.S");
      Date prev = prevs.get( seriesId );
      if ( prev != null &&
           curr.getTime() - prev.getTime() <= Constants.MILLIS_TO_MINUTE ) {
        logger.debug( "Ditching duplicate for series " + seriesId );
        continue; // discard duplicates
      }
      prevs.put( seriesId, curr );
      GraphInstance gi = GraphSeries.Factory.newInstance().addNewObject();
      gi.setInstanceId(instanceInfo[0][i]);
      gi.setReportId(reportId);
      gi.setResource( seriesResources.getProperty(seriesId) );
      gi.setNickname( seriesNicknames.getProperty(seriesId) );
      gi.setConfigId( seriesConfigIds.getProperty(seriesId) );
      Calendar cal = Calendar.getInstance();
      cal.setTime( curr );
      gi.setCollected( cal );
      String result = getResult
        ( reportStatuses.get(reportId), reportMessages.getProperty(reportId),
          reportComparisons.getProperty(reportId) );
      gi.setExitStatus( result );
      if ( result.equals("-1") ) {
        gi.setExitMessage(reportMessages.getProperty(reportId));
      } else {
        gi.setExitMessage("");
      }
      try {
        gi.setBody(AnyXmlSequence.Factory.parse(reportBodies.getProperty(reportId)));
      } catch(Exception e) {
        logger.error("Unable to parse report body '" + reportBodies.getProperty(seriesId) + "'");
      }
      String comparison = reportComparisons.getProperty(reportId);
      gi.setComparisonResult(comparison == null ? "" : comparison);
      gis.add(gi);
    }
    Util.printElapsedTime(queryHqlTime, "GRAPH: collate results");

    logger.debug("GRAPH: Returning " + gis.size() + " instances");
    Rows rows = Rows.Factory.newInstance();
    for( GraphInstance gi : gis ) {
      Row row = rows.addNewRow();
      row.set( gi );
    }
    object.set( rows );
    return XmlWrapper.prettyPrint( doc.xmlText(), "  " );

  }

  /**
   * Submit a query to the depot
   *
   * @param hql  A valid HQL query string
   *
   * @param fields The fields that should be returned in the query
   *
   * @return An array of field value arrays.
   */
  public String[][] queryAndParse( String hql, String... fields ) {
    ObjectDocument doc = null;
    String queryResults = null;
    long queryHqlTime;
    try {
      queryHqlTime = Util.getTimeNow();
      logger.debug( "HQL: " + hql );
      queryResults = DepotQuery.query( "queryHql", (Object)hql );
      if ( queryResults != null ) {
        doc = ObjectDocument.Factory.parse( queryResults );
      }
      Util.printElapsedTime(queryHqlTime, "GRAPH: queryHQL");
    } catch(Throwable t){
      logger.warn("Problem querying depot", t);
    }
    if(doc == null) {
      return new String[0][];
    }
    logger.debug( "RESULT: " + queryResults );
    String[][] fieldValues = new String[fields.length][];
    for( int i = 0; i < fieldValues.length; i++ ) {
      String xpath = "/q:object/row/object/" + fields[i] +
        " | /q:object/object/" + fields[i];
      logger.debug( "XPATH: " + xpath );
      XmlObject[] results = doc.selectPath( NAMESPACE_DECLS + xpath );
      fieldValues[i] = new String[results.length];
      logger.debug( "Found " + results.length + " " + fields[i] + " values" );
      for( int j = 0; j < results.length; j++ ) {
        fieldValues[i][j] = ((XmlAnyTypeImpl)results[j]).stringValue();
      }
    }
    return fieldValues;
  }

  /**
   * Set the end date for the series histories.
   *
   * @param endDate  A valid date
   */
  public void setEndDate(String endDate) {
    this.endDate = StringMethods.convertDateString(endDate, "MMddyy" );
  }

  /**
   * Set a regular expression pattern to mark neutrally if an error matches it
   *
   * @param ignoreErrors  The pattern to mark neutrally in error msgs
   */
  public static void setIgnorePattern(String ignoreErrors) {
    ignorePattern = ignoreErrors;
  }

  /**
   * Set the list of series nicknames that will be queried
   *
   * @param nickname  a list of series nicknames
   */
  public void setNickname( String[] nickname) {
    this.nickname = nickname;
    for( int i = 0; i < this.nickname.length; i++ ) {
      this.nickname[i] = "'" + this.nickname[i] + "'";
    }

  }

  /**
   * Set the list of series resources that will be queried
   *
   * @param resource  a list of series resources
   */
  public void setResource( String[] resource ) {
    this.resource = resource;
    for( int i = 0; i < this.resource.length; i++ ) {
      this.resource[i] = "'" + this.resource[i] + "'";
    }
  }

  /**
   * Set the list of series that will be queried for their history
   *
   * @param series An array of series nickname,resource pairs
   */
  public void setSeries( String[] series ) {
    if ( series == null ) return;

    this.resource = new String[series.length];
    this.nickname = new String[series.length];
    for( int i = 0; i < series.length; i++ ) {
      String[] seriesParts = series[i].split( "\\s*,\\s*" );
      this.nickname[i] = "'" + seriesParts[0] + "'";
      if ( seriesParts.length > 1 ) {
        this.resource[i] = "'" + seriesParts[1] + "'";
      }
    }
  }

  /**
   * Set the start date for the series histories.
   *
   * @param startDate  A valid date
   */
  public void setStartDate(String startDate) {
    this.startDate = StringMethods.convertDateString(startDate, "MMddyy" );
  }

  /**
   * Return a subarray of the given array.
   *
   * @param orig An array of string values
   * @param start  The start index of the subarray
   * @param end  The exclusive end index of the subarray
   * @return  A new string array that array starting at start to just before end
   */
  private static String[] subArray( String[] orig, int start, int end ) {
    String[] newArray = new String[end-start];
    int j = 0;
    for( int i = start; i < end; i++ ) {
      newArray[j] = orig[i];
      j++;
    }
    return newArray;
  }

}
