/* empty.h - Make sure 'include_dirs' get passed to the compiler */

#define EMPTY 1
