package edu.sdsc.inca.util;

import junit.framework.Assert;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: cmills
 * Date: Feb 4, 2005
 * Time: 1:14:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class WorkQueueTest extends TestCase {

    /**
     * just testing to see that it gets through the constructor without an
     * exception.
     */
    public void testConstructorSimple() {
        WorkQueue wq = null;
        try {
            wq = new WorkQueue();
        } catch (Exception e) {
            fail("constructor failed");
        }
        Assert.assertNotNull(wq);
    }

    /**
     * Tests the addition of one task and the removal of that task.
     */
    public void testAddWork() {
        WorkQueue wq = null;
        try {
            wq = new WorkQueue();
            wq.addWork(new Integer(1));
            Assert.assertFalse(wq.isEmpty());
            final Integer i = (Integer) wq.getWork();
            Assert.assertTrue(wq.isEmpty());
            Assert.assertEquals(i.intValue(), 1);
        } catch (Exception e) {
            Assert.fail(e.toString());
        }
    }

    /**
     * Adding null to the queue should throw a nullPointerException.
     */
    public void testAddNull() {
        WorkQueue wq = null;
        try {
            wq = new WorkQueue();
            wq.addWork(null);
            fail("should have thrown Null Pointer");
        } catch (NullPointerException e) {
        }
    }

    /**
     * Adds 10 integers and then uses 5 threads to retrieve them.  Merges all
     * the results to make sure that each object was removed once and only
     * once.
     */
    public void testAddRemoveSameWork() {
        final Integer ins[] = new Integer[10];
        final WorkQueue wq = new WorkQueue();
        final IntegerReader[] workers = new IntegerReader[5];
        final Integer outs[] = new Integer[10];

        for (int i = 0; i < 10; i++) {
            ins[i] = new Integer(i);
            wq.addWork(ins[i]);
        }
        for (int i = 0; i < 5; i++) {
            workers[i] = new IntegerReader(wq);
            workers[i].start();
        }

        // wait for all the work to be done
        while (!wq.isEmpty()) ;

        // join the results
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 10; j++) {
                if (workers[i].results[j] != null) {
                    if (outs[j] == null) {
                        outs[j] = workers[i].results[j];
                    } else {
                        fail("2 workers got same work");
                    }
                }
            }
        }
        for (int i = 0; i < 10; i++) {
            assertNotNull(outs[i]);
        }

    }

    /**
     * Tests clear
     */
    public void testClear() {
        WorkQueue wq = null;
        try {
            wq = new WorkQueue();
            wq.addWork( 1 );
            wq.addWork( 5 );
            wq.addWork( 10 );
            Assert.assertFalse(wq.isEmpty());
            wq.clear();
            Assert.assertTrue(wq.isEmpty());
        } catch (Exception e) {
            Assert.fail(e.toString());
        }
    }

    /**
     * Class to assist with testing the queue.
     */
    private class IntegerReader extends Worker {

        public Integer[] results = new Integer[10];

        /**
         * create this worker attached to the indicated Q.
         *
         * @param wq
         */
        public IntegerReader(WorkQueue wq) {
            super(wq);
        }

        /**
         * Abstract method: should do the actual work required.
         *
         * @param work the socket that was queued
         */
        protected void doWork(Object work) {
            Integer in = (Integer) work;
            results[in.intValue()] = in;
        }
    }


}
