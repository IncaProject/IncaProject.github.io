package edu.sdsc.inca.agent.access;

import org.apache.log4j.Logger;
import org.globus.io.gass.server.GassServer;
import org.globus.io.gass.server.JobOutputStream;
import org.globus.gram.GramJob;
import org.globus.gram.GramAttributes;
import org.globus.gram.GramException;
import org.globus.gram.internal.GRAMConstants;

import java.io.File;
import java.io.IOException;
import java.io.FileWriter;

import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.agent.AccessMethodOutput;
import edu.sdsc.inca.agent.AccessMethodException;

/**
 * Handles the creation and running PreWS GRAM jobs
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GlobusPreWSGramJob extends GlobusJob {
  private Logger logger = Logger.getLogger(GlobusPreWSGramJob.class);

  public JobState activeJob = null;

  // data struct for storing temporary job state
  private class JobState {
    public GassServer gassServer = null;
    public GramJob job = null;
    public GlobusOutputListener stdout = null;
    public GlobusOutputListener stderr = null;
    public File tempStdin = null;
  }

  /**
   * Handles the creation of a Globus Pre-WS GRAM job
   *
   * @param host  The hostname of the WS GRAM server
   * @param port  The port of the WS GRAM server.  Use 0 to get default port.
   * @param dn    An optional subject dn for the WS GRAM credentials
   *              (null if empty)
   * @param service GRAM service type (default: jobmanager)
   */
  public GlobusPreWSGramJob( String host, int port, String dn, String service ){
    this.host = host;
    this.port = port;
    if ( port == 0 ) {
      this.port = Integer.parseInt(Protocol.GRAM_SERVER_PORT_MACRO_DEFAULT);
    }
    this.dn = dn;
    this.service = service;
    if ( service == null ) this.service = Protocol.GRAM_SERVICE_MACRO_DEFAULT;
  }

  /**
   * Cleanup local and remote temporary files
   *
   * @param jobState holds temporary files and gridftp connection for a job
   */
  public void cleanup( JobState jobState ) {
    if ( jobState.tempStdin != null ) jobState.tempStdin.delete();
  }

  /**
   * Create a globus job using the specified parameters
   *
   * @param executable Path to the remote executable.
   * @param arguments  Contains the arguments that should be passed to the
   *                   executable
   * @param dir  Path to the directory where the process will be executed
   *             from
   * @param stdin  A string that will be passedd in as stdin to the process
   *               when it is started
   * @param streamOutput true if stdout and stderr should be streamed back
   *                     locally
   * @param jobState holds temporary files and gridftp connection for a job
   *                 (cannot be null)
   *
   * @throws Exception If problem creating the task.
   */
  public void createJob( String executable, String[] arguments, String dir,
                         String stdin, boolean streamOutput, JobState jobState )
    throws Exception {

    // Create RSL request
    GramAttributes rsl = new GramAttributes( );
    // if bash -c variant, we need to replace HOME with the environment
    // variable -- when quoted, Globus won't interpret $(VAR)
    boolean bashCommand = false;
    if ( executable.matches("\\/bin\\/b*a*sh") ) {
      for ( String arg : arguments ) {
        if ( arg.equals("-c") ) {
          bashCommand = true;
        }
      }
    }
    rsl.setExecutable( executable );
    for ( String arg : arguments ) {
      if ( bashCommand ) {
        rsl.addArgument( arg.replaceAll("\\$\\(HOME\\)", "\\${HOME}") );
      } else {
        rsl.addArgument( arg );
      }
    }
    // we need a gass server if stdin, stdout, or stderr need to be streamed
    if ( stdin != null || streamOutput ) {
      jobState.gassServer = new GassServer( this.credential, Globus.GASS_PORT );
    }
    // stdin needs to be passed in as a file
    if ( stdin != null ) {
      jobState.tempStdin = File.createTempFile
        ( "inca", "tmp", new File(tempDir) );
      try {
        Runtime.getRuntime().exec
          ( "chmod 600 " + jobState.tempStdin.getAbsolutePath() ).waitFor();
      } catch (InterruptedException e) {
        throw new IOException("Unable to change permissions on stdin file"+e);
      }
      FileWriter writer = new FileWriter( jobState.tempStdin );
      writer.write( stdin );
      writer.close();
    }
    // setup stdout and stderr streams
    if ( streamOutput ) {
      jobState.stdout = new GlobusOutputListener();
      JobOutputStream outStream = new JobOutputStream(jobState.stdout);
      jobState.gassServer.registerJobOutputStream("out-ap", outStream );
      jobState.stderr = new GlobusOutputListener();
      JobOutputStream errStream = new JobOutputStream(jobState.stderr);
      jobState.gassServer.registerJobOutputStream("err-ap", errStream );
    }

    if ( jobState.tempStdin != null ) {
      rsl.setStdin
        (jobState.gassServer.getURL()+"/"+jobState.tempStdin.getAbsolutePath());
    }
    if ( jobState.stdout != null ) {
      rsl.setStdout( jobState.gassServer.getURL() + "/dev/stdout-ap" );
    }
    if ( jobState.stderr != null ) {
      rsl.setStderr( jobState.gassServer.getURL() + "/dev/stderr-ap" );
    }
    String rslString = rsl.toRSL();
    if (dir != null) {
      // manually add directory arg because if contains $(HOME) will be quoted
      // by rsl.add function which means globus won't intrepret the value
      rslString +=  "(directory=" + dir + ")";
    }
    logger.info( "GRAM CONTACT = " + this );
    logger.debug( "RSL: " + rslString );
    jobState.job = new GramJob( this.credential, rslString );
  }

  /**
   * Check whether the remote process is alive.
   *
   * @return true if the remote process is alive; false otherwise.
   */
  public boolean isActive() {
    return activeJob != null &&
      activeJob.job.getStatus() == GramJob.STATUS_ACTIVE;
  }

  /**
   * Given a path relative to the home directory, prepend '$(HOME)/'
   * to the path and return the new string.
   *
   * @param path   A path relative to the user's home directory
   *
   * @return  A new string that contains '$(HOME)/' prepended to the
   * provided path.
   */
  public String prependHome( String path ) {
    return "$(HOME)/" + path;
  }
  
  /**
   * Execute the specified process on the remote resource.  This call will block
   * until the process has completed.
   *
   * @param executable Path to the remote executable.
   * @param arguments  Contains the arguments that should be passed to the
   *                   executable
   * @param stdin      A string that will be passedd in as stdin to the process
   *                   when it is started

   * @param directory  Path to the directory where the process will be executed
   *                   from
   * @return The stdout and stderr of the executed process in
   * RemoteProcessObject.
   *
   * @throws AccessMethodException if trouble running job
   * @throws InterruptedException if interrupted while running job
   */
  public AccessMethodOutput run ( String executable, String[] arguments,
                                  String stdin, String directory )
    throws AccessMethodException, InterruptedException {


    JobState jobState = new JobState();
    try {
      this.createJob( executable, arguments, directory, stdin, true, jobState );
    } catch ( Exception e ) {
      this.cleanup( jobState );
      throw new AccessMethodException
        ( "Globus remote run failed to create job", e );
    }

    // Submit request and error checking
    String errorMsg = "Globus call failed to " + this;
    try {
      jobState.job.request( this.toString(), false, false );
      logger.debug( "Waiting for Globus GRAM job to complete" );
      GlobusJobListener listener = new GlobusJobListener( true, jobState.job );
      jobState.job.addListener( listener );
      listener.waitFor();
      logger.debug( "Globus GRAM job completed" );
    } catch( InterruptedException e ) {
      throw e;
    } catch ( Exception e ) {
      logger.error( errorMsg, e );
      throw new AccessMethodException( errorMsg, e );
    } finally {
      this.cleanup( jobState );
    }
    if ( jobState.job.getStatus() != GRAMConstants.STATUS_DONE ) {
      int errorCode = jobState.job.getError();
      throw new AccessMethodException(errorMsg, new GramException( errorCode ) );
    }

    // return stdout and stderr
    AccessMethodOutput result = new AccessMethodOutput();
    result.setStdout( jobState.stdout.getOutput() );
    logger.debug( "STDOUT: " + result.getStdout() );
    result.setStderr( jobState.stderr.getOutput() );
    logger.debug( "STDERR: " + result.getStderr() );    
    return result;
  }

  /**
   * Start a process on a remote machine.  This is a non-blocking call.
   *
   * @param executable  Path to the remote executable.
   * @param arguments   Contains the arguments that should be passed to the
   *                    executable
   * @param stdin      A string that will be passedd in as stdin to the process
   *                   when it is started
   * @param directory  Path to the directory where the process will be executed
   *                   from
   */
  public void start( String executable, String[] arguments, String stdin,
                     String directory) throws AccessMethodException {

    if ( this.activeJob != null  ) {
      throw new AccessMethodException(
        "An existing job is already running; " +
          "only one process at a time currently supported"
      );
    }

    activeJob = new JobState();
    GlobusJobListener listener = new GlobusJobListener( false, activeJob.job );
    String errorMsg = "Globus call failed to " + this;
    try {
      this.createJob(executable, arguments, directory, stdin, false, activeJob);
      activeJob.job.addListener( listener );
      // Submit GRAM request and error checking
      activeJob.job.request( this.toString() );
      listener.waitFor();
    } catch ( Exception e ) {
      throw new AccessMethodException("Unable to start remote globus process",e);
    } finally {
      this.cleanup( activeJob );
    }
    if ( listener.isFailed() ) {
      throw new AccessMethodException(errorMsg+": "+activeJob.job.getError());
    }
  }

  /**
   * Kill the remote process that was started by the start() call.
   *
   * @throws AccessMethodException if unable to kill process
   */
  public void stop() throws AccessMethodException {
    try {
      if ( activeJob != null ) {
        activeJob.job.cancel();
      }
    } catch (Exception e) {
      throw new AccessMethodException( "Unable to cancel job", e );
    } finally {
      activeJob = null;
    }
  }

  /**
   * Return the contact string for this GRAM service
   *
   * @return  A string complying to host:port/service[:subject]
   */
  public String toString() {
    String contact = this.host + ":" + this.port + "/" + this.service;
    if ( this.dn != null ) {
      contact += ":" + this.dn;
    }
    return contact;
  }

}
