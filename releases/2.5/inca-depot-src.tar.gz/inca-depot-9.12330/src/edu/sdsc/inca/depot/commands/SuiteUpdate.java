package edu.sdsc.inca.depot.commands;

import edu.sdsc.inca.dataModel.suite.SuiteDocument;
import edu.sdsc.inca.depot.persistent.*;
import edu.sdsc.inca.depot.util.HibernateMessageHandler;
import edu.sdsc.inca.protocol.MessageHandler;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.protocol.Statement;
import org.apache.xmlbeans.XmlException;
import java.util.Iterator;

/**
 * @author cmills
 */
public class SuiteUpdate extends HibernateMessageHandler {

  public static final String ADD = "add";
  public static final String DELETE = "delete";

  public void executeHibernateAction(
    ProtocolReader reader, ProtocolWriter writer, String dn) throws Exception {
    Suite suite = null;
    SuiteDocument doc = null;
    try {
      String xml = new String(reader.readStatement().getData());
      doc = SuiteDocument.Factory.parse(xml);
      if(!doc.validate()) {
        throw new XmlException("Invalid suite XML '" + xml + "'");
      }
      suite = new Suite().fromBean(doc.getSuite());
    } catch(XmlException e) {
      throw new ProtocolException("Unable to parse suite XML: " + e);
    }
    if(!MessageHandler.isPermitted(dn, Protocol.SUITE_ACTION)) {
      throw new ProtocolException
        (Protocol.SUITE_ACTION + " not allowed by " + dn);
    }
    Suite dbSuite = SuiteDAO.loadOrSave(suite);
    dbSuite.incrementVersion();
    dbSuite.setDescription(suite.getDescription());
    // Perform the actions specified in the report series configs.  Note that
    // we have to iterate through the SeriesConfigs in the SuiteDocument,
    // rather than those in dbSuite, to preserve ordering.  The SeriesConfig
    // set in dbConfig is unordered.
    edu.sdsc.inca.dataModel.util.SeriesConfig[] configs =
      doc.getSuite().getSeriesConfigs().getSeriesConfigArray();
    for(int i = 0; i < configs.length; i++) {
      SeriesConfig config = new SeriesConfig().fromBean(configs[i]);
      SeriesConfig dbConfig = null;
      // If this is not a new suite, check to see if the DB version contains
      // an equivalent series.
      if(dbSuite != suite) {
        for(Iterator j = dbSuite.getSeriesConfigs().iterator(); j.hasNext(); ) {
          SeriesConfig existingConfig = (SeriesConfig)j.next();
          if(existingConfig.equals(config)) {
            dbConfig = existingConfig;
            break;
          }
        }
      }
      if(dbConfig == null) {
        if(DELETE.equals(config.getAction())) {
          logger.warn("No deletion match found for config " + config);
          // Note: even though we're deactivating the series, we'll add it to
          // the DB.  This might be useful for documentary purposes, and it
          // should be extremely rare in any case.
        }
        Series dbSeries = SeriesDAO.loadOrSave(config.getSeries());
        config.setSeries(dbSeries);
        dbSuite.addSeriesConfig(config);
        dbConfig = SeriesConfigDAO.loadOrSave(config);
      } else {
        if(ADD.equals(config.getAction()) &&
           dbConfig.getActivated() >= dbConfig.getDeactivated()) {
          logger.warn("Add of already-active config " + config);
        }
        dbConfig.setAcceptedOutput(config.getAcceptedOutput());
        dbConfig.setLimits(config.getLimits());
        dbConfig.setNickname(config.getNickname());
        dbConfig.setSchedule(config.getSchedule());
      }
      if(ADD.equals(config.getAction())) {
        dbConfig.setActivated(dbSuite.getVersion());
      } else if(DELETE.equals(config.getAction())) {
        dbConfig.setDeactivated(dbSuite.getVersion());
      }
      SeriesConfigDAO.update(dbConfig);
    }
    SuiteDAO.update(dbSuite);
    writer.write(Statement.getOkStatement(dbSuite.getVersion() + ""));
  }

}
