package edu.sdsc.inca.depot.commands;

import edu.sdsc.inca.dataModel.graphSeries.GraphInstance;
import edu.sdsc.inca.dataModel.graphSeries.GraphSeries;
import edu.sdsc.inca.dataModel.reportDetails.ReportDetailsDocument;
import edu.sdsc.inca.dataModel.util.AnyXmlSequence;
import edu.sdsc.inca.dataModel.util.Log;
import edu.sdsc.inca.dataModel.util.ReportDetails;
import edu.sdsc.inca.depot.persistent.*;
import edu.sdsc.inca.depot.util.HibernateMessageHandler;
import edu.sdsc.inca.protocol.*;
import edu.sdsc.inca.queryResult.ReportSummaryDocument;
import edu.sdsc.inca.util.StringMethods;
import edu.sdsc.inca.util.XmlWrapper;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;
import org.hibernate.Session;
import org.hibernate.metadata.ClassMetadata;
import org.perf4j.StopWatch;
import org.perf4j.log4j.Log4JStopWatch;

/**
 */
public class Query extends HibernateMessageHandler {

  private static Logger logger = Logger.getLogger(Query.class);
  private static final Statement S_FINISH =
    new Statement(Protocol.END_QUERY_RESULTS_COMMAND.toCharArray(), null);

  /**
   * Execute queries on the depot.
   *
   * @param reader   Reader to the query request.
   * @param writer   Writer to the remote process making the request.
   * @throws Exception
   */
  public void executeHibernateAction(
    ProtocolReader reader, ProtocolWriter writer, String dn) throws Exception {

    Statement queryStatement = reader.readStatement();
    String cmd = new String(queryStatement.getCmd());
    String data = new String(queryStatement.getData());
    StopWatch timer = new Log4JStopWatch(logger);
    try {
      if(cmd.equals(Protocol.QUERY_DB_COMMAND)) {
        getDbInfo(writer);
      } else if(cmd.equals(Protocol.QUERY_GUIDS_COMMAND)) {
        getGuidList(writer);
      } else if(cmd.equals(Protocol.QUERY_HQL_COMMAND)) {
        getSelectOutput(writer, data, true);
        writer.write(S_FINISH);
      } else if(cmd.equals(Protocol.QUERY_INSTANCE_COMMAND)) {
        getInstance(writer, data);
        writer.write(S_FINISH);
      } else if(cmd.equals(Protocol.QUERY_LATEST_COMMAND)) {
        getLatestInstances(writer, data);
        writer.write(S_FINISH);
      } else if(cmd.equals(Protocol.QUERY_PERIOD_COMMAND)) {
        getPeriodInstances(writer, data);
        writer.write(S_FINISH);
      } else if(cmd.equals(Protocol.QUERY_SQL_COMMAND)) {
        getSelectOutput(writer, data, false);
        writer.write(S_FINISH);
      } else if(cmd.equals(Protocol.QUERY_STATUS_COMMAND)) {
        getStatusHistory(writer, data);
        writer.write(S_FINISH);
      }
      timer.stop( cmd );
    } catch(Exception e) {
      e.printStackTrace();
      throw e;
    }

  }

  /**
   * Return XML that represents the structure of the database.
   *
   * @param writer Writer to the remote process making the request
   *
   * @throws Exception if trouble querying the database
   */
  private void getDbInfo(ProtocolWriter writer) throws Exception {
    StringBuffer response = new StringBuffer("<incadb>\n");
    Map<?, ?> metadata = HibernateUtil.getSessionFactory().getAllClassMetadata();
    for( Object obj : metadata.keySet() ) {
      String name = (String)obj;
      response.append("  <dbclass>\n    <name>");
      response.append(name.replaceAll(".*\\.", ""));
      response.append("</name>\n");
      String[] properties =
        ((ClassMetadata)metadata.get(name)).getPropertyNames();
      for(String field : properties ) {
        // For client convenience, lie about how the Report body is stored
        if(field.equals("bodypart1")) {
          field = "body";
        } else if(field.equals("bodypart2") || field.equals("bodypart3")) {
          continue;
        }
        response.append("    <field>\n      <name>");
        response.append(field);
        response.append("</name>\n    </field>\n");
      }
      response.append("  </dbclass>\n");
    }
    response.append("</incadb>");
    writer.write(Statement.getOkStatement(response.toString()));
  }

  /**
   * Return a list of the Suite guids in the database.
   *
   * @param writer Writer to the remote process making the request
   * @throws Exception if trouble querying the database or writing result
   */
  private void getGuidList(ProtocolWriter writer) throws Exception {
    List<?> guids = DAO.selectMultiple("select s.guid from Suite as s", null);
    String[] result = new String[guids.size()];
    for(int i = 0; i < result.length; i++) {
      result[i] = (String)guids.get(i);
    }
    writer.write(Statement.getOkStatement(StringMethods.join("\n", result)));
  }

  /**
   * Return a report details document to the client for the given report
   * instance and configuration.
   *
   * @param writer  Writer to the remote process making the request.
   * @param request The instance query request which contains the
   * instance id, followed by a space, and then the report series configuration
   * id.
   *
   * @throws Exception if trouble querying the database or writing result
   */
  private void getInstance(ProtocolWriter writer, String request)
    throws Exception {
    String[] pieces = request.split(" ");
    Long instanceId, configId;
    if(pieces.length != 2) {
      throw new ProtocolException
        ("Expected 'instanceId configId', got '" + request + "'");
    }
    try {
      instanceId = Long.valueOf(pieces[0]);
      configId = Long.valueOf(pieces[1]);
    } catch(NumberFormatException e) {
      throw new ProtocolException("Non-numeric id in '" + request + "'");
    }
    SeriesConfig sc = SeriesConfigDAO.load(configId);
    InstanceInfo ii = InstanceInfoDAO.load(instanceId);
    if(sc == null) {
      throw new PersistenceException("Request for unknown config " + configId);
    } else if(ii == null) {
      throw new PersistenceException
        ("Request for unknown instance " + instanceId);
    }
    Report r = ReportDAO.load(ii.getReportId());
    String query = "select cr from ComparisonResult cr " +
                   "  where cr.reportId = " + r.getId() +
                   "  and cr.seriesConfigId = " + configId;
    ComparisonResult cr = (ComparisonResult)DAO.selectUnique(query, null);
    ReportDetailsDocument rdd = toBean(sc, r, ii, cr);
    String response = rdd.toString();
    writer.write(new Statement(Protocol.QUERY_RESULT, response));
  }

  /**
   * Return the output from an HQL/SQL query.
   *
   * @param writer  writer to the remote process making the request.
   * @param select the HQL/SQL select statement
   * @param isHql indicates whether the select is HQL or SQL
   * @throws Exception if trouble running query
   */
  private void getSelectOutput
    (ProtocolWriter writer, String select, boolean isHql) throws Exception {
    // Allow only query HQL/SQL, to avoid a client modifying tables
    if(!select.matches("(?i)^\\s*(SELECT|FROM)\\s.*$")) {
      throw new PersistenceException("Not a SELECT: " + select);
    }
    // Parse the column names from the select statement so that we can use them
    // as XML tags in the reply.  A token is a quoted literal, a name/number, a
    // paren, comma, or operator.  Take care not to treat comma in a function
    // invocation (e.g., concat(a,b) as terminating a column name.
    ArrayList<String> names = new ArrayList<String>();
    Matcher m = Pattern.compile
      ("('[^']*'|\"[^\"]\"|[\\w\\.\\-]+|[\\(\\),]|[^\\w\\(\\),]+)\\s*").
      matcher(select.replaceFirst("(?i)^SELECT\\s+(DISTINCT\\s+)?", ""));
    int parenDepth = 0;
    String name = "";
    while(true) {
      m.find();
      String token = m.group(1);
      if(parenDepth == 0 && token.matches("(?i)as")) {
        name = ""; // Use the subsequent AS name as the entire name
      } else if(parenDepth == 0 && (token.matches("(?i),|FROM"))) {
        name = name.replaceAll("[^\\w\\.\\-]", "_");
        names.add(name);
        name = "";
        if(!token.equals(",")) {
          break;
        }
      } else {
        name += token;
        if(token.equals("(")) {
          parenDepth++;
        } else if(token.equals(")")) {
          parenDepth--;
        }
      }
    }
    // For client convenience, automatic translate references to report body
    // into bodypart1||bodypart2||bodypart3
    select = select.replaceFirst("\\b[aA][sS]\\s+body\\b", "as xBODYx");
    while(true) {
      m = (Pattern.compile("\\b((\\w+)\\.)?body\\b")).matcher(select);
      if(!m.find()) {
        break;
      }
      String prefix = m.group(1) == null ? "" : m.group(1);
      select = select.substring(0, m.start()) +
               prefix + "bodypart1 || " +
               prefix + "bodypart2 || " +
               prefix + "bodypart3" +
               select.substring(m.end());
    }
    select = select.replaceFirst("xBODYx", "body");
    // Make the query
    Session session = HibernateUtil.getCurrentSession();
    List<?> l;
    try {
      l = isHql ? session.createQuery(select).list() :
                  session.createSQLQuery(select).list();
    } catch(Exception e) {
      e.printStackTrace();
      throw new PersistenceException(e.toString());
    }
    // Send one response per row.  If the row is a PersistentObject (e.g.,
    // "select sc from SeriesConfig sc", then we can use its toXml() method to
    // translate it; otherwise, we'll have an object array which we'll
    // translate to XML using the parsed names above.
    for( Object o : l ) {
      String xml;
      if(o instanceof PersistentObject) {
        xml = ((PersistentObject)o).toXml();
      } else {
        StringBuffer sb = new StringBuffer();
        Object[] values;
        try {
          values = (Object [])o;
        } catch(Exception e) {
          values = new Object[] {o};
        }
        sb.append("<object>\n");
        for(int j = 0; j < values.length; j++) {
          name = names.get(j) == null ? j + "" : names.get(j);
          Object value = values[j];
          String s = value == null ? "null" :
            value instanceof PersistentObject?((PersistentObject)value).toXml():
            XmlWrapper.escape( value.toString() );
          sb.append("<");
          sb.append(name);
          sb.append(">");
          sb.append(s);
          sb.append("</");
          sb.append(name);
          sb.append(">\n");
        }
        sb.append("</object>");
        xml = sb.toString();
      }
      writer.write(new Statement(Protocol.QUERY_RESULT, xml));
    }
  }

  /**
   * Return the latest report summaries for all series selected by an HQL
   * WHERE clause expression.
   *
   * @param writer  Writer to the remote process making the request.
   * @param expr An HQL WHERE clause expression specifying the series of
   *             interest
   * @throws Exception if trouble running query
   */
  private void getLatestInstances(ProtocolWriter writer, String expr)
    throws Exception {

    List<?> scList = getSelectedConfigs(expr);
    StringBuffer crIds = new StringBuffer();
    StringBuffer iiIds = new StringBuffer();
    for( Object obj : scList ) {
      SeriesConfig config = (SeriesConfig)obj;
      Long crId = config.getLatestComparisonId();
      Long iiId = config.getLatestInstanceId();
      if(crId != null && crId >= 0) {
        crIds.append(crId.toString());
        crIds.append(",");
      }
      if(iiId != null && iiId >= 0) {
        iiIds.append(iiId.toString());
        iiIds.append(",");
      }
    }
    Hashtable<Long,ComparisonResult> crsById = new Hashtable<Long,ComparisonResult>();
    if(crIds.length() > 0) {
      crIds.deleteCharAt(crIds.length() - 1); // Trim trailing ,
      String query =
        "SELECT cr FROM ComparisonResult cr WHERE cr.id IN (" + crIds + ")";
      List<?> crList = DAO.selectMultiple(query, null);
      for( Object obj : crList ) {
        ComparisonResult cr = (ComparisonResult)obj;
        crsById.put(cr.getId(), cr);
      }
    }
    Hashtable<Long,InstanceInfo> iisById = new Hashtable<Long,InstanceInfo>();
    Hashtable<Long,Report> reportsById = new Hashtable<Long,Report>();
    if(iiIds.length() > 0) {
      iiIds.deleteCharAt(iiIds.length() - 1); // Trim trailing ,
      String query = "SELECT ii, r " +
                     "FROM InstanceInfo ii, Report r " +
                     "WHERE ii.id IN (" + iiIds + ") " +
                     "AND r.id = ii.reportId";
      List<?> iiList = DAO.selectMultiple(query, null);
      for( Object obj : iiList ) {
        Object[] row = (Object [])obj;
        InstanceInfo ii = (InstanceInfo)row[0];
        Report r = (Report)row[1];
        iisById.put(ii.getId(), ii);
        reportsById.put(r.getId(), r);
      }
    }
    // Loop through each item in the sc list and turn it into a BasicResult.
    Statement reply = new Statement(Protocol.QUERY_RESULT, null);
    for( Object obj : scList ) {
      SeriesConfig sc = (SeriesConfig)obj;
      ComparisonResult cr = null;
      InstanceInfo ii = null;
      Report r = null;
      Long id = sc.getLatestInstanceId();
      if(id != null && id >= 0) {
        ii = iisById.get(id);
      }
      if(ii == null) {
        logger.debug("No latest instance for SC " + sc);
      }
      id = ii == null ? null : ii.getReportId();
      if(id != null && id >= 0) {
        r = reportsById.get(id);
      }
      if(r == null) {
        logger.debug("No latest report for SC " + sc);
      }
      id = sc.getLatestComparisonId();
      if(id != null && id >= 0) {
        cr = crsById.get(id);
      }
      if(cr == null) {
        logger.debug("No latest comparison for SC " + sc);
      }
      ReportSummaryDocument rsd = toBean(sc, cr, ii, r);
      String s = rsd.toString();
      reply.setData(s.toCharArray());
      writer.write(reply);
    }
  }

  /**
   * Return the a set of GraphInstances for all series selected by an HQL
   * WHERE clause expression.
   *
   * @param writer  Writer to the remote process making the request.
   * @param request a space-separated string specifying the beginning and
   *        ending timestamps and an HQL WHERE clause expression that selects
   *        the desired series.
   * @throws Exception if trouble querying database
   */
  private void getPeriodInstances(ProtocolWriter writer, String request)
    throws Exception {

    // Parse the request
    String[] pieces = request.split(" ", 3);
    if(pieces.length != 3) {
      throw new ProtocolException
        ("Expected 'begin end expr', got '" + request + "'");
    }
    long begin, end;
    if(pieces[0].matches("^\\d+$")) {
      begin = Long.parseLong(pieces[0]);
    } else {
      throw new ProtocolException("Bad value '" + pieces[0] + "' for begin");
    }
    if(pieces[1].matches("^\\d+$")) {
      end = Long.parseLong(pieces[1]);
    } else {
      throw new ProtocolException("Bad value '" + pieces[1] + "' for end");
    }

    // Get the complete list of SeriesConfigs to report.
    List<?> scList = getSelectedConfigs(pieces[2]);
    if(scList.size() == 0) {
      return;
    }

    // Return each in-range instance for each series
    Statement reply = new Statement(Protocol.QUERY_RESULT, null);
    for(int i = 0; i < scList.size(); i++) {
      SeriesConfig sc = (SeriesConfig)scList.get(i);

      HashMap<Long,HashMap> reports = new HashMap<Long,HashMap>();
      HashMap[] instances = getReportsInstances
        (begin, end, new String[]{sc.getSeries().getId().toString()},
          new String[]{"exit_status", "exit_message"}, new String[]{"id", "collected"},
          reports);
      if(instances.length == 0) {
        continue; // No reports for this series
      }
      Hashtable<Long,String> crList = getRelatedComparisons(scList, i, i + 1);

      for( HashMap ii : instances ) {
        long reportId = (Long)ii.get( "reportId" );
        HashMap r = reports.get( reportId );
        String cr = crList.get(reportId);

        GraphSeries gs = GraphSeries.Factory.newInstance();
        GraphInstance gi = gs.addNewObject();
        gi.setResource(sc.getSeries().getResource());
        gi.setNickname(sc.getNickname());
        gi.setInstanceId(ii.get("id").toString());
        gi.setReportId(Long.toString(reportId));
        gi.setConfigId(sc.getId().toString());
        Date collected = StringMethods.convertDateString
          (ii.get("collected").toString(), "yyyy-MM-dd HH:mm:ss.S");
        Calendar cal = Calendar.getInstance();
        cal.setTime(collected);
        gi.setCollected(cal);
        String message = r.get("exit_message").toString();
        boolean success =
          cr == null || cr.equals("\t") ? (Boolean)r.get("exit_status") :
                                           cr.matches("^Success");
        gi.setExitStatus(success ? "Success" : "Failure");
        gi.setExitMessage(message == null ? "" : message);
        gi.setComparisonResult(cr == null ? "" : cr);

        reply.setData(gs.xmlText().toCharArray());
        writer.write(reply);
      }
    }
  }

  private static final int SERIES_PER_BATCH = 5;
  /**
   * Return the success/failure counts over a given period for all series in a
   * given newline-delimited list of suites and/or series.
   *
   * @param writer  Writer to the remote process making the request.
   * @param request a space-separated string specifying the period length,
   *   beginning and ending timestamps, and an HQL WHERE clause expression
   *   that selects the desired series.
   * @throws Exception if trouble retrieving results
   *
   */
  private void getStatusHistory(ProtocolWriter writer, String request)
    throws Exception {

    // Parse the request
    String[] pieces = request.split(" ", 4);
    if(pieces.length != 4) {
      throw new ProtocolException
        ("Expected 'period begin end expr', got '" + request + "'");
    }
    long periodInMillis, begin, end;
    if(pieces[0].equals("DAY")) {
      periodInMillis = 24L * 60L * 60L * 1000L;
    } else if(pieces[0].equals("WEEK")) {
      periodInMillis = 7L * 24L * 60L * 60L * 1000L;
    } else if(pieces[0].equals("MONTH")) {
      periodInMillis = 30L * 24L * 60L * 60L * 1000L;
    } else if(pieces[0].equals("QUARTER")) {
      periodInMillis = 90L * 24L * 60L * 60L * 1000L;
    } else if(pieces[0].matches("^\\d+$")) {
      periodInMillis = Long.parseLong(pieces[0]) * 60L * 1000L;
    } else {
      throw new ProtocolException("Bad value '" + pieces[0] + "' for period");
    }
    if(pieces[1].matches("^\\d+$")) {
      begin = Long.parseLong(pieces[1]);
    } else {
      throw new ProtocolException("Bad value '" + pieces[1] + "' for begin");
    }
    if(pieces[2].matches("^\\d+$")) {
      end = Long.parseLong(pieces[2]);
    } else {
      throw new ProtocolException("Bad value '" + pieces[2] + "' for end");
    }

    // Get the complete list of SeriesConfigs to report.
    List<?> scList = getSelectedConfigs(pieces[3]);

    // Construct a separate query result for each SeriesConfig, processing them
    // in batches for efficiency
    Statement reply = new Statement(Protocol.QUERY_RESULT, null);

    for(int i = 0; i < scList.size(); i += SERIES_PER_BATCH) {
      float startMem = Runtime.getRuntime().totalMemory() / (1024 * 1024);

      int last = Math.min(i + SERIES_PER_BATCH , scList.size());
      // process series in batches to make it quicker
      String[] seriesIds = new String[SERIES_PER_BATCH];
      for(int j = 0; j < SERIES_PER_BATCH && i + j < scList.size(); j++) {
        seriesIds[j] = (((SeriesConfig)scList.get(i + j))
                       .getSeries().getId().toString());
      }

      // Retrieve fields from associated ComparisonResults
      Hashtable<Long,String> crResultsByReportId=getRelatedComparisons
        ( scList, i, last );

      // retrieve Reports, and InstanceInfos that fall w/in the specified time
      HashMap<Long,HashMap> reports = new HashMap<Long,HashMap>();
      HashMap[] instances = getReportsInstances
        (begin, end, seriesIds,
          new String[]{ "exit_message", "series.id"}, new String[]{"collected"},
          reports);

      // Construct the return XML for each SeriesConfig
      for(int j = 0; j < SERIES_PER_BATCH && i + j < scList.size(); j++) {
        SeriesConfig sc = (SeriesConfig)scList.get(i + j);

        Series series = sc.getSeries();
        StringBuffer xml = new StringBuffer();
        Long count;
        xml.append("<series>\n");
        xml.append("  <guid>");
        xml.append(sc.getSuite().getGuid());
        xml.append("</guid>\n");
        xml.append("  <nickname>");
        xml.append(sc.getNickname());
        xml.append("</nickname>\n");
        xml.append("  <resource>");
        xml.append(series.getResource());
        xml.append("</resource>\n");
        // For each period, from least recent to most recent ...
        for(long lowBound=begin; lowBound<=end; lowBound+=periodInMillis) {

          Hashtable<String,Long> messageCounts = new Hashtable<String,Long>();
          long highBound = lowBound + periodInMillis - 1;

          // Count the occurences for each message associated with the instances
          // that fall w/in this period, if any
          for( HashMap ii : instances ) {
            Long reportId = (Long) ii.get("reportId");
            Date collected = (Date) ii.get("collected");
            if(collected.getTime()<lowBound || collected.getTime()>highBound) {
              continue;
            }
            if(!reports.get(reportId).get("series.id").equals(series.getId())) {
              continue;
            }
            String message = (String) reports.get(reportId).get("exit_message");
            if(message == null) {
              message = crResultsByReportId.get(reportId);
            }
            count = messageCounts.get(message);
            count = (count == null ? 0 : count) + 1;
            messageCounts.put(message, count);
          }

          // Add XML for the successes and failures in this period
          xml.append("  <period>\n");
          xml.append("    <begin>");
          xml.append(lowBound);
          xml.append("</begin>\n");
          xml.append("    <end>");
          xml.append(highBound);
          xml.append("</end>\n");
          long successes = 0;
          count = messageCounts.get("Success");
          if(count != null) {
            messageCounts.remove("Success");
            successes += count;
          }
          count = messageCounts.get(PersistentObject.DB_EMPTY_STRING);
          if(count != null) {
            messageCounts.remove(PersistentObject.DB_EMPTY_STRING);
            successes += count;
          }
          xml.append("    <success>");
          xml.append(successes);
          xml.append("</success>\n");
          for(Enumeration<String> e = messageCounts.keys(); e.hasMoreElements(); ) {
            String message = e.nextElement();
            xml.append("    <failure><message>");
            xml.append(XmlWrapper.escape(message));
            xml.append("</message><count>");
            xml.append(messageCounts.get(message));
            xml.append("</count></failure>\n");
          }
          xml.append("  </period>\n" );
        }

        // Send the reply
        xml.append("</series>");
        reply.setData(xml.toString().toCharArray());
        writer.write(reply);
      }
      float mem = Runtime.getRuntime().totalMemory() / (1024 * 1024);
      logger.debug("gSH: ("+i+") mem=" + mem + "MB, memDiff="+(mem-startMem));
    }
  }

  /**
   * Creates a ReportDetailsDocument by copying fields from a DB SeriesConfig,
   * a DB report, and a DB InstanceInfo.
   *
   * @param sc the SeriesConfig for the document
   * @param r the Report for the document
   * @param ii the latest InstanceInfo for the document
   * @param cr the latest ComparisonResult for the document
   *
   * @return report details document object
   */
  protected static ReportDetailsDocument toBean
    (SeriesConfig sc, Report r, InstanceInfo ii, ComparisonResult cr) {
    ReportDetailsDocument result =
      ReportDetailsDocument.Factory.newInstance();
    ReportDetails rd = result.addNewReportDetails();
    rd.setSuiteId(sc.getSuite().getId());
    rd.setSeriesConfigId(sc.getId());
    rd.setSeriesId(r.getSeries().getId());
    rd.setReportId(r.getId());
    rd.setInstanceId(ii.getId());
    rd.setSeriesConfig((edu.sdsc.inca.dataModel.util.SeriesConfig)sc.toBean());
    rd.setReport((edu.sdsc.inca.dataModel.util.Report)r.toBean());
    // Note: apparently getGmt() returns a copy, so the following doesn't work
    //rd.getReport().getGmt().setTime(ii.getCollected());
    GregorianCalendar gmt = new GregorianCalendar();
    gmt.setTime(ii.getCollected());
    rd.getReport().setGmt(gmt);
    String log = ii.getLog();
    if(log != null && !log.equals("") &&
      !log.equals(PersistentObject.DB_EMPTY_STRING)) {
      try {
        rd.getReport().setLog(Log.Factory.parse(log));
      } catch(Exception e) {
        logger.error("Unable to parse log stored in DB:", e);
      }
    }
    if(cr != null) {
      rd.setComparisonResult(cr.getResult());
    }
    rd.setSysusage((edu.sdsc.inca.dataModel.util.Limits)ii.toBean());
    rd.setStderr(r.getStderr());
    return result;
  }

  /**
   * Creates a ReportSummaryDocument by copying fields from a DB SeriesConfig.
   *
   * @param sc the SeriesConfig for the document
   * @param cr the latest comparison result for sc
   * @param ii the latest instance info for sc
   * @param r the latest report for sc
   *
   * @return report summary document
   */
  protected static ReportSummaryDocument toBean
    (SeriesConfig sc, ComparisonResult cr, InstanceInfo ii, Report r)
     {
    ReportSummaryDocument result = ReportSummaryDocument.Factory.newInstance();
    ReportSummaryDocument.ReportSummary summary = result.addNewReportSummary();
    Series s = sc.getSeries();
    summary.setHostname(s.getResource());
    summary.setUri(s.getUri());
    summary.setNickname(sc.getNickname());
    summary.setSeriesConfigId(sc.getId());
    if(ii != null) {
      summary.setInstanceId(ii.getId());
      GregorianCalendar gmt = new GregorianCalendar();
      gmt.setTime(ii.getCollected());
      summary.setGmt(gmt);
      Schedule sched = sc.getSchedule();
      if(sched != null) {
        // Note that the instance expires two cycles after it was collected
        Date expires = sched.nextEvent(ii.getCollected());
        if(expires != null) {
          expires = sched.nextEvent(expires);
        }
        if(expires != null) {
          GregorianCalendar gmtExpires = new GregorianCalendar();
          gmtExpires.setTime(expires);
          summary.setGmtExpires(gmtExpires);
        }
      }
    }
    if(r != null) {
      String bodyText = r.getBody();
      try {
        summary.setBody(AnyXmlSequence.Factory.parse(bodyText));
      } catch(XmlException e) {
        // empty
      }
      summary.setErrorMessage(r.getExit_message());
    }
    if(cr != null) {
      summary.setComparisonResult(cr.getResult());
    }
    return result;
  }

  /**
   * Returns a list of ComparisonResult objects generated by a given set of
   * SeriesConfig objects.
   *
   * @param configList a list of SeriesConfig objects of interest
   * @param first the index of the first element of configList of interest
   * @param last the index + 1 of the last element of configList of interest
   *
   * @return hashtable where the keys are report ids and the values are the
   *         result
   *
   * @throws PersistenceException on DB error
   */
  protected Hashtable<Long,String> getRelatedComparisons(List configList, int first, int last)
    throws PersistenceException {

    StopWatch timer = new Log4JStopWatch(logger);
    if(configList.size() == 0) {
      return new Hashtable<Long,String>();
    }
    // create query
    StringBuffer configIdList = new StringBuffer();
    for(int i = first; i < last; i++) {
      configIdList.append(((SeriesConfig)configList.get(i)).getId().toString());
      configIdList.append(",");
    }
    configIdList.deleteCharAt(configIdList.length() - 1); // trim trailing ,
    String query = "SELECT cr.reportId, cr.result FROM ComparisonResult cr " +
      "WHERE cr.seriesConfigId IN (" + configIdList + ")";
    // execute query and parse results
    List crList = DAO.selectMultiple(query, null);
    Hashtable<Long,String> crResultsByReportId = new Hashtable<Long,String>();
    for( Object obj : crList ) {
      Object[] info = (Object[])obj;
      crResultsByReportId.put( (Long)info[0], (String)info[1] );
    }
    timer.lap("getRelatedComparisons", "numCRs=" + crResultsByReportId.size());
    return crResultsByReportId;
  }

  /**
   * Return the related instances for the provided reports within a specified
   * time interval
   *
   * @param fields  return selected instanceinfo fields only; if null will
   *                return the whole object
   * @param beginTime  the begin time expressed as milliseconds
   * @param endTime    the end time expressed as milliseconds
   * @param reportIds a list of report ids for which we need to fetch instances
   *
   * @return the results expressed as a list of object arrays
   *
   * @throws PersistenceException if trouble executing query
   */
  protected List getRelatedInstances( String[] fields, Long[] reportIds,
                                      long beginTime, long endTime )
    throws PersistenceException {

    List iiList;
    if( reportIds.length == 0 ) {
      iiList = new ArrayList();
    } else {
      String select = "ii";
      if( fields != null && fields.length > 0 ) {
        StringBuffer selectBuffer = new StringBuffer();
        for( String field : fields ) {
          selectBuffer.append("ii.");
          selectBuffer.append(field);
          selectBuffer.append(",");
        }
        selectBuffer.deleteCharAt(selectBuffer.length() - 1); // Trim trailing ,
        select = selectBuffer.toString();
      }
      String query = "SELECT " + select + " " +
                     "FROM InstanceInfo ii " +
                     "WHERE ii.collected >= :p0 AND ii.collected <= :p1 ";
      if ( reportIds.length == 1 ) {
        query += "AND ii.reportId = " + reportIds[0];
      } else {
        StringBuffer reportList = new StringBuffer();
        for( long id : reportIds ) {
          reportList.append(id);
          reportList.append(",");
        }
        reportList.deleteCharAt(reportList.length() - 1); // Trim trailing ,
        query += "AND ii.reportId IN (" + reportList + ") ";
      }
      query += " ORDER BY ii.collected";
      iiList = DAO.selectMultiple
        ( query, new Object[]{new Date(beginTime), new Date(endTime)} );
    }
    return iiList;
  }

  /**
   * Return the report count for the listed series
   *
   * @param seriesIds  An array of series ids
   *
   * @return  The report count for the selected series
   *
   * @throws PersistenceException if trouble querying
   */
  protected long getReportCount( String[] seriesIds ) throws PersistenceException {

    StopWatch timer = new Log4JStopWatch(logger);
    String query =
      "SELECT count(r.id) " +
      "FROM Report r " +
      "WHERE r.series.id IN (" + StringMethods.join( ",", seriesIds) + ")";
    Object o = DAO.selectUnique(query, null);
    Long numReports = Long.valueOf( o.toString() );
    timer.stop( "getReportCount", numReports.toString() );
    return numReports;
  }

  /**
   * Retrieve a set of instances and related reports for the specified series
   * ids within the specified range using the most efficient method based on the
   * number of unique reports there are.  By default, if there are more than
   * 100 reports, a join is used.  If there are 100 or less reports, an IN
   * clause is used which is more efficient than a join.  Set system property
   * inca.depot.join to set the join value to something other than 100.
   *
   * @param beginTime The beginning of range specified in milliseconds
   * @param endTime   The end of range specified in milliseconds
   * @param seriesIds The set of series to return reports/instances
   * @param queryReportFields Specific report fields to return (less is better)
   * @param queryInstanceFields  Specific instance fields to return (reportId
   *                             gets added automatically; less fields is better)
   * @param returnReports An empty hash array where report results can be stored
   *
   * @return An array of HashMaps where each HashMap contains the instance
   * fields results plus reportId.
   *
   * @throws PersistenceException if unable to query
   */
  protected HashMap[] getReportsInstances(
    long beginTime, long endTime, String[] seriesIds,
    String[] queryReportFields, String[] queryInstanceFields,
    HashMap<Long,HashMap> returnReports)

    throws PersistenceException {

    if ( seriesIds == null || seriesIds.length == 0 ) {
      logger.warn( "No series ids found" );
      return new HashMap[0];
    }

    int joinThreshold = 100;
    String thresholdProp = System.getProperty("inca.depot.join");
    if(thresholdProp != null) {
      try {
        joinThreshold = Integer.parseInt(thresholdProp);
      } catch(Exception e) {
        logger.warn("Invalid threshold value '" + thresholdProp + "'");
      }
    }

    long reportCount = getReportCount(seriesIds);

    // get results based on either join or IN method
    StopWatch timer = new Log4JStopWatch(logger);
    HashMap<String,Object>[] returnInstances;
    if( reportCount > joinThreshold) {
      StringBuffer selectFields = new StringBuffer();
      for( String reportField : queryReportFields ) {
        selectFields.append("r.");
        selectFields.append(reportField);
        selectFields.append(",");
      }
      for( String instanceField : queryInstanceFields ) {
        selectFields.append("ii.");
        selectFields.append(instanceField);
        selectFields.append(",");
      }
      selectFields.deleteCharAt(selectFields.length()-1); // remove tail ,
      String query =
        "SELECT r.id, " + selectFields + " " +
        "FROM Report r, InstanceInfo ii " +
        "WHERE ii.reportId = r.id " +
        "  AND ii.collected >= :p0 AND ii.collected <= :p1 ";
      if ( seriesIds.length == 1 ) {
        query += "AND r.series.id = " + seriesIds[0];
      } else {
        query += "AND r.series.id IN ("+StringMethods.join(",", seriesIds)+")";
      }
      List reportInstanceList = DAO.selectMultiple
        ( query, new Date[] { new Date(beginTime), new Date(endTime) });
      returnInstances = new HashMap[reportInstanceList.size()];
      for(int j = 0; j < reportInstanceList.size(); j++) {
        Object info[] = (Object[])reportInstanceList.get(j);
        // add report fields and values to a hashmap and store in reportResults
        HashMap<String,Object> reportResults = new HashMap<String,Object>();
        Long reportId = (Long)info[0];
        for( int k = 1; k < queryReportFields.length+1; k++ ) {
          reportResults.put( queryReportFields[k-1], info[k] );
        }
        returnReports.put( reportId, reportResults );
        // create a new hashmap and store the instance fields and values
        returnInstances[j] = new HashMap<String,Object>();
        returnInstances[j].put( "reportId", reportId );
        for( int k = queryReportFields.length+1, l=0;
             k < queryReportFields.length+1 + queryInstanceFields.length; l++, k++ ) {
          returnInstances[j].put( queryInstanceFields[l], info[k] );
        }
      }
      timer.lap( "getReportInstances.join",
                 "numReports=" + returnReports.size() + ", " +
                 "numInstances=" + returnInstances.length );
    } else {
      // get reports using a IN and then get instances using IN
      StringBuffer selectFields = new StringBuffer();
      for( String reportField : queryReportFields ) {
        selectFields.append("r.");
        selectFields.append(reportField);
        selectFields.append(",");
      }
      selectFields.deleteCharAt(selectFields.length()-1); // remove tail ,
      String query = "SELECT r.id, " + selectFields + " " +
                     "FROM Report r ";
      if ( seriesIds.length == 1 ) {
        query += "WHERE r.series.id = " + seriesIds[0];
      } else {
        query += "WHERE r.series.id IN ("+StringMethods.join(",",seriesIds)+")";
      }
      List reportList = DAO.selectMultiple(query, null);

      for( Object obj : reportList ) {
        HashMap<String,Object> reportResults = new HashMap<String,Object>();
        Object info[] = (Object[])obj;
        Long reportId = (Long)info[0];
        for( int k = 1; k < queryReportFields.length+1; k++ ) {
          reportResults.put( queryReportFields[k-1], info[k] );
        }
        returnReports.put( reportId, reportResults );
      }
      timer.lap
        ( "getReportInstances.report", "numReports=" + returnReports.size() );

      Long[] reportIds = returnReports.keySet().toArray( new Long[returnReports.size()] );
      String[] select = new String[queryInstanceFields.length+1];
      select[0] = "reportId";
      System.arraycopy(queryInstanceFields, 0, select, 1, queryInstanceFields.length);
      List iiList = getRelatedInstances(select, reportIds, beginTime, endTime);
      returnInstances = new HashMap[iiList.size()];
      for( int i = 0; i < iiList.size(); i++ ) {
        returnInstances[i] = new HashMap();
        Object info[] = (Object[])iiList.get(i);
        Long reportId = (Long)info[0];
        returnInstances[i].put( "reportId", reportId );
        for( int j = 1; j < queryInstanceFields.length+1; j++ ) {
          returnInstances[i].put( queryInstanceFields[j-1], info[j] );
        }
      }
      timer.lap("getReportInstances.instance", "numInstances=" + iiList.size());
    }
    return returnInstances;
  }

  /**
   * Returns a list of SeriesConfig objects selected by a WHERE expression.
   *
   * @param expr the HQL WHERE clause to select objects of interest
   *
   * @return list of active series configs that match the expression
   *
   * @throws PersistenceException on DB error
   */
  protected List<?> getSelectedConfigs(String expr) throws PersistenceException {
    StopWatch timer = new Log4JStopWatch(logger);
    String query =
      "SELECT config " +
        "FROM Suite suite, SeriesConfig config, Series series " +
        "WHERE config.suite = suite AND config.series = series AND " +
        "config.activated >= config.deactivated AND suite.name != '" +
        Protocol.IMMEDIATE_SUITE_NAME + "' AND " + "(" + expr + ")";
    List<?> results = DAO.selectMultiple(query, null);
    timer.lap( "getSelectedConfigs", "numSCs=" + results.size() );
    return results;
  }

}
