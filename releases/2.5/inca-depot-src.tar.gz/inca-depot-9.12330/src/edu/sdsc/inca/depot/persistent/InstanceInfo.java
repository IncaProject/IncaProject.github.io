package edu.sdsc.inca.depot.persistent;

import java.util.Date;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlObject;

/**
 * Represents information specific to a particular instance of a reporter run.
 */
public class InstanceInfo extends PersistentObject {

  private static final Logger logger = Logger.getLogger(PersistentObject.class);

  /** id set iff this object is stored in the DB. */
  private Long id;

  /** Persistent fields. */
  private Date collected;
  private Date commited;
  private Float memoryUsageMB;
  private Float cpuUsageSec;
  private Float wallClockTimeSec;
  private String log; // Long string
  private Long reportId;

  /**
   * Pattern matcher for spliting sysusage string.
   */
  private static Pattern SYSUSAGE_PATTERN =
    Pattern.compile("(cpu_secs|wall_secs|memory_mb)\\s*=\\s*(\\d+(\\.\\d+)?)");

  /**
   * Default constructor.
   */
  public InstanceInfo() {
    this(new Date(), new Date(), new Float(-1), new Float(-1), new Float(-1));
  }

  /**
   * Full constructor.
   *
   * @param collected        The time that the data was collected
   * @param commited         The time that the data was saved to the database.
   * @param memoryUsageMB    The amount of memory used by the reporter.
   * @param cpuUsageSec      The cpu used by this run of the reporter
   * @param wallClockTimeSec The time the reporter took to run.
   */
  public InstanceInfo(Date collected, Date commited, Float memoryUsageMB,
                      Float cpuUsageSec, Float wallClockTimeSec) {
    this.setCollected(collected);
    this.setCommited(commited);
    this.setMemoryUsageMB(memoryUsageMB);
    this.setCpuUsageSec(cpuUsageSec);
    this.setWallClockTimeSec(wallClockTimeSec);
    this.setLog("");
    this.setReportId(new Long(-1));
  }

  /**
   * A constructor that parses the Inca protocol SYSUSAGE message.
   *
   * @param collected The time that the date was collected.
   * @param sysusage  The Inca protocol SYSUSAGE message.
   */
  public InstanceInfo(Date collected, String sysusage) {
    this();
    this.setCollected(collected);
    Matcher m = SYSUSAGE_PATTERN.matcher(sysusage);
    for(int start = 0; m.find(start); start = m.start() + 1) {
      String metric = m.group(1);
      Float value = new Float(m.group(2));
      if(metric.equals("cpu_secs")) {
        this.setCpuUsageSec(value);
      } else if(metric.equals("wall_secs")) {
        this.setWallClockTimeSec(value);
      } else {
        this.setMemoryUsageMB(value);
      }
    }
  }

  /**
   * Copies information from an Inca schema XmlBean object so that this object
   * contains equivalent information.
   *
   * @param o the XmlBean object to copy
   * @return this, for convenience
   */
  public PersistentObject fromBean(XmlObject o) {
    return this; // No XmlBean equivalent to InstanceInfo
  }

  /**
   * Retrieve the id -- null if not yet connected to database.
   *
   * @return The Long representation of the DB ID
   */
  public Long getId() {
    return this.id;
  }

  /**
   * Set the id.  Hibernate use only.
   *
   * @param id The DB ID.
   */
  public void setId(Long id) {
    this.id = id;
  }

  /**
   * Retrieve the time this instance was collected.
   *
   * @return date collected
   */
  public Date getCollected() {
    return this.collected;
  }

  /**
   * Set the time this data was collected.
   *
   * @param collected date collected
   */
  public void setCollected(Date collected) {
    this.collected = collected;
  }

  /**
   * Retrieve the time this instance was committed.
   *
   * @return date committed
   */
  public Date getCommited() {
    return this.commited;
  }

  /**
   * set the thime this data was commited to db.
   *
   * @param commited commit time
   */
  public void setCommited(Date commited) {
    this.commited = commited;
  }

  /**
   * Retrieve the memory usage.
   *
   * @return memory usage
   */
  public Float getMemoryUsageMB() {
    return this.memoryUsageMB == null ? new Float(-1) : this.memoryUsageMB;
  }

  /**
   * Set the memory usage.
   *
   * @param memoryUsageMB Memory usage in MB
   */
  public void setMemoryUsageMB(Float memoryUsageMB) {
    this.memoryUsageMB = memoryUsageMB;
  }

  /**
   * get the cpu usage.
   *
   * @return cpu usage in Sec
   */
  public Float getCpuUsageSec() {
    return this.cpuUsageSec == null ? new Float(-1) : this.cpuUsageSec;
  }

  /**
   * Set the cup usage.
   *
   * @param cpuUsageSec cpu usage in sec
   */
  public void setCpuUsageSec(Float cpuUsageSec) {
    this.cpuUsageSec = cpuUsageSec;
  }

  /**
   * Get the length of time this reporter took to run.
   *
   * @return runtime in sec
   */
  public Float getWallClockTimeSec() {
    return this.wallClockTimeSec==null ? new Float(-1) : this.wallClockTimeSec;
  }

  /**
   * Set the amount of time this reporter took to run.
   *
   * @param wallClockTimeSec time in sec
   */
  public void setWallClockTimeSec(Float wallClockTimeSec) {
    this.wallClockTimeSec = wallClockTimeSec;
  }

  /**
   * Retrieve the log of this InstanceInfo as an XML string.
   *
   * @return XML string
   */
  public String getLog() {
    return this.log;
  }

  /**
   * Set the log of this InstanceInfo.
   *
   * @param log xml log of InstanceInfo
   */
  public void setLog(String log) {
    if(log == null || log.equals("")) {
      log = DB_EMPTY_STRING;
    }
    if(log.length() > MAX_DB_LONG_STRING_LENGTH) {
      logger.warn("Discarding messages from over-long log '" + log + "'");
      // Throw away one message at a time until we get under the threshhold or
      // the pattern match fails
      do {
        int len = log.length();
        log = log.replaceFirst
          ("(?s)<(debug|error|info|system|warn)>.*?</\\1>\\s*", "");
        if(log.length() == len) {
          log = "";
        }
      } while(log.length() > MAX_DB_LONG_STRING_LENGTH);
    }
    this.log = log;
  }

  /**
   * Return the DB id of the report to which this instance is attached.
   *
   * @return the DB id of this instance's report
   */
  public Long getReportId() {
    return this.reportId;
  }

  /**
   * Set the DB id of the report to which this instance is attached.
   *
   * @param id the DB id of this instance's report
   */
  public void setReportId(Long id) {
    this.reportId = id;
  }

  /**
   * Returns a Inca schema XmlBean Limits object that contains information
   * equivalent to this object.
   *
   * @return an XmlBean Limits object that contains equivalent information
   */
  public XmlObject toBean() {
    edu.sdsc.inca.dataModel.util.Limits result =
      edu.sdsc.inca.dataModel.util.Limits.Factory.newInstance();
    result.setCpuTime(this.getCpuUsageSec().toString());
    result.setMemory(this.getMemoryUsageMB().toString());
    result.setWallClockTime(this.getWallClockTimeSec().toString());
    return result;
  }

  /**
   * Compares another object to this InstanceInfo for logical equality.
   *
   * @param o the object to compare
   * @return true iff the comparison object represents the same InstanceInfo
   */
  public boolean equals(Object o) {
    if(this == o) {
      return true;
    } else if(!(o instanceof InstanceInfo)) {
      return false;
    }
    InstanceInfo ii = (InstanceInfo)o;
    return
      this.getCollected().equals(ii.getCollected()) &&
      this.getCommited().equals(ii.getCommited()) &&
      this.getCpuUsageSec().equals(ii.getCpuUsageSec()) &&
      this.getMemoryUsageMB().equals(ii.getMemoryUsageMB()) &&
      this.getWallClockTimeSec().equals(ii.getWallClockTimeSec());
  }

  /**
   * Returns XML that represents the information in this object.
   */
  public String toXml() {
    // InstanceInfo has no corresponding XML bean.  This implementation is
    // for debugging purposes.
    String result =
      "<instance>\n" +
      "  <collected>" + this.getCollected() + "</collected>\n" +
      "  <commited>" + this.getCommited() + "</commited>\n" +
      "  <cpuUsageSec>" + this.getCpuUsageSec() + "</cpuUsageSec>\n" +
      "  <memoryUsageMB>" + this.getMemoryUsageMB() + "</memoryUsageMB>\n" +
      "  <wallClockTimeSec>" + this.getWallClockTimeSec() + "</wallClockTimeSec>\n";
    String log = this.getLog();
    if(!log.equals(DB_EMPTY_STRING)) {
      result += "  <log>\n" + log + "  </log>\n";
    }
    result += "</instance>\n";
    return result;
  }

  /**
   * Calculate a hash code using the same fields that where used in equals.
   * @return a hash code for this object
   */
  public int hashCode() {
    return 29 * this.getCollected().hashCode() +
                this.getCommited().hashCode() +
                this.getCpuUsageSec().hashCode() +
                this.getMemoryUsageMB().hashCode() +
                this.getWallClockTimeSec().hashCode();
  }

}
