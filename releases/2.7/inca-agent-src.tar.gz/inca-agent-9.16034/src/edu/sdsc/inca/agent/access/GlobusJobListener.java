package edu.sdsc.inca.agent.access;

import org.globus.gram.GramJob;
import org.globus.gram.GramJobListener;
import org.globus.exec.generated.StateEnumeration;
import org.apache.log4j.Logger;

/**
 * Subclass of GramJobListener that can be used to create a non-blocking
 * and blocking GRAM request.  For example,
 *
 * <pre>
 *   GramJob job = new GramJob( false, null );
 *   GlobusBlockingJobListener listener = new GlobusBlockingJobListener();
 *   job.addListener( listener );
 *   job.request( gramContact );
 *   listener.waitFor();
 *   // job is now active
 * </pre>
 *
 * Based on Java COG code for globusrun.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GlobusJobListener implements GramJobListener,
                                        org.globus.exec.client.GramJobListener {

  Logger logger = Logger.getLogger(GlobusJobListener.class);

  // generic status to be used irregardless of GRAM job type
  public enum Status { UNSUBMITTED, FAILED, ACTIVE, DONE }
  // type of globus job
  public enum GRAM_TYPE { GRAM, WSGRAM }


  // Member variables
  private boolean blocking = true;
  private GRAM_TYPE gramType = GRAM_TYPE.GRAM;
  private org.globus.exec.client.GramJob job = null;
  private Status status = Status.UNSUBMITTED;

  /**
   * Create a job listener for a PreWS GRAM job
   *
   * @param blocking  True if waitFor should block until job is complete; false
   *                  if waitFor should block only until job is active
   * @param gramJob  A PreWS GRAM job
   */
  public GlobusJobListener( boolean blocking, GramJob gramJob ) {
    this.blocking = blocking;
    logger.debug( "Creating " + (this.blocking ? "blocking" : "nonblocking") +
                  " JobListener for GRAM job" );
    this.gramType = GRAM_TYPE.GRAM;
  }

  /**
   * Create a job listener for a WS GRAM job
   *
   * @param blocking  True if waitFor should block until job is complete; false
   *                  if waitFor should block only until job is active
   * @param gramJob   A WS GRAM job
   */
  public GlobusJobListener( boolean blocking,
                            org.globus.exec.client.GramJob gramJob ) {

    this.blocking = blocking;
    logger.debug( "Creating " + (this.blocking ? "blocking" : "nonblocking") +
                  " JobListener for WS GRAM job" );
    this.gramType = GRAM_TYPE.WSGRAM;
    this.job = gramJob;
  }

  /**
   * Get the status code for the Globus GRAM job.  Should be called after the
   * job is finished.
   *
   * @return A constant from the GramJob class indicating the status of the job.
   */
  public Status getStatus() {
    return status;
  }

  /**
   * Check for active status of job.
   *
   * @return Returns true if the job status is active.
   */
  public boolean isActive() {
    return status == Status.ACTIVE;
  }

  /**
   * Check for failure status of job.
   *
   * @return Returns true if the job status is failed.
   */
  public boolean isFailed() {
    return status == Status.FAILED;
  }

  /**
   * Returns true if the job has finished.
   *
   * @return  Returns true if the job status is either done or failed; false
   * otherwise.
   */
  public boolean isFinished() {
    return (status == Status.DONE || status == Status.FAILED);
  }

  /**
   * Set the status code for the Globus GRAM job.
   *
   * @param status  A Status enum value
   */
  private void setStatus( Status status ) {
    this.status = status;
  }

  /**
   * Called when the status of a WS GRAMjob is changed.  Unlike GRAM, it seems a
   * specific refresh call is needed to invoke this function.
   *
   * @param job  A WS GRAM job
   */
  public synchronized void stateChanged( org.globus.exec.client.GramJob job ) {
    logger.debug( "WS GRAM job state is " + job.getState() );
    if ( job.getState() == StateEnumeration.Active ) {
      setStatus( Status.ACTIVE);
    } else if ( job.getState() == StateEnumeration.Done ) {
      setStatus( Status.DONE );
    } else if ( job.getState() == StateEnumeration.Failed ) {
      setStatus( Status.FAILED );
    }
  }
  /**
   * Called when the status of a PreWS GRAM changes.
   *
   * @param job a PreWS GRAM job
   */
  public synchronized void statusChanged( GramJob job ) {
    logger.debug( "GRAM job state is " + job.getStatusAsString() );    
    if ( job.getStatus() == GramJob.STATUS_ACTIVE) {
      setStatus( Status.ACTIVE );
      notify();
    } else if ( job.getStatus() == GramJob.STATUS_DONE ) {
      setStatus( Status.DONE );
      notify();      
    } else if ( job.getStatus() == GramJob.STATUS_FAILED ) {
      setStatus( Status.FAILED );
      notify();            
    }
  }

  /**
   * Wait for the job to finish or become active.  In the case of a WS GRAM
   * job periodically refreshes the job's status until it is active or complete.
   * For PreWS GRAM job, it blocks until another thread notifies it and
   * then checks the job status and returns if finished or active.
   *
   * @throws InterruptedException if interrupted while waiting
   */
  public synchronized void waitFor() throws InterruptedException {
    if ( gramType == GRAM_TYPE.WSGRAM ) {
      while ( (blocking && ! this.isFinished()) ||
              (!blocking && ! this.isActive() && ! this.isFinished()) ) {
        try {
          if ( job != null ) job.refreshStatus();
        } catch (Exception e ) {
          logger.debug("Exception while refreshing job state", e);
        }
        Thread.sleep( 5000 );
      }
    } else {
      while ( (blocking && !this.isFinished()) ||
              (!blocking && !this.isActive() && !this.isFinished()) ) {
        wait();
      }
    }
  }

}

