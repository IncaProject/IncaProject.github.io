package edu.sdsc.inca.agent.access;

import org.ietf.jgss.GSSCredential;
import edu.sdsc.inca.agent.AccessMethodOutput;
import edu.sdsc.inca.agent.AccessMethodException;
import edu.sdsc.inca.ConfigurationException;

/**
 * Base class for Globus job submission services. Use the create method to
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
abstract public class GlobusJob {
  protected GSSCredential credential = null;
  protected String dn = null;
  protected String host = null;
  protected int port = 8443;
  protected String service = null;
  protected String tempDir = null;

  /**
   * Create a globus job where the type of Globus job (PreWS or WS) GRAM is
   * determined from the provider argument.
   *
   * @param provider  A string indicating the type of GRAM job to create
   *                  (globus2 or globus4)
   * @param host  A string containing the hostname for the Globus job service
   * @param port An integer containing the port for the Globus job service.
   *             When the value is 0, Inca will use the default port.
   * @param dn   An optional string indicating the subject DN of the Globus
   *             job service
   * @param serviceType The type of Globus job manager to invoke (Fork)
   * @param gridftp  The gridftp server to use for transferring files
   *
   * @return A GlobusJob object that can be used to submit jobs
   *
   * @throws ConfigurationException if trouble creating job
   */
  static public GlobusJob create( String provider, String host, int port,
                                  String dn, String serviceType,
                                  Globus.Service gridftp )
    throws ConfigurationException {
    if ( provider.equals("globus4") ) {
      return new GlobusWSGramJob( host, port, dn, serviceType, gridftp );
    } else {
      return new GlobusPreWSGramJob( host, port, dn, serviceType );
    }
  }

  /**
   * Return the credential used for the Globus job
   *
   * @return  A valid GSS credential
   */
  public GSSCredential getCredential() {
    return credential;
  }

  /**
   * Return the directory where temporary files may be stored
   *
   * @return  A string containing a temporary directory path
   */
  public String getTempDir() {
    return tempDir;
  }

  /**
   * Check whether the remote process is alive.
   *
   * @return true if the remote process is alive; false otherwise.
   */
  abstract public boolean isActive();

  /**
   * Given a path relative to the home directory, prepend '$(HOME)/'
   * to the path and return the new string.
   *
   * @param path   A path relative to the user's home directory
   *
   * @return  A new string that contains '$(HOME)/' prepended to the
   * provided path.
   */
  abstract public String prependHome( String path );

  /**
   * Execute the specified process on the remote resource.  This call will block
   * until the process has completed.
   *
   * @param executable Path to the remote executable.
   * @param args  Contains the arguments that should be passed to the
   *                   executable
   * @param stdin      A string that will be passedd in as stdin to the process
   *                   when it is started

   * @param directory  Path to the directory where the process will be executed
   *                   from
   * @return The stdout and stderr of the executed process in
   * RemoteProcessObject.
   *
   * @throws AccessMethodException if trouble running job
   * @throws InterruptedException if interrupted while running job
   */
  abstract public AccessMethodOutput run ( String executable, String[] args,
                                           String stdin, String directory )
    throws AccessMethodException, InterruptedException;

  /**
   * Set the credential for the Globus gram job
   *
   * @param cred  A valid GSS credential
   */
  public void setCredential( GSSCredential cred ) {
    this.credential = cred;
  }

  /**
   * Set the directory where temporary files can be stored
   *
   * @param tempDir A path to a directory
   */
  public void setTempDir( String tempDir ) {
    this.tempDir = tempDir;
  }

  /**
   * Start a process on a remote machine.  This is a non-blocking call.
   *
   * @param executable  Path to the remote executable.
   * @param arguments   Contains the arguments that should be passed to the
   *                    executable
   * @param stdin      A string that will be passedd in as stdin to the process
   *                   when it is started
   * @param directory  Path to the directory where the process will be executed
   *                   from
   * @throws AccessMethodException if trouble starting job
   */
  abstract public void start(String executable, String[] arguments, String stdin,
                             String directory)
    throws AccessMethodException;

  /**
   * Kill the remote process that was started by the start() call.
   *
   * @throws AccessMethodException if unable to kill process
   */
  abstract public void stop() throws AccessMethodException;
}
