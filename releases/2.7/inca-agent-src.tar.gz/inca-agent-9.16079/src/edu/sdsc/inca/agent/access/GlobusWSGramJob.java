package edu.sdsc.inca.agent.access;

import org.apache.log4j.Logger;
import org.apache.axis.message.addressing.EndpointReferenceType;
import org.globus.exec.generated.JobDescriptionType;
import org.globus.exec.generated.StateEnumeration;
import org.globus.exec.generated.FaultType;
import org.globus.exec.utils.client.ManagedJobFactoryClientHelper;
import org.globus.exec.utils.rsl.RSLHelper;
import org.globus.ftp.GridFTPClient;
import org.globus.ftp.Session;
import org.globus.wsrf.impl.security.authorization.IdentityAuthorization;
import org.globus.wsrf.client.ServiceURL;
import org.globus.wsrf.utils.FaultHelper;
import org.globus.gram.GramException;

import java.io.File;
import java.io.IOException;
import java.io.FileWriter;

import edu.sdsc.inca.agent.AccessMethodOutput;
import edu.sdsc.inca.agent.AccessMethodException;
import edu.sdsc.inca.util.StringMethods;
import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.protocol.Protocol;

/**
 * Handles the creation and running WS Gram jobs
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GlobusWSGramJob extends GlobusJob {
  public static String WSGRAM_PROTOCOL = "https://";
  public static String WSGRAM_SERVICE="/wsrf/services/ManagedJobFactoryService";
  private Logger logger = Logger.getLogger(GlobusWSGramJob.class);

  private JobState activeJob = null;
  public EndpointReferenceType factoryEndpoint = null;
  public Globus.Service gridftpServer = null;

  // data struct for storing temporary job state
  private class JobState {
    public GridFTPClient gridftpClient = null;
    public File localStderr = null;
    public File localStdin = null;
    public File localStdout = null;
    public org.globus.exec.client.GramJob job = null;
    public String remoteStderr = null;
    public String remoteStdin = null;
    public String remoteStdout = null;
  }

  /**
   * Create a Globus WS GRAM job
   *
   * @param host  The hostname of the WS GRAM server
   * @param port  The port of the WS GRAM server.  Use 0 to get default port.
   * @param dn    An optional subject dn for the WS GRAM credentials
   *              (null if empty)
   * @param factoryType WS GRAM factory type (default: Fork)
   * @param gridftpServer  The contact for a corresponding GridFTP server
   *
   * @throws ConfigurationException if unable to create endpoing
   */
  public GlobusWSGramJob( String host, int port, String dn, String factoryType,
                          Globus.Service gridftpServer )
    throws ConfigurationException {

    this.host = host;
    if ( port > 0 ) {
      this.port = port;
    } else {
      this.port = Integer.parseInt( Protocol.WSGRAM_SERVER_PORT_MACRO_DEFAULT );
    }
    this.dn = dn;
    this.service = factoryType;
    if ( factoryType == null ) {
      factoryType = Protocol.WSGRAM_SERVICE_MACRO_DEFAULT;
    }
    this.gridftpServer = gridftpServer;
    try {
      String contact = WSGRAM_PROTOCOL + this.host + ":" + this.port +
        WSGRAM_SERVICE;
      logger.debug( "Endpoint " + contact );
      ServiceURL factoryURL = ManagedJobFactoryClientHelper.getServiceURL
        ( contact );
      this.factoryEndpoint = ManagedJobFactoryClientHelper.getFactoryEndpoint
        (factoryURL.getURL(), factoryType );
    } catch ( Exception e ) {
      throw new ConfigurationException( "Unable to create WSGRAM endpoint", e);
    }
  }

  /**
   * Cleanup local and remote temporary files
   *
   * @param jobState holds temporary files and gridftp connection for a job
   */
  public void cleanup( JobState jobState ) {
    logger.debug( "Cleaning up temporary WS GRAM job files" );
    if ( jobState.localStdin != null ) {
      jobState.localStdin.delete();
      jobState.localStdin = null;
    }
    if ( jobState.localStdout != null ) {
      jobState.localStdout.delete();
      jobState.localStdout = null;
    }
    if ( jobState.localStderr != null ) {
      jobState.localStderr.delete();
      jobState.localStderr = null;
    }
    if ( jobState.gridftpClient != null ) {
      try {
        if ( jobState.remoteStdin != null &&
          jobState.gridftpClient.exists(jobState.remoteStdin) ) {
          jobState.gridftpClient.deleteFile(jobState.remoteStdin);
          jobState.remoteStdin = null;
        }
        if ( jobState.remoteStdout != null &&
          jobState.gridftpClient.exists(jobState.remoteStdout) ) {
          jobState.gridftpClient.deleteFile(jobState.remoteStdout);
          jobState.remoteStdout = null;
        }
        if ( jobState.remoteStderr != null &&
          jobState.gridftpClient.exists(jobState.remoteStderr) ) {
          jobState.gridftpClient.deleteFile(jobState.remoteStderr);
          jobState.remoteStderr = null;
        }
      } catch (Exception e) {
        logger.warn( "Unable to cleanup temporary remote files", e );
      } finally {
        try {
          jobState.gridftpClient.close();
        } catch ( Exception e ) {
          logger.warn( "Unable to close GridFTP connection", e );
        }
      }
    }
  }

  /**
   * Create a globus job using the specified parameters
   *
   * @param executable Path to the remote executable.
   * @param arguments  Contains the arguments that should be passed to the
   *                   executable
   * @param dir  Path to the directory where the process will be executed
   *             from
   * @param stdin  A string that will be passedd in as stdin to the process
   *               when it is started
   * @param streamOutput true if stdout and stderr should be streamed back
   *                     locally
   * @param jobState holds temporary files and gridftp connection for a job
   *                 (cannot be null)
   *
   * @throws Exception If problem creating the task.
   */
  public void createJob( String executable, String[] arguments, String dir,
                         String stdin, boolean streamOutput,
                         JobState jobState)
    throws Exception {

    // Create RSL request
    JobDescriptionType desc = new JobDescriptionType();
    desc.setExecutable( executable );
    desc.setArgument( arguments );

    // stdin needs to be passed in as a file
    if ( stdin != null ) {
      jobState.localStdin = File.createTempFile
        ( "incalocalStdin",".tmp",new File(this.getTempDir()) );
      jobState.remoteStdin = "~/" + jobState.localStdin.getName().replace
        ("incalocal", "incaremote");
      try {
        Runtime.getRuntime().exec
          ( "chmod 600 " + jobState.localStdin.getAbsolutePath() ).waitFor();
      } catch (InterruptedException e) {
        throw new IOException("Unable to change permissions on stdin file"+e);
      }
      FileWriter writer = new FileWriter( jobState.localStdin );
      writer.write( stdin );
      writer.close();
      desc.setStdin( this.prependHome( jobState.remoteStdin ) );
    }
    if ( streamOutput ) {
      jobState.localStderr = File.createTempFile
        ( "incalocalStderr",".tmp",new File(this.getTempDir()) );
      jobState.localStdout = File.createTempFile
        ( "incalocalStdout",".tmp",new File(this.getTempDir()) );
      jobState.remoteStdout = "~/" + jobState.localStdout.getName().replace
        ("incalocal", "incaremote");
      jobState.remoteStderr = "~/" + jobState.localStderr.getName().replace
        ("incalocal", "incaremote");
      desc.setStdout( this.prependHome( jobState.remoteStdout ) );
      desc.setStderr( this.prependHome( jobState.remoteStderr ) );
    }
    if (dir != null) {
      desc.setDirectory( dir );
    }
    logger.info( "WSGRAM contact = " + this );
    logger.debug( "WSGRAM RSL:\n" + RSLHelper.convertToString(desc) );
    jobState.job = new org.globus.exec.client.GramJob(desc);
    jobState.job.setCredentials(this.credential);
    if ( this.dn != null ) {
      jobState.job.setAuthorization( new IdentityAuthorization(this.dn) );
    }
    try {
      logger.info( "GridFTP contact: " + this.gridftpServer );
      jobState.gridftpClient = Globus.connectGridftp
        ( this.gridftpServer,this.credential );
      jobState.gridftpClient.setLocalPassive();
      jobState.gridftpClient.setActive();
      jobState.gridftpClient.setType( Session.TYPE_IMAGE );
    } catch (Exception e) {
      throw new AccessMethodException("Could not connect to Service server", e);
    }
    if ( jobState.localStdin != null ) {
      jobState.gridftpClient.put
        ( jobState.localStdin, jobState.remoteStdin, false );
    }
  }

  /**
   * Check whether the remote process is alive.
   *
   * @return true if the remote process is alive; false otherwise.
   */
  public boolean isActive() {
    return activeJob != null &&
      activeJob.job.getState() == StateEnumeration.Active;
  }

  /**
   * Given a path relative to the home directory, prepend '${GLOBUS_USER_HOME}/'
   * to the path and return the new string.
   *
   * @param path   A path relative to the user's home directory
   *
   * @return  A new string that contains '${GLOBUS_USER_HOME}/' prepended to the
   * provided path.
   */
  public String prependHome( String path ) {
    return "${GLOBUS_USER_HOME}/" + path.replaceFirst( "^~/", "" );
  }

  /**
   * Execute the specified process on the remote resource.  This call will block
   * until the process has completed.
   *
   * @param executable Path to the remote executable.
   * @param arguments  Contains the arguments that should be passed to the
   *                   executable
   * @param stdin      A string that will be passedd in as stdin to the process
   *                   when it is started

   * @param directory  Path to the directory where the process will be executed
   *                   from
   * @return The stdout and stderr of the executed process in
   * RemoteProcessObject.
   *
   * @throws AccessMethodException if trouble running job
   * @throws InterruptedException if interrupted while running job
   */
  public AccessMethodOutput run ( String executable, String[] arguments,
                                  String stdin, String directory )
    throws AccessMethodException, InterruptedException {

    // create job request
    JobState jobState = new JobState();
    try {
      this.createJob(executable, arguments, directory, stdin, true, jobState);
    } catch ( Exception e ) {
      this.cleanup(jobState);
      throw new AccessMethodException
        ( "Globus remote run failed to create job", e );
    }

    // Submit request and error checking
    AccessMethodOutput result = new AccessMethodOutput();
    String errorMsg = "Globus WS GRAM call failed to " + this;
    try {
      jobState.job.submit( factoryEndpoint );
      logger.debug( "Waiting for Globus WS GRAM job to complete" );
      GlobusJobListener listener = new GlobusJobListener(true, jobState.job);
      jobState.job.addListener( listener );
      listener.waitFor();
      if ( jobState.job.getState() == StateEnumeration.Failed ) {
        int error = jobState.job.getError();
        logger.debug( "Error code is " + error );
        FaultType fault = jobState.job.getFault();
        FaultHelper helper = new FaultHelper( fault );
        throw new GramException( helper.getDescriptionAsString() );
      }
      logger.debug( "Globus WS GRAM job completed; getting output" );
      if ( jobState.gridftpClient.exists(jobState.remoteStdout) &&
        jobState.gridftpClient.size(jobState.remoteStdout) > 0 ) {
        jobState.gridftpClient.setLocalPassive();
        jobState.gridftpClient.setActive();
        jobState.gridftpClient.get( jobState.remoteStdout,  jobState.localStdout );
      }
      if ( jobState.gridftpClient.exists(jobState.remoteStderr ) &&
        jobState.gridftpClient.size(jobState.remoteStderr) > 0) {
        jobState.gridftpClient.setLocalPassive();
        jobState.gridftpClient.setActive();
        jobState.gridftpClient.get( jobState.remoteStderr,  jobState.localStderr );
      }
      if ( jobState.localStdout.length() > 0 ) {
        result.setStdout
          (StringMethods.fileContents(jobState.localStdout.getAbsolutePath()));
        logger.debug( "STDOUT: " + result.getStdout() );
      }
      if ( jobState.localStderr.length() > 0 ) {
        result.setStderr
          (StringMethods.fileContents(jobState.localStderr.getAbsolutePath()));
        logger.debug( "STDERR: " + result.getStderr() );
      }
    } catch( InterruptedException e ) {
      throw e;
    } catch ( Exception e ) {
      logger.error( errorMsg, e );
      throw new AccessMethodException( errorMsg, e );
    } finally {
      this.cleanup(jobState);
    }

    // return stdout and stderr
    return result;
  }

  /**
   * Start a process on a remote machine.  This is a non-blocking call.
   *
   * @param executable  Path to the remote executable.
   * @param arguments   Contains the arguments that should be passed to the
   *                    executable
   * @param stdin      A string that will be passedd in as stdin to the process
   *                   when it is started
   * @param directory  Path to the directory where the process will be executed
   *                   from
   */
  public void start( String executable, String[] arguments, String stdin,
                     String directory) throws AccessMethodException {

    if ( this.activeJob != null  ) {
      throw new AccessMethodException(
        "An existing job is already running; " +
          "only one process at a time currently supported"
      );
    }

    activeJob = new JobState();

    String errorMsg = "Globus call failed to " + this;
    try {
      this.createJob(executable, arguments, directory, stdin, false, activeJob);
      GlobusJobListener listener = new GlobusJobListener(false, activeJob.job);
      activeJob.job.addListener( listener );
      activeJob.job.submit( factoryEndpoint );
      listener.waitFor();
    } catch ( Exception e ) {
      throw new AccessMethodException("Unable to start remote globus process",e);
    } finally {
      this.cleanup( activeJob );
    }
    if ( activeJob.job.getState() == StateEnumeration.Failed ) {
      throw new AccessMethodException(errorMsg+": "+activeJob.job.getError());
    }
  }

  /**
   * Kill the remote process that was started by the start() call.
   *
   * @throws AccessMethodException if unable to kill process
   */
  public void stop() throws AccessMethodException {
    try {
      if ( activeJob != null ) {
        activeJob.job.cancel();
      }
    } catch (Exception e) {
      throw new AccessMethodException( "Unable to cancel job", e );
    } finally {
      activeJob = null;
    }
  }

  /**
   * Return the contact string for this GRAM service
   *
   * @return  A string complying to host:port/service[:subject]
   */
  public String toString() {
    return factoryEndpoint.toString();
  }

}
