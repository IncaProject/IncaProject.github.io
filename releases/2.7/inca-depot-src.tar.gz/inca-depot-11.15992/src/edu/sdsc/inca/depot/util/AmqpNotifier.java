/*
 * AmqpNotifier.java
 */
package edu.sdsc.inca.depot.util;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Pattern;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import javax.security.auth.x500.X500Principal;

import org.apache.log4j.Logger;
import org.bouncycastle.asn1.x500.RDN;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.style.BCStyle;
import org.bouncycastle.asn1.x500.style.IETFUtils;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.openssl.PEMDecryptorProvider;
import org.bouncycastle.openssl.PEMEncryptedKeyPair;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.openssl.jcajce.JcePEMDecryptorProviderBuilder;
import org.json.JSONObject;
import org.json.XML;

import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.DefaultSaslConfig;

import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.dataModel.report.ReportDocument;
import edu.sdsc.inca.dataModel.util.Report;
import edu.sdsc.inca.depot.persistent.AcceptedOutput;
import edu.sdsc.inca.depot.persistent.InstanceInfo;
import edu.sdsc.inca.depot.persistent.PersistentObject;
import edu.sdsc.inca.depot.persistent.ReportDAO;
import edu.sdsc.inca.depot.persistent.Series;
import edu.sdsc.inca.depot.persistent.SeriesConfig;


/**
 *
 * @author Paul Hoover
 *
 */
public class AmqpNotifier implements ReportNotifier {

  // nested classes


  /**
   *
   */
  private interface KeyPattern {

    /**
     *
     * @param target
     * @return
     */
    String match(String target);
  }

  /**
   *
   */
  private static class FixedResultPattern implements KeyPattern {

    private final Pattern m_pattern;
    private final String m_result;


    /**
     *
     * @param pair
     * @throws ConfigurationException
     */
    public FixedResultPattern(String pair) throws ConfigurationException
    {
      String[] parts = pair.split("=");

      if (parts.length != 2)
        throw new ConfigurationException("Invalid key pattern " + pair);

      m_pattern = Pattern.compile(parts[0]);
      m_result = parts[1];
    }


    /**
     *
     * @param target
     * @return
     */
    public String match(String target)
    {
      if (m_pattern.matcher(target).matches())
        return m_result;
      else
        return null;
    }
  }

  /**
   *
   */
  private static class ConstantPattern implements KeyPattern {

    private final String m_result;


    /**
     *
     * @param result
     */
    public ConstantPattern(String result)
    {
      m_result = result;
    }


    /**
     *
     * @param target
     * @return
     */
    public String match(String target)
    {
      return m_result;
    }
  }

  /**
   *
   */
  private static class EchoPattern implements KeyPattern {

    /**
     *
     * @param target
     * @return
     */
    public String match(String target)
    {
      return target;
    }
  }


  // data fields


  private static final String PROVIDER = "BC";
  private static final Logger m_logger = Logger.getLogger(AmqpNotifier.class);
  private final String m_exchange;
  private final String m_keyBase;
  private final List<ConnectionFactory> m_factories = new ArrayList<ConnectionFactory>();
  private final List<KeyPattern> m_servicePatterns = new ArrayList<KeyPattern>();
  private final List<KeyPattern> m_resourcePatterns = new ArrayList<KeyPattern>();


  // constructors


  /**
   *
   * @param hosts
   * @param exchange
   * @param base
   * @param patterns
   * @throws KeyManagementException
   * @throws NoSuchAlgorithmException
   * @throws URISyntaxException
   * @throws ConfigurationException
   */
  public AmqpNotifier(String[] hosts, String exchange, String base, String[] patterns) throws KeyManagementException, NoSuchAlgorithmException, URISyntaxException, ConfigurationException
  {
    for (String uri : hosts) {
      ConnectionFactory newFactory = new ConnectionFactory();

      newFactory.setUri(uri);
      newFactory.setConnectionTimeout(30000);

      m_factories.add(newFactory);
    }

    m_exchange = exchange;

    if (base != null && base.length() > 0)
      m_keyBase = "." + base;
    else
      m_keyBase = "";

    if (patterns != null) {
      for (String pair : patterns) {
        String[] parts = pair.split(":");

        if (parts[0].equals("service"))
          m_servicePatterns.add(new FixedResultPattern(parts[1]));
        else if (parts[0].equals("resource"))
          m_resourcePatterns.add(new FixedResultPattern(parts[1]));
        else
          throw new ConfigurationException("Unknown key pattern type " + parts[0]);
      }

      m_servicePatterns.add(new ConstantPattern("general"));
    }

    m_resourcePatterns.add(new EchoPattern());
  }


  // public methods


  /**
   *
   * @param userCert
   * @param userKey
   * @param keyPassPhrase
   * @param hostCerts
   * @throws IOException
   * @throws KeyStoreException
   * @throws NoSuchProviderException
   * @throws NoSuchAlgorithmException
   * @throws CertificateException
   * @throws UnrecoverableKeyException
   * @throws KeyManagementException
   */
  public void setSslContext(String userCert, String userKey, String keyPassPhrase, String[] hostCerts) throws IOException, KeyStoreException, NoSuchProviderException, NoSuchAlgorithmException, CertificateException, UnrecoverableKeyException, KeyManagementException
  {
    if (keyPassPhrase == null)
      keyPassPhrase = "";

    KeyStore userStore = readUserCert(userCert, userKey, keyPassPhrase);
    KeyManagerFactory keyFactory = KeyManagerFactory.getInstance("SunX509");

    keyFactory.init(userStore, keyPassPhrase.toCharArray());

    KeyStore trustedStore = readHostCerts(hostCerts);
    TrustManagerFactory trustFactory = TrustManagerFactory.getInstance("SunX509");

    trustFactory.init(trustedStore);

    SSLContext context = SSLContext.getInstance("SSLv3");

    context.init(keyFactory.getKeyManagers(), trustFactory.getTrustManagers(), null);

    for (ConnectionFactory factory : m_factories) {
      factory.useSslProtocol(context);
      factory.setSaslConfig(DefaultSaslConfig.EXTERNAL);
    }
  }

  /**
   *
   * @param command
   * @param report
   * @param series
   * @param instance
   * @throws Exception
   */
  public void notify(String command, Report report, Series series, InstanceInfo instance) throws Exception
  {
    edu.sdsc.inca.depot.persistent.Report dbReport = ReportDAO.load(instance.getReportId());

    if (dbReport == null) {
      m_logger.warn("InstanceInfo " + instance.getId() + " has invalid Report id " + instance.getReportId());

      return;
    }

    Set<String> routingKeys = new TreeSet<String>();

    for (SeriesConfig dbSc : series.getSeriesConfigs()) {
      if (dbSc.getDeactivated() != null || dbSc.getSchedule().getType().equals("immediate"))
        continue;

      AcceptedOutput ao = dbSc.getAcceptedOutput();

      if (ao == null)
        continue;

      String comparitor = ao.getComparitor();

      if (comparitor == null || comparitor.length() < 1 || comparitor.equals(PersistentObject.DB_EMPTY_STRING))
        continue;

      StringBuilder keyBuilder = new StringBuilder();
      String comparison = (new ExprComparitor()).compare(ao, dbReport);
      String testResult = comparison.startsWith(ExprComparitor.FAILURE_RESULT) ? "error" : "success";
      String nickname = dbSc.getNickname();
      String target = series.getTargetHostname();
      String resource = series.getResource();

      keyBuilder.append(testResult);
      keyBuilder.append('.');
      keyBuilder.append(nickname);

      applyKeyPatterns(m_servicePatterns, nickname, keyBuilder);

      if (target != null && target.length() > 0 && !target.equals(PersistentObject.DB_EMPTY_STRING))
        applyKeyPatterns(m_resourcePatterns, target, keyBuilder);
      else
        applyKeyPatterns(m_resourcePatterns, resource, keyBuilder);

      keyBuilder.append(m_keyBase);

      routingKeys.add(keyBuilder.toString());
    }

    ReportDocument reportDoc = ReportDocument.Factory.newInstance();

    reportDoc.setReport(report);

    JSONObject jsonObj = XML.toJSONObject(reportDoc.xmlText());
    byte[] message = jsonObj.toString().getBytes();

    for (ConnectionFactory factory : m_factories) {
      Connection connection = null;
      Channel channel = null;

      try {
        connection = factory.newConnection();
        channel = connection.createChannel();

        for (String key : routingKeys) {
          channel.basicPublish(m_exchange, key, null, message);

          m_logger.debug("Published a report for InstanceInfo " + instance.getId() + " using routing key " + key);
        }

        break;
      }
      catch (IOException ioErr) {
        int port = factory.getPort();
        String virtualHost = factory.getVirtualHost();
        String errMessage = ioErr.getMessage();
        StringBuilder logMessage = new StringBuilder();

        logMessage.append("Unable to publish a report at ");
        logMessage.append(factory.getHost());

        if (port != ConnectionFactory.DEFAULT_AMQP_PORT && port != ConnectionFactory.DEFAULT_AMQP_OVER_SSL_PORT) {
          logMessage.append(':');
          logMessage.append(port);
        }

        if (!virtualHost.equals(ConnectionFactory.DEFAULT_VHOST)) {
          logMessage.append('/');
          logMessage.append(virtualHost);
        }

        if (errMessage != null && errMessage.length() > 0) {
          logMessage.append(": ");
          logMessage.append(errMessage);
        }

        m_logger.warn(logMessage.toString());
      }
      finally {
        if (channel != null && channel.isOpen())
          channel.close();

        if (connection != null && connection.isOpen())
          connection.close();
      }
    }
  }


  // private methods


  /**
   *
   * @param fileName
   * @return
   * @throws FileNotFoundException
   */
  private InputStream openStream(String fileName) throws FileNotFoundException
  {
    InputStream result = ClassLoader.getSystemClassLoader().getResourceAsStream(fileName);

    if (result == null)
      result = new FileInputStream(fileName);

    return result;
  }

  /**
   *
   * @param fileName
   * @return
   * @throws IOException
   */
  private Object readPEMFile(String fileName) throws IOException
  {
    InputStream inStream = openStream(fileName);
    PEMParser parser = null;

    try {
      parser = new PEMParser(new InputStreamReader(inStream));

      return parser.readObject();
    }
    finally {
      if (parser != null)
        parser.close();
      else
        inStream.close();
    }
  }

  /**
   *
   * @param fileName
   * @return
   * @throws IOException
   * @throws CertificateException
   */
  private X509Certificate readCertFile(String fileName) throws IOException, CertificateException
  {
    X509CertificateHolder certHolder = (X509CertificateHolder)readPEMFile(fileName);
    JcaX509CertificateConverter certConverter = new JcaX509CertificateConverter();

    certConverter.setProvider(PROVIDER);

    return certConverter.getCertificate(certHolder);
  }

  /**
   *
   * @param fileName
   * @param password
   * @return
   * @throws IOException
   * @throws KeyStoreException
   */
  private KeyPair readKeyFile(String fileName, final String password) throws IOException, KeyStoreException
  {
    Object pemObject = readPEMFile(fileName);
    PEMKeyPair pemKey;

    if (pemObject instanceof PEMKeyPair)
      pemKey = (PEMKeyPair)pemObject;
    else if (pemObject instanceof PEMEncryptedKeyPair) {
      PEMEncryptedKeyPair encryptedKey = (PEMEncryptedKeyPair)pemObject;
      JcePEMDecryptorProviderBuilder decryptBuilder = new JcePEMDecryptorProviderBuilder();

      decryptBuilder.setProvider(PROVIDER);

      PEMDecryptorProvider decryptor = decryptBuilder.build(password.toCharArray());

      pemKey = encryptedKey.decryptKeyPair(decryptor);
    }
    else
      throw new KeyStoreException(fileName + " does not contain a key pair");

    JcaPEMKeyConverter keyConverter = new JcaPEMKeyConverter();

    keyConverter.setProvider(PROVIDER);

    return keyConverter.getKeyPair(pemKey);
  }

  /**
   *
   * @param principal
   * @return
   */
  private String getCommonName(X500Principal principal)
  {
    X500Name name = new X500Name(principal.getName());
    RDN[] rdns = name.getRDNs(BCStyle.CN);

    return IETFUtils.valueToString(rdns[0].getFirst().getValue());
  }

  /**
   *
   * @param cert
   * @return
   */
  private String getAlias(X509Certificate cert)
  {
    String subjectCN = getCommonName(cert.getSubjectX500Principal());
    String issuerCN = getCommonName(cert.getIssuerX500Principal());

    return subjectCN + " issued by " + issuerCN;
  }

  /**
   *
   * @param certFile
   * @param keyFile
   * @param keyPassPhrase
   * @return
   * @throws IOException
   * @throws KeyStoreException
   * @throws NoSuchProviderException
   * @throws NoSuchAlgorithmException
   * @throws CertificateException
   */
  private KeyStore readUserCert(String certFile, String keyFile, String keyPassPhrase) throws IOException, KeyStoreException, NoSuchProviderException, NoSuchAlgorithmException, CertificateException
  {
    X509Certificate cert = readCertFile(certFile);
    KeyPair keyPair = readKeyFile(keyFile, keyPassPhrase);
    String alias = getAlias(cert);
    KeyStore.PrivateKeyEntry entry = new KeyStore.PrivateKeyEntry(keyPair.getPrivate(), new Certificate[] { (Certificate)cert });
    KeyStore.PasswordProtection prot = new KeyStore.PasswordProtection(keyPassPhrase.toCharArray());
    KeyStore store = KeyStore.getInstance("PKCS12", PROVIDER);

    store.load(null, null);
    store.setEntry(alias, entry, prot);

    return store;
  }

  /**
   *
   * @param certFiles
   * @return
   * @throws IOException
   * @throws KeyStoreException
   * @throws NoSuchAlgorithmException
   * @throws CertificateException
   */
  private KeyStore readHostCerts(String[] certFiles) throws IOException, KeyStoreException, NoSuchAlgorithmException, CertificateException
  {
    KeyStore store = KeyStore.getInstance("JKS");

    store.load(null, null);

    for (String file : certFiles) {
      X509Certificate cert = readCertFile(file);
      KeyStore.TrustedCertificateEntry entry = new KeyStore.TrustedCertificateEntry(cert);
      String alias = getAlias(cert);

      store.setEntry(alias, entry, null);
    }

    return store;
  }

  /**
   *
   * @param patterns
   * @param target
   * @param output
   */
  private void applyKeyPatterns(List<KeyPattern> patterns, String target, StringBuilder output)
  {
    for (KeyPattern pattern : patterns) {
      String result = pattern.match(target);

      if (result != null) {
        output.append('.');
        output.append(result);

        break;
      }
    }
  }
}
