package URI::mms;

use strict;
use warnings;

use parent 'URI::http';

sub default_port { 1755 }

1;
