package edu.sdsc.inca.depot.util;

import edu.sdsc.inca.Depot;
import edu.sdsc.inca.util.StringMethods;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;
import org.apache.log4j.Logger;

/**
 * A Notifier that executes a script.
 *
 * @author jhayes
 */
public class ScriptNotifier extends Notifier {

  private static Logger logger = Logger.getLogger(ScriptNotifier.class);

  /**
   * Transforms the initial notification template from the depot into a
   * notification-specific format.
   *
   * @param initial the Depot notification template
   * @return a notification-specific template
   */
  public String constructNotificationTemplate(String initial) {
    return initial != null ? initial :
      "--comparison=@comparison@\n\n--series=@nickname@\n\n" +
      "--resource=@resource@\n\n--state=@comparisonResult@";
  }

  /**
   * Invokes a script, passing info about an AcceptedOutput state change.
   *
   * @param target the script to notify
   * @param fail indicates whether or not the state indicates failure
   * @param notification the text of the notification
   */
  public void notify(String target, boolean fail, String notification) {
    String[] commandWords = (target + "\n\n" + notification).split("\n\n");
    // Check to see if the script has either a temporary directory or the
    // working dir as an ancestor; other paths are disallowed for security.
    // Check target for initial /tmp, but check cononical path for wd to avoid
    // potential problems with ../ in path.
    try {
      String targetPath = new File(target).getCanonicalPath();
      String workingDir =
        new File(System.getProperty("user.dir")).getCanonicalPath();
      if(!target.startsWith("/tmp/") && !targetPath.startsWith(workingDir)) {
        logger.error("Invalid script file path '" + targetPath + "'");
        return;
      }
      commandWords[0] = targetPath;
    } catch(Exception e) {
      logger.error("Error examining script path: " + e);
      return;
    }
    // Now run the script
    String command = StringMethods.join(" ", commandWords);
    try {
      logger.debug(command);
      Process p = Runtime.getRuntime().exec(commandWords);
      p.waitFor();
      if(p.exitValue() != 0) {
        BufferedReader reader =
          new BufferedReader(new InputStreamReader(p.getErrorStream()));
        String stderr = "", line;
        while((line = reader.readLine()) != null) {
          stderr += line;
        }
        logger.error("Error executing script " + command + ": " + stderr);
      }
    } catch(InterruptedException e) {
      // empty
    } catch(IOException e) {
      logger.error("Error executing script " + command + ": " + e);
    }

  }

}
