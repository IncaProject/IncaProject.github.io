package edu.sdsc.inca.depot.util;

import edu.sdsc.inca.depot.persistent.AcceptedOutput;
import edu.sdsc.inca.depot.persistent.Arg;
import edu.sdsc.inca.depot.persistent.PersistentObject;
import edu.sdsc.inca.depot.persistent.Report;
import edu.sdsc.inca.depot.persistent.Series;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.util.ExprEvaluator;
import edu.sdsc.inca.util.StringMethods;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import org.apache.log4j.Logger;

/**
 * Implements a comparitor that matches the contents of certain tags in a
 * report body against an expected expression.  Supports the boolean binary
 * operators &lt;, &lt;=, &gt;, &gt;=, ==, !=, &lt;&gt;, &amp;&amp;, and ||,
 * as well as perl's pattern match (=~) and mismatch (!~) operators.  Supports
 * parenthesized sub-expressions.  Operands may be any of: a quoted string
 * literal; a numeric literal; a pattern literal enclosed in slashes; an
 * identifier defined in the report body by an ID tag; a version literal
 * composed of digits, letters, underscores and dots.
 *
 * @author jhayes
 */
public class ExprComparitor implements Comparitor {

  private static Logger logger = Logger.getLogger(ExprComparitor.class);
  private static Pattern ID_PATTERN =
    Pattern.compile("<(ID|name)>([^<]*)</\\1>\\s*(<(\\w+)>(.*?)</\\4>)?");

  public String compare(AcceptedOutput ao, Report report) {
    Properties symbolTable = new Properties();
    // Generate symbols for report body, arguments, and error message
    String body = report.getBody();
    if(body == null || body.equals(PersistentObject.DB_EMPTY_STRING)) {
      body = "";
    }
    symbolTable.setProperty("body", body);
    Series s = report.getSeries();
    if(s != null) {
      Iterator it = s.getArgs().iterator();
      while(it.hasNext()) {
        Arg a = (Arg)it.next();
        symbolTable.setProperty(a.getName(), a.getValue());
      }
    }
    String errorMessage = report.getExit_message();
    if(errorMessage == null ||
       errorMessage.equals(PersistentObject.DB_EMPTY_STRING)) {
      errorMessage = "";
    }
    symbolTable.setProperty("errorMessage", errorMessage);
    String expr = ao.getComparison();
    if(expr == null) {
      logger.warn("Null expression passed to ExprComparitor");
      expr = "1==0"; // Handle error gracefully
    }
    logger.debug("Compare '" + body + "' to '" + expr + "'");
    // For each <ID>name</ID><any>text</any> tag pair in the body, assign text
    // as the value of the name; ditto for <name>name</name><any>text</any>
    Matcher m = ID_PATTERN.matcher(body);
    for(int index = 0; m.find(index); index = m.start() + 1) {
      String name = body.substring(m.start(2), m.end(2));
      String value = m.start(5) < 0 ? "" : body.substring(m.start(5), m.end(5));
      symbolTable.setProperty(name, value);
    }
    String result = ExprEvaluator.eval(expr, symbolTable, null);
    if(result == null) {
      return SUCCESS_RESULT;
    }
    return FAILURE_RESULT + ":" +
           result.replaceAll(ExprEvaluator.FAIL_EXPR_FAILED + ":", "");
  }

}
