package edu.sdsc.inca.depot.util;

import edu.sdsc.inca.Depot;
import edu.sdsc.inca.protocol.Protocol;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * An abstract class that notifies a "target" (for example, an email address)
 * about a state change in AcceptableOutput.
 *
 * @author jhayes
 */
public abstract class Notifier {

  static final protected Pattern MACRO_REFERENCE_PATTERN =
    Pattern.compile("@" + Protocol.MACRO_NAME_PATTERN + "@");
  static final protected String UNDEFINED_MACRO_VALUE = "XxXxXx";

  /**
   * Transforms the initial notification template from the depot into a
   * notification-specific format.
   *
   * @param initial the Depot notification template
   * @return a notification-specific template
   */
  public abstract String constructNotificationTemplate(String initial);

  /**
   * Notifies a target of an AcceptedOutput state change.
   *
   * @param target the target to notify
   * @param props property values to plug into the notification text
   */
  public void notify(String target, Properties props) {
    String s = constructNotificationTemplate(Depot.getNotificationTemplate());
    String result = props.getProperty("comparisonResult");
    boolean fail =
      result != null && result.startsWith(Comparitor.FAILURE_RESULT);
    props.setProperty("result", fail ? "FAIL" : "PASS");
    Matcher m;
    while((m = MACRO_REFERENCE_PATTERN.matcher(s)).find()) {
      String name = s.substring(m.start() + 1, m.end() - 1);
      String value = props.getProperty(name);
      if(value == null) {
        value = UNDEFINED_MACRO_VALUE;
      }
      s = s.substring(0, m.start()) + value + s.substring(m.end());
    }
    notify(target, fail, s);
  }

  /**
   * Notifies a target of an AcceptedOutput state change.
   *
   * @param target the target to notify
   * @param fail indicates whether or not the state indicates failure
   * @param notification the text of the notification
   */
  public abstract void notify(String target, boolean fail, String notification);

}
