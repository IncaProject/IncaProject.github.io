package edu.sdsc.inca.depot.commands;

import edu.sdsc.inca.depot.persistent.PersistenceException;
import edu.sdsc.inca.depot.persistent.PersistentTest;
import edu.sdsc.inca.depot.persistent.Series;
import edu.sdsc.inca.depot.persistent.Suite;
import edu.sdsc.inca.depot.persistent.SeriesConfig;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import java.io.CharArrayReader;
import java.io.CharArrayWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class QueryTest extends PersistentTest {

  static final String CRLF = "\r\n";

  public void testNoSuiteFound() {

    Query myQuery = new Query();
    String request = Protocol.QUERY_SUITE_COMMAND + " notThere" + CRLF;
    ProtocolReader in = new ProtocolReader(
      new CharArrayReader(request.toCharArray())
    );
    CharArrayWriter caw = new CharArrayWriter();
    String reply;
    try {
      myQuery.execute(in, new ProtocolWriter(caw));
      fail("No exception on missing suite");
    } catch(Exception e) {
      if(e instanceof PersistenceException) {
        // empty
      } else {
        fail("Incorrect exception thrown:" + e);
      }
    }
  }

  public void testGetGuids() throws Exception {

    Suite suite1 = Suite.generate("aSuite", 0);
    Suite suite2 = Suite.generate("bSuite", 0);

    String request =
      Protocol.SUITE_UPDATE_COMMAND + " " + suite1.toXml() + CRLF;
    ProtocolReader in =
      new ProtocolReader(new CharArrayReader(request.toCharArray()));
    CharArrayWriter caw = new CharArrayWriter();
    try {
      new SuiteUpdate().execute(in, new ProtocolWriter(caw));
    } catch (Exception e) {
      e.printStackTrace();
      fail("protocol exception: " + e);
    }
    String reply = caw.toString();
    assertNotNull(reply);
    assertTrue(reply.startsWith("OK"));
    request = Protocol.SUITE_UPDATE_COMMAND + " " + suite2.toXml() + CRLF;
    in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
    caw = new CharArrayWriter();
    try {
      new SuiteUpdate().execute(in, new ProtocolWriter(caw));
    } catch (Exception e) {
      e.printStackTrace();
      fail("protocol exception: " + e);
    }
    reply = caw.toString();
    assertNotNull(reply);
    assertTrue(reply.startsWith("OK"));

    request = Protocol.QUERY_GUIDS_COMMAND + CRLF;
    in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
    caw = new CharArrayWriter();
    try {
      new Query().execute(in, new ProtocolWriter(caw));
    } catch (Exception e) {
      e.printStackTrace();
      fail("protocol exception: " + e);
    }
    reply = caw.toString();
    assertNotNull(reply);
    reply = reply.replaceAll(CRLF, "");
    assertEquals("OK " + suite1.getGuid() + "\n" + suite2.getGuid(), reply);

  }

  public void testGetLatestSuiteResults() throws Exception {

    int CONFIG_COUNT = 6;
    Suite testSuite = Suite.generate("aSuite", 0);
    String[] reports = new String[CONFIG_COUNT];
    for(int i = 0; i < CONFIG_COUNT; i++) {
      SeriesConfig sc = SeriesConfig.generate("localhost", "@@ " + i, 2);
      testSuite.addSeriesConfig(sc);
      reports[i] = sc.getSeries().generateReport();
    }
    String reply = null;

    String request =
      Protocol.SUITE_UPDATE_COMMAND + " " + testSuite.toXml() + CRLF;
    ProtocolReader in =
      new ProtocolReader(new CharArrayReader(request.toCharArray()));
    CharArrayWriter caw = new CharArrayWriter();
    try {
      new SuiteUpdate().execute(in, new ProtocolWriter(caw));
    } catch (Exception e) {
      e.printStackTrace();
      fail("protocol exception: " + e);
    }
    reply = caw.toString();
    assertNotNull(reply);
    assertTrue(reply.startsWith("OK"));

    // insert two reports for each series in the suite
    for(int i = 0; i < reports.length; i++) {
      String context = testSuite.getSeriesConfig(i).getSeries().getContext();
      logger.debug("Insert " + context);
      request = Protocol.INSERT_COMMAND + " localhost " + context + CRLF +
        "STDOUT " + reports[i] + CRLF +
        "SYSUSAGE cpu_secs=12\nwall_secs=13\nmemory_mb=14\n" + CRLF;
      caw = new CharArrayWriter();
      try {
        in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
        new Insert().execute(in, new ProtocolWriter(caw));
        in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
        new Insert().execute(in, new ProtocolWriter(caw));
      } catch (Exception e) {
        e.printStackTrace();
        fail("protocol exception: " + e);
      }
      reply = caw.toString();
      assertNotNull(reply);
    }

    // query for the latest instance from each series
    request = Protocol.QUERY_SUITE_COMMAND + " " + testSuite.getGuid() + CRLF;
    caw = new CharArrayWriter();
    try {
      in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
      new Query().execute(in, new ProtocolWriter(caw));
    } catch (Exception e) {
      e.printStackTrace();
      fail("protocol exception: " + e);
    }
    reply = caw.toString();
    assertNotNull(reply);
    logger.debug("Suite query reply is '" + reply + "'");
    int replyCount = 0;
    for(int i = reply.indexOf("QUERYRESULT");
        i >= 0;
        i = reply.indexOf("QUERYRESULT", i + 1)) {
      replyCount++;
    }
    assertEquals(reports.length, replyCount);

  }

  public void testSeriesInstances() throws Exception  {

    int CONFIG_COUNT = 6;
    Suite testSuite = Suite.generate("aSuite", 0);
    String[] reports = new String[CONFIG_COUNT];
    for(int i = 0; i < CONFIG_COUNT; i++) {
      SeriesConfig sc = SeriesConfig.generate("localhost", "@@ " + i, 2);
      testSuite.addSeriesConfig(sc);
      reports[i] = sc.getSeries().generateReport();
    }
    String reply = null;

    // insert a suite
    String request =
      Protocol.SUITE_UPDATE_COMMAND + " " + testSuite.toXml() + CRLF;
    ProtocolReader in =
      new ProtocolReader(new CharArrayReader(request.toCharArray()));
    CharArrayWriter caw = new CharArrayWriter();
    try {
      new SuiteUpdate().execute(in, new ProtocolWriter(caw));
    } catch (Exception e) {
      e.printStackTrace();
      fail("protocol exception: " + e);
    }
    reply = caw.toString();
    assertNotNull(reply);
    assertTrue(reply.startsWith("OK"));

    // insert two reports for each series in the suite
    for(int i = 0; i < reports.length; i++) {
      String context = testSuite.getSeriesConfig(i).getSeries().getContext();
      logger.debug("Insert " + context);
      request = Protocol.INSERT_COMMAND + " localhost " + context + CRLF +
        "STDOUT " + reports[i] + CRLF +
        "SYSUSAGE cpu_secs=12\nwall_secs=13\nmemory_mb=14\n" + CRLF;
      caw = new CharArrayWriter();
      try {
        in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
        new Insert().execute(in, new ProtocolWriter(caw));
        in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
        new Insert().execute(in, new ProtocolWriter(caw));
      } catch (Exception e) {
        e.printStackTrace();
        fail("protocol exception: " + e);
      }
      reply = caw.toString();
      assertNotNull(reply);
    }

    // first, figure out the seriesConfigId for reports[4]
    request = Protocol.QUERY_SUITE_COMMAND + " " + testSuite.getGuid() + CRLF;
    caw = new CharArrayWriter();
    try {
      in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
      new Query().execute(in, new ProtocolWriter(caw));
    } catch (Exception e) {
      e.printStackTrace();
      fail("protocol exception: " + e);
    }
    reply = caw.toString();
    assertNotNull(reply);
    logger.debug("Suite query reply is '" + reply + "'");
    int pos = reply.indexOf(testSuite.getSeriesConfig(4).getSeries().getUri() + "</uri>");
    assertTrue(pos >= 0);
    pos = reply.indexOf("</seriesConfigId>", pos);
    assertTrue(pos >= 0);
    String seriesConfigId = reply.substring(pos - 1, pos);

    // now, requst all instances of that seriesConfig
    request = Protocol.QUERY_SERIES_COMMAND + " " + seriesConfigId + CRLF;
    caw = new CharArrayWriter();
    try {
      in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
      new Query().execute(in, new ProtocolWriter(caw));
    } catch (Exception e) {
      e.printStackTrace();
      fail("protocol exception: " + e);
    }
    reply = caw.toString();
    assertNotNull(reply);
    logger.debug("Series query reply is '" + reply + "'");
    int replyCount = 0;
    for(int i = reply.indexOf("QUERYRESULT");
        i >= 0;
        i = reply.indexOf("QUERYRESULT", i + 1)) {
      replyCount++;
    }
    assertEquals(2, replyCount);

  }

  public void testHql() throws Exception  {

    int CONFIG_COUNT = 6;
    Suite testSuite = Suite.generate("aSuite", 0);
    String[] reports = new String[CONFIG_COUNT];
    for(int i = 0; i < CONFIG_COUNT; i++) {
      SeriesConfig sc = SeriesConfig.generate("localhost", "@@ " + i, 2);
      testSuite.addSeriesConfig(sc);
      reports[i] = sc.getSeries().generateReport();
    }
    String reply = null;

    // insert a suite
    String request =
      Protocol.SUITE_UPDATE_COMMAND + " " + testSuite.toXml() + CRLF;
    ProtocolReader in =
      new ProtocolReader(new CharArrayReader(request.toCharArray()));
    CharArrayWriter caw = new CharArrayWriter();
    try {
      new SuiteUpdate().execute(in, new ProtocolWriter(caw));
    } catch (Exception e) {
      e.printStackTrace();
      fail("protocol exception: " + e);
    }
    reply = caw.toString();
    assertNotNull(reply);
    assertTrue(reply.startsWith("OK"));

    // insert two reports for each series in the suite
    for(int i = 0; i < reports.length; i++) {
      String context = testSuite.getSeriesConfig(i).getSeries().getContext();
      logger.debug("Insert " + context);
      request = Protocol.INSERT_COMMAND + " localhost " + context + CRLF +
        "STDOUT " + reports[i] + CRLF +
        "SYSUSAGE cpu_secs=12\nwall_secs=13\nmemory_mb=14\n" + CRLF;
      caw = new CharArrayWriter();
      try {
        in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
        new Insert().execute(in, new ProtocolWriter(caw));
        in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
        new Insert().execute(in, new ProtocolWriter(caw));
      } catch (Exception e) {
        e.printStackTrace();
        fail("protocol exception: " + e);
      }
      reply = caw.toString();
      assertNotNull(reply);
    }

    request = Protocol.QUERY_HQL_COMMAND + " " +
              "select r from Report as r" + CRLF;
    caw = new CharArrayWriter();
    try {
      in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
      new Query().execute(in, new ProtocolWriter(caw));
    } catch (Exception e) {
      e.printStackTrace();
      fail("protocol exception: " + e);
    }
    reply = caw.toString();
    assertNotNull(reply);
    logger.debug("SQL query reply is '" + reply + "'");
    int pos = reply.indexOf("<body>");
    assertTrue(pos >= 0);

  }

  public void testReportLog() throws Exception  {

    int CONFIG_COUNT = 6;
    String gmt =
      new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ").format(new Date());
    gmt = gmt.substring(0,gmt.length()-2) + ":" + gmt.substring(gmt.length()-2);
    Suite testSuite = Suite.generate("aSuite", 0);
    String[] reports = new String[CONFIG_COUNT];
    for(int i = 0; i < CONFIG_COUNT; i++) {
      SeriesConfig sc = SeriesConfig.generate("localhost", "@@ " + i, 2);
      testSuite.addSeriesConfig(sc);
      reports[i] = sc.getSeries().generateReport();
      // add a log section
      String log = "<log>\n" +
                   "  <info>\n" +
                   "    <gmt>" + gmt + "</gmt>\n" +
                   "    <message>This is a log message</message>\n" +
                   "  </info>\n" +
                   "</log>\n";
      reports[i] = reports[i].replaceAll("<body", log + "<body");
    }
    String reply = null;

    // insert a suite
    String request =
      Protocol.SUITE_UPDATE_COMMAND + " " + testSuite.toXml() + CRLF;
    ProtocolReader in =
      new ProtocolReader(new CharArrayReader(request.toCharArray()));
    CharArrayWriter caw = new CharArrayWriter();
    try {
      new SuiteUpdate().execute(in, new ProtocolWriter(caw));
    } catch (Exception e) {
      e.printStackTrace();
      fail("protocol exception: " + e);
    }
    reply = caw.toString();
    assertNotNull(reply);
    assertTrue(reply.startsWith("OK"));

    // insert two reports for each series in the suite
    for(int i = 0; i < reports.length; i++) {
      String context = testSuite.getSeriesConfig(i).getSeries().getContext();
      logger.debug("Insert " + context);
      request = Protocol.INSERT_COMMAND + " localhost " + context + CRLF +
        "STDOUT " + reports[i] + CRLF +
        "SYSUSAGE cpu_secs=12\nwall_secs=13\nmemory_mb=14\n" + CRLF;
      caw = new CharArrayWriter();
      try {
        in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
        new Insert().execute(in, new ProtocolWriter(caw));
        in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
        new Insert().execute(in, new ProtocolWriter(caw));
      } catch (Exception e) {
        e.printStackTrace();
        fail("protocol exception: " + e);
      }
      reply = caw.toString();
      assertNotNull(reply);
    }

    // Make sure report details include logs

    // first, figure out the seriesConfigId for reports[4]
    request = Protocol.QUERY_SUITE_COMMAND + " " + testSuite.getGuid() + CRLF;
    caw = new CharArrayWriter();
    try {
      in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
      new Query().execute(in, new ProtocolWriter(caw));
    } catch (Exception e) {
      e.printStackTrace();
      fail("protocol exception: " + e);
    }
    reply = caw.toString();
    assertNotNull(reply);
    logger.debug("Suite query reply is '" + reply + "'");
    int pos = reply.indexOf(testSuite.getSeriesConfig(4).getSeries().getUri() + "</uri>");
    assertTrue(pos >= 0);
    pos = reply.indexOf("</seriesConfigId>", pos);
    assertTrue(pos >= 0);
    String seriesConfigId = reply.substring(pos - 1, pos);

    // now, requst all instances of that seriesConfig
    request = Protocol.QUERY_SERIES_COMMAND + " " + seriesConfigId + CRLF;
    caw = new CharArrayWriter();
    try {
      in = new ProtocolReader(new CharArrayReader(request.toCharArray()));
      new Query().execute(in, new ProtocolWriter(caw));
    } catch (Exception e) {
      e.printStackTrace();
      fail("protocol exception: " + e);
    }
    reply = caw.toString();
    assertNotNull(reply);
    logger.debug("Series query reply is '" + reply + "'");
    int replyCount = 0;
    for(int i = reply.indexOf("QUERYRESULT");
        i >= 0;
        i = reply.indexOf("QUERYRESULT", i + 1)) {
      replyCount++;
    }
    assertEquals(2, replyCount);
    assertTrue(reply.indexOf("<log>") >= 0);

  }

}
