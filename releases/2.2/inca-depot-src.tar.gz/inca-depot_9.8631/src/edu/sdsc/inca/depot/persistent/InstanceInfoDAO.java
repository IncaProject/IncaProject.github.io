package edu.sdsc.inca.depot.persistent;

/**
 * This class transfers InstanceInfo objects between memory and the DB.
 */
public class InstanceInfoDAO extends DAO {

  /**
   * Returns an InstanceInfo object from the DB with the id specified, null if
   * no such object appears in the DB.
   *
   * @param id the id of the object to be retrieved
   * @return an object from the DB marked with the given id
   * @throws PersistenceException on err
   */
  public static InstanceInfo load(Long id) throws PersistenceException {
    String query = "select ii from InstanceInfo ii where ii.id = " + id;
    return (InstanceInfo)DAO.selectUnique(query, null);
  }

  /**
   * Returns an InstanceInfo object from the DB with the same field values
   * as one specified, or the saved version of the specified object if no such
   * object appears in the DB.  Synchronized to avoid race conditions that
   * could result in DB duplicates.
   *
   * @param ii an object that contains field values used in the retrieval
   * @return an object from the DB that contains the same values
   * @throws PersistenceException on err
   */
  public static synchronized InstanceInfo loadOrSave(InstanceInfo ii)
    throws PersistenceException {
    InstanceInfo dbIi = null;
    if(ii.getId() != null) {
      dbIi = InstanceInfoDAO.load(ii.getId());
    }
    return dbIi == null ? (InstanceInfo)DAO.save(ii) : dbIi;
  }

  /**
   * A wrapper around DAO.update that handles the necessary casting.
   *
   * @param ii the object to update
   * @return ii for convenience
   * @throws PersistenceException on error
   */
  public static InstanceInfo update(InstanceInfo ii)
      throws PersistenceException {
    return (InstanceInfo)DAO.update(ii);
  }

}
