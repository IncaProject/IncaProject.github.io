package edu.sdsc.inca.depot.commands;

import edu.sdsc.inca.Depot;
import edu.sdsc.inca.depot.persistent.*;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import java.io.BufferedReader;
import java.io.CharArrayWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.StringReader;
import java.util.List;

/**
 * User: cmills
 * Date: Mar 24, 2005
 * Time: 3:25:08 PM
 * For now this class is just required to be able to have the following conversation
 * REPORT SP bogus.name CRLF
 * STDOUT SP {xml data} CRLF
 * SYSUSAGE SP ignored CRLF
 * <p/>
 * This implies that the depot will be able to injest a report that has no errors.
 */

public class InsertTest extends PersistentTest {

  public static final String CRLF = "\r\n";

  private String report
    (String resource, String context, String stdout, String stderr,
     boolean addSysusage) {
    String result = "REPORT " + resource + " " + context + CRLF;
    if(stderr != null) {
      result += "STDERR " + stderr + CRLF;
    }
    if(stdout != null) {
      result += "STDOUT " + stdout + CRLF;
    }
    if(addSysusage) {
      result += "SYSUSAGE cpu_secs=12\nwall_secs=13\nmemory_mb=14\n" + CRLF;
    }
    return result;
  }

  private String report(String resource, String context, String stdout) {
    return report(resource, context, stdout, null, true);
  }

  public void testDuplicateInsert() throws Exception {

    Series s = Series.generate("localhost", "myreporter", 3);
    String report = s.generateReport();

    logger.debug("Insert the first");
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    CharArrayWriter caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    String reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));

    logger.debug("Insert the second");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));

    // make sure that the report was put in the db
    Series dbSeries = SeriesDAO.load(s);
    assertNotNull(dbSeries);
    Object[] reports = dbSeries.getReports().toArray();
    assertEquals(1, reports.length);

    // now try a duplicate w/a different timestamp
    String report2 = report.replaceFirst("<gmt>\\d+", "<gmt>2007");
    logger.debug("Insert the third");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report2)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));

    logger.debug("Query the second");
    dbSeries = SeriesDAO.load(s);
    assertNotNull(dbSeries);
    reports = dbSeries.getReports().toArray();
    assertEquals(1, reports.length);

    // we now should have three instances
    assertEquals(3, DAO.selectMultiple("select i from InstanceInfo as i where i.reportId = :p0", new Object[] {((Report)reports[0]).getId()}).size());

  }

  /** Tests reports for a SeriesConfig that includes a comparitor. */
  public void testWithComparitor() throws Exception {

    SuiteUpdateTest sut = new SuiteUpdateTest();
    Suite suite = Suite.generate("aSuite", 1);
    SeriesConfig sc = suite.getSeriesConfig(0);
    Series s = sc.getSeries();
    AcceptedOutput ao = new AcceptedOutput("ExprComparitor", "body !~ /GOOgi/");
    sc.setAcceptedOutput(ao);
    sut.updateSuite(suite);
    String report = s.generateReport();

    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    CharArrayWriter caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    String reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);

    // See if a ComparisonResult was placed into the DB
    SeriesConfig dbSc =
      (SeriesConfig)DAO.selectUnique("select sc from SeriesConfig as sc", null);
    assertNotNull(dbSc);
    assertTrue(dbSc.getLatestComparisonId().longValue() >= 0);

    // An identical report should not trigger a second CR
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);

    List crs =
     DAO.selectMultiple("select cr from ComparisonResult as cr", null);
    assertEquals(1, crs.size());

    // But a different one should
    String report2 =
      report.replaceAll("<body[^>]*>.*</body>", "<body><x>GOOgi</x></body>");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report2)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);

    crs = DAO.selectMultiple("select cr from ComparisonResult as cr", null);
    assertEquals(2, crs.size());

  }

  /** Tests reports for a SeriesConfig that includes a log notifier. */
  public void testWithLogNotifier() throws Exception {

    String logPath = "/tmp/InsertLogOutput.txt";
    File logFile = new File(logPath);

    SuiteUpdateTest sut = new SuiteUpdateTest();
    Suite suite = Suite.generate("aSuite", 1);
    SeriesConfig sc = suite.getSeriesConfig(0);
    Series s = sc.getSeries();
    AcceptedOutput ao = new AcceptedOutput("ExprComparitor", "body !~ /GOOgi/");
    Notification n = new Notification();
    n.setNotifier("LogNotifier");
    n.setTarget(logPath);
    ao.setNotification(n);
    sc.setAcceptedOutput(ao);
    sut.updateSuite(suite);
    String report = s.generateReport();

    FileWriter fw = new FileWriter(logPath);
    fw.close();
    long emptyLength = logFile.length();

    // Successful comparison should generate a notification
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    CharArrayWriter caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    String reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(emptyLength == logFile.length());
    long notifyLength = logFile.length();

    // A failed comparison should also
    String report2 =
      report.replaceAll("<body[^>]*>.*</body>", "<body><x>GOOgi</x></body>");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report2)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(emptyLength == notifyLength);
    notifyLength = logFile.length();

    // An identical failure should not
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report2)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertEquals(notifyLength, logFile.length());

    // A return to success should
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(notifyLength == logFile.length());

    // Try specifying a template to use
    notifyLength = logFile.length();
    Depot.setNotificationTemplate("Twas brillig and the slithy @result@ toves");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report2)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(notifyLength == logFile.length());
    BufferedReader br = new BufferedReader(new FileReader(logPath));
    String line;
    for(line = br.readLine();
        line != null && line.indexOf("brillig") < 0;
        line = br.readLine()) {
      // empty
    }
    assertNotNull(line);

    logFile.delete();

  }

  /** Tests reports for a SeriesConfig that includes a script notifier. */
  public void testWithScriptNotifier() throws Exception {

    String logPath = "/tmp/InsertScriptOutput.txt";
    String scriptPath = "/tmp/InsertOutputScript.sh";
    File logFile = new File(logPath);
    File scriptFile = new File(scriptPath);

    SuiteUpdateTest sut = new SuiteUpdateTest();
    Suite suite = Suite.generate("aSuite", 1);
    SeriesConfig sc = suite.getSeriesConfig(0);
    Series s = sc.getSeries();
    AcceptedOutput ao = new AcceptedOutput("ExprComparitor", "body !~ /GOOgi/");
    Notification n = new Notification();
    n.setNotifier("ScriptNotifier");
    n.setTarget(scriptPath);
    ao.setNotification(n);
    sc.setAcceptedOutput(ao);
    sut.updateSuite(suite);
    String report = s.generateReport();

    FileWriter fw = new FileWriter(logPath);
    fw.close();
    long emptyLength = logFile.length();
    fw = new FileWriter(scriptPath);
    fw.write(
      "#!/bin/sh\n" +
      "echo $0 >> " + logPath + "\n" +
      "echo $1 >> " + logPath + "\n" +
      "echo $2 >> " + logPath + "\n" +
      "echo $3 >> " + logPath + "\n" +
      "echo $4 >> " + logPath + "\n" +
      "echo $5 >> " + logPath + "\n"
    );
    fw.close();
    try {
      Process p = Runtime.getRuntime().exec("chmod +x " + scriptPath);
      p.waitFor();
    } catch(Exception e) {
      // empty
    }

    // Successful comparison should generate a notification
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    CharArrayWriter caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    String reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(emptyLength == logFile.length());
    long notifyLength = logFile.length();

    // A failed comparison should also
    String report2 =
      report.replaceAll("<body[^>]*>.*</body>", "<body><x>GOOgi</x></body>");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report2)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(notifyLength == logFile.length());
    notifyLength = logFile.length();

    // An identical failure should not
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report2)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertEquals(notifyLength, logFile.length());

    // A return to success should
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(notifyLength == logFile.length());

    logFile.delete();
    scriptFile.delete();

  }

  /** Tests a malformed report. */
  public void testInvalidXml() throws Exception {

    Series s = Series.generate("localhost", "myreporter", 3);
    String report = s.generateReport();
    // Remove hostname--a required tag
    report = report.replaceAll("<hostname>.*</hostname>", "");

    logger.debug("Insert the first");
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    CharArrayWriter caw = new CharArrayWriter();
    // Should throw a protocol exception
    try {
      new Insert().execute(in, new ProtocolWriter(caw));
    } catch(ProtocolException e) {
      assertTrue(e.toString().indexOf("Invalid") >= 0);
      return;
    }
    fail("Invalid XML does not raise an exception");

  }

  /** Tests a series w/no arguments. */
  public void testNoArgs() throws Exception {

    Series s = Series.generate("localhost", "myreporter", 0);
    String report = s.generateReport();

    logger.debug("Insert the first");
    logger.info(report);
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    CharArrayWriter caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    String reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));

    // make sure that the report was put in the db
    Series dbSeries = SeriesDAO.load(s);
    assertNotNull(dbSeries);
    Object[] reports = dbSeries.getReports().toArray();
    assertEquals(1, reports.length);

  }

  /** Tests an excessive report log section. */
  public void testLongLog() throws Exception {

    Series s = Series.generate("localhost", "myreporter", 3);
    String report = s.generateReport();
    String logContent = "";
    while(logContent.length() <= PersistentObject.MAX_DB_LONG_STRING_LENGTH) {
      logContent += "<debug><gmt>0001-01-01T00:00:00</gmt><message>" +
                    logContent.length() + "</message></debug>\n";
    }
    report = report.replaceFirst
      ("</args>", "</args>\n<log>\n" + logContent + "</log>\n");

    logger.debug("Insert the first");
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    CharArrayWriter caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));

    logger.debug("Query the first");
    Series dbSeries = SeriesDAO.load(s);
    assertNotNull(dbSeries);
    Object[] reports = dbSeries.getReports().toArray();
    InstanceInfo ii =
      (InstanceInfo)DAO.selectUnique("select i from InstanceInfo as i", null);
    assertTrue(ii != null);
    String dbLogContent = ii.getLog();
    assertTrue
      (dbLogContent.length() <= PersistentObject.MAX_DB_LONG_STRING_LENGTH);
    while(dbLogContent.indexOf(logContent) < 0) {
      logContent = logContent.replaceFirst("<debug>.*?</debug>\n", "");
    }
    assertTrue(!logContent.equals(""));

  }

}
