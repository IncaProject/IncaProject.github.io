package edu.sdsc.inca.depot.util;

import edu.sdsc.inca.util.StringMethods;
import java.util.Properties;
import java.util.regex.Pattern;

/**
 * A Notifier that sends email to its target.
 *
 * @author jhayes
 */
public class EmailNotifier extends Notifier {

  /**
   * Transforms the initial notification template from the depot into a
   * notification-specific format.
   *
   * @param initial the Depot notification template
   * @return a notification-specific template
   */
  public String constructNotificationTemplate(String initial) {
    if(initial == null) {
      initial =
        "This is notification from the Inca system that results of test\n\n" +
        "@comparison@\n\n" +
        "on the output of series @nickname@ on @resource@ have changed.\n\n" +
        "Comparitor message: @comparisonResult@\n\n" +
        "Exit message: @errorMessage@\n";
    }
    if(!Pattern.compile("SUBJECT\\s*=").matcher(initial).find()) {
      initial +=
        "SUBJECT=Inca Notification: @nickname@ on @resource@ @result@\n";
    }
    return initial;
  }

  /**
   * Emails a target email address about an AcceptedOutput state change.
   *
   * @param target the email address(es) to notify
   * @param fail indicates whether or not the state indicates failure
   * @param notification the text of the notification
   */
  public void notify(String target, boolean fail, String notification) {
    String[] emails = target.split("[\\s,;]+");
    String body = notification.replaceFirst(".*SUBJECT\\s*=.*\n", "");
    body = body.replaceAll(".*"+UNDEFINED_MACRO_VALUE+".*\n(\\s*\n)*", "");
    String subject = notification.replaceFirst("(?s)^.*SUBJECT\\s*=\\s*", "").
                     replaceFirst("(?s)\n.*$", "");
    for(int i = 0; i < emails.length; i++) {
      String[] pieces = emails[i].split(":");
      if(pieces.length == 1 || fail == pieces[0].startsWith("Fail")) {
        StringMethods.sendEmail
          (pieces[pieces.length == 1 ? 0 : 1], subject, body);
      }
    }
  }

}
