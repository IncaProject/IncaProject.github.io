package edu.sdsc.inca.depot.commands;

import edu.sdsc.inca.dataModel.reportDetails.ReportDetailsDocument;
import edu.sdsc.inca.dataModel.util.AnyXmlSequence;
import edu.sdsc.inca.dataModel.util.Log;
import edu.sdsc.inca.dataModel.util.ReportDetails;
import edu.sdsc.inca.depot.persistent.*;
import edu.sdsc.inca.depot.util.HibernateMessageHandler;
import edu.sdsc.inca.protocol.*;
import edu.sdsc.inca.queryResult.ReportSummaryDocument;
import edu.sdsc.inca.util.StringMethods;
import edu.sdsc.inca.util.XmlWrapper;
import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;
import org.hibernate.Session;
import org.hibernate.metadata.ClassMetadata;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 */
public class Query extends HibernateMessageHandler {

  private static Logger logger = Logger.getLogger(Query.class);
  private static final Statement S_FINISH =
    new Statement(Protocol.END_QUERY_RESULTS_COMMAND.toCharArray(), null);

  /**
   * Execute queries on the depot.
   *
   * @param reader   Reader to the query request.
   * @param writer   Writer to the remote process making the request.
   * @throws Exception
   */
  public void executeHibernateAction(
    ProtocolReader reader, ProtocolWriter writer) throws Exception {

    Statement queryStatement = null;
    queryStatement = reader.readStatement();
    String cmd = new String(queryStatement.getCmd());
    String data = new String(queryStatement.getData());
    try {
      if(cmd.equals(Protocol.QUERY_DB_COMMAND)) {
        getDbInfo(writer);
      } else if(cmd.equals(Protocol.QUERY_GUIDS_COMMAND)) {
        getGuidList(writer);
      } else if(cmd.equals(Protocol.QUERY_HQL_COMMAND)) {
        getSelectOutput(writer, data, true);
        writer.write(S_FINISH);
      } else if(cmd.equals(Protocol.QUERY_SQL_COMMAND)) {
        getSelectOutput(writer, data, false);
        writer.write(S_FINISH);
      } else if(cmd.equals(Protocol.QUERY_INSTANCE_COMMAND)) {
        getInstance(writer, data);
        writer.write(S_FINISH);
      } else if(cmd.equals(Protocol.QUERY_SERIES_COMMAND)) {
        getSeriesInstances(writer, data);
        writer.write(S_FINISH);
      } else if(cmd.equals(Protocol.QUERY_SUITE_COMMAND)) {
        getLatestInstancesForSuite(writer, data);
        writer.write(S_FINISH);
      }
    } catch(Exception e) {
      e.printStackTrace();
      throw e;
    }

  }

  /**
   * Return XML that represents the structure of the database.
   *
   * @param writer Writer to the remote process making the request
   * @throws Exception
   */
  private void getDbInfo(ProtocolWriter writer) throws Exception {
    StringBuffer response = new StringBuffer("<incadb>\n");
    Map metadata = HibernateUtil.getSessionFactory().getAllClassMetadata();
    String[] names = (String [])metadata.keySet().toArray(new String[0]);
    for(int i = 0; i < names.length; i++) {
      String name = names[i];
      response.append("  <dbclass>\n    <name>").
               append(name.replaceAll(".*\\.", "")).append("</name>\n");
      String[] properties =
        ((ClassMetadata)metadata.get(name)).getPropertyNames();
      for(int j = 0; j < properties.length; j++) {
        name = properties[j];
        // For client convenience, lie about how the Report body is stored
        if(name.equals("bodypart1")) {
          name = "body";
        } else if(name.equals("bodypart2") || name.equals("bodypart3")) {
          continue;
        }
        response.append("    <field>\n      <name>").append(name).
                 append("</name>\n    </field>\n");
      }
      response.append("  </dbclass>\n");
    }
    response.append("</incadb>");
    writer.write(Statement.getOkStatement(response.toString()));
  }

  /**
   * Return a list of the Suite guids in the database.
   *
   * @param writer Writer to the remote process making the request
   * @throws Exception
   */
  private void getGuidList(ProtocolWriter writer) throws Exception {
    List suites = DAO.selectMultiple("select s from Suite as s", null);
    String[] guids = new String[suites.size()];
    for(int i = 0; i < guids.length; i++) {
      guids[i] = ((Suite)suites.get(i)).getGuid();
    }
    writer.write(Statement.getOkStatement(StringMethods.join("\n", guids)));
  }

  /**
   * Return a report details document to the client for the given report
   * instance and configuration.
   *
   * @param writer  Writer to the remote process making the request.
   * @param request The instance query request which contains the
   * instance id, followed by a space, and then the report series configuration
   * id.
   *
   * @throws PersistenceException on a failed lookup
   * @throws Exception
   */
  private void getInstance(ProtocolWriter writer, String request)
    throws Exception {
    String[] pieces = request.split(" ");
    Long instanceId = null, configId = null;
    if(pieces.length != 2) {
      throw new ProtocolException
        ("Expected 'instanceId configId', got '" + request + "'");
    }
    try {
      instanceId = Long.valueOf(pieces[0]);
      configId = Long.valueOf(pieces[1]);
    } catch(NumberFormatException e) {
      throw new ProtocolException("Non-numeric id in '" + request + "'");
    }
    SeriesConfig sc = SeriesConfigDAO.load(configId);
    InstanceInfo ii = InstanceInfoDAO.load(instanceId);
    if(sc == null) {
      throw new PersistenceException("Request for unknown config " + configId);
    } else if(ii == null) {
      throw new PersistenceException
        ("Request for unknown instance " + instanceId);
    }
    Report r = ReportDAO.load(ii.getReportId());
    String query = "select cr from ComparisonResult cr " +
                   "  where cr.reportId = " + r.getId() +
                   "  and cr.seriesConfigId = " + configId;
    ComparisonResult cr = (ComparisonResult)DAO.selectUnique(query, null);
    ReportDetailsDocument rdd = toBean(sc, r, ii, cr);
    String response = rdd.toString();
    writer.write(new Statement(Protocol.QUERY_RESULT, response));
  }

  /**
   * Return the output from an HQL/SQL query.
   *
   * @param writer  writer to the remote process making the request.
   * @param select the HQL/SQL select statement
   * @param isHql indicates whether the select is HQL or SQL
   * @throws Exception
   */
  private void getSelectOutput
    (ProtocolWriter writer, String select, boolean isHql) throws Exception {
    // Allow only query HQL/SQL, to avoid a client modifying tables
    if(!select.matches("(?i)^\\s*(SELECT|FROM)\\s.*$")) {
      throw new PersistenceException("Not a SELECT: " + select);
    }
    // Parse the column names from the select statement so that we can use them
    // as XML tags in the reply.  A token is a quoted literal, a name/number, a
    // paren, comma, or operator.  Take care not to treat comma in a function
    // invocation (e.g., concat(a,b) as terminating a column name.
    ArrayList names = new ArrayList();
    Matcher m = Pattern.compile
      ("'[^']*'|\"[^\"]\"|[\\w\\.\\-]+|[\\(\\),]|[^\\w\\(\\),]+\\s*").
      matcher(select.replaceFirst("(?i)^SELECT\\s+(DISTINCT\\s+)?", ""));
    int parenDepth = 0;
    String name = "";
    while(true) {
      m.find();
      String token = m.group().trim();
      if(parenDepth == 0 && token.matches("(?i)as")) {
        name = ""; // Use the subsequent AS name as the entire name
      } else if(parenDepth == 0 && (token.matches("(?i),|FROM"))) {
        name = name.replaceAll("[^\\w\\.\\-]", "_");
        names.add(name);
        name = "";
        if(!token.equals(",")) {
          break;
        }
      } else {
        name += token;
        if(token.equals("(")) {
          parenDepth++;
        } else if(token.equals(")")) {
          parenDepth--;
        }
      }
    }
    // For client convenience, automatic translate references to report body
    // into bodypart1||bodypart2||bodypart3
    select = select.replaceFirst("\\b[aA][sS]\\s+body\\b", "as xBODYx");
    while(true) {
      m = (Pattern.compile("\\b((\\w+)\\.)?body\\b")).matcher(select);
      if(!m.find()) {
        break;
      }
      String prefix = m.group(1) == null ? "" : m.group(1);
      select = select.substring(0, m.start()) +
               prefix + "bodypart1 || " +
               prefix + "bodypart2 || " +
               prefix + "bodypart3" +
               select.substring(m.end());
    }
    select = select.replaceFirst("xBODYx", "body");
    // Make the query
    Session session = HibernateUtil.getCurrentSession();
    List l = null;
    try {
      l = isHql ? session.createQuery(select).list() :
                  session.createSQLQuery(select).list();
    } catch(Exception e) {
      e.printStackTrace();
      throw new PersistenceException(e.toString());
    }
    // Send one response per row.  If the row is a PersistentObject (e.g.,
    // "select sc from SeriesConfig sc", then we can use its toXml() method to
    // translate it; otherwise, we'll have an object array which we'll
    // translate to XML using the parsed names above.
    for(int i = 0; i < l.size(); i++) {
      Object o = l.get(i);
      String xml = null;
      if(o instanceof PersistentObject) {
        xml = ((PersistentObject)o).toXml();
      } else {
        StringBuffer sb = new StringBuffer();
        Object[] values = null;
        try {
          values = (Object [])o;
        } catch(Exception e) {
          values = new Object[] {o};
        }
        sb.append("<object>\n");
        for(int j = 0; j < values.length; j++) {
          name = names.get(j) == null ? j + "" : (String)names.get(j);
          Object value = values[j];
          String s = value == null ? "null" :
            value instanceof PersistentObject?((PersistentObject)value).toXml():
            XmlWrapper.escape( value.toString() );
          sb.append("<").append(name).append(">").
             append(s).
             append("</").append(name).append(">\n");
        }
        sb.append("</object>");
        xml = sb.toString();
      }
      writer.write(new Statement(Protocol.QUERY_RESULT, xml));
    }
  }

  /**
   * Return a report details document to the requester for every instance of
   * a given series.
   *
   * @param writer  Writer to the remote process making the request.
   * @param request The query request that contains the SeriesConfig id.
   * @throws Exception
   */
  private void getSeriesInstances
    (ProtocolWriter writer, String request) throws Exception {
    SeriesConfig sc = null;
    String query = "select sc from SeriesConfig sc where sc.nickname = :p0";
    if(request.matches("^\\d+$")) {
      sc = SeriesConfigDAO.load(Long.valueOf(request));
    } else {
      sc = (SeriesConfig)DAO.selectUnique(query, new Object[] {request});
    }
    if(sc == null) {
      throw new PersistenceException("Request for unknown config " + request);
    }
    query = "select r, ii from Report r, InstanceInfo ii " +
            "where r.series = :p0 and ii.reportId = r.id " +
            "order by ii.collected";
    List results = DAO.selectMultiple(query, new Object[] {sc.getSeries()});
    Statement reply = new Statement(Protocol.QUERY_RESULT, null);
    for(int i = 0; i < results.size(); i++) {
      Object[] result = (Object [])results.get(i);
      Report r = (Report)result[0];
      InstanceInfo ii = (InstanceInfo)result[1];
      query = "select cr from ComparisonResult cr " +
              "  where cr.reportId = " + r.getId() +
              "  and cr.seriesConfigId = " + sc.getId();
      ComparisonResult cr = (ComparisonResult)DAO.selectUnique(query, null);
      ReportDetailsDocument rdd = toBean(sc, r, ii, cr);
      String str = rdd.toString();
      char[] chars = str.toCharArray();
      reply.setData(chars);
      writer.write(reply);
    }
  }

  /**
   * Return the latest report summaries for all series in a given suite.
   *
   * @param writer  Writer to the remote process making the request.
   * @param suiteGuid A suite GUID string.
   * @throws Exception
   */
  private void getLatestInstancesForSuite(
    ProtocolWriter writer, String suiteGuid) throws Exception {

    String query = "select s from Suite as s where s.guid = :p0";
    Suite suite = (Suite)DAO.selectUnique(query, new Object[] {suiteGuid});
    if(suite == null) {
      throw new PersistenceException("Suite " + suiteGuid + " not found in DB");
    }
    query = "select sc from SeriesConfig sc " +
            "where sc.suite = " + suite.getId() + " " +
              "and sc.deactivated <= sc.activated";
    List scs = DAO.selectMultiple(query, null);
    query = "select cr from SeriesConfig sc, ComparisonResult cr " +
            "where sc.suite = " + suite.getId() + " " +
              "and sc.deactivated <= sc.activated " +
              "and sc.latestComparisonId = cr.id";
    List results = DAO.selectMultiple(query, null);
    Hashtable comparisons = new Hashtable();
    for(int i = 0; i < results.size(); i++) {
      ComparisonResult cr = (ComparisonResult)results.get(i);
      comparisons.put(cr.getId(), cr);
    }
    query = "select ii from SeriesConfig sc, InstanceInfo ii " +
            "where sc.suite = " + suite.getId() + " " +
              "and sc.deactivated <= sc.activated " +
              "and sc.latestInstanceId = ii.id";
    results = DAO.selectMultiple(query, null);
    Hashtable instances = new Hashtable();
    for(int i = 0; i < results.size(); i++) {
      InstanceInfo ii = (InstanceInfo)results.get(i);
      instances.put(ii.getId(), ii);
    }
    query = "select r from SeriesConfig sc, InstanceInfo ii, Report r " +
            "where sc.suite = " + suite.getId() + " " +
              "and sc.deactivated <= sc.activated " +
              "and sc.latestInstanceId = ii.id " +
              "and ii.reportId = r.id";
    results = DAO.selectMultiple(query, null);
    Hashtable reports = new Hashtable();
    for(int i = 0; i < results.size(); i++) {
      Report r = (Report)results.get(i);
      reports.put(r.getId(), r);
    }

    // loop through each item in the list and turn it into a BasicResult
    Statement reply = new Statement(Protocol.QUERY_RESULT, null);
    for(int i = 0; i < scs.size(); i++) {
      SeriesConfig sc = (SeriesConfig)scs.get(i);
      ComparisonResult cr =
        (ComparisonResult)comparisons.get(sc.getLatestComparisonId());
      InstanceInfo ii = (InstanceInfo)instances.get(sc.getLatestInstanceId());
      Report r = ii == null ? null : (Report)reports.get(ii.getReportId());
      ReportSummaryDocument rsd = toBean(sc, cr, ii, r);
      String s = rsd.toString();
      char[] chars = s.toCharArray();
      reply.setData(chars);
      writer.write(reply);
    }
  }

  /**
   * Creates a ReportDetailsDocument by copying fields from a DB SeriesConfig,
   * a DB report, and a DB InstanceInfo.
   *
   * @param sc the SeriesConfig for the document
   * @param r the Report for the document
   * @param ii the latest InstanceInfo for the document
   * @param cr the latest ComparisonResult for the document
   */
  protected static ReportDetailsDocument toBean
    (SeriesConfig sc, Report r, InstanceInfo ii, ComparisonResult cr)
    throws PersistenceException {
    ReportDetailsDocument result =
      ReportDetailsDocument.Factory.newInstance();
    ReportDetails rd = result.addNewReportDetails();
    rd.setSuiteId(sc.getSuite().getId().longValue());
    rd.setSeriesConfigId(sc.getId().longValue());
    rd.setSeriesId(r.getSeries().getId().longValue());
    rd.setReportId(r.getId().longValue());
    rd.setInstanceId(ii.getId().longValue());
    rd.setSeriesConfig((edu.sdsc.inca.dataModel.util.SeriesConfig)sc.toBean());
    rd.setReport((edu.sdsc.inca.dataModel.util.Report)r.toBean());
    // Note: apparently getGmt() returns a copy, so the following doesn't work
    //rd.getReport().getGmt().setTime(ii.getCollected());
    GregorianCalendar gmt = new GregorianCalendar();
    gmt.setTime(ii.getCollected());
    rd.getReport().setGmt(gmt);
    String log = ii.getLog();
    if(log != null && !log.equals("") &&
       !log.equals(PersistentObject.DB_EMPTY_STRING)) {
      try {
        rd.getReport().setLog(Log.Factory.parse(log));
      } catch(Exception e) {
        logger.error("Unable to parse log stored in DB:", e);
      }
    }
    if(cr != null) {
      rd.setComparisonResult(cr.getResult());
    }
    rd.setSysusage((edu.sdsc.inca.dataModel.util.Limits)ii.toBean());
    rd.setStderr(r.getStderr());
    return result;
  }

  /**
   * Creates a ReportSummaryDocument by copying fields from a DB SeriesConfig.
   *
   * @param sc the SeriesConfig for the document
   * @param cr the latest comparison result for sc
   * @param ii the latest instance info for sc
   * @param r the latest report for sc
   */
  protected static ReportSummaryDocument toBean
    (SeriesConfig sc, ComparisonResult cr, InstanceInfo ii, Report r)
    throws PersistenceException {
    ReportSummaryDocument result = ReportSummaryDocument.Factory.newInstance();
    ReportSummaryDocument.ReportSummary summary = result.addNewReportSummary();
    Series s = sc.getSeries();
    summary.setHostname(s.getResource());
    summary.setUri(s.getUri());
    summary.setNickname(sc.getNickname());
    summary.setSeriesConfigId(sc.getId().longValue());
    if(ii != null) {
      summary.setInstanceId(ii.getId().longValue());
      GregorianCalendar gmt = new GregorianCalendar();
      gmt.setTime(ii.getCollected());
      summary.setGmt(gmt);
    }
    if(r != null) {
      String bodyText = r.getBody();
      try {
        summary.setBody(AnyXmlSequence.Factory.parse(bodyText));
      } catch(XmlException e) {
        // empty
      }
      summary.setErrorMessage(r.getExit_message());
    }
    if(cr != null) {
      summary.setComparisonResult(cr.getResult());
    }
    return result;
  }

}
