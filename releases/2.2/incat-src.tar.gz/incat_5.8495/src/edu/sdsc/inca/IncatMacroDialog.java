package edu.sdsc.inca;

import edu.sdsc.inca.protocol.Protocol;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Box;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;

/**
 * A Dialog window that allows the user to edit a macro name and value.
 */
public class IncatMacroDialog extends JDialog
  implements ActionListener, DocumentListener {

  protected JTextField name;
  protected ActionListener listener;
  protected JTextField valueEdit;
  protected IncatList valueList;

  /**
   * Constructs an IncatMacroDialog.
   *
   * @param listener the listener to invoke when OK or cancel is pressed
   * @param okCommand the command to send when OK is pressed
   * @param cancelCommand the command to send when Cancel is pressed
   */
  public IncatMacroDialog(ActionListener listener,
                          String okCommand,
                          String cancelCommand) {
    this.name = IncatComponents.JTextFieldFactory(15, okCommand, this);
    this.valueEdit = IncatComponents.JTextFieldFactory(30, "valueAdd", this);
    this.valueEdit.getDocument().addDocumentListener(this);
    this.valueList = new IncatList("Value(s)", "value", "Add,Delete", this);
    Box nameBox = IncatComponents.BoxFactory(new JComponent[] {
      this.name, null,
      new JLabel("Macro Name *"), null,
    }, false);
    Box valueBox = IncatComponents.BoxFactory(new JComponent[] {
      this.valueEdit, null,
      this.valueList, null,
    }, false);
    IncatComponents.alignBoxHeights(new Box[] {nameBox, valueBox});
    this.setContentPane(IncatComponents.BoxFactory(new JComponent[] {
      nameBox, valueBox, null,
      IncatComponents.BoxFactory(new JComponent[] {
        IncatComponents.JButtonFactory("Cancel", cancelCommand, listener),
        IncatComponents.JButtonFactory("Ok", okCommand, this)
      }, false)
    }, false));
    this.setTitle("Incat Macro Dialog");
    this.pack();
    this.listener = listener;
  }

  /**
   * Returns the macro name.
   *
   * @return the macro name
   */
  public String getName() {
    return this.name.getText();
  }

  /**
   * Returns the macro values.
   *
   * @return the macro values
   */
  public String[] getValues() {
    String[] result = new String[this.valueList.getLength()];
    for(int i = 0; i < result.length; i++) {
      result[i] = (String)this.valueList.getElementAt(i);
    }
    return result;
  }

  /**
   * Sets the macro name.
   *
   * @param name the macro name
   */
  public void setName(String name) {
    this.name.setText(name);
    this.name.requestFocus();
  }

  /**
   * Sets the macro values.
   *
   * @param values the macro values
   */
  public void setValues(String[] values) {
    if(values == null || values.length == 0) {
      values = new String[] {""};
    }
    this.valueList.removeAllElements();
    for(int i = 0; i < values.length; i++) {
      this.valueList.addElement(values[i]);
    }
    this.valueList.setSelectedIndex(0);
    this.valueEdit.setText(values[0]);
    this.valueEdit.requestFocus();
  }

  /**
   * An action listener that checks for required fields on dialog exit.
   */
  public void actionPerformed(ActionEvent ae) {
    String command = ae.getActionCommand();
    if(command.equals("valueAdd")) {
      this.valueList.addElement("");
      this.valueList.setSelectedIndex(this.valueList.getLength() - 1);
      this.valueEdit.setText("");
      this.valueEdit.requestFocus();
    } else if(command.equals("valueDelete")) {
      int index = this.valueList.getSelectedIndex();
      if(index >= 0) {
        this.valueList.removeElementAt(index);
        if(this.valueList.getLength() == 0) {
          this.valueList.addElement("");
        }
        this.valueList.setSelectedIndex(index);
        this.valueEdit.setText((String)this.valueList.getSelectedElement());
      }
    } else if(command.equals("valueDoubleClick")) {
      // empty
    } else if(command.equals("valueEdit")) {
      String s = this.valueEdit.getText();
      int index = this.valueList.getSelectedIndex();
      if(index >= 0) {
        this.valueList.setElementAt(s, index);
        // NOTE: We could sort here, but it's visually weird to have the edit
        // element jump around in the list as its leading characters change
      }
    } else if(command.startsWith("valueFocus")) {
      // empty
    } else if(command.equals("valueSingleClick")) {
      this.valueEdit.setText((String)this.valueList.getSelectedElement());
      this.valueEdit.requestFocus();
    } else {
      if(this.getName().equals("")) {
        JOptionPane.showMessageDialog
          (this, "Please provide a macro name",
           "Incat Message", JOptionPane.ERROR_MESSAGE);
        return;
      } else if(!this.getName().matches("^"+Protocol.MACRO_NAME_PATTERN+"$")) {
        JOptionPane.showMessageDialog
          (this, "Invalid format for macro name",
           "Incat Message", JOptionPane.ERROR_MESSAGE);
        return;
      }
      this.listener.actionPerformed(ae);
    }
  }

  /**
   * Transforms document events into action events.
   */
  public void changedUpdate(DocumentEvent e) { }
  public void insertUpdate(DocumentEvent e) {
    this.actionPerformed(
      new ActionEvent(this.valueEdit,ActionEvent.RESERVED_ID_MAX+1,"valueEdit")
    );
  }
  public void removeUpdate(DocumentEvent e) {
    this.actionPerformed(
      new ActionEvent(this.valueEdit,ActionEvent.RESERVED_ID_MAX+1,"valueEdit")
    );
  }

}
