package edu.sdsc.inca.consumer.tag;

import junit.framework.TestCase;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.ConsumerTest;
import edu.sdsc.inca.util.ConfigProperties;
import edu.sdsc.inca.util.SuiteWrapper;

import org.apache.log4j.Logger;

import java.util.regex.Pattern;

/*
*
*  Test class for GetSuiteConfigs JSP tag
*
* @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
*/

public class GetSuiteConfigsTest extends TestCase {
  private static Logger logger = Logger.getLogger(GetSuiteConfigsTest.class);

  public void testGetSuiteConfigs() throws Exception {

    ConsumerTest.ConsumerTester tester = new ConsumerTest.ConsumerTester(1,2);
    try {
      SuiteWrapper suiteWrapper = new SuiteWrapper();
      tester.agent.setSuites(
        new String[] {suiteWrapper.getSuiteDocument().xmlText()}
      );

      tester.start();
      GetSuiteConfigs getSuiteConfigs = new GetSuiteConfigs();

      String suites = getSuiteConfigs.getSuiteConfigs();
      assertTrue(
        "Unnamed suite retrieved",
        Pattern.compile("Unnamed").matcher(suites).find()
      );
    } finally {
      tester.stop();
    }
  }


}
