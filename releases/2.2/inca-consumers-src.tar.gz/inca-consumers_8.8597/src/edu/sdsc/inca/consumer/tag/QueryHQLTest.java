package edu.sdsc.inca.consumer.tag;

import junit.framework.TestCase;
import org.apache.log4j.Logger;
import edu.sdsc.inca.ConsumerTest;
import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.util.StringMethods;
import edu.sdsc.inca.consumer.Queries;
import edu.sdsc.inca.consumer.CachedQueryTest;

import java.io.File;

/**
 * Test the functions used in the QueryHQL bean.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class QueryHQLTest extends TestCase {
  private static Logger logger = Logger.getLogger( QueryHQLTest.class );

  public void setUp() {
    File qDir = new File( "var/queries" );
    if ( qDir.exists() ) StringMethods.deleteDirectory(qDir);
    File qStore = new File( "var/queryStore.xml" );
    if ( qStore.exists() ) qStore.delete();
  }

  public void testNewline() throws Exception {
     String hql = "select\ns.id\nfrom\rSuite s";
     assertEquals
       ( "newlines replaced", "select s.id from Suite s",
         QueryHQL.normalizeQuery(hql) );
  }

  public void testQuery() throws Exception {
    ConsumerTest.ConsumerTester tester = new ConsumerTest.ConsumerTester(1, 4);
    tester.consumer.setCacheReloadPeriod( 20000 );
    tester.start();

    long startTime = Util.getTimeNow();

    // add cached and non-cached queries
    Queries queries = Consumer.getGlobalConsumer().getQueries();
    queries.add( "q1", "select id from suite" );
    queries.add( "q2", "select id from suite", 10 );
    Thread.sleep( 5000 );


    // verify non-cached query
    logger.debug( "Getting result 1" );
    long q1Result = CachedQueryTest.getAndVerifyResult
      ( queries.getQueryResult( "q1") );
    assertTrue( "query time 1 is good", q1Result > startTime );

    // verify cached query
    logger.debug( "Getting result 2" );
    long q2Result = CachedQueryTest.getAndVerifyResult
       ( queries.getQueryResult( "q2") );
     assertTrue( "query time 2 is good", q2Result > startTime );

    // verify hql query
    long q3Result = CachedQueryTest.getAndVerifyResult
      ( QueryHQL.getResultsAsXmlBean("select id from suite").xmlText() );
    assertTrue( "query time 3 is good", q3Result > startTime );

    logger.debug( "done" );

    tester.stop();
  }

}
