package edu.sdsc.inca.consumer;

import junit.framework.TestCase;
import org.apache.log4j.Logger;

import java.io.File;

import edu.sdsc.inca.ConsumerTest;
import edu.sdsc.inca.util.StringMethods;

/**
 * Test the class used to store queries.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class QueriesTest extends TestCase {
  private static Logger logger = Logger.getLogger( QueriesTest.class );
  private static File qsFile = new File( "var/qs.xml" );
  private static File qDir = new File( "var/queries" );


  /**
   * Delete any pre-existing files.
   */
  public void setUp() {
    if ( qsFile.exists() ) qsFile.delete();
    if ( qDir.exists() ) StringMethods.deleteDirectory( qDir );
  }

  /**
   * Verify persistence by adding a few queries and then reading them back
   *
   * @throws Exception
   */
  public void testPersistence() throws Exception {

    // queries
    String[] sql = {
      "select id from suite",
      "select id from seriesconfig"
    };
    String[] names = { "q1", "q2" };

    // add queries
    Queries queries = new Queries( qsFile.getAbsolutePath() );
    assertFalse( "no queries yet", queries.hasQuery( "q1") );
    assertEquals( "0 queries yet", 0, queries.list().length );
    for( int i = 0; i < names.length; i++ ) {
      queries.add( names[i], sql[i] );
    }

    // read the queries back and check entries
    Queries checkQueries = new Queries( "var/qs.xml" );
    for( int i = 0; i < names.length; i++ ) {
      assertTrue
        ("has query " + i, checkQueries.hasQuery( names[i]) );
      assertEquals
        ("got correct hql for " + i, sql[i], checkQueries.getHql( names[i]) );
    }
    String[] queryList = checkQueries.list();
    assertEquals( "correct list count", sql.length, queryList.length );
    for( int i = 0; i < sql.length; i++ ) {
      assertEquals( "list returned right for " + i, names[i], queryList[i] );
    }

    for( int i = 0; i < sql.length; i++ ) {
      checkQueries.delete( names[i] );
    }
    queryList = checkQueries.list();
    assertEquals( "correct list count", 0, queryList.length );
  }

  /**
   * Verify the ability to retrieve query results from non-cached and
   * cached queries.
   *
   * @throws Exception
   */
  public void testQueryCache() throws Exception {
    ConsumerTest.ConsumerTester tester = new ConsumerTest.ConsumerTester(1, 5);
    tester.consumer.setCacheReloadPeriod( 20000 );
    tester.start();

    //  verify ability to get fresh query
    Queries queries = new Queries( qsFile.getAbsolutePath() );
    queries.start();
    queries.add( "q1", "select id from suite" );
    long firstResult = CachedQueryTest.getAndVerifyResult
      ( queries.getQueryResult( "q1") );
    long secondResult = CachedQueryTest.getAndVerifyResult
      ( queries.getQueryResult( "q1") );
    assertTrue( "Results successfully retrieved", secondResult > firstResult );
    queries.stop();

    // verify ability to get cached query (fresh and not)
    queries.start();
    queries.add( "q2", "select id from suite", 5 );
    firstResult = CachedQueryTest.getAndVerifyResult
      ( queries.getQueryResult( "q2") );
    logger.debug( "Got cached result" );

    Thread.sleep(1000);
    logger.debug( "Getting cached result 2" );
    secondResult = CachedQueryTest.getAndVerifyResult
      ( queries.getQueryResult( "q2") );
    assertTrue( "Results successfully retrieved", secondResult == firstResult );
    Thread.sleep(5000);
    long thirdResult = CachedQueryTest.getAndVerifyResult
      ( queries.getQueryResult( "q2") );
    assertTrue( "Results successfully retrieved", thirdResult > firstResult );

    assertTrue( "query was deleted", queries.delete( "q2" ) );
    assertFalse( "verify query gone", queries.hasQuery("q2") );

    queries.stop();
    tester.stop();
  }

}
