package edu.sdsc.inca.consumer.dataproducer;

import de.laures.cewolf.DatasetProduceException;
import de.laures.cewolf.DatasetProducer;
import de.laures.cewolf.tooltips.XYToolTipGenerator;
import edu.sdsc.inca.dataModel.graphSeries.GraphInstance;
import org.apache.log4j.Logger;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import java.io.Serializable;
import java.util.*;
import java.util.regex.Pattern;

/**
 * A dataset producer for a cewolf histogram.  A histogram dataset
 * is created for each configID in a Hashtable and its
 * GraphInstance objects (the configID's value in the Hashtable).
 *
 * Example call from JSP:
 *
 * HistogramData histData = new HistogramData();
 * histData.setGraphInstanceHash(hash);
 * histData.setConfigIDs(configIDs);
 * histData.setSeriesLabels(seriesLabels);
 * histData.createHistogramDataset();
 * pageContext.setAttribute("histData", histData);
 * ...
 * <cewolf:data>
 *  <cewolf:producer id="histData"/>
 * </cewolf:data>
 *
 * @author  Kate Ericson
 */

public class HistogramData implements DatasetProducer,
    XYToolTipGenerator, Serializable  {

  private String[] configIDs;
  private double[][] errorCounts;
  private Hashtable graphInstanceHash;
  private XYSeriesCollection histogram;
  private static Logger logger = Logger.getLogger(TimeSeriesData.class);
  private String[] seriesLabels;
  private boolean showGraph = false;
  private Vector skipInstances;
  private String[][] tooltips;

  /**
   * Create a jfree histogram dataset of error counts appropriate to graph.
   * Store the results internally into the member variable collection
   */
  public void createHistogramDataset() {
    XYSeriesCollection hd = new XYSeriesCollection();
    int numConfigs = configIDs.length;

    // mouseover and error arrays for graph's image map and table
    tooltips = new String[numConfigs][];
    errorCounts = new double[numConfigs][];

    // process GraphInstance data for each configID
    for (int i=0; i < numConfigs; i++) {
      String configID = configIDs[i];
      GraphInstance[] gis = (GraphInstance[])graphInstanceHash.get(configID);
      Hashtable histHash = new Hashtable();
      // add GraphInstance data to this configID's histogram
      for (int j=0; j<gis.length; j++) {
        GraphInstance gi = gis[j];
        String errorMessage = gi.getExitMessage();
        String instance = gi.getInstanceId();
        // If the error message string isn't empty and the instance isn't
        // to be excluded from the graph, add to hash.
        // If the error message is in the hash already, increment message count.
        if (Pattern.matches(".*\\S.*", errorMessage) &&
            !skipInstances.contains(instance)){
          if (!histHash.containsKey(errorMessage)){
            histHash.put(errorMessage, new Integer(1));
          } else {
            Integer oldCount = (Integer)histHash.get(errorMessage);
            int newCount = oldCount.intValue() + 1;
            Integer count = new Integer(newCount);
            histHash.put(errorMessage, count);
          }
        }
      }
      // If the hash of error messages isn't empty, add it to the histogram.
      int hashSize = histHash.size();
      XYSeries series = new XYSeries(seriesLabels[i]);
      if (!histHash.isEmpty()){
        Enumeration enum = histHash.keys();
        Vector errsVector = new Vector();
        Vector dataVector = new Vector();
        while (enum.hasMoreElements ()) {
          String err = (String)enum.nextElement();
          errsVector.addElement(err);
          Integer count = (Integer)histHash.get(err);
          dataVector.addElement(count);
        }
        String[] errs = new String[hashSize];
        errs = (String[])errsVector.toArray(errs);
        Integer[] data = new Integer[hashSize];
        data = (Integer[])dataVector.toArray(data);
        double[] dataDouble = new double[hashSize];
        for (int d=0; d<hashSize; d++){
          dataDouble[d] = data[d].doubleValue();
          series.add(d+1, dataDouble[d]);
        }
        tooltips[i] = errs;
        errorCounts[i] = dataDouble;
        setShowGraph(true);
      } else {
        tooltips[i] = new String[]{""};
        errorCounts[i] = new double[]{0.0};
        series.add(0, 0.0);
      }
      hd.addSeries(series);
    }
    setHistogram(hd);
  }

  /**
   * Text to display when datapoint is moused over
   *
   * @param data  Jfree XYDataset object to add mouseover text to.
   *
   * @param series  Integer for the jfree chart series to add mouseover text to.
   *
   * @param item  Integer for the item to add mouseover text to
   *              (e.g. a histogram bar).
   *
   * @return  Mouseover text string
   */
  public String generateToolTip(XYDataset data, int series, int item) {
    return tooltips[series][item];
  }

  /**
   * Get a string array of configIDs (used for ordering the hashtable)
   */
  public String[] getConfigIDs() {
    return configIDs;
  }

  /**
   * Get error counts for each of the configID's error messages
   */
  public double[][] getErrorCounts() {
    return errorCounts;
  }

  /**
   * Return a hash of configIDs and their associated GraphInstance objects
   * (one for each instance in the configID's history).
   *
   * @return A hash of configIDs and their associated GraphInstance objects.
   */
  public Hashtable getGraphInstanceHash() {
    return graphInstanceHash;
  }

  /**
   * Return a histogram dataset of error messages and their frequencies.
   *
   * @return A histogram dataset of error messages and their frequencies.
   */
  public XYSeriesCollection getHistogram() {
    return histogram;
  }

  /**
   * Returns a unique ID for this DatasetProducer
   */
  public String getProducerId() {
    return "inca histogram";
  }

  /**
   * Return array of labels used for each configID in the graph legend.
   *
   * @return Array of labels used for each configID in the graph legend.
   */
  public String[] getSeriesLabels() {
    return seriesLabels;
  }

  /**
   * Vector of instanceIDs to exclude from graph.
   *
   */
  public Vector getSkipInstances() {
    return skipInstances;
  }

  /**
   * Return array of mouseover text that corresponds to an array of configIDs.
   *
   * @return Array of mouseover text that corresponds to an array of configIDs.
   */
  public String[][] getTooltips() {
    return tooltips;
  }

  /**
   * This method influences Cewolf's caching behaviour.
   *
   * Example of invalid data after a day (86,400 seconds):
   *   log.debug(getClass().getName() + "hasExpired()");
   *   return (System.currentTimeMillis() - since.getTime()) > 86400000;
   */
  public boolean hasExpired(Map params, Date since) {
    return true;
  }

  /**
   * Create jfree histogram dataset of error message counts from
   * a set of GraphInstance objects.
   *
   * @param params  Additional params for the dataset production.
   *                All elements of this HashMap are of type
   *                java.io.Serializable.
   *
   * @return jfree  A jfree HistogramDataset object
   *                with error message counts.
   *
   * @throws DatasetProduceException
   */
  public Object produceDataset(Map params) throws DatasetProduceException {
    return this.getHistogram();
  }

  /**
   * Set a string array of configIDs (used for ordering the hashtable)
   *
   * @param configIDs   An array of configIDs for ordering the hashtable
   */
  public void setConfigIDs(String[] configIDs) {
    this.configIDs = configIDs;
  }

  /**
   * Set error counts for each of the configID's error messages
   *
   * @param errorCounts An array of error counts for each configID.
   */
  public void setErrorCounts(double[][] errorCounts) {
    this.errorCounts = errorCounts;
  }

  /**
   * Set a hash of configIDs and their associated GraphInstance objects
   * (one for each instance in the configID's history).
   *
   * @param graphInstanceHash    A hash of configIDs and their
   *                             associated GraphInstance objects.
   */
  public void setGraphInstanceHash(Hashtable graphInstanceHash) {
    this.graphInstanceHash = graphInstanceHash;
  }

  /**
   * Set a histogram dataset of error messages and their frequencies.
   *
   * @param histogram     A histogram dataset of error messages
   *                      and their frequencies.
   */
  public void setHistogram(XYSeriesCollection histogram) {
    this.histogram = histogram;
  }

  /**
   * Set array of labels used for each configID in the graph legend.
   *
   * @param seriesLabels    Array of labels used for each configID
   *                        in the graph legend.
   */
  public void setSeriesLabels(String[] seriesLabels) {
    this.seriesLabels = seriesLabels;
  }

  /**
   * Set boolean for jsp to show bar graph if there are error messages to graph.
   *
   * @param showGraph     Boolean for jsp to show bar graph
   *                     if there are error messages to graph.
   */
  public void setShowGraph(boolean showGraph) {
    this.showGraph = showGraph;
  }

  /**
   * Set vector of instanceIDs to exclude from graph.
   *
   * @param skipInstances    Vector of instanceIDs to exclude from graph.
   */
  public void setSkipInstances(Vector skipInstances) {
    this.skipInstances = skipInstances;
  }

  /**
   * Set array of mouseover text that corresponds to an array of configIDs.
   *
   * @param tooltips    Array of mouseover text that corresponds
   *                    to an array of configIDs.
   */
  public void setTooltips(String[][] tooltips) {
    this.tooltips = tooltips;
  }

  /**
   * Boolean for jsp to show bar graph if there are error messages to graph.
   */
  public boolean showGraph() {
    return showGraph;
  }

  /**
   * @see java.lang.Object#finalize()
   */
  protected void finalize() throws Throwable {
    super.finalize();
    logger.debug(this + " finalized.");
  }

}
