package edu.sdsc.inca.consumer;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlOptions;
import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.dataModel.queryResults.ObjectDocument;
import edu.sdsc.inca.consumer.tag.QueryHQL;
import edu.sdsc.inca.consumer.tag.Util;
import edu.sdsc.inca.util.StringMethods;
import edu.sdsc.inca.util.XmlWrapper;

import java.io.File;
import java.io.IOException;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * Handles the prefetching and caching of HQL queries to the depot.  The HQL
 * queries allow users to request customized data from the depot.  In the
 * event that a query takes a long time to load, this class can be used
 * to continuously query results from the depot and store them.  The advantage
 * of this is that whenever requests are made on the consumer for the data,
 * the latest cached data can be returned immediately rather than waiting for
 * the lengthy query to complete.  Furthermore, it will reduce the load on the
 * consumer and depot.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class CachedQuery extends Thread {
  private static Logger logger = Logger.getLogger( CachedQuery.class );
  public static String QUERYDIR = "queries";


  private File resultFile = null;
  private String hql = null;
  private String name = null;
  private int period = 0; // seconds


  /**
   * Create a new cache query thread for the specified query.
   *
   * @param name   The name of the query (may contain whitespace)
   * @param hql    The HQL query string to be sent to the depot
   * @param period  The frequency of which the consumer should prefetch the
   *                query (seconds)
   */
  public CachedQuery( String name, String hql, int period ) {
    this.setQueryName( name );
    this.setHql( hql );
    this.setPeriod( period );
  }

  /**
   * Return the handle of the file used to store the query result.
   *
   * @return The file handle to the query result.
   */
  public File getCacheFile() {
    return resultFile;
  }

  /**
   * Return the HQL query string being used to fetch data from the depot.
   *
   * @return A string containing a HQL query.
   */
  public String getHql() {
    return hql;
  }

  /**
   * Returns the frequency of queries to the depot.
   *
   * @return The number of seconds used to wait before querying the depot again.
   */
  public float getPeriod() {
    return period / 1000;
  }

  /**
   * Returns the name of the query.
   *
   * @return  A string containing the name of the HQL query.
   */
  public String getQueryName() {
    return name;
  }

  /**
   * Returns the latest result of the query stored in the file cache.  Does
   * a synchronized read of the data from file and returns it.
   *
   * @return  An XML document containing the results of the query or null if
   * nothing has been cached yet or there are problems reading the file from
   * disk.
   */
  public synchronized String getResult() {
    if ( ! resultFile.exists() ) {
      return null;
    }
    try {
      return StringMethods.fileContents( resultFile.getAbsolutePath() );
    } catch ( IOException e ) {
      logger.error( "Problem reading cached query " + name + " from disk", e );
      return null;
    }
  }

  public synchronized String getResultOrWait() throws InterruptedException {
    String result = null;
    while ( (result=this.getResult()) == null ) {
      logger.debug( "Waiting for result of query " + name );
      this.wait();
    }
    logger.debug( "Result of query " + name + " received" );
    return result;
  }



  /**
   * Will first check to see if there is a result already stored on disk and
   * if so, will check to see how fresh it is.  If the result is younger than
   * the refresh period, we will wait until it has expired before querying
   * the depot.  Once the first query is made, this thread will continously
   * query until it receives an interrupt.
   */
  public void run() {
    logger.debug( "Starting cache thread for query " + name );
    long age = Util.getTimeNow() - resultFile.lastModified();
    if ( age < period ) {
      logger.debug( "Cached query for " + name + " is up to date; sleeping " +
                    (period - age) + " millis" );
      try {
        Thread.sleep( period - age );
      } catch ( InterruptedException e ) {
        logger.info( "Cached query thread for " + name + " exitting" );
        return;
      }
    }
    while ( ! Thread.interrupted() ) {
      try {
        long queryStart = Util.getTimeNow();
        ObjectDocument result = QueryHQL.getResultsAsXmlBean( hql );
        long lastCacheTime = (Util.getTimeNow() - queryStart)/1000;
        logger.info
          ( "Query time for " + name + " = " + lastCacheTime + " secs" );
        synchronized ( this ) {
          result.save( resultFile, XmlWrapper.getPrettyPrintOptions() );
          this.notifyAll();
        }
        logger.info( "New query result for " + name + " stored in " +
                     resultFile.getAbsolutePath() );
      } catch ( Exception e ) {
        logger.error( "Error retrieving query " + name, e );
      } finally {
        logger.debug(
          "Cache thread for query " + name + " sleeping " + period + " millis"
        );
        try {
          Thread.sleep( period );
        } catch ( InterruptedException e ) {
          logger.info( "Interrupting cache thread for query " + name );
          break;
        }

      }
    }
    logger.debug( "Exitting cache thread for query " + name );
  }

  /**
   * Set the HQL query string being used to fetch data from the depot.
   *
   * @param hql   A string containing a HQL query.
   */
  public void setHql( String hql ) {
    this.hql = hql;
  }

  /**
   * Set the frequency of queries to the depot.
   *
   * @param period Set the number of seconds used to wait before querying the
   * depot again.
   */
  public void setPeriod( int period ) {
    this.period = period * 1000;
  }

  /**
   * Set the name of the query.
   *
   * @param name  A string containing the name of the HQL query.
   */
  public void setQueryName( String name ) {
    this.name = name;
    Pattern space = Pattern.compile( "\\s" );
    Matcher matcher = space.matcher( name );
    String filename = matcher.replaceAll( "_" );
    File queryDir = new File
      (Consumer.getGlobalConsumer().getTempPath() + File.separator + QUERYDIR);
    if ( ! queryDir.exists() ) queryDir.mkdirs();
    this.resultFile = new File
      ( queryDir.getAbsolutePath() + File.separator + filename + ".xml" );
    logger.debug
      ( "Query results for " + name + " at " + resultFile.getAbsolutePath() );
  }

}
