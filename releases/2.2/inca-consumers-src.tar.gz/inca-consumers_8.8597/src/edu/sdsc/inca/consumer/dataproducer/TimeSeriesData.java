package edu.sdsc.inca.consumer.dataproducer;

import de.laures.cewolf.DatasetProduceException;
import de.laures.cewolf.DatasetProducer;
import de.laures.cewolf.links.XYItemLinkGenerator;
import de.laures.cewolf.tooltips.XYToolTipGenerator;
import edu.sdsc.inca.consumer.tag.Util;
import edu.sdsc.inca.dataModel.graphSeries.GraphInstance;
import edu.sdsc.inca.util.StringMethods;
import org.apache.log4j.Logger;
import org.jfree.data.time.Minute;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;

import java.io.Serializable;
import java.util.*;
import java.util.regex.Pattern;

/**
 * A dataset producer for a timeseries cewolf chart.  A dataset (corresponding
 * to a line on the graph) is created for each configID in a Hashtable and its
 * GraphInstance objects (the configID's value in the Hashtable).
 *
 * Example call from JSP:
 *
 * TimeSeriesData data = new TimeSeriesData();
 * data.setGraphInstanceHash(hash);
 * data.setConfigIDs(configIDs);
 * data.setSeriesLabels(seriesLabels);
 * data.createTimeSeriesCollection();
 * pageContext.setAttribute("data", data);
 * ...
 * <cewolf:data>
 *  <cewolf:producer id="data"/>
 * </cewolf:data>
 *
 * @author  Kate Ericson
 */

public class TimeSeriesData implements DatasetProducer,
    XYToolTipGenerator, XYItemLinkGenerator, Serializable  {

  private TimeSeriesCollection collection;
  private String[] configIDs;
  private Hashtable graphInstanceHash;
  private String[][] links;
  private static Logger logger = Logger.getLogger(TimeSeriesData.class);
  private String[] seriesLabels;
  private int[] seriesPercPass;
  private int[] seriesTotalFail;
  private int[] seriesTotalPass;
  private Vector skipInstances = new Vector();
  private String[][] tooltips;

  /**
   * Create a jfree dataset of pass/fail statuses and
   * timestamps appropriate to graph.  Store the results internally
   * into the member variable collection
   */
  public void createTimeSeriesCollection() {
    long startTime = Util.getTimeNow();
    int numConfigs = configIDs.length;

    // create new timeseries *collection* for multiple sets of x,y data
    TimeSeriesCollection tsc = new TimeSeriesCollection();

    // mouseover and href arrays for graph's image map
    tooltips = new String[numConfigs][];
    links = new String[numConfigs][];

    // pass/fail totals for series
    seriesTotalPass = new int[numConfigs];
    seriesPercPass = new int[numConfigs];
    seriesTotalFail = new int[numConfigs];

    // process data for each configID
    for (int i=0; i < numConfigs; i++) {
      String configID = configIDs[i];
      GraphInstance[] gis = (GraphInstance[])graphInstanceHash.get(configID);
      // create timeseries for this configID
      TimeSeries ts = new TimeSeries(seriesLabels[i], Minute.class);
      Vector tooltipsVector = new Vector();
      Vector linksVector = new Vector();
      int seriesPass = 0;
      int seriesFail = 0;
      // add data to this configID's time series
      for (int j=0; j<gis.length; j++) {
        GraphInstance gi = gis[j];
        Date date = StringMethods.convertDateString(gi.getCollected(),
            "yyyy-MM-dd HH:mm:ss.S");
        int ts_result = addInstanceToTimeSeries(gi, ts, date, skipInstances);
        if (ts_result == 1){
          seriesPass++;
        }
        if (ts_result == 0){
          seriesFail++;
        }
        if (ts_result != -1){
          String errorMessage = gi.getExitMessage();
          tooltipsVector.addElement( errorMessage +
              " (" + date.toString() + ")");
          linksVector.addElement( "xslt.jsp?xsl=instance.xsl&instanceID="+
              gi.getInstanceId() + "&configID="+ configID );
        }
      }
      seriesTotalPass[i] = seriesPass;
      seriesTotalFail[i] = seriesFail;
      float percPass =  (float)seriesPass/(seriesPass+seriesFail)*100;
      seriesPercPass[i] = (int)percPass;
      // add this configID's time series to the collection
      tsc.addSeries(ts);
      tooltips[i] = new String [ts.getItemCount()];
      tooltips[i] = (String[]) tooltipsVector.toArray(tooltips[i]);
      links[i] = new String [ts.getItemCount()];
      links[i] = (String[]) linksVector.toArray(links[i]);
    }
    setCollection(tsc);
    Util.printElapsedTime( startTime, "GRAPH: total time" );
  }

  /**
   * Hyperlink for datapoint
   *
   * @param data  Jfree Dataset object to add href to.
   *
   * @param series  Integer for the jfree chart series to link.
   *
   * @param item  Integer for the item to add href to
   *              (e.g. an XY point in a chart series).
   *
   * @return  Hyperlink string
   */
  public String generateLink(Object data, int series, int item) {
    return links[series][item];
  }

  /**
   * Text to display when datapoint is moused over
   *
   * @param data  Jfree XYDataset object to add mouseover text to.
   *
   * @param series  Integer for the jfree chart series to add mouseover text to.
   *
   * @param item  Integer for the item to add mouseover text to
   *              (e.g. an XY point in a chart series).
   *
   * @return  Mouseover text string
   */
  public String generateToolTip(XYDataset data, int series, int item) {
    return tooltips[series][item];
  }

  /**
   * Return a TimeSeriesCollection with timestamp/value data for each configID.
   *
   * @return TimeSeriesCollection with timestamp/value data for each configID.
   */
  public TimeSeriesCollection getCollection() {
    return collection;
  }

  /**
   * Get a string array of configIDs (used for ordering the hashtable)
   */
  public String[] getConfigIDs() {
    return configIDs;
  }

  /**
   * Return a hash of configIDs and their associated GraphInstance objects
   * (one for each instance in the configID's history).
   *
   * @return A hash of configIDs and their associated GraphInstance objects.
   */
  public Hashtable getGraphInstanceHash() {
    return graphInstanceHash;
  }


  /**
   * Return array of hyperlinks that corresponds to an array of configIDs.
   *
   * @return Array of hyperlinks that corresponds to an array of configIDs.
   */
  public String[][] getLinks() {
    return links;
  }

  /**
   * Returns a unique ID for this DatasetProducer
   */
  public String getProducerId() {
    return "inca timeseries";
  }

  /**
   * Return array of labels used for each configID in the graph legend.
   *
   * @return Array of labels used for each configID in the graph legend.
   */
  public String[] getSeriesLabels() {
    return seriesLabels;
  }

  /**
   * Return percentage of tests passed for each configID being graphed.
   *
   * @return Percentage of tests passed for each configID being graphed.
   */
  public int[] getSeriesPercPass() {
    return seriesPercPass;
  }

  /**
   * Return total tests failed for each configID being graphed.
   *
   * @return Total tests failed for each configID being graphed.
   */
  public int[] getseriesTotalFail() {
    return seriesTotalFail;
  }

  /**
   * Return total tests passed for each configID being graphed.
   *
   * @return Total tests passed for each configID being graphed.
   */
  public int[] getseriesTotalPass() {
    return seriesTotalPass;
  }

  /**
   * Vector of instanceIDs to exclude from graph.
   *
   */
  public Vector getSkipInstances() {
    return skipInstances;
  }

  /**
   * Return array of mouseover text that corresponds to an array of configIDs.
   *
   * @return Array of mouseover text that corresponds to an array of configIDs.
   */
  public String[][] getTooltips() {
    return tooltips;
  }

  /**
   * This method influences Cewolf's caching behaviour.
   *
   * Example of invalid data after a day (86,400 seconds):
   *   log.debug(getClass().getName() + "hasExpired()");
   *   return (System.currentTimeMillis() - since.getTime()) > 86400000;
   */
  public boolean hasExpired(Map params, Date since) {
    return true;
  }

  /**
   * Create jfree dataset of pass/fail statuses and timestamps from
   * a set of GraphInstance objects.
   *
   * @param params  Additional params for the dataset production.
   *                All elements of this HashMap are of type
   *                java.io.Serializable.
   *
   * @return jfree  A jfree TimeSeriesCollection object
   *                with data and timeestamps.
   *
   * @throws DatasetProduceException
   */
  public Object produceDataset(Map params) throws DatasetProduceException {
    return this.getCollection();
  }

  /**
   * Set a TimeSeriesCollection with timestamp/value data for each configID.
   *
   * @param collection  TimeSeriesCollection with timestamp/value data
   *                    for each configID.
   */
  public void setCollection(TimeSeriesCollection collection) {
    this.collection = collection;
  }

  /**
   * Set a string array of configIDs (used for ordering the hashtable)
   *
   * @param configIDs   An array of configIDs for ordering the hashtable
   */
  public void setConfigIDs(String[] configIDs) {
    this.configIDs = configIDs;
  }

  /**
   * Set a hash of configIDs and their associated GraphInstance objects
   * (one for each instance in the configID's history).
   *
   * @param graphInstanceHash    A hash of configIDs and their
   *                          associated GraphInstance objects.
   */
  public void setGraphInstanceHash(Hashtable graphInstanceHash) {
    this.graphInstanceHash = graphInstanceHash;
  }

  /**
   * Set array of hyperlinks that corresponds to an array of configIDs.
   *
   * @param links   Array of hyperlinks that corresponds
   *                to an array of configIDs.
   */
  public void setLinks(String[][] links) {
    this.links = links;
  }

  /**
   * Set array of labels used for each configID in the graph legend.
   *
   * @param seriesLabels    Array of labels used for each configID
   *                        in the graph legend.
   */
  public void setSeriesLabels(String[] seriesLabels) {
    this.seriesLabels = seriesLabels;
  }

  /**
   * Set percentage of tests passed for each configID being graphed.
   *
   * @param seriesPercPass    Percentage of tests passed
   *                          for each configID being graphed.
   */
  public void setSeriesPercPass(int[] seriesPercPass) {
    this.seriesPercPass = seriesPercPass;
  }

  /**
   * Set total tests failed for each configID being graphed.
   *
   * @param seriesTotalFail   Total tests failed
   *                          for each configID being graphed.
   */
  public void setseriesTotalFail(int[] seriesTotalFail) {
    this.seriesTotalFail = seriesTotalFail;
  }

  /**
   * Set total tests passed for each configID being graphed.
   *
   * @param seriesTotalPass   Total tests passed
   *                          for each configID being graphed.
   */
  public void setseriesTotalPass(int[] seriesTotalPass) {
    this.seriesTotalPass = seriesTotalPass;
  }

  /**
   * Set vector of instanceIDs to exclude from graph.
   *
   * @param skipInstances    Vector of instanceIDs to exclude from graph.
   */
  public void setSkipInstances(Vector skipInstances) {
    this.skipInstances = skipInstances;
  }

  /**
   * Set array of mouseover text that corresponds to an array of configIDs.
   *
   * @param tooltips    Array of mouseover text that corresponds
   *                    to an array of configIDs.
   */
  public void setTooltips(String[][] tooltips) {
    this.tooltips = tooltips;
  }

  /**
   * @see java.lang.Object#finalize()
   */
  protected void finalize() throws Throwable {
    super.finalize();
    logger.debug(this + " finalized.");
  }

  /**
   * Add values from a GraphInstance object to a TimeSeries object.
   *
   * @param gi  GraphInstance object
   *
   * @param ts  Jfree TimeSeries object
   *
   * @param date  Date object
   */
  private int addInstanceToTimeSeries(GraphInstance gi, TimeSeries ts,
                                      Date date, Vector skipInstances){
    int result;
    String cr = gi.getComparisonResult();
    String pass = "^Success.*$";
    String fail = "^Failure.*$";
    if (cr != null && Pattern.matches(pass, cr)){
      result = 1;
    }else if (cr != null && Pattern.matches(fail, cr)){
      result = 0;
    }else{
      boolean exitStatus = gi.getExitStatus();
      result = (new Boolean(exitStatus).booleanValue())?1:0;
    }
    try{
      // add x,y data to this timeseries (x=date, y=exitStatus)
      ts.add(new Minute(date), result);
    } catch(Exception e) {
      result = -1;
      skipInstances.addElement(gi.getInstanceId());
    }
    return result;
  }

}