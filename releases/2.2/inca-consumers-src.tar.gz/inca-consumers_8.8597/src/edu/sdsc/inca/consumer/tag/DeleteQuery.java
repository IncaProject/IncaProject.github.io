package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;

import org.apache.log4j.Logger;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.consumer.Queries;

/**
 * Jsp tag to deleted a named query from the Inca data consumer.
 *
 * Required parameter: name
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class DeleteQuery extends TagSupport {
  private static Logger logger = Logger.getLogger( DeleteQuery.class );
  private String name = null;

  public int doEndTag(){
    return EVAL_PAGE;
  }

  /**
   * Called when the jsp tag is referenced in a JSP document.
   * Will return string containing true if the delete is successful or an error
   * in the supplied var attribute.
   *
   * @return SKIP_BODY as required
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {
    if ( this.getName() == null ){
      pageContext.setAttribute(this.getVar(),"Missing name attribute");
      return SKIP_BODY;
    }

    Queries queries = Consumer.getGlobalConsumer().getQueries();
    if ( queries.hasQuery(this.getName()) ) {
      boolean result = queries.delete( this.getName() );
      pageContext.setAttribute( this.getVar(), Boolean.toString(result) );
    } else {
      pageContext.setAttribute
        ( this.getVar(), "Query " + this.getName() + " does not exist" );
    }

    return SKIP_BODY;
  }

  /**
   * Return the name of the query that will be deleted from the consumer's
   * query store.
   *
   * @return  The name of the query that will be deleted.
   */
  public String getName() {
    return name;
  }

  /**
   * Set the name of the query that will be deleted from the consumer's
   * query store.
   *
   * @param name  The name of the query that will be deleted.
   */
  public void setName( String name ) {
    this.name = name;
  }

}
