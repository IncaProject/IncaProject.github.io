package edu.sdsc.inca.consumer.dataproducer;

import java.util.Map;
import java.util.regex.Pattern;
import java.text.DateFormat;

import org.apache.log4j.Logger;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.axis.*;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.TimeSeriesCollection;
import edu.sdsc.inca.util.StringMethods;
import de.laures.cewolf.ChartPostProcessor;

/**
 * A post-processor for an XY cewolf chart
 *
 * Example call from JSP:
 *
 * <cewolf:chartpostprocessor id="postprocess">
 *   <cewolf:param name="xmin" value="<%=xmin%>"/>
 *   <cewolf:param name="xmax" value="<%=xmax%>"/>
 *   <cewolf:param name="ymin" value="<%=ymin%>"/>
 *   <cewolf:param name="ymax" value="<%=ymax%>"/>
 *   <cewolf:param name="ytick" value="<%=ytick%>"/>
 * </cewolf:chartpostprocessor>
 *
 * @author Kate Ericson
 */

public class TimeSeriesPostProcess implements ChartPostProcessor {
  private static Logger log = Logger.getLogger(TimeSeriesPostProcess.class);

  public void processChart(Object chart, Map params) {
    XYPlot plot = ((JFreeChart) chart).getXYPlot();

    // show filled shapes at each data point.
    for(int i = 0 ; i < plot.getDatasetCount(); i++){
      TimeSeriesCollection dataset = (TimeSeriesCollection)plot.getDataset(i);
      plot.getRendererForDataset(dataset);
      XYLineAndShapeRenderer renderer =
          (XYLineAndShapeRenderer)plot.getRenderer();
      for(int j = 0; j < dataset.getSeriesCount(); j++){
        renderer.setSeriesShapesVisible(j, true);
        renderer.setSeriesShapesFilled(j, true);
      }
    }

    // format xaxis date and max/min values
    DateAxis xaxis = (DateAxis)plot.getDomainAxis();
    xaxis.setDateFormatOverride(DateFormat.getInstance());
    String xmin = (String)params.get("xmin");
    String xmax = (String)params.get("xmax");
    String dateformat = "MMddyy";
    String regex = "\\d{6}";
    if (xmin != null && Pattern.matches(regex, xmin)){
      xaxis.setMinimumDate(StringMethods.convertDateString(xmin, dateformat));
    }
    if (xmax != null && Pattern.matches(regex, xmax)){
      xaxis.setMaximumDate(StringMethods.convertDateString(xmax, dateformat));
    }

    // format yaxis max/min values
    NumberAxis yaxis = (NumberAxis)plot.getRangeAxis();
    String ymin = (String)params.get("ymin");
    String ymax = (String)params.get("ymax");
    String ytick = (String)params.get("ytick");
    if (ymin != null){
      yaxis.setLowerBound(Double.parseDouble(ymin));
    }
    if (ymax != null){
      yaxis.setUpperBound(Double.parseDouble(ymax));
    }

    // set number between yaxis tick marks
    NumberTickUnit tick = new NumberTickUnit(Double.parseDouble(ytick));
    yaxis.setTickUnit(tick);
  }

}
