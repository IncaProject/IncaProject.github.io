package edu.sdsc.inca.consumer;

import org.apache.log4j.Logger;
import edu.sdsc.inca.dataModel.queryStore.QueryStoreDocument;
import edu.sdsc.inca.dataModel.queryStore.Query;
import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.util.XmlWrapper;
import edu.sdsc.inca.consumer.tag.QueryHQL;

import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.math.BigInteger;

/**
 * Manages a list of stored (persistent) depot queries, some of which are longer
 * queries that are cached to disk so that results can be prefetched.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class Queries {
  private static Logger logger = Logger.getLogger( Queries.class );

  private File qsFile = null;
  private QueryStoreDocument queryStore = null;
  Hashtable cachedQueries = new Hashtable();

  /**
   * Read in or create a new list of stored queries from the provided file.
   *
   * @param filePath  A string containing the path to an XML file.
   *
   * @throws ConfigurationException
   */
  public Queries( String filePath ) throws ConfigurationException {
    this.setFile( filePath );
    if ( qsFile.exists() ) {
      try {
        queryStore = QueryStoreDocument.Factory.parse( qsFile );
      } catch ( Exception e ) {
        logger.error
          ( "Unable to parse query store file " + qsFile.getAbsolutePath(), e );
        init();
      }
    } else {
      init();
    }
  }

  /**
   * Add a query to the query store.  The results of this query will always
   * be fetched directly from the depot.  Use this function for light to medium
   * weight queries.
   *
   * @param name  The name of the query to store the hql under.
   * @param hql   The HQL query string to send to the depot.
   *
   * @return True if the query was successfully added to the store and false
   * if not.
   */
  public synchronized boolean add( String name, String hql ) {
    return add( name, hql, 0 );
  }

  /**
   * Add a query to the query store.  The results of this query will be stored
   * to disk and continously fetched (via a thread) using the frequency
   * provided.  Use this function for heavy-duty queries.
   *
   * @param name  The name of the query to store the hql under.
   * @param hql   The HQL query string to send to the depot.
   * @param cachePeriod  The frequency in seconds to fetch the results of the
   *                     query periodically from the depot.
   *
   * @return True if the query was successfully added to the store and false
   * if not.
   */
  public synchronized boolean add( String name, String hql, int cachePeriod ) {
    Query query = queryStore.getQueryStore().addNewQuery();
    query.setName( name );
    query.setHql( hql );
    if ( cachePeriod > 0 ) {
      query.addNewCache().setReloadPeriod( BigInteger.valueOf(cachePeriod));
      CachedQuery cache = new CachedQuery( name, hql, cachePeriod );
      cache.start();
      cachedQueries.put( name, cache );
    }
    try {
      this.save();
      return true;
    } catch ( IOException e ) {
      logger.error
        ( "Problem saving query store to " + qsFile.getAbsolutePath(), e );
      return false;
    }
  }

  /**
   * Delete the specified query from the query store.
   *
   * @param name  The name of the query to remove.
   *
   * @return True if the query was successfully deleted and false if not.
   */
  public boolean delete( String name ) {
    Query[] queries = queryStore.getQueryStore().getQueryArray();
    for ( int i = 0; i < queries.length; i++ ) {
      if ( queries[i].getName().equals(name) ) {
        if ( queries[i].isSetCache() ) {
          CachedQuery query = (CachedQuery)cachedQueries.remove
            ( queries[i].getName() );
          query.interrupt();
          try {
            query.join();
          } catch ( InterruptedException e ) {
            logger.warn( "Received interrupt while shutting down query thread" +
                         query.getQueryName() );
          }
        }
        queryStore.getQueryStore().removeQuery(i);
        try {
          this.save();
          return true;
        } catch ( IOException e ) {
          logger.error( "Problem saving updated query store to disk", e );
          return false;
        }
      }
    }
    return false;
  }

  /**
   * Return a handle to the query file.
   *
   * @return  A File object.
   */
  public File getFile() {
    return qsFile;
  }

  /**
   * Return the HQL query string for the named query.
   *
   * @param name  The name of a stored query
   *
   * @return A string containing the stored HQL query.
   */
  public String getHql( String name ) {
    Query[] queries = queryStore.getQueryStore().getQueryArray();
    for ( int i = 0; i < queries.length; i++ ) {
      if ( queries[i].getName().equals(name) ) {
        return queries[i].getHql();
      }
    }
    return null;
  }

  /**
   * Retrieve a result for the named query.  The result will either be
   * fetched directly from the depot or from disk (if it is cached).
   * This is a blocking function.
   *
   * @param name  The name of the query to retrieve the results for
   *
   * @return  A string containing the result of the query.
   *
   * @throws InterruptedException
   */
  public String getQueryResult( String name ) throws InterruptedException {
    if ( cachedQueries.containsKey(name) ) {
      logger.debug( "Fetching query results from cache" );
      CachedQuery query = (CachedQuery)cachedQueries.get(name);
      return query.getResultOrWait();
    } else {
      logger.debug( "Fetching query results from depot" );
      try {
        return QueryHQL.getResultsAsXmlBean
          (this.getHql(name)).xmlText( XmlWrapper.getPrettyPrintOptions() );
      } catch ( Exception e ) {
        logger.error( "Problem fetching result for cached query " + name, e );
        return null;
      }
    }
  }

  /**
   * Check to see if the query exists in the store already.
   *
   * @param name   The name of the query to search for.
   *
   * @return True if the query exists in the store and false if not.
   */
  public synchronized boolean hasQuery( String name ) {
    Query[] queries = queryStore.getQueryStore().getQueryArray();
    for ( int i = 0; i < queries.length; i++ ) {
      if ( queries[i].getName().equals(name) ) {
        return true;
      }
    }
    return false;
  }

  /**
   * Fetch the list of stored query names.
   *
   * @return A list containing the names of the stored queries.
   */
  public synchronized String[] list() {
    Query[] queries = queryStore.getQueryStore().getQueryArray();
    String[] names = new String[queries.length];
    for ( int i = 0; i < queries.length; i++ ) {
      names[i] = queries[i].getName();
    }
    return names;
  }

  public synchronized String listXml() {
    return queryStore.xmlText( XmlWrapper.getPrettyPrintOptions() );
  }

  /**
   * Save the query store configuration to disk.
   *
   * @throws IOException
   */
  public void save() throws IOException {
    queryStore.save( qsFile, XmlWrapper.getPrettyPrintOptions() );
  }

  /**
   * Set the path to the file containing stored query information.
   *
   * @param filePath  A path to an XML file.
   */
  public void setFile( String filePath ) {
    this.qsFile = new File(filePath);
  }

  /**
   * Starts the cached query threads so that results are prefetched from the
   * depot and continuously updated.
   *
   * @throws ConfigurationException
   */
  public void start() throws ConfigurationException {
    Query[] queries = queryStore.getQueryStore().getQueryArray();
    for( int i = 0; i < queries.length; i++ ) {
      if ( queries[i].isSetCache() ) {
        int cachePeriod = queries[i].getCache().getReloadPeriod().intValue();
        CachedQuery cache = new CachedQuery
         ( queries[i].getName(), queries[i].getHql(), cachePeriod );
        cache.start();
        cachedQueries.put( queries[i].getName(), cache );
      }
    }
  }

  /**
   * Stop prefetching query results from the depot.
   */
  public void stop() {
    CachedQuery[] queries = new CachedQuery[cachedQueries.size()];
    cachedQueries.values().toArray( queries );
    for( int i = 0; i < queries.length; i++ ) {
      queries[i].interrupt();
    }
  }

  // Private Functions

  /**
   * Create a new XML file for persisting stored queries and save it to disk.
   *
   * @throws ConfigurationException
   */
  private void init() throws ConfigurationException {
    logger.info
      ( "Initializing query store document at " + qsFile.getAbsolutePath() );
    queryStore = QueryStoreDocument.Factory.newInstance();
    queryStore.addNewQueryStore();

    try {
      this.save();
    } catch ( IOException e ) {
      throw new ConfigurationException( "Unable to save new file", e );
    }
  }
}
