package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlException;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.DepotClient;
import edu.sdsc.inca.util.XmlWrapper;
import edu.sdsc.inca.consumer.Queries;
import edu.sdsc.inca.dataModel.queryResults.ObjectDocument;
import edu.sdsc.inca.dataModel.queryResults.Row;
import edu.sdsc.inca.dataModel.queryResults.Rows;
import edu.sdsc.inca.protocol.ProtocolException;

import java.io.IOException;
import java.util.regex.Pattern;

/**
 * Jsp tag to query the Inca depot with HQL.
 * Required parameter: query
 *
 * @author Kate Ericson &lt;kericson@sdsc.edu&gt;,
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class QueryHQL extends TagSupport {
  private static Logger logger = Logger.getLogger( QueryHQL.class );
  private String hql = null;
  private String name = null;

  public int doEndTag(){
    return EVAL_PAGE;
  }

  /**
   * Called when the jsp tag is referenced in a JSP document.
   * Will return XML HQL query results or an error
   * (expressed in XML -- &lt;error&gt;...&lt;/error&gt;)
   *
   * @return SKIP_BODY as required
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {
    String results = null;

    if ( this.getHql() == null && this.getName() == null ) {
      results = "<error>Missing hql and name</error>";
    } else {
      try {
        Queries queries = Consumer.getGlobalConsumer().getQueries();
        if ( this.getName() != null && ! this.getName().equals("") &&
             queries.hasQuery(this.getName()) ) {
          logger.debug( "Fetching results for query '" + this.getName() + "'");
          results = queries.getQueryResult( this.getName() );
        } else {
          logger.debug("Fetching results for hql '" + this.getHql() + "'");
          results = getResultsAsXmlBean().xmlText
            ( XmlWrapper.getPrettyPrintOptions() );
        }
      } catch (Exception e ) {
        logger.error
          ( "Error fetching query " + (getName()==null?getHql():getName()), e );
        results = "<error>Unable to fetch result: " + e + "</error>";
      }
    }
    if ( this.getVar() != null && ! this.getVar().equals("") ) {
      pageContext.setAttribute( this.getVar(), results );
    } else {
      JspWriter out = pageContext.getOut();
      try {
        out.println( results );
      } catch ( IOException e ) {
        logger.error( "Unable to write query results", e );
      }
    }

    return SKIP_BODY;
  }

  /**
   * Get the query string for the hql (will be called by a jsp page)
   * @return An hql string
   */
  public String getHql() {
    return hql;
  }

  /**
   * Return the name of the query that will be sent to the depot.
   *
   * @return  The name of the query whose results will be fetched.
   */
  public String getName() {
    return name;
  }

  /**
   * Query the depot using an HQL string and return the results (rows) in
   * an array of strings.
   *
   * @return  An XmlBean containing the query results.
   *
   * @throws ConfigurationException
   * @throws IOException
   * @throws ProtocolException
   */
  public ObjectDocument getResultsAsXmlBean()
    throws ConfigurationException, IOException, ProtocolException {

    return getResultsAsXmlBean( hql );
  }

  /**
   * Query the depot using an HQL string and return the results (rows) in
   * an array of strings.
   *
   * @param query   A string containing a HQL query.
   *
   * @return  An XmlBean containing the query results.
   *
   * @throws ConfigurationException
   * @throws IOException
   * @throws ProtocolException
   */
  public static ObjectDocument getResultsAsXmlBean( String query )
    throws ConfigurationException, IOException, ProtocolException {

    String[] queryresult = queryDepot( query );
    ObjectDocument queryResult = ObjectDocument.Factory.newInstance();
    ObjectDocument.Object object = queryResult.addNewObject();
    if ( queryresult != null && queryresult.length > 0 ) {
      if ( queryresult.length == 1 ) {
        try {
          object.set( XmlObject.Factory.parse( queryresult[0].trim() ) );
        } catch ( XmlException e ) {
          logger.error( "Unable to parse query result", e );
        }
      } else {
        Rows rows = Rows.Factory.newInstance();
        for ( int i = 0; i < queryresult.length; i++ ) {
          Row row = rows.addNewRow();
          try {
            row.set( XmlObject.Factory.parse( queryresult[i].trim() ) );
          } catch ( XmlException e ) {
            logger.error( "Unable to parse query result " + i, e );
          }
        }
        object.set( rows );
      }
    }
    return queryResult;
  }

  /**
   * Query the depot using an HQL string and return the results (rows) in
   * an array of strings.
   *
   * @param query   A string containing a HQL query.
   *
   * @return An array of strings, each containing a row of the result.
   *
   * @throws ConfigurationException
   * @throws IOException
   * @throws ProtocolException
   */
  public static String[] queryDepot( String query )
    throws ConfigurationException, IOException, ProtocolException {

    String[] queryresult;
    DepotClient depotClient = new DepotClient();
    depotClient.setConfiguration
      ( Consumer.getGlobalConsumer().getClientConfiguration() );
    logger.info( "Contacting depot " + depotClient.getUri() );
    depotClient.connect();
    queryresult = depotClient.queryHql( normalizeQuery(query) );
    depotClient.close();
    return queryresult;
  }

  /**
   * Set the query string for the hql (will be called by a jsp page)
   * @param hql  An hql string
   */
  public void setHql(String hql) {
    this.hql = hql;
  }


  /**
   * Make sure query string is acceptable for hibernate by removing newlines
   * and carriage returns.
   *
   * @param hql  A string containing hql that may contain newlines or cr.
   *
   * @return  A string that can be fed to hibernate.
   */
  public static String normalizeQuery(String hql) {
    return hql.replaceAll( "\n", " " ).replaceAll( "\r", " " );
  }

  /**
   * Set the name of the query that will be sent to the depot.
   *
   * @param name  The name of the query whose results will be fetched.
   */
  public void setName( String name ) {
    this.name = name;
  }
}
