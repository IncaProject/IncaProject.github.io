package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;
import org.apache.log4j.Logger;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.AgentClient;
import edu.sdsc.inca.protocol.ProtocolException;

import java.io.IOException;

/**
 * Jsp tag that will query the configured Inca agent for its catalogs (of
 * reporters).  Required parameters are:
 *
 * retAttrName
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GetCatalog extends TagSupport {
  private static Logger logger = Logger.getLogger(GetCatalog.class);

  /**
   * Called when the jsp tag is referenced in a JSP document.  Will return
   * a xml document with a list of catalogs stored in the configured
   * agent or an error (expressed in XML --
   * &lt;error&gt;...&lt;/error&gt;)
   *
   * @return SKIP_BODY as required
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {
    if ( this.getVar() == null ){
      pageContext.setAttribute(
        "suite",
        "<error>Missing return attribute name</error>"
      );
      return SKIP_BODY;
    }

    try {
      pageContext.setAttribute(
        this.getVar(),
        getCatalog()
      );
    } catch ( Exception e ) {
      logger.error( "Unable to retrieve catalog xml from agent", e );
      pageContext.setAttribute(
        this.getVar(),
        "<error>" + e + "</error>"
      );
    }

    return SKIP_BODY;
  }

  /**
   * Query the Consumer cache for the list of repositories being used by
   * the agent.  For each repository, query the agent for its catalog and
   * return as a XML document in the form of
   *
   * &lt;catalogs&gt;
   *   &lt;catalog&gt;
   *   ...
   *   &lt;/catalog&gt;
   *   ...
   * &lt;catalogs/&gt;
   *
   * @return A XML document containing a list of catalogs.
   *
   * @throws java.io.IOException
   */
  public String getCatalog()
    throws IOException, ConfigurationException, ProtocolException {

    StringBuffer catalogXml = new StringBuffer( "<catalogs>" );
    String[] repositories = Consumer.getGlobalConsumer().getRepositories(
      Consumer.getGlobalConsumer().getCacheMaxWaitPeriod()
    );
    if ( repositories == null || repositories.length < 1 ) {
      catalogXml.append( "</catalogs>" );
      return catalogXml.toString();
    }
    AgentClient agentClient = new AgentClient();
    agentClient.setConfiguration
      ( Consumer.getGlobalConsumer().getClientConfiguration() );
    logger.info( "Contacting agent " + agentClient.getUri() );
    agentClient.connect();
    for ( int i = 0; i < repositories.length; i++ ) {
      logger.info( "Getting repository catalog " + repositories[i] );
      catalogXml.append( agentClient.getCatalogAsXml( repositories[i] ) );
    }
    agentClient.close();
    catalogXml.append( "</catalogs>" );

    return catalogXml.toString();
  }

}
