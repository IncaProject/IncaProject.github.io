package edu.sdsc.inca.consumer.dataproducer;

import java.util.Date;
import java.util.Hashtable;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;
import edu.sdsc.inca.dataModel.graphSeries.GraphSeries;
import edu.sdsc.inca.dataModel.graphSeries.GraphInstance;
import edu.sdsc.inca.consumer.tag.QueryHQL;
import edu.sdsc.inca.consumer.tag.Util;


public class GraphInstanceHash extends Hashtable {

  public static final int TOOLTIP_MAX_STRING_LENGTH = 120;
  private static Logger logger = Logger.getLogger(TimeSeriesData.class);

  /**
   * Get a hashtable of configIDs and their corresponding
   * GraphInstance objects, one for each instance in the configID's history.
   *
   * @param configIDs   An array of configIDs that will be
   *                    used to query the depot.
   *
   * @param startDate   A start date to limit the earliest data
   *                    returned from the depot.
   *
   * @param endDate     An end date to limit the latest data
   *                    returned from the depot.
   */
  public GraphInstanceHash(String[] configIDs, Date startDate, Date endDate){
    for (int i=0; i < configIDs.length; i++){
      String config = configIDs[i];
      GraphInstance[] gis = getGraphInstances(config, startDate, endDate);
      this.put( config, gis);
    }
  }

  /**
   * Get GraphInstance objects for a configID.
   *
   * @param configID    ConfigID string that corresponds to the data to graph.
   *
   * @param startDate   A start date to limit the earliest data
   *                    returned from the depot.
   *
   * @param endDate     An end date to limit the latest data
   *                    returned from the depot.
   *
   * @return gs         An array of GraphInstance objects,
   *                    one for each instance in the configID's history.
   */
  private GraphInstance[] getGraphInstances(String configID, Date startDate,
                                            Date endDate){
    SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
    String query = "SELECT " +
        " ii.id as instanceId," +
        " ii.collected as collected," +
        " r.exit_status as exit_status," +
        " r.exit_message as exit_message," +
        " cr.result as comparisonResult " +
        "FROM " +
        " SeriesConfig sc," +
        " Report r," +
        " InstanceInfo ii," +
        " ComparisonResult cr " +
        "WHERE " +
        " sc.id = " + configID +
        " AND r.series.id = sc.series.id" +
        " AND ii.reportId = r.id" +
        " AND ((cr.reportId = r.id AND cr.seriesConfigId = sc.id)" +
        " OR (sc.latestComparisonId = -1 AND cr.reportId = -1))";
    if (startDate != null){
      query += " AND ii.collected >= '" + fmt.format(startDate) + "'";
    }
    if (endDate != null){
      query += " AND ii.collected <= '" + fmt.format(endDate) + "'";
    }
    query += " ORDER BY ii.collected";

    logger.debug( "GRAPH: starting queryHQL");
    long queryHqlTime = Util.getTimeNow();
    String[] results = new String[0];
    try {
      results = QueryHQL.queryDepot(query);
    } catch (Exception c){
      logger.warn( "Problem querying depot: " + c );
    }
    Util.printElapsedTime( queryHqlTime, "GRAPH: queryHQL" );
    GraphInstance[] gis = new GraphInstance[results.length];
    for ( int i = 0; i < results.length; i++ ) {
      GraphSeries gs = GraphSeries.Factory.newInstance();
      try {
        gs.set( GraphSeries.Factory.parse( results[i].trim() ) );
        // cleanup error message if it exists (xfree doesn't like ' or long
        // strings. we take out \n cause easier to see
        String errorMessage = gs.getObject().getExitMessage();
        errorMessage = errorMessage.replaceAll("\n","").replaceAll("'", "");
        if ( errorMessage.length() > TOOLTIP_MAX_STRING_LENGTH ) {
          errorMessage = errorMessage.substring(0, TOOLTIP_MAX_STRING_LENGTH);
        }
        gs.getObject().setExitMessage(errorMessage);
        gis[i] = gs.getObject();
      } catch ( XmlException e ) {
        logger.debug( "Unable to parse graphInstance " + e );
      }
    }
    return gis;
  }

}