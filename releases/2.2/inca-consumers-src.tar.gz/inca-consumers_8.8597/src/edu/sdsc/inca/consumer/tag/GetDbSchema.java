package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;

import org.apache.log4j.Logger;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.DepotClient;
import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.protocol.ProtocolException;

import java.io.IOException;

/**
 * Jsp tag to query the depot for information on the database structure
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GetDbSchema extends TagSupport {
  private static Logger logger = Logger.getLogger( GetDbSchema.class );

  public int doEndTag(){
    return EVAL_PAGE;
  }

  /**
   * Called when the jsp tag is referenced in a JSP document.
   * Will return an XML document containing the db structure or an error
   * tag if unsuccessful.
   *
   * @return SKIP_BODY as required
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {
    try {
      pageContext.setAttribute( this.getVar(), queryDepot() );
    } catch ( Exception e ) {
      logger.error( "Unable to query database", e );
      pageContext.setAttribute
        ( this.getVar(), "<error>Problem querying depot</error>");
    }
    return SKIP_BODY;
  }

  /**
   * Queries the depot for the database structure and returns the result as
   * a string.
   *
   * @return An XML document containing the structure of the depot db.
   *
   * @throws ConfigurationException
   * @throws IOException
   * @throws ProtocolException
   */
  public String queryDepot()
    throws ConfigurationException, IOException, ProtocolException {

    String queryresult;
    DepotClient depotClient = new DepotClient();
    depotClient.setConfiguration
      ( Consumer.getGlobalConsumer().getClientConfiguration() );
    logger.info( "Contacting depot " + depotClient.getUri() );
    depotClient.connect();
    queryresult = depotClient.queryDatabase();
    depotClient.close();
    return queryresult;
  }

}
