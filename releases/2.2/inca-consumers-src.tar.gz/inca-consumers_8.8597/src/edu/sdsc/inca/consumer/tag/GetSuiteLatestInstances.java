package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;
import org.apache.log4j.Logger;

import edu.sdsc.inca.Consumer;

import java.io.IOException;

/**
 * Jsp tag that will query the configured Inca depot for report summaries for
 * a given suite and return as a single XML document.  Required parameters are:
 *
 * suiteName
 * retAttrName
 *
 * @author Kate Ericson &lt;kericson@sdsc.edu&gt;
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GetSuiteLatestInstances extends TagSupport {
  private static Logger logger=Logger.getLogger(GetSuiteLatestInstances.class);

  private String suiteName;
  public boolean debug = false;

  /**
   * Called when the jsp tag is referenced in a JSP document.  Will return
   * a software stack status xml document or an error (expressed in XML --
   * &lt;error&gt;...&lt;/error&gt;)
   *
   * @return SKIP_BODY as required
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {
    if ( this.getVar() == null ){
      pageContext.setAttribute(
        "suite",
        "<error>Missing return attribute name</error>"
      );
      return SKIP_BODY;
    }

    if ( this.suiteName == null ){
      pageContext.setAttribute(
        this.getVar(),
        "<error>Missing suite name</error>"
      );
      return SKIP_BODY;
    }

    try {
      long startTime = Util.getTimeNow();
      pageContext.setAttribute(
        this.getVar(),
        getSuiteLatestInstances()
      );
      Util.printElapsedTime( startTime, "getSuiteLatestInstances" );
    } catch ( IOException e ) {
      logger.error( "Unable to retrieve software stack status xml", e );
      pageContext.setAttribute(
        this.getVar(),
        "<error>" + e + "</error>"
      );
    }

    return SKIP_BODY;
  }

  /**
   * Retrieve the requested suite (i.e., the latest instances of
   * all reports returned as reportSummary xml documents) from the Consumer's
   * cache   If debug is true, will return the contents of "reportSummary.xml"
   * located somewhere in the classpath.
   *
   * @return A XML document containing a series of reportSummary xml elements
   * where each reportSummary contains information on the latest instance of
   * a report.
   *
   * @throws java.io.IOException
   */
  public String getSuiteLatestInstances() throws IOException {
    String[] results = Consumer.getGlobalConsumer().getSuite(
      this.suiteName, Consumer.getGlobalConsumer().getCacheMaxWaitPeriod()
    );
    if ( results != null ) {
      return Util.summariesToSuite( this.suiteName, results );
    } else {
      throw new IOException( "Error retrieving suite " + this.getSuiteName() );
    }
  }


  /**
   * Return the name of the suite used to query the status from the depot.
   *
   * @return The name of the suite to query the status from.
   */
  public String getSuiteName() {
    return suiteName;
  }

  /**
   * Set the name of the suite to query the status from the depot.
   *
   * @param suiteName name of the suite to query the status from
   */
  public void setSuiteName(String suiteName) {
    this.suiteName = suiteName;
  }
}
