package edu.sdsc.inca.consumer.dataproducer;

import java.util.Map;

import org.apache.log4j.Logger;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.axis.*;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYSeriesCollection;
import de.laures.cewolf.ChartPostProcessor;

/**
 * A post-processor for a cewolf histogram
 *
 * Example call from JSP:
 *
 * <cewolf:chartpostprocessor id="histPostprocess"/>
 *
 * @author Kate Ericson
 */

public class HistogramPostProcess implements ChartPostProcessor {
  private static Logger log = Logger.getLogger(TimeSeriesPostProcess.class);

  public void processChart(Object chart, Map params) {
    XYPlot plot = ((JFreeChart) chart).getXYPlot();

    // outline each bar
    for(int i = 0 ; i < plot.getDatasetCount(); i++){
      XYSeriesCollection dataset = (XYSeriesCollection)plot.getDataset(i);
      plot.getRendererForDataset(dataset);
      XYBarRenderer renderer = (XYBarRenderer)plot.getRenderer();
      for(int j = 0; j < dataset.getSeriesCount(); j++){
        renderer.setDrawBarOutline(true);
      }
    }

    // hide xaxis labels
    Axis xaxis = plot.getDomainAxis();
    xaxis.setTickLabelsVisible(false);
  }

}
