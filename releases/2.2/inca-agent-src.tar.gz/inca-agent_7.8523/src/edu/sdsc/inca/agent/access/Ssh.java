package edu.sdsc.inca.agent.access;

import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.agent.AccessMethodOutput;
import edu.sdsc.inca.agent.AccessMethod;
import edu.sdsc.inca.agent.AccessMethodException;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.util.ResourcesWrapper;
import com.sshtools.j2ssh.SshClient;
import com.sshtools.j2ssh.SftpClient;
import com.sshtools.j2ssh.connection.ChannelState;
import com.sshtools.j2ssh.session.SessionChannelClient;
import com.sshtools.j2ssh.transport.IgnoreHostKeyVerification;
import com.sshtools.j2ssh.transport.publickey.SshPrivateKeyFile;
import com.sshtools.j2ssh.transport.publickey.SshPrivateKey;
import com.sshtools.j2ssh.authentication.PublicKeyAuthenticationClient;
import com.sshtools.j2ssh.authentication.AuthenticationProtocolState;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;

import org.apache.log4j.Logger;

/**
 * A class that implements AccessMethod using the SSH protocol for transferring
 * files and running processes on remote resources.
 *
 * Important note: stop() does not kill the remote process currently
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class Ssh extends AccessMethod {
  // Constants
  public static final int CHECK_PERIOD = 5000;
  public static final String[] SSH_IDENTITY_FILENAMES = {
    ".ssh/id_dsa", ".ssh/id_rsa"
  };

  // Member variables
  private String sshServer;
  private int sshPort = -1;
  private String sshUsername = null;
  private String[] sshKeyFiles;
  private String sshPassword = null;
  private Logger logger = Logger.getLogger(this.getClass().toString());
  private SshClient activeSsh = null;
  private SessionChannelClient activeSession = null;

  // Public Methods

  /**
   * Create a new remote process controlling it via SSH. The given
   * resource should exist in the resource configuration file and  the
   * following fields can be optionally defined:
   *
   * sshServer - the remote hostname [default: resource name]
   * sshPort - alternative port of SSH server [default: SSHClient's default]
   * sshUsername - username on remote machine [default: user.home from Java]
   * sshPrivateKeyFile - identity to use to authenticate
   *                     [default: ~/.ssh/id_dsa, ~/.ssh/id_rsa]
   *
   * @param resource  The name of the resource to start the process on
   * @param resources The resource configuration information.
   * @throws ConfigurationException
   */
  public Ssh( String resource, ResourcesWrapper resources )
    throws ConfigurationException {

    sshServer = resources.getValue( resource, Protocol.COMPUTE_SERVER_MACRO );
    logger.debug( "sshServer is '" + sshServer + "'" );
    if ( sshServer == null || sshServer.equals("") ) {
      sshServer = resource;
    }
    logger.debug( "sshServer is '" + sshServer + "'" );

    String sshPortString =
      resources.getValue( resource, Protocol.COMPUTE_PORT_MACRO );
    if ( sshPortString != null ) {
      sshPort = Integer.parseInt( sshPortString );
    }

    sshUsername = resources.getValue( resource, Protocol.LOGIN_ID_MACRO );
    if ( sshUsername == null ) {
      sshUsername = System.getProperty( "user.name" );
    }

    String sshIdentity = resources.getValue(resource, Protocol.SSH_IDENTITY_MACRO );
    if ( sshIdentity != null ) {
      sshKeyFiles = new String[]{ sshIdentity };
    } else {
      String userhome = System.getProperty( "user.home" );
      sshKeyFiles = new String[SSH_IDENTITY_FILENAMES.length];
      for ( int i = 0; i < SSH_IDENTITY_FILENAMES.length; i++ ) {
        sshKeyFiles[i] = userhome + File.separator + SSH_IDENTITY_FILENAMES[i];
      }
    }

    sshPassword = resources.getValue(resource, Protocol.SSH_PASSWORD_MACRO );

  }

  /**
   * Transfer a list of remote files to a directory on the local machine using
   * SSH.
   *
   * @param remoteFiles  List of paths to remote files that will be transfered
   * @param localDir   Path to the directory on the local machine where
   *                   the remote files will be placed
   * @throws AccessMethodException
   */
  public void get( String[] remoteFiles, String localDir )
    throws AccessMethodException {

    SshClient ssh;
    try {
      ssh = connect();
    } catch ( IOException e ) {
      throw new AccessMethodException( "Unable to connect to " + sshServer, e );
    }
    if ( ssh == null ) {
      throw new AccessMethodException( "Unable to connect to " + sshServer );
    }
    try {
      File localDirF = new File( localDir );
      if ( ! localDirF.exists() ) localDirF.mkdirs();
      SftpClient sftp = ssh.openSftpClient();
      sftp.lcd( localDir );
      for ( int i = 0; i < remoteFiles.length; i++ ) {
        String remoteFile = remoteFiles[i].replaceFirst( "\\$\\{HOME\\}/", "" );
        logger.info( "Getting " + remoteFile + " from " + sshServer );
        sftp.get( remoteFile );
      }
      sftp.quit();
      ssh.disconnect();
    } catch ( Exception e ) {
      throw new AccessMethodException( "Unable to put files", e );
    }
  }

  /**
   * Checks to see if the current ssh session is active.  Does not indicate
   * whether the remote process is alive (for now).
   *
   * @return true if the SSH session is alive; false otherwise.
   */
  public boolean isActive() throws AccessMethodException {
    return activeSession.getState().getValue() == ChannelState.CHANNEL_OPEN;
  }

  /**
   * Given a path relative to the home directory, prepend the home directory
   * to the path and return the new string.
   *
   * @param path   A path relative to the user's home directory
   *
   * @return  A new string that contains the home directory prepended to the
   * provided path.
   */
  public String prependHome( String path ) {
    return "${HOME}/" + path;
  }

  /**
   * Execute the specified process on the remote resource.  This call will block
   * until the process has completed.
   *
   * @param executable Path to the remote executable.
   * @param arguments  Contains the arguments that should be passed to the
   *                   executable
   * @param stdin      A string that will be passedd in as stdin to the process
   *                   when it is started
   * @param directory  Path to the directory where the process will be executed
   *                   from
   * @return The stdout and stderr of the executed process in
   * AccessMethodOutput
   */
  public AccessMethodOutput run( String executable, String[] arguments,
                                 String stdin, String directory)
    throws AccessMethodException {

    String stdout = null;
    String stderr = null;
    try {
      SshClient ssh = connect();
      if ( ssh == null ) {
        throw new IOException( "Could not create ssh connection" );
      }
      SessionChannelClient session = sendCommand( ssh, executable, arguments,
                                                  directory );
      if ( stdin != null ) {
        session.getOutputStream().write( stdin.getBytes() );
        session.getOutputStream().close();
      }

      // read stdout/stderr
      BufferedReader stdoutReader = new BufferedReader(
        new InputStreamReader( session.getInputStream() )
      );
      BufferedReader stderrReader = new BufferedReader(
        new InputStreamReader( session.getStderrInputStream() )
      );
      stdout = "";
      stderr = "";
      String line;
      while( (line = stdoutReader.readLine()) != null ) {
        stdout += line;
      }
      while( (line = stderrReader.readLine()) != null ) {
        stderr += line;
      }
      session.close();
      ssh.disconnect();
    } catch ( IOException e ) {
      throw new AccessMethodException( "SSH remote run failed", e );
    }

    AccessMethodOutput result = new AccessMethodOutput();
    result.setStdout( stdout );
    result.setStderr( stderr );
    return result;
  }

  /**
   * Start a process on a remote machine.  This is a non-blocking call.
   *
   * Important note:  this process will not be killed on call to stop()
   *
   * @param executable  Path to the remote executable.
   * @param arguments   Contains the arguments that should be passed to the
   *                    executable
   * @param directory  Path to the directory where the process will be executed
   * @throws AccessMethodException
   */
  public void start( String executable, String[] arguments, String stdin,
                     String directory ) throws AccessMethodException {

    try {
      activeSsh = connect();
      activeSession = sendCommand( activeSsh, executable, arguments,
                                   directory );
      if ( stdin != null ) {
        activeSession.getOutputStream().write( stdin.getBytes() );
        activeSession.getOutputStream().close();
      }
    } catch ( IOException e ) {
      throw new AccessMethodException( "Unable to start remote process", e );
    }
  }

  /**
   * This call should kill the remote process that was started by the start()
   * call.  However, since a remote process won't be killed when the ssh client
   * session is closed, the remote process will persist.  Will try to figure
   * out if there is a SSH configuration mechanism that can be turned on so
   * that the process will be killed upon disconnect.  This call does
   * disconnect the active SSH session.
   *
   * @throws AccessMethodException
   */
  public void stop() throws AccessMethodException {
    try {
      activeSession.close();
    } catch ( IOException e ) {
      throw new AccessMethodException( "Stop of remote SSH process failed", e );
    }
    activeSsh.disconnect();
  }

  /**
   * Transfer a list of local files to a directory on a remote machine using
   * SSH.
   *
   * @param localFiles  List of paths to local files that will be transfered
   * @param remoteDir   Path to the directory on the remote machine where
   *                   the local files will be placed
   * @throws AccessMethodException
   */
  public void put( String[] localFiles, String remoteDir )
    throws AccessMethodException {

    SshClient ssh;
    try {
      ssh = connect();
    } catch ( IOException e ) {
      throw new AccessMethodException( "Unable to connect to " + sshServer, e );
    }
    if ( ssh == null ) {
      throw new AccessMethodException( "Unable to connect to " + sshServer );
    }
    try {
      SftpClient sftp = ssh.openSftpClient();
      remoteDir = remoteDir.replaceFirst( "\\$\\{HOME\\}/", "" );
      try {
        sftp.stat(remoteDir);
      } catch ( IOException e ) {
        sftp.mkdirs(remoteDir);
      }
      sftp.cd( remoteDir );
      String cwd = System.getProperty( "user.dir" );
      sftp.lcd( cwd );
      for ( int i = 0; i < localFiles.length; i++ ) {
        logger.info(
          "Tranferring " + localFiles[i] + " to " + sshServer + " - " + remoteDir
        );
        sftp.put( localFiles[i] );
      }
      sftp.quit();
      ssh.disconnect();
    } catch ( Exception e ) {
      throw new AccessMethodException( "Unable to put files", e );
    }
  }

  // Private Methods

  /**
   * Connect and authenticate to the remote resource.
   *
   * @return An active SshClient connection to the remote resource.
   *
   * @throws IOException
   */
  private SshClient connect() throws IOException {
    SshClient ssh = new SshClient();
    if ( sshPort == -1 ) {
      logger.debug( "Connecting to ssh server " + sshServer );
      ssh.connect( sshServer, new IgnoreHostKeyVerification() );
    } else {
      logger.debug( "Connecting to ssh server " + sshServer + ":" + sshPort );
      ssh.connect( sshServer, sshPort, new IgnoreHostKeyVerification() );
    }
    PublicKeyAuthenticationClient pk = new PublicKeyAuthenticationClient();
    logger.debug( "Using username " + sshUsername );
    pk.setUsername( sshUsername );
    int authenticationStatus = AuthenticationProtocolState.FAILED;
    for ( int i = 0; i < sshKeyFiles.length; i++ ) {
      try {
        logger.debug( "Trying ssh key file " + sshKeyFiles[i] );
        SshPrivateKeyFile file=SshPrivateKeyFile.parse(new File(sshKeyFiles[i]));
        SshPrivateKey key = file.toPrivateKey( sshPassword );
        pk.setKey(key);
        authenticationStatus = ssh.authenticate( pk );
      } catch ( Exception e ) {
        logger.debug( "Ssh key file " + sshKeyFiles[i] + " failed" );
        // do nothing and hope a subsequent file works
      }
      if ( authenticationStatus == AuthenticationProtocolState.COMPLETE ) {
        logger.debug( "Authentication succeeded" );
        break;
      }
    }
    if ( authenticationStatus != AuthenticationProtocolState.COMPLETE ) {
      logger.error( "Unable to create ssh connection to " + sshServer );
      return null;
    } else {
      return ssh;
    }
  }

  /**
   * Send the specified command to the open ssh client and return the active
   * session.
   *
   * @param ssh        An open SshClient connection to the remote resource.
   * @param exec       Path to the remote executable.
   * @param args       Contains the arguments that should be passed to the
   *                   executable
   * @param remoteDir  Path to the directory where the process will be executed
   * @return active SessionChannelClient that has just sent a command.
   * @throws IOException
   */
  private SessionChannelClient sendCommand(
    SshClient ssh, String exec, String[] args, String remoteDir
    ) throws IOException {

    String command = "";
    if ( remoteDir != null ) {
      command += "cd " + remoteDir + ";";
    }
    command += exec + " ";
    for ( int i = 0; i < args.length; i++ ) {
      command += "\"" + args[i] + "\" ";
    }
    SessionChannelClient session = ssh.openSessionChannel();
    logger.info( "Sending SSH command to " + sshServer + ": " + command );    
    session.executeCommand( command );
    return session;
  }
}

