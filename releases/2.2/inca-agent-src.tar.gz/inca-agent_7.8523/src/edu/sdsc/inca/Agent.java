package edu.sdsc.inca;

import java.io.IOException;
import java.io.File;
import java.util.Properties;
import java.util.HashMap;
import java.util.Iterator;
import java.math.BigInteger;
import java.net.InetAddress;

import edu.sdsc.inca.protocol.*;
import edu.sdsc.inca.repository.Repository;
import edu.sdsc.inca.repository.Repositories;
import edu.sdsc.inca.util.ConfigProperties;
import edu.sdsc.inca.util.ResourcesWrapper;
import edu.sdsc.inca.util.CrypterException;
import edu.sdsc.inca.util.SuiteWrapper;
import edu.sdsc.inca.util.SuiteStagesWrapper;
import edu.sdsc.inca.util.Constants;
import edu.sdsc.inca.util.WorkQueue;
import edu.sdsc.inca.agent.*;
import edu.sdsc.inca.dataModel.suite.SuiteDocument;
import edu.sdsc.inca.dataModel.catalog.PackageType;
import edu.sdsc.inca.dataModel.util.SeriesConfig;
import org.apache.xmlbeans.XmlException;
import org.apache.log4j.Logger;

/**
 * The agent is the Inca component that provides centralized control
 * of the reporters running on the monitored resources.  A client of the
 * agent (usually thru incat) can
 * <ol>
 * <li>request specific reporters be executed on the monitored resources by
 * submitting suites</li>
 * <li>configure the agent with a list of reporter repositories where it can
 * find reporters requested in the suites</li>
 * <li>configure the agent with information about the resources it is monitoring
 * (e.g., the access method to use to start up a remote reporter manager
 * process)</li>
 * </ol>
 *
 * Note: The Agent is subclass of the Server component whose command threads
 * (which service client requests) do not have access to the server object.
 * Therefore, we have a static Agent object which can be accessed by the
 * command threads to perform actions requested by the clients.
 */
public class Agent extends Server {

  // Constants
  final public static String GLOBUS_IP_PROPERTY = "org.globus.ip";
  final static public int PING_PERIOD = 10 * Constants.MILLIS_TO_MINUTE;
  final public static String REPOSITORY_CACHE = "repository";
  final public static String REPOSITORIES_PATH = "repositories.xml";
  final public static String RESOURCES_PATH = "resources.xml";
  final static public String RMDIR = "rm";
  final static public int START_ATTEMPT_PERIOD = Constants.MILLIS_TO_HOUR;

  public static final String SUITEDIR_PATH = "suites";

  // Standard logger
  private static Logger logger = Logger.getLogger( Agent.class );

  // Static (i.e., global) agent that can be referenced from any thread
  private static Agent globalAgent = new Agent();

  // The agent's communicator to the Inca depot
  private DepotClient depotClient = new DepotClient();

  // Handle to the available Inca reporter repositories
  private Repositories repositories = null;

  // The agent's local copy of reporters and packages (only downloads
  // those reporters and dependencies that were requested in a suite).
  private RepositoryCache repositoryCache = null;

  // The current resource configuration on the agent
  private ResourcesWrapper resources = null;

  // Holds handles (i.e., ReporterManagerControllers) to the currently running
  // remote reporter managers
  private ReporterManagerTable rms = new ReporterManagerTable();

  // The suites current configured on the agent
  private SuiteTable suites;

  // Global agent state
  protected boolean ranShutdown = false;

  // Configuration options to specify alternative agent behavior
  protected String upgradeReporterManagers = null; // upgrade the remote RMs
  protected String checkReporterManagers = null; // check the remote RMs

  // Configuration options to run agent -- note need static copies of
  // credentials because the credentials are needed from static functions
  private String adminEmail = null;
  private String[] depots;
  private int pingPeriod = Agent.PING_PERIOD;
  private int startAttemptWaitPeriod = Agent.START_ATTEMPT_PERIOD;

  // Setup the agent configuration options
  private static final String AGENT_OPTS =
    ConfigProperties.mergeValidOptions(
      SERVER_OPTS,
      DepotClient.DEPOT_CLIENT_OPTS +
      "b|buildscript str  path to reporter manager build script\n" +
      "C|check       str  check the reporter manager stage on resources\n" +
      "e|email       str  email to send notifications of manager restarts\n" +
      "r|rmdist      str  path to reporter manager tarball distribution\n" +
      "R|refreshPkgs int refresh period for checking for package updates\n" +
      "s|stayAlive   int period between stay alive pings of the manager\n" +
      "S|startAttempt int period between re-start attempts of the manager\n" +
      "u|upgrade     str  upgrade the reporter manager install on resources\n",
      true
    );
  static {
    MessageHandlerFactory.registerMessageHandler
      (Protocol.CATALOG_GET_COMMAND,
       "edu.sdsc.inca.agent.commands.RepositoryCommands");
    MessageHandlerFactory.registerMessageHandler
      (Protocol.CONFIG_GET_COMMAND,
       "edu.sdsc.inca.agent.commands.ConfigCommands");
    MessageHandlerFactory.registerMessageHandler
      (Protocol.CONFIG_SET_COMMAND,
       "edu.sdsc.inca.agent.commands.ConfigCommands");
    MessageHandlerFactory.registerMessageHandler
      (Protocol.REGISTER_COMMAND, "edu.sdsc.inca.agent.commands.Register");
    MessageHandlerFactory.registerMessageHandler
      (Protocol.PROXY_RENEW_INFO_GET_COMMAND,
       "edu.sdsc.inca.agent.commands.Proxy");
  }


  /**
   * Check to see if the reporter manager has been staged to all resources in
   * the specified resource group
   *
   * @param resourcesToCheck  A resource or resource group to check
   *
   * @throws ConfigurationException if missing information about a resource
   */
  public void checkReporterManagers( String resourcesToCheck )
    throws ConfigurationException {

    String[] resources = this.resources.getResources( resourcesToCheck, true );
    for ( int i = 0; i < resources.length; i++ ) {
      logger.info( "Checking reporter manager on resource " + resources[i] );
      String desc = "Reporter manager stage on resource " + resources[i] + ":";
      ReporterManagerStarter rmStarter = new ReporterManagerStarter(
        resources[i], this
      );
      for ( int j = 0; j < rmStarter.getEquivalentHosts().length; j++ ) {
        if ( rmStarter.isStaged() ) {
          logger.info( desc + " good" );
          return;
        }
        rmStarter.nextHost();
      }
      logger.error( desc + "' bad" );
    }
  }

  /**
   * Send a newer version of the specified package to all remote reporter
   * managers.
   *
   * @param packageName  The name of the package to update.
   */
  public void distributePackageUpdate( String packageName ) {
    String[] resources = this.rms.getResourceNames();
    for ( int i = 0; i < resources.length; i++) {
      ReporterManagerController managerController = getReporterManager(
        resources[i], this.getResources()
      );
      if ( managerController == null ) {
        logger.error(
          "Unable to retrieve controller for reporter manager " + resources[i]
        );
        return;
      }
      if ( managerController.hasPackage(packageName, null) ) {
        logger.debug(
          "Adding update for package " + packageName +
          " to reporter manager " + resources[i]
        );
        managerController.addPackage( packageName );
      }
    }
  }

  /**
   * Send the suites to all reporter managers.
   *
   * @param suites  A HashMap where the resources are the keys and
   * each entry is the SuiteDocument that should be distributed to the resource.
   */
  public void distributeSuites( HashMap suites ) {
    Iterator subIterator = suites.keySet().iterator();
    while( subIterator.hasNext()) {
      String resource = (String)subIterator.next();
      logger.debug( "Attempting to distribute suite to " + resource );
      ReporterManagerController managerController = this.getReporterManager(
        resource, this.getResources()
      );
      if ( managerController != null ) {
        SuiteDocument s=((SuiteWrapper)suites.get(resource)).getSuiteDocument();
        logger.debug( "Adding suite "+s.getSuite().getGuid()+" to "+resource );
        managerController.addSuite( s );
      } else {
        logger.error(
          "Unable to retrieve controller for reporter manager " + resource
        );
      }
    }
  }

  /**
   * Return the email address used to send notifications upon reporter manager
   * restart.
   *
   * @return The email address of the administrator or null if no emails should
   * be sent.
   */
  public String getAdminEmail() {
    return adminEmail;
  }

  /**
   * Returns the depot client object to use to communicate to the depot
   * (currently to send suite expanded documents).
   *
   * @return a depot client object.
   */
  public DepotClient getDepotClient() {
    return this.depotClient;
  }

  /**
   * Get the URIs for the depots.  For now this is one depot, but in the future
   * we will have a list of depots.  The first depot in the list will be used
   * unless it is unreachable. In that case, subsequent depots in the list
   * will be tried until one is reachable.
   *
   * @return  A list of depot URIs in the format:  inca[s]://host:port
   */
  public String[] getDepots() {
    return depots;
  }

  public static Agent getGlobalAgent() {
    return Agent.globalAgent;
  }

  /**
   * Return the current wait period between pinging of a reporter manager.
   *
   * @return the current ping wait period
   */
  public int getPingPeriod() {
    return this.pingPeriod;
  }

  /**
   * Get the controller for the remote reporter manager.  If the reporter
   * manager does not exist already, create it.
   *
   * @param resource  The name of the resource.
   * @param resources The resource configuration information.
   *
   * @return A reporter manager controller for the remote reporter manager
   * process. If we have just created the reporter manager process, will not
   * wait for reporter manager to register.
   */
  public ReporterManagerController getReporterManager( String resource,
                                             ResourcesWrapper resources ) {
    ReporterManagerController managerController;
    if ( this.rms.containsResource(resource)) {
      managerController = this.rms.get( resource );
    } else {
      logger.info("No active reporter manager on resource '" + resource + "'");
      try {
        managerController = new ReporterManagerController(
          resource, this );
        managerController.getReporterManagerStarter().start();
        rms.put( resource, managerController );
        logger.info( "Reporter manager started on resource '" + resource );
      } catch ( Exception e ) {
        logger.error(
          "Unable to start reporter manager for resource '" + resource + "'", e
        );
        return null;
      }
    }
    return managerController;
  }

  public ReporterManagerTable getReporterManagerTable() {
    return rms;
  }

  /**
   * Returns the list of reporter repositories the agent knows about.
   *
   * @return A list of repository objects.
   */
  public Repositories getRepositories() {
    return this.repositories;
  }

  /**
   * Return the repository cache which provides access to packages cached
   * locally on the Agent as they are requested in suites.
   *
   * @return  The repository cache object.
   */
  public RepositoryCache getRepositoryCache() {
    return this.repositoryCache;
  }

  /**
   * Retrieves the current resource configuration stored on the agent.
   *
   * @return A ResourcesWrapper object which holds the current resource
   * configuration.
   */
  public ResourcesWrapper getResources() {
    return this.resources;
  }

  /**
   * Return the current wait period between start attempts.
   *
   * @return the current start attempt wait period
   */
  public int getStartAttemptWaitPeriod() {
    return this.startAttemptWaitPeriod;
  }

  /**
   * Returns the suites stored at the agent.
   *
   * @return  A table of suites where the keys are the names of the suites
   * and the entries are SuiteDocuments.
   */
  public SuiteTable getSuites() {
    return this.suites;
  }

  /**
   * Starts the Agent server.  This overrides the Server call in order to
   * do some post configuration.
   */
  public void runServer() throws Exception {
    class RestartSuiteThread extends Thread {
      Agent agent;
      RestartSuiteThread( Agent agent ) {
        this.agent = agent;
      }
      public void run() {
        ranShutdown = false;
        try {
          logger.info( "Waiting for agent to start up" );
          while( ! this.agent.isRunning() ) {
            Thread.sleep(1000);
          }
          logger.info
            ( "Agent is up...sending existing suites to reporter managers" );
        } catch ( InterruptedException e ) {
          logger.info("Received interrupt while waiting for agent to start up");
          logger.info( "Exitting suite start up" );
          return;
        }
        this.agent.getRepositoryCache().start();
        this.agent.restartSuites();
      }
    }
    new RestartSuiteThread( this ).start();
    super.runServer();
  }

  /**
   * Overrides the server's setConfiguration function to configure the
   * agent specific properties.
   *
   * @param config contains configuration values
   * @throws ConfigurationException on a faulty configuration property value
   */
  public void setConfiguration(Properties config) throws ConfigurationException{
    logger.debug( "Configuring agent" );
    super.setConfiguration( config );

    if((config.getProperty("check")) != null) {
      this.checkReporterManagers = config.getProperty("check");
    }
    if ( config.getProperty("depot") == null ) {
      throw new ConfigurationException( "depot uri not defined" );
    }
    depotClient.setConfiguration( config );
    setAdminEmail( config.getProperty("email") );
    if((config.getProperty("stayAlive")) != null) {
      this.setPingPeriod(
        Integer.parseInt(config.getProperty("stayAlive")) *
        Constants.MILLIS_TO_SECOND
      );
    }
    if((config.getProperty("startAttempt")) != null) {
      this.setStartAttemptWaitPeriod(
        Integer.parseInt(config.getProperty("startAttempt")) *
        Constants.MILLIS_TO_SECOND
      );
    }
    this.setDepots( new String[] {depotClient.getUri()} );

    logger.debug( "temp path is " + this.getTempPath() );
    try {
      setAgentTempPath
        ( this.getTempPath() == null ? "/tmp" : this.getTempPath() );
    } catch(IOException e) {
      throw new ConfigurationException("Unable to configure temp directory", e);
    }
    if((config.getProperty("refreshPkgs")) != null) {
      this.getRepositoryCache().setUpdatePeriod(
        Integer.parseInt(config.getProperty("refreshPkgs")) *
        Constants.MILLIS_TO_SECOND
      );
    }
    if((config.getProperty("upgrade")) != null) {
      this.upgradeReporterManagers = config.getProperty("upgrade");
    }

    // The system property org.globus.ip is required for when the access method
    // globus is used.  Rather than propogating the hostname thru to the
    // AccessMethod class, we set it here to avoid api clutter even though
    // it's not needed unless the user uses the globus access method for one of
    // their resources.
    String ip = System.getProperty( GLOBUS_IP_PROPERTY );
    if ( ip == null ) {
      try {
        InetAddress addr = InetAddress.getByName( this.getHostname() );
        System.setProperty( GLOBUS_IP_PROPERTY, addr.getHostAddress() );
      } catch(IOException e) {
        logger.warn("Cannot resolve hostname: " + e);
      }
    }

  }

  /**
   * Set the URIs for the depots.  The first depot in the list will be used
   * unless it is unreachable. In that case, subsequent depots in the list
   * will be tried until one is reachable.
   *
   * @param depots  A list of depot URIs in the format:  inca[s]://host:port
   */
  public void setDepots( String[] depots ) {
    this.depots = depots;
  }

  /**
   * Set a new global agent.
   *
   * @param a  The new agent object
   */
  public static void setGlobalAgent( Agent a ) {
    logger.debug( "Setting global agent" );
    Agent.globalAgent = a;
  }

  /**
   * Set the period for how often to ping the reporter manager.
   *
   * @param pingPeriod  The period to wait in between pings to the reporter
   * manager.
   */
  public void setPingPeriod( int pingPeriod ) {
    this.pingPeriod = pingPeriod;
  }

  /**
   * Set the repositories the agent should download reporters from upon
   * receiving a suite (if it hasn't downloaded them before).
   *
   * @param repos  A list of repositories.
   */
  public void setRepositories(Repository[] repos) {
    this.repositories.setRepositories( repos );
    this.repositoryCache.setRepositories( this.repositories );
    this.updateCachedPackages();
  }

  /**
   * Set the repository cache which provides access to packages cached
   * locally on the Agent as they are requested in suites.

   * @param repositoryCache  A repository cache object.
   */
  public void setRepositoryCache( RepositoryCache repositoryCache ) {
    this.repositoryCache = repositoryCache;
  }

  /**
   * Check for updates on all packages in the repository cache including
   * reporters.  A series config is identified by the reporter context and
   * version of the reporter.  So, if a series config in a suite uses the
   * latest version of a package and there is a reporter update, we will need
   * to delete the existing series config (with its current version) and add
   * a new series config (with the updated package version).  This function
   * will iterate thru the agent's existing suites and perform the needed adds
   * and deletes.
   */
  public synchronized void updateCachedPackages() {
    String[] pkgs = this.repositoryCache.checkForPackageUpdates();
    for( int i = 0; i < pkgs.length; i++ ) {
      distributePackageUpdate( pkgs[i] );
      String[] suiteNames = this.getSuites().getNames();
      for ( int j = 0; j < suiteNames.length; j++ ) {
        logger.info(
          "Checking suite " + suiteNames[j] + " for package " + pkgs[i]
        );
        SuiteStagesWrapper suite = this.getSuites().getSuite( suiteNames[j] );
        PackageType pkg = this.getRepositoryCache().getPackage(pkgs[i], null);
        SuiteWrapper suiteMods = suite.updatePackage(
          pkgs[i],
          pkg.getVersion(),
          pkg.getUri()
        );
        if ( suiteMods.getSeriesConfigCount() < 1 ) {
          logger.info( "No changes found" );
          continue;
        }
        try {
          logger.info(
            "Found " + suiteMods.getSeriesConfigCount() + " changes"
          );
          SuiteStagesWrapper changes = suite.modify( suiteMods );
          logger.info( "Sending package update to depot" );
          BigInteger version = this.updateSuiteOnDepot(
            changes.getPerResourceSuiteDocument()
          );
          suite.getDocument().getSuiteStages().setVersion( version );
          suite.save();
          logger.info( "Sending package update to managers" );
          this.distributeSuites( changes.getResourceSuites() );
        } catch ( Exception e ) {
          logger.error(
            "Error applying package update for " + pkgs[i] + " to suite " +
            suiteNames[j], e
          );
        }
      }
    }
  }

  /**
   * Updates the resource configuration on the agent.
   *
   * @param resources  A ResourcesWrapper object which contains the new
   * resource configuration for the agent to utilize.
   *
   * @throws ConfigurationException if trouble reading info about resources
   * @throws CrypterException if trouble reading resource information
   * @throws IOException if trouble communicating with resources
   * @throws ProtocolException if problem communicating with resources
   * @throws XmlException if trouble updating resources
   */
  public synchronized void updateResources( ResourcesWrapper resources )
    throws XmlException, ProtocolException, ConfigurationException,
           CrypterException, IOException {

    if ( this.resources == null ) {
      throw new ConfigurationException( "Current resources is null" );
    }
    if ( this.getResources().equals(resources) ) {
      logger.info( "No resource change found" );
      return;
    }
    logger.debug( "Resources has changed" );

    String[] resourceNames = this.rms.getResourceNames();
    for ( int i = 0; i < resourceNames.length; i++ ) {
      ReporterManagerController rm = this.rms.get( resourceNames[i] );
      if ( rm != null ) {
        logger.info( "Updating resources for " + resourceNames[i] );
        rm.getReporterManagerStarter().refreshHosts();
      }
    }
    SuiteDocument[] changes = this.getSuites().applyResourceChanges(
      resources
    );
    this.setResources( resources );
    for ( int i = 0; i < changes.length; i++ ) {
      if ( new SuiteWrapper(changes[i]).getSeriesConfigCount() > 0 ) {
        logger.info( "Sending expanded suite update " + i + " to depot" );
      } else {
        logger.info( "No changes in suite " + i );
        continue;
      }
      try {
        this.updateSuiteOnDepot( changes[i] );
      } catch ( Exception e ) {
        logger.error( "Error sending suite expanded to depot " +
                      this.getDepotClient().getHost() + ":" +
                      this.getDepotClient().getPort(), e );
        throw new ProtocolException(
          "Error sending suite expanded to depot", e
        );
      }
      logger.info( "Depot accepted update to suite " + i );
      logger.info( "Queuing resource suites for suite " + i );
      try {
        this.distributeSuites(SuiteStagesWrapper.getResourceSuites(changes[i]));
      } catch ( Exception e ) {
        logger.error("Error distributing suites to reporter managers",e);
      }
      logger.info( "Suites queued for suite " + i );
    }
  }

  /**
   * Register the given reporter manager with the agent so that the agent
   * can begin to send it requests.
   *
   * @param resource  The resource the reporter manager is running on.
   * @param reader  the ProtocolReader for reading responses from the remote
   * reporter manager.
   * @param writer  the ProtocolWriter for sending commands to the remote
   * reporter manager.
   *
   * @throws IOException if trouble writing response to reporter manager
   */
  public void registerReporterManager(
    String resource, ProtocolReader reader, ProtocolWriter writer )
  throws IOException {

    // is this a resource we know about?
    if ( ! this.rms.containsResource(resource)) {
      String error = "Unknown resource " + resource + " registering";
      logger.error( error + "...ignoring" );
      writer.write(Statement.getErrorStatement(error));
      return;
    }

    // is this a duplicate resource?
    ReporterManagerController managerController = this.rms.get( resource );
    if ( managerController.isRunning() ) {
      String error = "Reporter manager already running for " + resource;
      logger.error( error );
      writer.write(Statement.getErrorStatement(error));
      return;
    }

    // Otherwise, reply it is OK and register this stream with the reporter
    // manager so the agent can continue to communicate with it.
    Statement response = new Statement(
      Protocol.SUCCESS_COMMAND.toCharArray()
    );
    writer.write(response);

    // name the thread to make it easier to view log messages
    Thread.currentThread().setName( resource );

    managerController.register( reader, writer );

  }

  public static void reinitialize() {
    Agent.globalAgent = new Agent();
  }

  /**
   * Called when a remote reporter manager registers with the agent in order
   * to get the existing suites for this resource.  Since we don't know
   * if this is a restart, we empty its queue and get the suites
   * from the table (since the suites contain any changes that might
   * be in the queue).  Since this function is sychronized, it should
   * be safe from race conditions (e.g., that might result in a suite
   * being added twice).
   *
   * @param resource  The resource the remote reporter manager is executing on.
   *
   * @param queue  The reporter manager's work queue.
   */
  public synchronized void reinitializeManagerWorkQueue(
    String resource, WorkQueue queue ) {

    logger.debug( "Reinitialize work queue for resource " + resource );
    // dump existing suite changes
    if ( ! queue.isEmpty() ) {
      logger.debug( "Starting with a fresh work queue " );
    }
    while ( ! queue.isEmpty() ) {
      try {
        logger.debug( "Emptying subcription from the queue" );
        queue.getWork();
      } catch ( InterruptedException e ) {
        logger.error( "Trying to empty work out of the queue", e );
      }
    }

    // get the complete suites but don't resend to manual reporter managers
    // since they have it already.  we do want to send the suite the first
    // time the manual rm is created (we know because it won't have any
    // xml files in its dir)
    ReporterManagerController managerController = this.getReporterManager(
      resource, this.getResources()
    );
    File manualFile = new File
      ( managerController.getTemporaryDirectory() + File.separator +
        ReporterManagerStarter.LAST_CHANGE );
    if ( managerController != null &&
         (! managerController.getReporterManagerStarter().isManual()
         || ! manualFile.exists())  ) {
      SuiteTable suites = this.getSuites();
      String[] names = suites.getNames();
      for ( int i = 0; i < names.length; i++ ) {
        SuiteStagesWrapper suite = suites.getSuite( names[i] );
        HashMap resourceSuites = suite.getResourceSuites();
        if ( resourceSuites.containsKey(resource) ) {
          logger.info( "Add suite " + names[i] + " to queue for " + resource );
          queue.addWork(
            ((SuiteWrapper)resourceSuites.get(resource)).getSuiteDocument()
          );
        }
      }
    }
    logger.debug( "Work queue reinitialized for resource " + resource );
  }

  /**
   * Read the existing suites from disk and restart them.
   */
  public synchronized void restartSuites() {
    String[] existingSuites = this.suites.getNames();
    for( int i = 0; i < existingSuites.length; i++ ) {
      try {
        logger.info( "Restarting suite '" + existingSuites[i] + "'" );
        SuiteStagesWrapper suite = suites.getSuite(
          existingSuites[i]
        );
        this.distributeSuites( suite.getResourceSuites() );
        logger.info( "Finished restarting suite '" + existingSuites[i] + "'" );
      } catch ( Exception e ) {
        logger.error(
          "Unable to restart suite '" + existingSuites[i] + "'", e
        );
      }
    }
  }

  /**
   * Set the email address of the Inca administrator who should be notified
   * when reporter managers are restarted.
   *
   * @param adminEmail  An email address of the Inca administrator.
   */
  public void setAdminEmail( String adminEmail ) {
    this.adminEmail = adminEmail;
  }

  /**
   * Sets the directory path where the Agent stores state files such as
   * its list of reporter repositories, reporter cache files, resources, and
   * suites.
   *
   * @param path the temporary directory path
   * @throws IOException if the path does not exist and cannot be created
   */
  public void setAgentTempPath( String path ) throws IOException {
    this.tempPath = path;
    this.repositories = new Repositories(
      path + File.separator + REPOSITORIES_PATH
    );

    RepositoryCache cache = new RepositoryCache(
      path + File.separator + REPOSITORY_CACHE , this.repositories
    );
    this.setRepositoryCache( cache );

    String rcPath = path + File.separator + RESOURCES_PATH;
    try {
      ResourcesWrapper resources = null;
      if ( this.password == null || this.password.equals("") ) {
        resources = new ResourcesWrapper( rcPath );
      } else {
        resources = new ResourcesWrapper( rcPath, this.password );
      }
      this.resources = resources;
    } catch ( Exception e ) {
      String error = "Unable to load resource config file '" + rcPath + "'";
      logger.error( error, e );
      throw new IOException( error + ": " + e );
    }
    if ( this.getResources() == null ) {
      throw new IOException( "resource config is null" );
    }
    this.setSuites( path );
  }

  /**
   * Set the current wait period between start attempts.
   *
   * @param startAttemptWaitPeriod  the new start attempt wait period
   */
  public void setStartAttemptWaitPeriod( int startAttemptWaitPeriod ) {
    this.startAttemptWaitPeriod = startAttemptWaitPeriod;
  }


  /**
   * Create a suite directory for storing the results of suites
   *
   * @param path  A string containing the path to store suites
   */
  public void setSuites( String path ) {
    this.suites = new SuiteTable(
      path + File.separator + SUITEDIR_PATH, this.getResources()
    );
  }

  /**
   * Overrides the server shutdown in order to shutdown the reporter manager's
   * before the general server shutdown.
   *
   * @throws InterruptedException  (see server javadoc)
   */
  public void shutdown() throws InterruptedException {
    if ( ! ranShutdown ) {
      logger.debug( "Shutting down reporter managers" );
      String[] resources = rms.getResourceNames();
      for ( int i = 0; i < resources.length; i++ ) {
        logger.info( "Shutting down reporter managerController on '" + resources[i] + "'" );
        ReporterManagerController managerController = rms.get( resources[i] );
        if ( managerController.isRunning() ) {
          managerController.shutdown();
        }
      }
      ranShutdown = true;
      logger.debug( "Shutting down agent" );
      this.getRepositoryCache().interrupt();
      this.getRepositoryCache().join();
      super.shutdown();
    }
  }

  /**
   * Sets the resource configuration for the agent.
   *
   * @param resources  The resource configuration information.
   *
   * @throws CrypterException if trouble encrypting/decrypting resources
   * @throws IOException if trouble communicating with reporter managers
   * @throws XmlException if trouble reading resources
   */
  public void setResources( ResourcesWrapper resources )
    throws XmlException, CrypterException, IOException {

    this.resources.setResourceConfigDocument(
      resources.getResourceConfigDocument()
    );
    this.resources.save();
  }

  /**
   * Receive a set suite request from client and validate the XML. Then:
   *
   * 1) resolve the reporter names into reporter uris using available repos
   * 2) set the guid of the suite
   * 3) apply the expanded suite to the existing suite and hold onto the applied
   *    changes
   * 4) create resource suites
   * 5) test the resources if no RM running now
   * 6) send the suite expanded to the depot
   * 7) return ok to the client
   * 8) load the reporters into our cache
   * 9) send the suites to the reporter managers
   *
   * @param suite An update to a suite or a new suite.
   *
   */
  public synchronized void updateSuite(SuiteWrapper suite) {

    SuiteDocument sd = suite.getSuiteDocument();
    String suiteName = sd.getSuite().getName();
    if ( suite.getSeriesConfigCount() < 1 ) {
      logger.info( "No changes received for suite '" + suiteName + "'" );
      return;
    }
    logger.info( "Received update for suite '" + suiteName + "'" );

    HashMap suites;

    SeriesConfig[] configs = suite.getSeriesConfigs();
    // 1) load the reporters into our cache
    logger.info( "Loading reporters for suite update '" + suiteName + "'" );
    for ( int i = 0; i < configs.length; i++ ) {
      String name = configs[i].getSeries().getName();
      String version = configs[i].getSeries().getVersion();
      if ( ! this.getRepositoryCache().existsLocally(name,version) ) {
        if ( ! this.getRepositoryCache().fetchPackage(name,version) ) {
          logger.error
            ( "Unable to retrieve package " + name + " version=" + version +
              "and/or its dependencies; rejecting suite update " + suiteName );
          return;
        }
      }
    }
    logger.info( "Reporters loaded for suite update '" + suiteName + "'" );

    // 2) resolve the reporter names into reporter uris using available repos
    logger.info( "Resolving reporter names for suite update " + suiteName );
    try {
      this.getRepositoryCache().resolveReporters( suite );
    } catch ( Exception e ) {
      logger.error( e.getMessage() );
      return;
    }
    logger.info( "All reporters found for update " + suiteName );

    // 3) set the guid of the suite
    String guid = this.getUri() + "/"  + suiteName;
    sd.getSuite().setGuid( guid );

    // 4) Apply the suiteExpandedChanges to the existing suite
    SuiteStagesWrapper existingSuiteStagesWrapper = null;
    SuiteStagesWrapper suiteChanges = null;
    try {
      existingSuiteStagesWrapper =
      this.getSuites().getSuite(suiteName, this.getResources());
      suiteChanges = existingSuiteStagesWrapper.modify( suite );
      if( suiteName.equals( Protocol.IMMEDIATE_SUITE_NAME ) ) {
        // Set action on all series to "delete" and redo modify.  This
        // assures that the stored suite files don't get cluttered by one-off
        // series and prevents us from re-running immediate series on restart.
        SeriesConfig[] immConfigs = suite.getSeriesConfigs();
        for(int i = 0; i < immConfigs.length; i++) {
          immConfigs[i].setAction( "delete" );
        }
        existingSuiteStagesWrapper.modify( suite );
      }
    } catch ( Exception e ) {
      logger.error( "Unable to apply changes to existing suite", e );
      return;
    }

    // 5) create resource suites
    logger.info( "Extracting resource suites for suite '" + suiteName + "'" );
    try {
      suites = suiteChanges.getResourceSuites();
    } catch ( Exception e ) {
      logger.error( "Error in preparing suite for distribution", e );
      return;
    }
    logger.info( "Suites extracted for suite '" + suiteName + "'" );

    // 6) send the suite expanded to the depot unless it's the run now suite
    if( !suiteName.equals( Protocol.IMMEDIATE_SUITE_NAME ) ) {
      logger.info( "Sending expanded suite update '" + guid + "' to depot" );
      try {
        existingSuiteStagesWrapper.getDocument().getSuiteStages().setVersion(
          this.updateSuiteOnDepot(suiteChanges.getPerResourceSuiteDocument())
        );
      } catch ( Exception e ) {
        logger.error( "Error sending suite expanded to depot " +
                      this.getDepotClient().getHost() + ":" +
                      this.getDepotClient().getPort(), e );
        return;
      }
      logger.info( "Depot accepted update to suite '" + suiteName + "'" );
    }

    // 7) queue the suites to the reporter managers
    logger.info("Queuing " + suites.size() + " suites for '" + suiteName + "'");
    try {
      this.distributeSuites( suites );
    } catch ( Exception e ) {
      logger.error( "Error distributing suites to reporter managers", e );
    }
    logger.info( "Resource suites queued for '" + suiteName + "'" );

    // 8) so far so good. store suite to disk
    logger.info( "Storing suite update for suite '" + suiteName + "'" );
    try {
      this.getSuites().putSuite( existingSuiteStagesWrapper );
    } catch ( Exception e ) {
      logger.error( "Error saving suite " + suiteName + " to disk", e );
      return;
    }
    logger.info( "Suite update stored for suite '" + suiteName + "'" );

    logger.info( "Suite update '" + suiteName + "' completed" );
  }

  /**
   * Send the suite changes to the depot.
   *
   * @param expanded   An expanded suite document that should be sent to depot
   *
   * @return the new suite version number
   *
   * @throws ConfigurationException if trouble reading config info
   * @throws IOException if trouble communicating with depot
   * @throws ProtocolException if unexpected responses from depot
   */
  public  BigInteger updateSuiteOnDepot( SuiteDocument expanded )
    throws ConfigurationException, IOException, ProtocolException {

    this.getDepotClient().connect();
    String version = this.getDepotClient().updateSuite( expanded.xmlText() );
    this.getDepotClient().close();
    return new BigInteger(version);
  }

  /**
   * Upgrade the reporter manager distributions on the specified resources
   * read upon configuration.
   *
   * @param resourcesToUpgrade A resource name or group to upgrade
   *
   * @throws ConfigurationException if trouble reading resource config info
   */
  public void upgradeReporterManagers( String resourcesToUpgrade )
    throws ConfigurationException {

    String[] resourceNames = this.resources.getResources( resourcesToUpgrade, true );
    int numSuccessfulUpgrades = 0;
    for ( int i = 0; i < resourceNames.length; i++ ) {
      logger.info(
        "Upgrading reporter manager on resource '" + resourceNames[i] + "'"
      );
      ReporterManagerStarter rmStarter = new ReporterManagerStarter(
        resourceNames[i], this
      );
      int j;
      for ( j = 0; j < rmStarter.getEquivalentHosts().length; j++ ) {
        try {
          rmStarter.findBashLoginShellOption();
          rmStarter.stage( true );
          break;
        } catch ( ReporterManagerException e ) {
          logger.error(
            "Attempt to upgrade resource " + resourceNames[i] +
            " failed using host " + rmStarter.getCurrentHost(), e
          );
        }
        rmStarter.nextHost();
      }
      if ( j < rmStarter.getEquivalentHosts().length ) {
        logger.info(
          "Upgrade on resource '" + resourceNames[i] + "' completed"
        );
        numSuccessfulUpgrades++;
      } else {
        logger.error(
          "Upgrade on resource '" + resourceNames[i] + "' failed"
        );
      }
    }
    logger.info
      ( "Upgrade complete:  " + numSuccessfulUpgrades + " out of " +
        resourceNames.length + " resources were successfully upgraded" );
  }

  public boolean hasCredentials() {
    return this.authenticate &&
           this.getCertificate() != null &&
           this.getKey() != null &&
           this.getTrustedCertificates() != null;
  }

  public static void main(String[] args) {
    Agent a = new Agent();
    try {
      configComponent
        (a, args, AGENT_OPTS, "inca.agent.", "edu.sdsc.inca.Agent",
         "inca-agent-version");
    } catch(Exception e) {
      logger.fatal("Configuration error: ", e);
      System.err.println("Configuration error: " + e);
      System.exit(1);
    }
    try {
      Agent.setGlobalAgent( a );
      if ( a.upgradeReporterManagers != null ) {
        Agent.getGlobalAgent().readCredentials();
        Agent.getGlobalAgent().upgradeReporterManagers(
          a.upgradeReporterManagers
        );
      } else if ( a.checkReporterManagers != null ) {
        Agent.getGlobalAgent().readCredentials();
        Agent.getGlobalAgent().checkReporterManagers( a.checkReporterManagers );
      } else {
        a.runServer();
        while ( a.isRunning() ) {
          Thread.sleep( 2000 );
        }
      }
    } catch (Exception e) {
      logger.fatal("Server error: ", e);
      System.err.println("Server error: " + e);
      System.exit(1);
    }
  }

}
