package edu.sdsc.inca;

import junit.framework.TestCase;

import java.util.Properties;
import java.util.HashMap;
import java.util.regex.Pattern;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

import edu.sdsc.inca.agent.RepositoryCacheTest;
import edu.sdsc.inca.agent.RepositoryCache;
import edu.sdsc.inca.agent.ReporterManagerController;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.protocol.Statement;
import edu.sdsc.inca.dataModel.util.Resource;
import edu.sdsc.inca.dataModel.suite.SuiteDocument;
import edu.sdsc.inca.repository.Repository;
import edu.sdsc.inca.repository.Repositories;
import edu.sdsc.inca.repository.RepositoriesTest;
import edu.sdsc.inca.util.ConfigProperties;
import edu.sdsc.inca.util.ResourcesWrapper;
import edu.sdsc.inca.util.ResourcesWrapperTest;
import edu.sdsc.inca.util.SuiteWrapper;
import edu.sdsc.inca.util.SuiteStagesWrapper;
import edu.sdsc.inca.util.StringMethods;

import javax.net.ServerSocketFactory;

import org.apache.log4j.Logger;

/**
 * Tester class for Agent.  Other tests are in the AgentClientTest class.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class AgentTest extends TestCase {
  public static final String RESOURCES_FILE = "test/sampleresources.xml";
  public static final String TEST_RESOURCE = "localhost";
  public static final String REPOSITORY = "test/repository";
  public static final int LOW_LEVEL = 0;
  public static final int HIGH_LEVEL = 1;


  static private Logger logger = Logger.getLogger(AgentTest.class);

  private ConfigProperties config = null;
  private Agent agent = null;

  /**
   * A mockobject for the depot to that is used from the AgentClientTest.
   */
  static public class MockDepot extends Thread {
    private int port = -1;
    private int numReportsExpected = 0;
    public int numReportsReceived = 0;
    public String [] reports;
    private Logger logger = Logger.getLogger( this.getClass().getName() ) ;
    public int numSuitesExpected = 0;

    /**
     * Create a new mockdepot.
     *
     * @param port        The port to start the mock depot on.
     * @param numReports  The number of reports the depot should expect before
     * exitting.
     */
    public MockDepot( int port, int numReports) {
      this.port = port;
      this.numReportsExpected = numReports;
      this.reports = new String[numReports];
    }

    public boolean checkReportsForPatterns( String[] patterns ) {
      for ( int i = 0; i < patterns.length ; i++) {
        Pattern pattern = Pattern.compile(patterns[i]);
        int j;
        for ( j = 0; j < reports.length; j++ ) {
          if ( pattern.matcher(reports[j]).find() ) break;
        }
        if ( j >= reports.length ) {
          logger.info( "Pattern " + patterns[i] + " not found in any report" );
          return false;
        }
      }
      return true;
    }

    /**
     * Return the number of reports the depot actually received.  Should be
     * called after run or start.
     *
     * @return  the number of reports the depot received.
     */
    public int getNumReportsReceived() {
      return numReportsReceived;
    }

    public void run() {

      ServerSocketFactory factory =  ServerSocketFactory.getDefault();
      ServerSocket depotSocket = null;
      try {
        depotSocket = factory.createServerSocket( port );
      } catch ( IOException e ) {
        e.printStackTrace();
        return;
      }
      logger.info( "Starting on port " + port );
      for( int i = 0; i < numSuitesExpected; i++ ) {
        logger.info( "Expecting suite expanded" );
        try {
          Socket depot = depotSocket.accept();
          logger.info( "Connection received");
          ProtocolReader depotReader = new ProtocolReader(
            new InputStreamReader(depot.getInputStream())
          );
          ProtocolWriter depotWriter = new ProtocolWriter(
            new OutputStreamWriter(depot.getOutputStream())
          );
          logger.info( "Waiting to receive suite expanded" );
          Statement suiteStmt = depotReader.readStatement();
          logger.info( "Received: " + suiteStmt.toString() );
          Statement reply;
          String cmd = new String( suiteStmt.getCmd() );
          if ( cmd.equals("PING")) {
            reply = Statement.getOkStatement( new String(suiteStmt.getData()) );
          } else {
            logger.error( "Received wrong command" );
            reply = Statement.getErrorStatement(
              "Expecting ping command; got " + cmd
            );
          }
          depotWriter.write(reply);
          suiteStmt = depotReader.readStatement();
          cmd = new String( suiteStmt.getCmd() );
          if ( cmd.equals("SUITE")) {
            logger.info( "Received suite command" );
            reply = Statement.getOkStatement( "2" );
            SuiteDocument suiteDoc = SuiteDocument.Factory.parse(
              new String( suiteStmt.getData() )
            );
            String guid = suiteDoc.getSuite().getGuid();
            assertTrue( "GUID looks good",
                        Pattern.matches("^.*:.*/.*", guid) );
          } else {
            logger.error( "Received wrong command" );
            reply = Statement.getErrorStatement(
              "Expected 'SUITE'; received " + cmd
            );
          }
          depotWriter.write(reply);
        } catch ( Exception e ) {
          logger.debug( "Fatal error in mock depot", e );
        }
      }
      for( int i = 0; i < numReportsExpected; i++ ) {
        try {
          logger.info( "Waiting to receive report " + i );
          Socket depot = depotSocket.accept();
          logger.info( "Received connection from client" );
          ProtocolReader depotReader = new ProtocolReader(
            new InputStreamReader(depot.getInputStream())
          );
          ProtocolWriter depotWriter = new ProtocolWriter(
            new OutputStreamWriter(depot.getOutputStream())
          );
          logger.info( depotReader.readStatement().toString() ); // START
          depotWriter.write(Statement.getOkStatement(Statement.getVersion()));
          logger.info( depotReader.readStatement().toString() ); // REPORT
          Statement reportStmt = depotReader.readStatement(); // STDOUT
          this.reports[i] = new String( reportStmt.getData() );
          logger.info( "Received: " + this.reports[i] );
          logger.info( depotReader.readStatement().toString() ); // SYSUSAGE
          depotReader.close();
          depot.close();
          logger.info( "Received report " + i );
          numReportsReceived++;
        } catch ( Exception e) {
          e.printStackTrace();
          return;
        }
      }
      try {
        logger.info("Closing socket");
        depotSocket.close();
      } catch ( IOException e ) {
        e.printStackTrace();
      }
    }
  }

  /**
   * Start up the agent server
   *
   * @param auth        Configure the agent with authentication
   *
   * @param repository  Configure the agent with a temporary repository
   *
   * @throws Exception
   */
  public void createAgent( boolean auth, boolean repository )
    throws Exception {

    ResourcesWrapper resources = ResourcesWrapperTest.createSampleResources();

    agent = new Agent();
    Agent.setGlobalAgent( agent );
    config.setProperty( "auth", Boolean.toString( auth) );
    agent.setConfiguration( config );
    agent.runServer();
    if ( auth ) agent.setPassword( "topSecret!" );
    assertTrue( "agent is alive", agent.isRunning() );

    agent.setResources( resources );
    if ( repository ) {
      Repositories repositories = RepositoriesTest.createSampleRepository(null);
      RepositoryCache cache = RepositoryCacheTest.createSampleRepositoryCache(
        repositories
      );
      agent.setRepositories( repositories.getRepositories() );
      agent.setRepositoryCache( cache );
    }
  }

  /**
   * Return true if there is a sytem property inca.test=1 indicating to run
   * the heavier duty agent tests
   *
   * @return True if heavier duty agent tests should be run; otherwise false
   */
  public static boolean isRunningTest() {
    Properties sysProps = System.getProperties();
    String testLevel = sysProps.getProperty( "inca.test");
    if ( testLevel == null || Integer.parseInt(testLevel) == LOW_LEVEL ) {
      logger.warn( "Skipping test");
      return false;
    }
    return true;
  }

  /**
   * Return true if there is a system property inca.test.proxy indicating a
   * MyProxy server is available to test proxy related functionality
   *
   * @return True if proxy related tests should be run; false otherwise
   */
  public static boolean hasMyProxyServer() {
    Properties sysProps = System.getProperties();
    if ( sysProps.getProperty( "inca.test.myproxy") == null ) {
      logger.warn( "Skipping myproxy related test");
      return false;
    }
    return true;
  }

  /**
   * Return true if there is a system property inca.test.globus indicating a
   * GRAM and GridFTP server is available to test Globus related functionality
   *
   * @return True if Globus related tests should be run; false otherwise
   */
  public static boolean hasGlobusServer() {
    Properties sysProps = System.getProperties();
    if ( sysProps.getProperty( "inca.test.globus") == null ) {
      logger.warn( "Skipping globus related test");
      return false;
    }
    return true;
  }

  /**
   * Return true if there is a system property inca.test.ssh indicating a
   * SSH server is available to test SSH related functionality
   *
   * @return True if SSH related tests should be run; false otherwise
   */
  public static boolean hasSshServer() {
    Properties sysProps = System.getProperties();
    if ( sysProps.getProperty( "inca.test.ssh") == null ) {
      logger.warn( "Skipping ssh related test");
      return false;
    }
    return true;
  }

  /**
   * Create a configuration for the agent and clean out the agent temporary
   * files.
   *
   * @throws Exception
   */
  public void setUp() throws Exception {
    config = new ConfigProperties();
    config.putAllTrimmed(System.getProperties(), "inca.agent.");
    config.loadFromResource("inca.properties", "inca.agent.");
    config.setProperty( "auth", "false" );
    config.setProperty( "password", "" );

    File tempDir = new File( "var" );
    StringMethods.deleteDirectory( tempDir );
    Agent.reinitialize();
  }

  /**
   * Start up a remote reporter manager and wait for it to register
   *
   * @throws InterruptedException
   */
  public void startReporterManager() throws InterruptedException {
    logger.debug( "get reporter managerController" );
    ReporterManagerController managerController = agent.getReporterManager(
      TEST_RESOURCE, agent.getResources()
    );
    logger.debug( "got reporter managerController" );
    assertNotNull(managerController);
    assertFalse( "isRunning is false", managerController.isRunning() );
    assertTrue(
      "wait returned true",
      managerController.getReporterManagerStarter().waitForReporterManager()
    );
    assertTrue( "isRunning is true", managerController.isRunning() );
    logger.info( "Received reporter managerController" );
  }

  /**
   * Submit a suite to the agent and configure a mock depot to receive the
   * reports and return them
   *
   * @param suitePath    The suite to submit to the agent.
   *
   * @param numReports   The number of reports to have the mock depot receive
   *
   * @return A list of received reports from the mock depot
   *
   * @throws Exception
   */
  public String[] submitSuite( String suitePath, int numReports )
    throws Exception {

    Agent agent = Agent.getGlobalAgent();

    MockDepot depot = new MockDepot( 8935, numReports );
    depot.start();
    agent.setDepots( new String[]{ "inca://localhost:8935"} );

    // now delete one of them
    SuiteWrapper suite = new SuiteWrapper( suitePath );
    String suiteName = suite.getSuiteDocument().getSuite().getName();
    agent.getRepositoryCache().resolveReporters( suite );
    logger.info( "Submitting suite " + suiteName );

    // create a blank suite
    SuiteStagesWrapper changes;
    if  ( ! agent.getSuites().hasSuite( suiteName ) ) {
      File suiteFile = File.createTempFile( "inca", ".xml" );
      if ( suiteFile.exists() ) suiteFile.delete();
      SuiteStagesWrapper suiteStages = new SuiteStagesWrapper(
        suiteFile.getAbsolutePath(), agent.getResources()
      );
      changes = suiteStages.modify(suite);
      agent.getSuites().putSuite( suiteStages );
    } else {
      SuiteStagesWrapper suiteStages = agent.getSuites().getSuite( suiteName );
      changes = suiteStages.modify(suite);
    }

    // read in samplesuitelocal.xml and apply it to suite
    HashMap resourceSuite = changes.getResourceSuites();
    assertEquals( "one suite extracted", 1, resourceSuite.size() );


    logger.debug( "Distributing suite to manager" );
    agent.distributeSuites( resourceSuite );

    depot.join();
    assertEquals( numReports + " reports received by depot", numReports,
                  depot.getNumReportsReceived() );
    return depot.reports;
  }

  /**
   * Cleanup the agent if it was started
   *
   * @throws Exception
   */
  public void tearDown() throws Exception {
    if ( agent != null ) agent.shutdown();
  }

  /**
   * Tests the controller's checkReporterManagerStaging function.
   *
   * @throws Exception
   */
  public void testCheckReporterManagerStaging() throws Exception {
    if ( ! AgentTest.isRunningTest() ) return;

    ResourcesWrapper resources = ResourcesWrapperTest.createSampleResources();
    Agent agent = Agent.getGlobalAgent();
    agent.setAgentTempPath( "/tmp" );
    agent.setResources( resources );
    agent.checkReporterManagers( "localhost" ); // no exception
  }

  /**
   * Tests the controller's distributeSubcriptions function.  Should start
   * up a reporter manager and a depot to receive the reports.
   *
   * @throws Exception
   */
  public void testDeleteSuites() throws Exception {
    if ( AgentTest.isRunningTest() == false ) return;

    createAgent( false, true );
    submitSuite( "test/samplesuitelocal.xml", 2 );

    Thread.sleep(2000);
    logger.info( "Preparing to delete one reporter " );
    String[] reports = submitSuite( "test/delete_samplesuitelocal.xml", 1 );
    assertTrue(
      "openssl report received",
      Pattern.compile( "openssl").matcher( reports[0] ).find()
    );
  }

  /**
   * Tests the controller's distributeSubcriptions function.  Should start
   * up a reporter manager and a depot to receive the reports.
   *
   * @throws Exception
   */
  public void testDistributeSuites() throws Exception {
    if ( AgentTest.isRunningTest() == false ) return;

    createAgent( false, true );
    submitSuite( "test/samplesuitelocal.xml", 2 );
  }

  /**
   * Same as testDistributeSuites but with authentication
   *
   * @throws Exception
   */
  public void testDistributeSuitesAuth() throws Exception {
    if ( AgentTest.isRunningTest() == false ) return;

    createAgent( true, true );
    submitSuite( "test/samplesuitelocal.xml", 2 );
  }

  /**
   * Test the register task
   *
   * @throws Exception
   */
  public void testRegisterAuth() throws Exception {
    if ( isRunningTest() == false) return;

    createAgent( true, false );
    startReporterManager();
  }

  /**
   * Test the register task
   *
   * @throws Exception
   */
  public void testRegister() throws Exception {
    if ( isRunningTest() == false) return;

    createAgent( false, false );
    startReporterManager();
  }

  /**
   * Create a Agent object and configure it with a repositories file.  Create
   * a new Agent object and verify the repositories is there.  Set a new
   * repositories list and check the timestamp on the repositories file.
   *
   * @throws Exception
   */
  public void testRepositoriesPersistence() throws Exception {
    Agent agent = new Agent();
    agent.setConfiguration(config);
    assertEquals(
      "no resource yet",
      0,
      agent.getRepositories().getRepositories().length
    );
    Repositories repositories = RepositoriesTest.createSampleRepository(null);
    agent.setRepositories( repositories.getRepositories() );

    logger.debug( "Restarting agent" );
    agent = new Agent();
    agent.setConfiguration(config);
    assertEquals(
      "found 1 repositories",
      1,
      agent.getRepositories().getRepositories().length
    );

    File file = new File( "var" + File.separator +  "repositories.xml" );
    long lastsave = file.lastModified();
    Thread.sleep(2000);
    Repository[] repos = new Repository[0];
    logger.debug( "Setting new repositories" );
    agent.setRepositories( repos );
    logger.debug( "Checking timestamps" );
    assertTrue( "repositories.xml modified", file.lastModified() > lastsave );
  }

  /**
   * 1) Start up a fresh agent and check there are no resources configured
   * 2) Save the sample resources to the tempdir and start a new agent and
   *    check the sample resources is available
   * 3) Save a new blank resources file in the agent and check the timestamp
   * r) Configure the agent with a password and set a new resources file to
   *    be saved with encryption and then read it back in and verify the
   *    resource is there.
   *
   * @throws Exception
   */
  public void testResourceConfigPersistence() throws Exception {
    String filename = "var" + File.separator +
                      "resources.xml";
    File file = new File( filename );
    if ( file.exists() ) {
      file.delete();
    }
    Agent agent = new Agent();
    agent.setTempPath( "var" );
    agent.setConfiguration(config);
    assertEquals(
      "no resource yet",
      0,
      agent.getResources().getResourceConfigDocument().getResourceConfig().
      getResources().sizeOfResourceArray()
    );
    logger.info( "----------------------" );

    logger.info( "Creating fresh agent" );
    ResourcesWrapper resources = ResourcesWrapperTest.createSampleResources();
    resources.setFilePath( "var/resources.xml" );
    resources.setPassphrase( config.getProperty("password") );
    resources.save( );
    int resourceCount = resources.getResourceConfigDocument().
      getResourceConfig().getResources().sizeOfResourceArray();
    agent = new Agent();
    agent.setConfiguration(config);
    assertEquals(
      "found " + resourceCount + " resources",
      resourceCount,
      agent.getResources().getResourceConfigDocument().getResourceConfig().getResources().sizeOfResourceArray()
    );

    long lastsave = file.lastModified();
    Thread.sleep(2000);
    resources = new ResourcesWrapper();
    agent.setResources( resources );
    assertTrue( "resource.xml modified", file.lastModified() > lastsave );
    file.delete();
    logger.info( "----------------------" );

    logger.info( "Encryption begins" );
    // test encryption - first create an encrypted resource config
    String tmpPassword = "tissecret";
    agent = new Agent();
    agent.setPassword( tmpPassword );
    agent.setConfiguration(config);
    assertEquals(
      "no resource yet",
      0,
      agent.getResources().getResourceConfigDocument().getResourceConfig().getResources().sizeOfResourceArray()
    );
    resources = new ResourcesWrapper();
    Resource resource =
      resources.getResourceConfigDocument().getResourceConfig().getResources().addNewResource();
    resource.setName( "resourceA" );
    logger.info( "----------------------" );

    agent.setResources( resources );
    assertTrue( "encrypted resource config written", file.exists() );
    // now try to re-read it
    agent = new Agent();
    config.setProperty( "password", tmpPassword );
    agent.setConfiguration(config);
    config.remove( "password" );
    assertEquals(
      "resource read in",
      1,
      agent.getResources().getResourceConfigDocument().getResourceConfig().getResources().sizeOfResourceArray()
    );
    file.delete();
  }

  /**
   * Create an Agent object and save a suite.  Start a new agent object and
   * verify the suite is there.  Save a delete series change to the suite
   * and verify the timestamp and number of series.
   *
   * @throws Exception
   */
  public void testSuitePersistence() throws Exception {
    Repositories repositories = RepositoriesTest.createSampleRepository(null);

    String filename = "var" + File.separator +
                      "suites";
    File file = new File( filename );
    StringMethods.deleteDirectory( file );
    ResourcesWrapper resources = ResourcesWrapperTest.createSampleResources();
    logger.info( "\n>> Starting with initialized agent" );
    Agent agent = Agent.getGlobalAgent();
    agent.setConfiguration(config);
    agent.setRepositories( repositories.getRepositories() );
    agent.setResources( resources );
    RepositoryCache cache = RepositoryCacheTest.createSampleRepositoryCache(
      repositories
    );
    assertEquals(
      "no suites yet",
      0,
      agent.getSuites().getNames().length
    );
    logger.info( "\n>> Reading in TestSuiteLocal" );
    SuiteWrapper suite = new SuiteWrapper("test/samplesuitelocal.xml" );
    cache.resolveReporters( suite );
    logger.info( "\n>> Putting TestSuiteLocal in Agent" );
    SuiteStagesWrapper currentSuiteStagesWrapper = agent.getSuites().getSuite("TestSuiteLocal", resources);
    currentSuiteStagesWrapper.modify( suite );
    agent.getSuites().putSuite(currentSuiteStagesWrapper);
    logger.info( "\n>> Agent should now have TestSuiteLocal" );
    logger.info( "\n>> Starting fresh agent - should read in TestSuiteLocal " );

    agent = new Agent();
    agent.setConfiguration(config);
    assertEquals(
      "found 1 suite",
      1,
      agent.getSuites().getNames().length
    );
    logger.info( "\n>> Reading in delete suite request" );
    SuiteWrapper suiteDeletes = new SuiteWrapper( "test/delete_samplesuitelocal.xml" );
    cache.resolveReporters( suiteDeletes );
    File suiteFile = new File(
      file.getAbsolutePath() + File.separator + "TestSuiteLocal.xml"
    );
    long lastsave = suiteFile.lastModified();
    Thread.sleep(2000);
    logger.info( "\n>> Putting in delete suite request" );
    currentSuiteStagesWrapper = agent.getSuites().getSuite("TestSuiteLocal");
    currentSuiteStagesWrapper.modify( suiteDeletes );
    agent.getSuites().putSuite(currentSuiteStagesWrapper);
    logger.info( "\n>> delete suite finished" );
    assertTrue( "TestSuiteLocal.xml modified",
                suiteFile.lastModified() > lastsave );

    assertEquals( "Have 2 configs in expanded", 2,
                  new SuiteWrapper(
                    agent.getSuites().getSuite( "TestSuiteLocal").getPerResourceSuiteDocument()).
                  getSeriesConfigCount() );

    StringMethods.deleteDirectory( file );
  }

  /**
   * Tests the controller's upgradeReporterManager function.
   *
   * @throws Exception
   */
  public void testUpgradeResources() throws Exception {
    if ( ! AgentTest.isRunningTest() ) return;

    ResourcesWrapper resources = ResourcesWrapperTest.createSampleResources();
    Agent agent = Agent.getGlobalAgent();
    agent.setAgentTempPath( "/tmp" );
    agent.setResources( resources );
    agent.upgradeReporterManagers( "localhost" ); // no exception
  }
}
