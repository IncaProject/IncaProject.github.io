package edu.sdsc.inca.agent.access;

import org.globus.myproxy.MyProxyException;
import org.globus.gsi.gssapi.auth.IdentityAuthorization;
import org.globus.ftp.GridFTPClient;
import org.globus.ftp.Session;
import org.apache.log4j.Logger;
import org.gridforum.jgss.ExtendedGSSManager;
import org.ietf.jgss.GSSCredential;
import org.ietf.jgss.GSSException;

import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.agent.AccessMethod;
import edu.sdsc.inca.agent.ReporterManagerProxy;
import edu.sdsc.inca.util.ResourcesWrapper;
import edu.sdsc.inca.util.Constants;
import edu.sdsc.inca.agent.AccessMethodException;
import edu.sdsc.inca.agent.AccessMethodOutput;
import edu.sdsc.inca.protocol.Protocol;

import java.io.File;
import java.util.Random;


/**
 * A class that implements AccessMethod using Globus commands
 * (i.e., gridFTP and GRAM) for transferring files and running processes on
 * remote resources.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class Globus extends AccessMethod {
  // Constants
  public static final int MINIMUM_LIFETIME = 4 * Constants.SECONDS_TO_HOUR;
  public static final int GASS_PORT = 0;
  private static Logger logger = Logger.getLogger(Globus.class);
  public static Random RANDOM = new Random();

  public class Service {
    public String host = null;
    public int port = 0;
    public String dn = null;

    public String toString() {
      String contact = host;
      if ( port != 0 ) {
        contact += ":" + port;
      }
      if ( dn != null ) {
        contact += ":" + dn;
      }
      return contact;
    }
  }

  // Member variables
  protected Service gridftpService = null;
  protected GlobusJob gram = null;
  private ReporterManagerProxy proxy = null;
  private GSSCredential credential = null;

  /**
   * Create a new remote process controlling it via Globus commands. The given
   * resource should exist in the resource configuration file and have the
   * following fields defined:  gridFtpServer, gridFtpPort, gramServer,
   * and gramPort.  If one of those fields is missing, a ConfigurationException
   * is thrown.
   *
   * @param resource  The name of the resource to start the process on
   *
   * @param resources  The resource configuration information.
   *
   * @param temp      Path to a directory for temporary files to be stored
   *
   * @param provider  Indicate version of globus to use (i.e., GT2 or GT4)
   *
   * @throws ConfigurationException  if trouble configuring globus resource
   */
  public Globus(
    String resource, ResourcesWrapper resources, String temp, String provider )
    throws ConfigurationException {

    // Transfer info - <gridftp server>:<gridftp port>[:<gridftp server dn>]
    this.gridftpService = new Service();
    this.gridftpService.host = resources.getValue
      ( resource, Protocol.FILE_SERVER_MACRO );
    if ( this.gridftpService.host == null ) this.gridftpService.host = resource;
    String portString = resources.getValue(resource, Protocol.FILE_PORT_MACRO);
    if ( portString == null ) {
      portString = Protocol.FILE_PORT_MACRO_DEFAULT;
    }
    this.gridftpService.port = Integer.parseInt(portString);
    this.gridftpService.dn = resources.getValue(resource, Protocol.GRIDFTP_DN_MACRO);
    logger.debug( "gridftp contact: " + this.gridftpService);

    // Remote invocation
    //   <gram server>:<gram port>[/gram service][:<gram server dn>]
    String gramServer = resources.getValue
      ( resource, Protocol.COMPUTE_SERVER_MACRO );
    if ( gramServer == null ) gramServer = resource;
    int port = 0;
    portString = resources.getValue( resource, Protocol.COMPUTE_PORT_MACRO );
    if ( portString != null ) {
      port = Integer.parseInt(portString);
    }
    String service = resources.getValue(resource,Protocol.GRAM_SERVICE_MACRO);
    String dn = resources.getValue(resource, Protocol.GRAM_DN_MACRO);
    this.gram = GlobusJob.create
      ( provider, gramServer, port, dn, service, this.gridftpService);

    // proxy for launching jobs
    try {
      this.proxy = new ReporterManagerProxy( resource, resources );
    } catch ( ConfigurationException e ) {
      logger.info(
        "Proxy renewal turned off for resource '" + resource + "': " + e
      );
      this.proxy = null;
    }
    try {
      this.gram.setCredential( this.getCredential() );
    } catch ( Exception e ) {
      throw new ConfigurationException( "Unable to get credential", e );
    }
    this.gram.setTempDir( temp );
  }

  /**
   * Transfer a list of remote files to a directory on the local machine using
   * GridFTP.
   *
   * @param remoteFiles  Array of paths to remote files that will be transfered
   *
   * @param localDirPath    Path to the local directory where the remote file
   *                        will be placed
   *
   * @throws AccessMethodException if unable to put file
   */
  public void get( String[] remoteFiles, String localDirPath )
    throws AccessMethodException {

    try {
      // create connection
      GridFTPClient gridftp = connectGridftp();

      // make dir if it doesn't already exist.
      File localDirHandle = new File( localDirPath );
      if ( ! localDirHandle.exists() ) {
        if ( ! localDirHandle.mkdirs() ) {
          throw new AccessMethodException(
            "Failed to create directory '" + localDirPath + "'"
          );
        }
      }

      // get files
      for ( String remoteFile : remoteFiles ) {
        // Strip off $(HOME)/ if it exists because only gram recognizes it
        String remoteFilePath = remoteFile.replaceFirst
          ( "\\$\\(HOME\\)/", "" );
        remoteFilePath = remoteFilePath.replaceFirst( "\\$\\{GLOBUS_USER_HOME\\}/", "" );

        File remoteFileHandle = new File( remoteFilePath );
        String localFilePath = localDirPath + "/" + remoteFileHandle.getName();
        logger.debug
          ( "Get of remote file " + remoteFilePath + " to " + localFilePath );
        gridftp.setLocalPassive();
        gridftp.setActive();        // this needs to be set on every transfer
        gridftp.setType(Session.TYPE_IMAGE);
        gridftp.get( remoteFilePath, new File(localFilePath) );
      }
      gridftp.close();
    } catch ( Exception e ) {
      throw new AccessMethodException( "Unable to get files", e );
    }

  }

  /**
   * Check whether the remote process is alive.
   *
   * @return true if the remote process is alive; false otherwise.
   */
  public boolean isActive() {
    return gram.isActive();
  }

  /**
   * Given a path relative to the home directory, prepend '$(HOME)/'
   * to the path and return the new string.
   *
   * @param path   A path relative to the user's home directory
   *
   * @return  A new string that contains '$(HOME)/' prepended to the
   * provided path.
   */
  public String prependHome( String path ) {
    return this.gram.prependHome( path );
  }


  /**
   * Execute the specified process on the remote resource.  This call will block
   * until the process has completed.
   *
   * @param executable Path to the remote executable.
   * @param arguments  Contains the arguments that should be passed to the
   *                   executable
   * @param stdin      A string that will be passedd in as stdin to the process
   *                   when it is started

   * @param directory  Path to the directory where the process will be executed
   *                   from
   * @return The stdout and stderr of the executed process in
   * RemoteProcessObject.
   */
  public AccessMethodOutput run ( String executable, String[] arguments,
                                  String stdin, String directory )
    throws AccessMethodException, InterruptedException {

    return this.gram.run( executable, arguments, stdin, directory );
  }

  /**
   * Set the proxy for Globus related tasks.
   *
   * @param proxy  The reporter manager proxy object that can be used to
   * retrieve a proxy from the MyProxy server if available 
   */
  public void setProxy( ReporterManagerProxy proxy ) {
    this.proxy = proxy;
  }

  /**
   * Start a process on a remote machine.  This is a non-blocking call.
   *
   * @param executable  Path to the remote executable.
   * @param arguments   Contains the arguments that should be passed to the
   *                    executable
   * @param stdin      A string that will be passedd in as stdin to the process
   *                   when it is started
   * @param directory  Path to the directory where the process will be executed
   *                   from
   */
  public void start( String executable, String[] arguments, String stdin,
                     String directory) throws AccessMethodException {

    this.gram.start(executable, arguments, stdin, directory );
  }

  /**
   * Kill the remote process that was started by the start() call.
   *
   * @throws AccessMethodException
   */
  public void stop() throws AccessMethodException {
    this.gram.stop();
  }

  /**
   * Transfer a list of local files to a directory on a remote machine using
   * GridFTP.
   *
   * @param localFiles       Array of local file paths that will be transfered
   *
   * @param remoteDirPath    Path to the directory on the remote machine where
   *                         the local file will be placed
   *
   * @throws AccessMethodException if unable to transfer files
   */
  public void put( String[] localFiles, String remoteDirPath )
    throws AccessMethodException
  {

    try {
      // create connection
      GridFTPClient gridftp = connectGridftp();

      // Strip off $(HOME)/ if it exists because only gram recognizes it
      remoteDirPath = remoteDirPath.replaceFirst( "\\$\\(HOME\\)/", "" );
      remoteDirPath = remoteDirPath.replaceFirst( "\\$\\{GLOBUS_USER_HOME\\}/", "" );

      // make dir if it doesn't already exist.  Since there is no mkdirs option,
      // we have to start with the beginning of the path and check that each
      // dir exists.
      String[] remoteDir = remoteDirPath.split( "/" );
      String remoteDirPath2;
      if ( remoteDirPath.startsWith("/") ) {
        remoteDirPath2 = "/";
      } else {
        remoteDirPath2 = gridftp.getCurrentDir() + "/";
      }
      for ( String dir : remoteDir ) {
        remoteDirPath2 += dir + "/";
        if ( ! gridftp.exists( remoteDirPath2 ) ) {
          gridftp.makeDir(remoteDirPath2);
        }
        if ( gridftp.exists( remoteDirPath2 ) ) {
          gridftp.changeDir( remoteDirPath2 );
        } else {
          throw new AccessMethodException(
            "Unable to create remote directory: " + remoteDirPath2
          );
        }
      }
      // put files
      for ( String localFileName : localFiles ) {
        File localFile = new File( localFileName );
        String remotePath = remoteDirPath2 + "/" + localFile.getName();
        logger.debug("Put of local file " + localFileName + " to "+ remotePath);
        gridftp.setLocalPassive();
        gridftp.setActive();        
        gridftp.setType(Session.TYPE_IMAGE);
        gridftp.put( localFile, remotePath, false );
      }
      gridftp.close();
    } catch ( Exception e ) {
      throw new AccessMethodException( "Unable to put files", e );
    }

  }

  /**
   * Open a new GridFTP connection.
   *
   * @return A new GridFTP connection.
   *
   * @throws Exception  If unable to connect to remote gridftp server
   */
  public GridFTPClient connectGridftp( ) throws Exception {

    return Globus.connectGridftp( this.gridftpService, this.getCredential() );
  }

  /**
   * Open a new GridFTP connection.
   *
   * @return A new GridFTP connection.
   *
   * @throws Exception  If unable to connect to remote gridftp server
   */
  public static GridFTPClient connectGridftp( Service server, GSSCredential cred )
    throws Exception {

    GridFTPClient gridftp = new GridFTPClient( server.host, server.port );
    if ( server.dn != null ) {
      gridftp.setAuthorization
        (new IdentityAuthorization(server.dn));
    }
    gridftp.authenticate( cred );
    return gridftp;
  }

  /**
   * Get a proxy credential from the myproxy server if provided or from
   * default environment.
   *
   * @return  A valid proxy credential.
   *
   * @throws GSSException  If problem retrieving the credential.
   */
  private GSSCredential getCredential() throws GSSException {
    // check if existing credential is okay
    if ( credential != null &&
      credential.getRemainingLifetime() > MINIMUM_LIFETIME ) {
      logger.debug( "Remaining lifetime on credential is " +
        credential.getRemainingLifetime() + " seconds");
      return credential;
    }

    // next try MyProxy if it's an option
    if ( proxy != null ) {
      try {
        credential = proxy.getProxy();
        logger.debug( "Remaining lifetime on credential is " +
          credential.getRemainingLifetime() + " seconds" );
        return credential;
      } catch ( MyProxyException e ) {
        logger.error( "Unable to retrieve proxy credential: " + e );
      }
    }

    logger.info( "Attempting to retrieve default proxy credential" );
    ExtendedGSSManager manager =
      (ExtendedGSSManager)ExtendedGSSManager.getInstance();
    credential = manager.createCredential( GSSCredential.INITIATE_AND_ACCEPT);
    return credential;
  }
}
