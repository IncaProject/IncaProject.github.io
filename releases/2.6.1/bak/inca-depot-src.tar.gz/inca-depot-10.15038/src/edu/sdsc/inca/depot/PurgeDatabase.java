/*
 * PurgeDatabase.java
 */
package edu.sdsc.inca.depot;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;


/**
 *
 * @author Paul Hoover
 *
 */
public class PurgeDatabase {

  private static final int FETCH_SIZE = 100;


  // public methods


  /**
   *
   * @param args
   */
  public static void main(String[] args)
  {
    try {
      if (args.length < 2 || args.length > 3)
        throw new Exception("usage: PurgeDatabase url username [ date ]");

      String url = "jdbc:postgresql:";

      if (args[0].indexOf('/') >= 0)
        url += "//";

      url += args[0];

      String username = args[1];

      System.out.print("password>");

      String password = new BufferedReader(new InputStreamReader(System.in)).readLine();
      Properties connProps = new Properties();

      connProps.setProperty("user", username);

      if (password != null && password.length() > 0)
        connProps.setProperty("password", password);

      Connection selectConn = DriverManager.getConnection(url, connProps);

      try {
        Connection deleteConn = DriverManager.getConnection(url, connProps);

        try {
          int numReports = 0;
          int numComparisons = 0;
          int numInstances = 0;
          PurgeDatabase purgative = new PurgeDatabase();

          deleteConn.setAutoCommit(false);

          System.out.print("examining database... ");

          if (args.length == 3) {
            Date cutoff = (new SimpleDateFormat("yyyy-MM-dd")).parse(args[2]);

            numInstances += purgative.deleteOldInstances(deleteConn, cutoff);
          }

          numReports += purgative.deleteOrphanedReports(selectConn, deleteConn);
          numComparisons += purgative.deleteOrphanedComparisons(selectConn, deleteConn);
          numInstances += purgative.deleteOrphanedInstances(selectConn, deleteConn);

          System.out.println("deleted " + numReports + " reports");
          System.out.println("deleted " + numComparisons + " comparisons");
          System.out.println("deleted " + numInstances + " instances");
        }
        finally {
          deleteConn.close();
        }
      }
      finally {
        selectConn.close();
      }
    }
    catch (Exception err) {
      err.printStackTrace(System.err);

      System.exit(-1);
    }
  }


  // private methods


  /**
   *
   * @param selectConn
   * @param selectQuery
   * @return
   * @throws SQLException
   */
  private Set<Long> fetchIdSet(Connection selectConn, String selectQuery) throws SQLException
  {
    PreparedStatement selectStmt = selectConn.prepareStatement(selectQuery);
    ResultSet rows = null;

    try {
      selectStmt.setFetchSize(FETCH_SIZE);

      rows = selectStmt.executeQuery();

      Set<Long> ids = new TreeSet<Long>();

      while (rows.next())
        ids.add(rows.getLong(1));

      return ids;
    }
    finally {
      if (rows != null)
        rows.close();

      selectStmt.close();
    }
  }

  /**
   *
   * @param deleteConn
   * @param cutoff
   * @return
   * @throws SQLException
   */
  private int deleteOldInstances(Connection deleteConn, Date cutoff) throws SQLException
  {
    PreparedStatement deleteStmt = deleteConn.prepareStatement(
        "DELETE FROM incainstanceinfo " +
        "WHERE incacollected <= ?"
    );

    try {
      deleteStmt.setTimestamp(1, new Timestamp(cutoff.getTime()));

      int numDeleted = deleteStmt.executeUpdate();

      deleteConn.commit();

      return numDeleted;
    }
    finally {
      deleteStmt.close();
    }
  }

  /**
   *
   * @param selectConn
   * @param deleteConn
   * @return
   * @throws SQLException
   */
  private int deleteOrphanedReports(Connection selectConn, Connection deleteConn) throws SQLException
  {
    Set<Long> seriesIds = fetchIdSet(selectConn, "SELECT incaid FROM incaseries");
    Set<Long> runInfoIds = fetchIdSet(selectConn, "SELECT incaid FROM incaruninfo");
    Set<Long> instanceReportIds = fetchIdSet(selectConn, "SELECT incareportid FROM incainstanceinfo");
    PreparedStatement selectStmt = selectConn.prepareStatement(
        "SELECT incaid, incaseries_id, incaruninfo_id " +
        "FROM incareport"
    );
    BatchUpdateStatement deleteStmt = new BatchUpdateStatement(deleteConn,
        "DELETE FROM incareport " +
        "WHERE incaid = ?"
    );
    ResultSet rows = null;
    int totalDeleted = 0;

    try {
      selectStmt.setFetchSize(FETCH_SIZE);

      rows = selectStmt.executeQuery();

      while (rows.next()) {
        long reportId = rows.getLong(1);
        long seriesId = rows.getLong(2);
        long runInfoId = rows.getLong(3);

        if (seriesIds.contains(seriesId) && runInfoIds.contains(runInfoId) && instanceReportIds.contains(reportId))
          continue;

        deleteStmt.setLong(1, reportId);
        deleteStmt.update();

        totalDeleted += 1;
      }

      return totalDeleted;
    }
    finally {
      if (rows != null)
        rows.close();

      selectStmt.close();
      deleteStmt.close();
    }
  }

  /**
   *
   * @param selectConn
   * @param deleteConn
   * @return
   * @throws SQLException
   */
  private int deleteOrphanedComparisons(Connection selectConn, Connection deleteConn) throws SQLException
  {
    Set<Long> reportIds = fetchIdSet(selectConn, "SELECT incaid FROM incareport");
    Set<Long> configIds = fetchIdSet(selectConn, "SELECT incaid FROM incaseriesconfig");
    PreparedStatement selectStmt = selectConn.prepareStatement(
        "SELECT incaid, incareportid, incaseriesconfigid " +
        "FROM incacomparisonresult"
    );
    BatchUpdateStatement deleteStmt = new BatchUpdateStatement(deleteConn,
        "DELETE FROM incacomparisonresult " +
        "WHERE incaid = ?"
    );
    ResultSet rows = null;
    int totalDeleted = 0;

    try {
      selectStmt.setFetchSize(FETCH_SIZE);

      rows = selectStmt.executeQuery();

      while (rows.next()) {
        long comparisonId = rows.getLong(1);
        long reportId = rows.getLong(2);
        long configId = rows.getLong(3);

        if (reportIds.contains(reportId) && configIds.contains(configId))
          continue;

        deleteStmt.setLong(1, comparisonId);
        deleteStmt.update();

        totalDeleted += 1;
      }

      return totalDeleted;
    }
    finally {
      if (rows != null)
        rows.close();

      selectStmt.close();
      deleteStmt.close();
    }
  }

  /**
   *
   * @param selectConn
   * @param deleteConn
   * @return
   * @throws SQLException
   */
  private int deleteOrphanedInstances(Connection selectConn, Connection deleteConn) throws SQLException
  {
    Set<Long> reportIds = fetchIdSet(selectConn, "SELECT incaid FROM incareport");
    PreparedStatement selectStmt = selectConn.prepareStatement(
        "SELECT incaid, incareportid " +
        "FROM incainstanceinfo "
    );
    BatchUpdateStatement deleteStmt = new BatchUpdateStatement(deleteConn,
        "DELETE FROM incainstanceinfo " +
        "WHERE incaid = ?"
    );
    ResultSet rows = null;
    int totalDeleted = 0;

    try {
      selectStmt.setFetchSize(FETCH_SIZE);

      rows = selectStmt.executeQuery();

      while (rows.next()) {
        long instanceId = rows.getLong(1);
        long reportId = rows.getLong(2);

        if (reportIds.contains(reportId))
          continue;

        deleteStmt.setLong(1, instanceId);
        deleteStmt.update();

        totalDeleted += 1;
      }

      return totalDeleted;
    }
    finally {
      if (rows != null)
        rows.close();

      selectStmt.close();
      deleteStmt.close();
    }
  }
}
