package Inca::Client;

################################################################################

=head1 NAME

Inca::Client - A perl module for defining clients of Inca servers.

=head1 SYNOPSIS

  use Inca::Client;
  my $client = new Inca::Client(
    host => 'localhost',
    port => 6362,
    auth => 1,
    cert => 'etc/mycert.pem',
    init => 'etc/inca.properties',
    key => 'etc/mykey.pem',
    prefix => 'inca.client.',
    trusted => 'etc/mycert.pem',
    password => '1ncaD1nkaD00'
  );

=head1 DESCRIPTION

This module creates clients for Inca servers.  It handles both unauthenticated
and (where available) authenticated communication between client and server
and implements methods that are supported by all Inca servers.  This class will
rarely be instantiated directly; more often, it will serve as the base class
for other classes that communicate with particular Inca components.

=cut
################################################################################

use strict;
use IO::Socket::INET;

my $ioSocketSslAvailable;
BEGIN {
  $ioSocketSslAvailable = 0;
  eval {
    use IO::Socket::SSL;
  };
  $ioSocketSslAvailable = 1;
}

#=============================================================================#

=head1 CLASS METHODS

=cut

#=============================================================================#

#-----------------------------------------------------------------------------#

=head2 new

Class constructor which returns a new Inca::Client object.  The constructor
may be called with any of the following named parameters.

=over 13

=item auth

A boolean value indicating whether or not the connection to the server should
use certificate-based authentication.  The default is false.

=item cert

The path to the certificate file.  Required for authenticated connections.

=item host

The IP or DNS name of the server to contact.  Required.

=item init

Optional path to an Inca properties file specifying values for other parameters.

=item key

The path to the private key file.  Required for authenticated connections.

=item password

The password for decripting the private key file.  Required for authenticated
connections.

=item port

The server port to contact.  Required.

=item prefix

Optional prefix for properties in the init file.  The constructor ignores
properties that lack this prefix and strips the prefix from those that have it.

=item trusted

The path to the trusted ca certificate file.  Required for authenticated
connections.

=back

=cut

#-----------------------------------------------------------------------------#
sub new {
  my ($this, %config) = @_;

  my $class = ref($this) || $this;
  my $self = {};
  bless($self, $class);

  if(defined($config{init})) {
    if(!open(CONFIG, "<$config{init}")) {
      $self->setError("Unable to open $config{init}");
      return $self;
    }
    my $prefix = $config{prefix} || '';
    while(<CONFIG>) {
      chomp;
      $config{$1} = $2 if $_ =~ /^\s*$prefix([^=\s]+)\s*=\s*(.*)$/;
    }
    close(CONFIG);
  }

  my %configCopy;
  foreach my $key(keys %config) {
    $configCopy{$key} = $config{$key};
  }
  $self->{config} = \%configCopy;
  $self->connect();
  return $self;

}

#-----------------------------------------------------------------------------#

=head2 connected( )

Returns the server address if the client is connected, else undef.

=cut

#-----------------------------------------------------------------------------#
sub connect {
  my ($self) = @_;

  my %config = %{$self->{config}};
  my $host = $config{host};
  my $port = $config{port};
  my $stream;

  if(!defined($host) || !defined($port)) {
    $self->setError('Missing server host/port');
    return;
  }
  if(!$config{auth}) {
    $stream =
      new IO::Socket::INET(PeerAddr=>$host, PeerPort=>$port, Proto=>'tcp');
    if(!defined($stream)) {
      $self->setError($!);
    }
  } elsif(!$ioSocketSslAvailable) {
    $self->setError('Authentication not available');
  } elsif(!defined($config{cert}) ||
          !defined($config{key}) ||
          !defined($config{password})) {
    $self->setError('Authentication requires certificate, key, and password');
  } else {
    $stream = new IO::Socket::SSL(
      PeerAddr=>$host,
      PeerPort=>$port,
      Proto=>'tcp',
      SSL_ca_file=>$config{trusted},
      SSL_cert_file=>$config{cert},
      SSL_key_file=>$config{key},
      SSL_passwd_cb=>sub {return $config{password};},
      SSL_use_cert=>1,
      SSL_verify_mode=>0x07
    );
    if(!defined($stream)) {
      $self->setError(IO::Socket::SSL::errstr());
    }
  }
  if(defined($stream)) {
    $self->{stream} = $stream;
    my $response = $self->ping('TEST');
    if(!defined($response) && !defined($self->{error})) {
      $self->setError('Server closed connection: auth mismatch?');
    }
  }

}

#-----------------------------------------------------------------------------#

=head2 connected( )

Returns the server address if the client is connected, else undef.

=cut

#-----------------------------------------------------------------------------#
sub connected {
  my ($self) = @_;
  return defined($self->{stream}) && $self->{stream}->connected();
}

#-----------------------------------------------------------------------------#

=head2 getError( )

Returns and clears any error that occurred during the most recent operation on
the connection.  Returns undef if no error occurred.

=cut

#-----------------------------------------------------------------------------#
sub getError {
  my ($self) = @_;
  my $result = $self->{error};
  $self->{error} = undef;
  return $result;
}

#-----------------------------------------------------------------------------#

=head2 ping($text)

Sends $text to the server as part of a PING message and returns any successful
response, which should be the same text.

=cut

#-----------------------------------------------------------------------------#
sub ping {
  my ($self, $text) = @_;
  my $response = $self->_dialog("PING $text");
  return defined($response) && $response =~ s/^OK // ? $response : undef;
}

#-----------------------------------------------------------------------------#

=head2 setError($err)

Sets the error associated with this connection to $err.  Mostly for internal
and derived class use.

=cut

#-----------------------------------------------------------------------------#
sub setError {
  my ($self, $err) = @_;
  $self->{error} = $err;
}

#-----------------------------------------------------------------------------#

=head2 start($version)

Sends $version to the server as part of a START message and returns any
successful response, which should be empty.

=cut

#-----------------------------------------------------------------------------#
sub start {
  my ($self, $version) = @_;
  my $response = $self->_dialog("START $version");
  return defined($response) && $response =~ s/^OK // ? $response : undef;
}

#-----------------------------------------------------------------------------#

=head2 _dialog($message)

A convenience method for this class and derived classes.  Sends $message to the
server and returns any response, calling setError if the response indicates
that an error occurred.

=cut

#-----------------------------------------------------------------------------#
sub _dialog {
  my ($self, $message) = @_;
  $self->_write($message);
  my $response = $self->_read();
  return undef if !defined($response);
  if($response =~ /^ERROR (.*)/) {
    $self->setError($1);
  }
  return $response;
}

#-----------------------------------------------------------------------------#

=head2 _read( )

A convenience method for this class and derived classes.  Reads and returns a
message from the server.  Returns undef on EOF.

=cut

#-----------------------------------------------------------------------------#
sub _read {
  my ($self) = @_;
  my $result = '';
  do {
    my $line = $self->{stream}->getline();
    if(!defined($line)) {
      $self->{stream}->close();
      delete $self->{stream};
      return undef;
    }
    $result .= $line;
  } while $result !~ s/\r\n//;
  return $result;
}

#-----------------------------------------------------------------------------#

=head2 _write($message)

A convenience method for this class and derived classes.  Sends $message to
the server.

=cut

#-----------------------------------------------------------------------------#
sub _write {
  my ($self, $message) = @_;
  $self->{stream}->print("$message\r\n");
}

1;
