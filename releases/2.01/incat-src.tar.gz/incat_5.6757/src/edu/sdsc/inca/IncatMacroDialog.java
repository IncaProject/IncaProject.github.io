package edu.sdsc.inca;

import edu.sdsc.inca.protocol.Protocol;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 * A Dialog window that allows the user to edit a macro name and value.
 */
public class IncatMacroDialog extends JDialog implements ActionListener {

  protected JTextField name;
  protected JTextField value;
  protected ActionListener listener;

  /**
   * Constructs an IncatMacroDialog.
   *
   * @param listener the listener to invoke when OK or cancel is pressed
   * @param okCommand the command to send when OK is pressed
   * @param cancelCommand the command to send when Cancel is pressed
   */
  public IncatMacroDialog(ActionListener listener,
                          String okCommand,
                          String cancelCommand) {
    this.name = IncatComponents.JTextFieldFactory(15, okCommand, this);
    this.value = IncatComponents.JTextFieldFactory(30, okCommand, this);
    this.setContentPane(IncatComponents.JPanelFactory(new JComponent[] {
      IncatComponents.JPanelFactory(new JComponent[] {
        this.name, null,
        new JLabel("Macro Name *"), null
      }, false),
      IncatComponents.JPanelFactory(new JComponent[] {
        this.value, null,
        new JLabel("Macro Value(s)"), null
      }, false), null,
      IncatComponents.JPanelFactory(new JComponent[] {
        IncatComponents.JButtonFactory("Cancel", cancelCommand, listener),
        IncatComponents.JButtonFactory("Ok", okCommand, this), null
      }, false), null
    }, false));
    this.setTitle("Incat Macro Dialog");
    this.pack();
    this.listener = listener;
  }

  /**
   * Returns the macro name.
   *
   * @return the macro name
   */
  public String getName() {
    return this.name.getText();
  }

  /**
   * Returns the macro value.
   *
   * @return the macro value
   */
  public String getValue() {
    return this.value.getText();
  }

  /**
   * Sets both the macro name and value from a single string.
   *
   * @param macro a macro definition string of the form name=value
   */
  public void setMacro(String macro) {
    String[] pieces = macro.split("=", 2);
    this.setName(pieces[0]);
    this.setValue(pieces.length == 1 ? "" : pieces[1]);
  }

  /**
   * Sets the macro name.
   *
   * @param name the macro name
   */
  public void setName(String name) {
    this.name.setText(name);
  }

  /**
   * Sets the macro value.
   *
   * @param name the macro value
   */
  public void setValue(String name) {
    this.value.setText(name);
  }

  /**
   * An action listener that checks for required fields on dialog exit.
   */
  public void actionPerformed(ActionEvent ae) {
    if(this.getName().equals("")) {
      JOptionPane.showMessageDialog
        (this, "Please provide a macro name", "Missing Macro Name",
         JOptionPane.ERROR_MESSAGE);
      return;
    } else if(!this.getName().matches("^"+Protocol.MACRO_NAME_PATTERN+"$")) {
      JOptionPane.showMessageDialog
        (this, "Invalid format for macro name", "Invalid Macro Name",
         JOptionPane.ERROR_MESSAGE);
      return;
    }
    this.listener.actionPerformed(ae);
  }

}
