package edu.sdsc.inca.agent;

import java.util.Hashtable;
import java.util.Iterator;

/**
 * Convenience class for storing and tracking reporter managers.  This wraps a
 * Hashtable and provides functions specifically for working with reporter
 * manager objects (e.g., you don't have to cast an object after getting it).
 * This class is thread-safe.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class ReporterManagerTable {
  private Hashtable rms = new Hashtable();

  /**
   * Returns true if the specified resource exists in the table. Note, that
   * the reporter manager may still be in the start up process.  
   *
   * @param resource  A resource name from the resource configuration file.
   * @return True if the resource exists and false otherwise.
   */
  public boolean containsResource( String resource ) {
    return rms.containsKey( resource );
  }

  /**
   * Returns the reporter manager if it exists in the table regardless if
   * it's running or not.
   *
   * @param resource
   * @return A reporter manager object.
   */
  public ReporterManagerController get( String resource ) {
    return (ReporterManagerController)rms.get( resource );
  }

  /**
   * Return the a list of resources who have reporter managers stored in the
   * table.
   *
   * @return   A list of resource names.
   */
  public String[] getResourceNames() {
    Iterator iterator = rms.keySet().iterator();
    String[] names = new String[rms.size()];
    for ( int i = 0; i < rms.size(); i++ ) {
      names[i] = (String)iterator.next();
    }
    return names;
  }

  /**
   * Add a reporter manager to the table.
   *
   * @param resource  A string for retrieving the reporter manager from the
   * table.
   * @param rm A reporter manager to store in the table.
   */
  public void put( String resource, ReporterManagerController rm ) {
    rms.put( resource, rm );
  }

  /**
   * Removes the specified reporter manager from the table.
   *
   * @param resource  The name of the resource whose reporter manager
   * should be removed from the table.
   */
  public void remove( String resource ) {
    rms.remove( resource );
  }

}
