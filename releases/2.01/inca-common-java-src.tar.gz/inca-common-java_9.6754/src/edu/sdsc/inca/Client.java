package edu.sdsc.inca;

import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.protocol.Statement;
import edu.sdsc.inca.util.ConfigProperties;
import edu.sdsc.inca.util.StringMethods;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Properties;
import org.apache.log4j.Logger;

/**
 * This class implements the functionality common to all Inca client classes.
 * Along with defining an API that understands the Server protocol, it defines
 * a main method that allows access to a Server via a telnet-style interface.
 */
public class Client extends Component {

  // Command-line options--see main method
  public static final String CLIENT_OPTS =
    ConfigProperties.mergeValidOptions(
      COMPONENT_OPTS,
      "  S|server str Server specification; host:port\n",
      true
    );

  // Protected class vars
  protected static Logger logger = Logger.getLogger(Client.class);

  // Configuration instance variables
  protected String host = "localhost";
  protected int port = -1;

  // Other instance variables
  protected Socket socket;
  protected ProtocolReader reader;
  protected ProtocolWriter writer;

  /**
   * Close the client socket to the server.  If not called explicitly, this
   * method will be called when the Client instance is destroyed.
   */
  public void close() {
    if(!this.socket.isClosed()) {
      try {
        this.socket.close();
        logger.debug("Closed connection to server");
      } catch(IOException e) {
        logger.error("Unable to close socket", e);
      }
    }
  }

  /**
   * Retrieve the text in the server's log file, if any.
   *
   * @return the contents of the server's log, an empty string if none
   * @throws IOException on read/write error
   * @throws ProtocolException on an invalid message
   */
  public String commandGetLog() throws IOException, ProtocolException {
    return this.dialog(Protocol.GET_LOG_COMMAND, "");
  }

  /**
   * Send a log config message to the server.
   *
   * @param data a log4j setting of the form property=value
   * @throws IOException on read/write error
   * @throws ProtocolException on an invalid message
   */
  public void commandLogConfig(String data)
    throws IOException, ProtocolException {
    this.dialog(Protocol.LOG_CONFIG_COMMAND, data);
  }

  /**
   * Send a ping to the server and return the response data.
   *
   * @param data the ping message data
   * @return the ping response data
   * @throws IOException on read/write error
   * @throws ProtocolException on an invalid message
   */
  public String commandPing(String data) throws IOException, ProtocolException {
    String result = this.dialog(Protocol.PING_COMMAND, data);
    if(!result.equals(data)) {
      throw new ProtocolException("Unexpected reply '" + result + "'");
    }
    return result;
  }

  /**
   * Establish a connection to the server.
   *
   * @throws ConfigurationException if the configuration settings are invalid
   * @throws IOException if the attempt to contact the server fails
   */
  public void connect() throws ConfigurationException, IOException {
    logger.debug("Connecting to " + this.getUri());
    this.socket = (Socket)super.createSocket(false, this.host, this.port);
    this.reader =
      new ProtocolReader(new InputStreamReader(this.socket.getInputStream()));
    this.writer =
      new ProtocolWriter(new OutputStreamWriter(this.socket.getOutputStream()));
    // To detect an authentication mismatch (authenticating server/plaintext
    // client or vice-versa) we need to send a message--this will cause the SSL
    // layer to initiate a handshake and throw an exception on mismatch.
    try {
      this.commandPing("TEST");
    } catch(Exception e) {
      try {
        this.socket.close();
      } catch(IOException e2) {
        // empty
      }
      logger.error
        ("Client communication failed; suspect authorization mismatch:" + e);
      throw new ConfigurationException
        ("Client communication failed; suspect authorization mismatch:" + e);
    }
  }

  /**
   * Returns the host where the server is running.
   *
   * @return The server host.
   */
  public String getHost() {
    return this.host;
  }

  /**
   * Returns the port where the server is listening.
   *
   * @return The server port.
   */
  public int getPort() {
    return this.port;
  }

  /**
   * Return the uri for the server.
   *
   * @return A string containing the uri of the server.
   */
  public String getUri() {
    return (this.getAuthenticate() ? "incas://" : "inca://") +
           this.getHost() + ":" + this.getPort();
  }

  /**
   * Query whether the client is presently connected.
   *
   * @return true iff connected
   */
  public boolean isConnected() {
    return this.socket.isConnected();
  }

  /**
   * Read the next statement from the server.
   *
   * @return the next statement
   * @throws IOException on read error
   * @throws ProtocolException on an invalid message
   */
  public Statement read() throws IOException, ProtocolException {
    return this.reader.readStatement();
  }

  /**
   * A convenience function for setting multiple configuration properties at
   * once.  In addition to the keys recognized by the superclass, recognizes:
   * "server", the specification of the server.
   *
   * @param config contains client configuration values
   * @throws ConfigurationException on a faulty configuration property value
   */
  public void setConfiguration(Properties config) throws ConfigurationException{
    super.setConfiguration(config);
    String prop;
    if((prop = config.getProperty("server")) != null) {
      this.setServer(prop, 0);
    }
  }

  /**
   * Sets the host where the server is running.  If set to "localhost", the
   * method will attempt to resolve it to a DNS name.
   *
   * @param host the server host.
   */
  public void setHost(String host) {
    this.host = host;
    if(host.equals("localhost")) {
      try {
        this.host = InetAddress.getLocalHost().getHostName();
        logger.debug("Resolved localhost to " + this.host);
      } catch(UnknownHostException e) {
        logger.warn("Unable to resolve localhost to DNS name");
      }
    }
  }

  /**
   * Sets the port where the server is listening.
   *
   * @param port the server port.
   */
  public void setPort(int port) {
    this.port = port;
  }

  /**
   * Sets the host and port of the server to contact.
   *
   * @param server contact spec of the form [protcol://]host[:port]
   * @param defaultPort port to contact if server contains none
   */
  public void setServer(String server, int defaultPort) {
    int colonPos = server.indexOf("://");
    if(colonPos >= 0) {
      this.setAuthenticate
        (server.startsWith("incas") || server.startsWith("https"));
      server = server.substring(colonPos + 3);
    }
    colonPos = server.indexOf(":");
    if(colonPos < 0) {
      this.setHost(server);
      this.setPort(defaultPort);
    } else {
      this.setHost(server.substring(0, colonPos));
      this.setPort(Integer.parseInt(server.substring(colonPos + 1)));
    }
  }

  /**
   * Write a statement to the server.
   *
   * @param statement the statement to write
   * @throws IOException on write failure
   */
  public void write(Statement statement) throws IOException {
    writer.write(statement);
  }

  /**
   * Sends a statement to the server and returns the data from a successful
   * response.
   *
   * @param command the command to send
   * @param data the data to accompany the command
   * @return the data from a non-error response
   * @throws IOException on read failure
   * @throws ProtocolException if a failure message is received
   */
  protected String dialog(String command, String data)
    throws IOException, ProtocolException {
    this.write(new Statement(command, data));
    Statement reply = this.read();
    if(reply == null) {
      throw new IOException("Server closed connection");
    } 
    command = new String(reply.getCmd());
    data = new String(reply.getData());
    if(Protocol.FAILURE_COMMAND.equals(command)) {
      throw new ProtocolException(command + " command failed " + data);
    }
    return data;
  }

 /**
  * Close the client socket to the server before exiting.
  */
  public void finalize() {
    this.close();
  }

  /**
   * Allows the user to use a client via a telnet-style interface.  Allows
   * the contents of files to be substituted in commands via '&lt; path' and
   * output of commands to be redirected via '&gt; path'.
   *
   * @param c the client to use
   * @param prompt the user prompt
   */
  public static void telnetDialog(Client c,
                                  String prompt) {
    String command;
    BufferedReader keyboard =
      new BufferedReader(new InputStreamReader(System.in));
    OutputStreamWriter output = new OutputStreamWriter(System.out);
    ArrayList toDo = new ArrayList();
    while(true) {
      while(toDo.size() == 0) {
        if(prompt != null) {
          System.out.print(prompt);
        }
        try {
          command = keyboard.readLine();
        } catch(Exception e) {
          return;
        }
        if(command == null) {
          return;
        }
        output = new OutputStreamWriter(System.out);
        int pos;
        String path;
        if((pos = command.indexOf("> ")) >= 0) {
          path = command.substring(pos + 2).trim();
          command = command.substring(0, pos);
          try {
            output = new FileWriter(path);
          } catch(IOException e) {
            System.err.println(e.toString());
            continue;
          }
        }
        if((pos = command.indexOf("< ")) >= 0) {
          path = command.substring(pos + 2).trim();
          command = command.substring(0, pos);
          try {
            command += StringMethods.fileContents(path);
          } catch(IOException e) {
            System.err.println(e.toString());
            continue;
          }
        }
        String[] commands = command.split("\n");
        for(int i = 0; i < commands.length; i++) {
          toDo.add(commands[i]);
        }
      }
      command = (String)toDo.remove(0);
      if(command.matches("^\\s*$")) {
        continue;
      }
      try {
        c.write(new Statement(command));
        while(true) {
          Statement reply = c.read();
          if(reply == null) {
            logger.debug("Connection closed by server");
            System.err.println("Connection closed by server");
            return;
          }
          output.write(reply.toString() + "\n");
          output.flush();
          if(!reply.toString().startsWith("QUERYRESULT")) {
            break;
          }
        }
      } catch(IOException e) {
        logger.error("IOException " + e);
        System.err.println("IOException " + e);
      } catch(ProtocolException e) {
        logger.error("ProtocolException " + e);
        System.err.println("ProtocolException " + e);
        e.printStackTrace();
      }
    }
  }

  /**
   * A simple main method for exercising the Client.
   * <br/>
   * <pre>
   * usage: <code>java inca.Client</code><br/>
   *  -a|--auth     boolean Authenticated (secure) connection?
   *  -c|--cert     path    Path to the authentication certificate
   *  -f|--file     path    Inca installation configuration file path
   *  -h|--help     null    Print help/usage
   *  -i|--init     path    Path to properties file
   *  -k|--key      path    Path to the authentication key
   *  -P|--password str     Specify how to obtain encryption password
   *  -S|--server   str     Server specification; host:port
   *  -t|--trusted  path    Path to authentication trusted certificate dir
   *  -V|--version  null    Display program version
   * </pre>
   * <br/>
   * Each of these properties, other than --init, can also be specified in the
   * initialization file or in system properties defined via the -D switch.  In
   * each of these cases, the configuration name must be prefixed with
   * "inca.client.", e.g., use "inca.client.cert" to specify the cert value.
   * Command line arguments override any properties specified in this fashion.
   * If --file is specified, the main method reads the specified file and sends
   * it to the Server in a setConfig message; otherwise, main allows the user
   * to communicate with the Server via a telnet-style interface.  Supported
   * values for the --password argument are: "no" or "false" (no encryption);
   * "yes", "true", or "stdin:prompt" (read password from stdin after optionally
   * prompting); "pass:text" (specify the password directly--should only be
   * used for testing and, possibly, in the init file).
   * <br/>
   *
   * @param args command line arguments, as above.
   */
  public static void main(String[] args) {
    Client c = new Client();
    try {
      configComponent
        (c, args, CLIENT_OPTS, "inca.client.", "edu.sdsc.inca.Client",
         "inca-common-java-version");
      c.connect();
    } catch(Exception e) {
      logger.fatal("Client error: ", e);
      System.err.println("Client error: " + e);
      System.exit(1);
    }
    telnetDialog(c, "Client> ");
  }

}
