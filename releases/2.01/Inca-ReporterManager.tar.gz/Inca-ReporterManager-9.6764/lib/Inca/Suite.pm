package Inca::Suite;

################################################################################

=head1 NAME

Inca::Suite - Utility class for dealing with Inca suites

=head1 SYNOPSIS

=for example begin

  use Inca::Suite;
  my $suite = new Inca::Suite();
  $suite->read( "suite.xml" );
  my @scs = $suite->getSeriesConfigs();

=for example end

=head1 DESCRIPTION

An Inca suite is a request to change (i.e., add or delete) the data
collection on a resource.  It is an XML document that contains a list of
seriesConfigs.  Each seriesConfig contains an action (add or delete), 
a scheduler, and a reporter.  For each reporter, there is a name, version,
context, and an optional list of input arguments, limits, and execution
priority.

=cut 
################################################################################

#=============================================================================#
# Usage
#=============================================================================#

# pragmas
use strict;
use warnings;
use vars qw($VERSION);

# Inca
use Inca::Constants qw(:params);
use Inca::Logger;
use Inca::Suite::SeriesConfig;
use Inca::Validate qw(:all);

# Perl standard
use Carp;

# CPAN
use XML::Simple;

#=============================================================================#
# Global Vars
#=============================================================================#

our ( $VERSION ) = '$Revision: 1.2 $' =~ 'Revision: (.*) ';

my $SELF_PARAM_REQ = { isa => __PACKAGE__ };
my %XML_OPTIONS = ( ForceArray => [ qw(seriesConfig arg) ],
                    KeyAttr => { }, 
                    SuppressEmpty => undef );

#=============================================================================#

=head1 CLASS METHODS

=cut
#=============================================================================#

#-----------------------------------------------------------------------------#
# Public methods (documented with pod markers)
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#

=head2 new( )

Class constructor which returns a new Inca::Suite object.  

=begin testing

  use Inca::Suite;
  use Test::Exception;
  lives_ok { new Inca::Suite() } 'object created';

=end testing

=cut
#-----------------------------------------------------------------------------#
sub new {
  my $this = shift;
  my $class = ref($this) || $this;
  my $self = {};
  
  bless ($self, $class);

  # initialize vars
  $self->{configs} = [];
  $self->{logger} = Inca::Logger->get_logger( $class );

  return $self;
}

#-----------------------------------------------------------------------------#

=head2 getGuid( )

Return the guid of the suite.

=over 2

B<Returns>:

A string containing the guid of the suite.

=back

=begin testing

  use Inca::Suite;
  use Test::Exception;

  my $suite = new Inca::Suite();
  $suite->read( "t/suite.xml" ); 
  is( $suite->getGuid(), "incas://localhost:6323/testSuite", "got guid" );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub getGuid {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{guid};
}

#-----------------------------------------------------------------------------#

=head2 getSeriesConfigs( )

Return the list of series configs in the suite.

=over 2

B<Returns>:

An array of Inca::Suite::SeriesConfig objects.  

=back

=begin testing

  use Inca::Suite;
  use Test::Exception;

  my $suite = new Inca::Suite();
  $suite->read( "t/suite.xml" ); 
  my @scs = $suite->getSeriesConfigs();
  is( scalar(@scs), 2, "found 2 series configs" );
  isa_ok( $scs[0], "Inca::Suite::SeriesConfig", 
          "series config is a series config" );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub getSeriesConfigs {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return @{$self->{configs}};
}

#-----------------------------------------------------------------------------#

=head2 read( $file )

Read an Inca suite file into the object.  The suite is
structured as follows:

<suite>
  <seriesConfig>
    <!-- see L<Inca::Suite::SeriesConfig> for content here -->
  </reporterGroup>
  ...
</suite>

=over 2

B<Arguments>:

=over 13

=item xmlorFile

A string containing Inca suite xml or a path to an XML file containing an Inca 
suite

=back

B<Returns>:

Returns 1 if there are no errors reading the suite file; otherwise 
returns 0.

=back

=begin testing

  use Inca::Suite;
  use Test::Exception;

  my $suite = new Inca::Suite();
  my $result;
  $result = $suite->read( "t/suite.xml" ); 
  is( $result, 1, "read on good suite - returns true" );
  is( ($suite->getSeriesConfigs())[0]->getName(),
      "echo_report",
      "read on good suite - found first name" );
  my @files = qw(t/suite_badxml.xml t/suite_noaction.xml t/suite_badconfig.xml);
  for my $file ( @files ) {
    is( $suite->read( $file ), 0, "read on $file - returns false" );
  }

=end testing

=cut
#-----------------------------------------------------------------------------#
sub read {
  my ( $self, $xmlOrFile ) = validate_pos( @_, $SELF_PARAM_REQ, SCALAR );

  my $suite;
  eval {
    $suite = XMLin( $xmlOrFile, %XML_OPTIONS );
  };
  if ( $@ ) {
    $self->{logger}->error( "Problem reading suite: $@" );
    return 0;
  }
  my $success = 1;
  if ( ref($suite->{guid}) eq "HASH" ) {
    $self->{guid} = $suite->{guid}->{content};
  } else {
    $self->{guid} = $suite->{guid};
  }
  if ( exists $suite->{seriesConfigs} && 
       exists $suite->{seriesConfigs}->{seriesConfig} ) {
    my $i = 0;
    for my $scHash ( @{$suite->{seriesConfigs}->{seriesConfig}} ) {
      my $sc = new Inca::Suite::SeriesConfig();
      if ( $sc->read($scHash) ) {
        push( @{$self->{configs}}, $sc );
      } else {
        $success = 0;
        $self->{logger}->error( "Error reading config $i from suite" );
      }
      $i++;
    }
  }
  return $success;
}

#-----------------------------------------------------------------------------#

=head2 resolveReporters( $rc, $uri )

Look up the existing reporters listed in this suite and locate
their local copies.  Set the path attribute and resolve context.

=over 2

B<Arguments>:

=over 13

=item rc

A reference to a Inca::ReporterManager::ReporterCache object to look up
local reporter copies.

=item uri

A string containing the uri for the reporter instance manager to contact
to request proxy information in order to retrieve a proxy credential for
reporter execution.

=back

=back

=begin testing

  use Inca::Suite;
  use Inca::ReporterManager::ReporterCache;
  use Test::Exception;
  use Cwd;

  my $suite = new Inca::Suite();
  my $rc = new Inca::ReporterManager::ReporterCache( "t" );
  $suite->read( "t/suite.xml" ); 
  for my $sc ( $suite->getSeriesConfigs() ) {
    is( undef, $sc->getPath(), 'no path set now' );
  }
  my $uri = "incas://localhost:3234";
  $suite->resolveReporters( $rc, $uri );
  my $cwd = getcwd();
  for my $sc ( $suite->getSeriesConfigs() ) {
    ok( defined($sc->getPath()), 'path set now' );
    like( 
      $sc->getPath(), 
      qr/$cwd/, 
      "series config has set path"
    );
    ok( ! $sc->hasProxyContact(), "proxy contact not found" );
  }

  $suite = new Inca::Suite();
  $suite->read( "t/grid_suite.xml" ); 
  $suite->resolveReporters( $rc, $uri );
  for my $sc ( $suite->getSeriesConfigs() ) {
    ok( $sc->hasProxyContact(), "proxy contact found" );
    is( $sc->getProxyContact(), $uri, "proxy contact uri found" );
  }

=end testing

=cut
#-----------------------------------------------------------------------------#
sub resolveReporters {
 my ( $self, $rc, $uri ) = validate_pos( 
   @_, $SELF_PARAM_REQ, $REPORTER_CACHE_PARAM_REQ, $URI_PARAM_OPT 
 );

  for my $sc ( $self->getSeriesConfigs() ) {
    my $path = $rc->getPath( $sc->getName(), $sc->getVersion() );
    if ( ! defined $path ) { 
      $self->{logger}->error(
        "Unable to locate " . $sc->getName() . ", version=" .
        $sc->getVersion() .  " in local cache...skipping"
      );
    }
    my @depends = $rc->getDependencies( $sc->getName(), $sc->getVersion() );
    if ( grep(/Inca::Reporter::GridProxy/, @depends) ) {
      if ( defined $uri ) {
        $self->{logger}->debug( $sc->getName() . " requires a proxy" );
        $sc->setProxyContact( $uri );
      } else {
        $self->{logger}->debug( 
          $sc->getName() . " requires a proxy but no uri available" 
        );
      }
    }
    $sc->setPath( $path );
    $self->{logger}->info( $sc->getPath() );
  }
}

1; # need to return a true value from the file

__END__


=head1 AUTHOR

Shava Smallen <ssmallen@sdsc.edu>

=head1 CAVEATS/WARNINGS

No known problems.

=head1 SEE ALSO

L<Inca::Suite::SeriesConfig>

=cut
