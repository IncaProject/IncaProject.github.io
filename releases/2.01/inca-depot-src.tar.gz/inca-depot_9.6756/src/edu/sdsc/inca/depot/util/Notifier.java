package edu.sdsc.inca.depot.util;

/**
 * An abstract class that notifies a "target" (for example, an email address)
 * about a state change in AcceptableOutput.
 *
 * @author jhayes
 */
public interface Notifier {

  /**
   * Notifies a target of an AcceptedOutput state change.
   *
   * @param comparitor the name of the class that did the test
   * @param comparison the test that changed state
   * @param series the name of the series generating the output
   * @param resource the resource where the reporter ran
   * @param error an optional error message that accompanies a failure
   * @param target the target to notify
   * @param state a string indicating the new AO state
   */
  public void notify(String comparitor, String comparison,
                     String series, String resource, String error,
                     String target, String state);

}
