package edu.sdsc.inca.consumer.tag;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.io.FileReader;
import java.io.File;
import java.io.BufferedReader;
import java.net.URL;
import java.util.Calendar;
import java.util.Set;
import java.util.Arrays;

import edu.sdsc.inca.queryResult.ReportDetailsDocument;
import edu.sdsc.inca.util.StringMethods;

/**
 * Created by IntelliJ IDEA.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class Util {
  private static Logger logger = Logger.getLogger( Util.class );

  /**
   * Do some processing on the report details document returned from the depot
   * to make it easier to parse in the xsl stylesheet.  This includes:
   *
   * convert GMT to localtime
   *
   * @param detailsDoc  The report details XML Bean object parsed from the depot
   * query
   *
   * @return
   */
  static public String formatReportDetails(ReportDetailsDocument detailsDoc){

    String formatResult = detailsDoc.toString();
    formatResult = Util.stripNamespaces( formatResult );
    formatResult = formatResult.replaceAll( "\\w+:(reportDetails)", "$1" );
    return formatResult;
  }

  /**
   * Find a file from the classpath and return the contents as a string.
   *
   * @param filename  The name of the file to search for in the classpath.
   *
   * @return The contents of the file.
   *
   * @throws java.io.IOException
   */
  static public String getXMLFromClasspath( String filename )
    throws IOException {

    // locate in classpath
    URL url = ClassLoader.getSystemClassLoader().getResource( filename );
    if(url == null) {
      throw new IOException( filename + " not found in classpath" );
    }
    logger.debug( "Located file " + url.getFile() );

    // read in xml
    FileReader fr = new FileReader( new File( url.getFile() ) );
    BufferedReader br = new BufferedReader(fr);
    StringBuffer xml = new StringBuffer();
    while (br.ready()) {
      xml.append(br.readLine() + "\n");
    }
    br.close();
    fr.close();

    return xml.toString();
  }

  /**
   * Small convenience function to return the current time in milliseconds.
   *
   * @return the current time in milliseconds
   */
  public static long getTimeNow() {
    return Calendar.getInstance().getTimeInMillis();
  }

  /**
   * Small convenience function for printing out timing information.
   *
   * @param startTime  The time at which to compute the elapsed time from now.
   *
   * @param id  A small identifier string that can be used in the debug
   * statement.
   */
  public static void printElapsedTime( long startTime, String id ) {
    long endTime = getTimeNow();
    float elapsed = endTime - startTime;
    logger.info( id + " time = " + (elapsed / 1000) );
  }

  /**
   * Return the set of strings as a sorted string array.
   *
   * @param set  A set of strings
   *
   * @return  An array of strings containing the strings in set.
   */
  public static String[] setToArray( Set set ) {
    String[] nameArray =(String[])set.toArray( new String[set.size()] );
    Arrays.sort( nameArray );
    return nameArray;
  }

  /**
   * Strip xmlns and xsi attributes from xml
   *
   * @param xml  A xml string that potentially contains xmlns and xsi attributes
   *             in xml tags.
   * @return  A xml string without xmlns and xsi attributes
   */
  public static String stripNamespaces( String xml ) {
    return xml.replaceAll( " xmlns(:\\w+)?=\"[^\"]*\"", "" ).
      replaceAll( " xsi=\"[^\"]\"", "");
  }

  /**
   * Create a suite document from the provided report summary documents.
   *
   * @param results  An array of report summary xml documents.
   *
   * @return  A suite document.
   */
  public static String summariesToSuite( String name, String[] results ) {
    StringBuffer resultsXML = new StringBuffer( "<suite>\n" );
    resultsXML.append( "  <name>" + name + "</name>\n" );
    String allSummaries = StringMethods.join( "\n", results );
    allSummaries = Util.stripNamespaces( allSummaries );
    resultsXML.append( allSummaries );
    resultsXML.append( "</suite>\n" );
    return resultsXML.toString();
  }

  /**
   * Extract report summaries from a suite document.
   *
   * @param suite  A suite document.
   *
   * @return  An array of xml strings containing report summary xml.
   */
  public static String[] suiteToSummaries( String suite ) {
    suite = suite.replaceAll( "<suite>", "" );
    suite = suite.replaceAll( "</suite>", "" );
    String[] results = suite.split( "</reportSummary>\n" );
    for ( int j = 0; j < results.length; j++ ) {
      results[j] += "</reportSummary>";
    }
    return results;
  }
}
