package edu.sdsc.inca.consumer.tag;

import junit.framework.TestCase;
import org.apache.log4j.Logger;
import edu.sdsc.inca.queryResult.ReportSummaryDocument;
import edu.sdsc.inca.dataModel.util.AnyXmlSequence;
import edu.sdsc.inca.dataModel.all2all.All2AllSummariesDocument;
import edu.sdsc.inca.dataModel.all2all.Resources;
import edu.sdsc.inca.dataModel.all2all.Resource;
import edu.sdsc.inca.dataModel.all2all.TestSummaries;
import edu.sdsc.inca.dataModel.all2all.TestSummary;
import edu.sdsc.inca.dataModel.all2all.Failures;
import edu.sdsc.inca.dataModel.all2all.Failure;
import edu.sdsc.inca.ConsumerTest;

import java.io.FileWriter;
import java.util.Arrays;
import java.math.BigInteger;

/**
 * Created by IntelliJ IDEA.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GetAll2AllSummaryTest extends TestCase {
  private static Logger logger = Logger.getLogger( GetAll2AllSummaryTest.class );
  private String[] RESOURCES = new String[] { "A", "B", "C", "D" };
  private String[] TESTS = new String[] { "gram", "gridftp", "ssh" };
  private int[] FAILED = { 8, 15, 19, 25, 36, 41 };
  private int[] MISSING = { 4, 10, 28, 42, 47 };

  /**
   * Generate T X R X R all-to-all report summaries using the provided
   * test names and resources.  All report summaries will have success except
   * for the
   *
   * @throws Exception
   */
  public String[] generateSummaries( String[] tests, String[] resources,
                                     int[] failures, int[] missing )
    throws Exception {

    int count = 0;
    ReportSummaryDocument[] summaries =
      new ReportSummaryDocument[tests.length*resources.length*resources.length];
    for ( int i = 0; i < tests.length; i++ ) {
      for ( int j = 0; j < resources.length; j++ ) {
        for ( int k = 0; k < resources.length; k++ ) {
          ReportSummaryDocument sumDoc =
            ReportSummaryDocument.Factory.newInstance();
          sumDoc.addNewReportSummary();
          sumDoc.getReportSummary().setBody( AnyXmlSequence.Factory.parse(
            "<unitTest>\n" +
            "  <ID>" + tests[i] + "</ID>\n" +
            "</unitTest>\n"
          ));
          sumDoc.getReportSummary().setHostname( resources[j] );
          sumDoc.getReportSummary().setInstanceId( count );
          count++;
          sumDoc.getReportSummary().setNickname(
            "all2all:" + tests[i] + "_to_" + resources[k]
          );
          sumDoc.getReportSummary().setSeriesConfigId( count );
          count++;
          sumDoc.getReportSummary().setUri(
            "http://inca.sdsc.edu/2.0/repository/" + tests[i]
          );
          summaries[i*resources.length*resources.length+j*resources.length+k] =
          sumDoc;
        }
      }
    }
    String[] summaryXml = new String[summaries.length];
    for ( int i = 0; i < summaries.length; i++ ) {
      summaryXml[i] = summaries[i].toString();
    }
    for ( int i = 0; i < missing.length; i++ ) {
      summaries[missing[i]].getReportSummary().unsetInstanceId();
      summaries[missing[i]].getReportSummary().unsetBody();
      summaryXml[missing[i]] = summaries[missing[i]].toString();
    }
    for ( int i = 0; i < failures.length; i++ ) {
      summaries[failures[i]].getReportSummary().setBody(
        AnyXmlSequence.Factory.newInstance()
      );
      summaryXml[failures[i]] = summaries[failures[i]].toString();
    }

    FileWriter writer = new FileWriter( "/tmp/rs.xml" );
    for ( int i = 0; i < summaryXml.length; i++ ) {
      writer.write( summaryXml[i] );
    }
    writer.close();
    return summaryXml;
  }

  /**
   * Test ability to compute a summary from a results matrix.
   *
   * @throws Exception
   */
  public void testComputeSummary() throws Exception {
    int[][][] rawResults = new int[][][] {
      new int[][] {  // 0
        new int[] { -1, -1 },
        new int[] { -1, -1 }
      },
      new int[][] {  // 1
        new int[] { 0, -1 },
        new int[] { -1, -1 }
      },
      new int[][] {  // 2
        new int[] { -1, -1 },
        new int[] { -1, 0 }
      },
      new int[][] {  // 3
        new int[] { 0, -1 },
        new int[] { -1, 0 }
      },
      new int[][] {  // 4
        new int[] { 0, 0 },
        new int[] { -1, 0 }
      },
      new int[][] {  // 5
        new int[] { 0, -1 },
        new int[] { 0, 0 }
      },
      new int[][] {  // 6
        new int[] { 0, 0 },
        new int[] { 0, 0 }
      },
      new int[][] {  // 7
        new int[] { 1, 0 },
        new int[] { 0, 0 }
      },
      new int[][] {  // 8
        new int[] { 1, 0 },
        new int[] { 0, 1 }
      },
      new int[][] {  // 9
        new int[] { 1, 1 },
        new int[] { 0, 1 }
      },
      new int[][] {  // 10
        new int[] { 1, 1 },
        new int[] { 1, 1 }
      },
      new int[][] {  // 11
        new int[] { 0, 1, 1, 0 },
        new int[] { 1, 1, 1, 0 },
        new int[] { 0, 0, 0, 0 },
        new int[] { 1, 1, 0, 0 }
      },
      new int[][] {  // 12
        new int[] { 0, 0, 1, 0 },
        new int[] { 1, 0, 1, 0 },
        new int[] { 1, 0, 1, 1 },
        new int[] { 1, 1, 0, 0 }
      }
    };
    int[][][] expected = new int[][][] {
      new int[][] { // 0
        new int[] { 0, 0, 0 },
        new int[] { 0, 0, 0 }
      },
      new int[][] { // 1
        new int[] { 0, 0, 1 },
        new int[] { 0, 0, 0 }
      },
      new int[][] { // 2
        new int[] { 0, 0, 0 },
        new int[] { 0, 0, 1 }
      },
      new int[][] { // 3
        new int[] { 0, 0, 1 },
        new int[] { 0, 0, 1 }
      },
      new int[][] { // 4
        new int[] { 0, 0, 2 },
        new int[] { 0, 0, 2 }
      },
      new int[][] { // 5
        new int[] { 0, 0, 2 },
        new int[] { 0, 0, 2 }
      },
      new int[][] { // 6
        new int[] { 0, 0, 3 },
        new int[] { 0, 0, 3 }
      },
      new int[][] { // 7
        new int[] { 1, 0, 2 },
        new int[] { 0, 0, 3 }
      },
      new int[][] { // 8
        new int[] { 1, 0, 2 },
        new int[] { 1, 0, 2 }
      },
      new int[][] { // 9
        new int[] { 2, 0, 1 },
        new int[] { 2, 0, 1 }
      },
      new int[][] { // 10
        new int[] { 3, 0, 0 },
        new int[] { 3, 0, 0 }
      },
      new int[][] { // 11
        new int[] { 4, 2, 1 },
        new int[] { 5, 2, 0 },
        new int[] { 2, 1, 4 },
        new int[] { 2, 1, 4 }
      },
      new int[][] { // 12
        new int[] { 4, 0, 3 },
        new int[] { 3, 0, 4 },
        new int[] { 5, 0, 2 },
        new int[] { 3, 0, 4 }
      }
    };
    int[][][] failures = new int[][][] {
      new int[][] { // 0
        new int[] { },
        new int[] { }
      },
      new int[][] { // 1
        new int[] { 0 },
        new int[] { }
      },
      new int[][] { // 2
        new int[] { },
        new int[] { 3 }
      },
      new int[][] { // 3
        new int[] { 0 },
        new int[] { 3 }
      },
      new int[][] { // 4
        new int[] { 0, 1 },
        new int[] { 3, 1 }
      },
      new int[][] { // 5
        new int[] { 0, 2 },
        new int[] { 2, 3 }
      },
      new int[][] { // 6
        new int[] { 0, 1, 2 },
        new int[] { 2, 3, 1 }
      },
      new int[][] { // 7
        new int[] { 1, 2 },
        new int[] { 2, 3, 1 }
      },
      new int[][] { // 8
        new int[] { 1, 2 },
        new int[] { 2, 1 }
      },
      new int[][] { // 9
        new int[] { 2 },
        new int[] { 2 }
      },
      new int[][] { // 10
        new int[] { },
        new int[] { }
      },
      new int[][] { // 11
        new int[] { 0 },
        new int[] { },
        new int[] { 8, 9, 10, 14 },
        new int[] { 14, 15, 3, 7 }
      },
      new int[][] { // 12
        new int[] { 0, 1, 3 },
        new int[] { 5, 7, 1, 9 },
        new int[] { 9, 14 },
        new int[] { 14, 15, 3, 7 }
      }
    };

    GetAll2AllSummary summary = new GetAll2AllSummary();
    for ( int i = 0; i < rawResults.length; i++ ) {
      GetAll2AllSummary.TestSummaryResults summaryResults =
        summary.computeSummary( rawResults[i] );
      logger.debug( i + " " + matrixToString( summaryResults.summary ));
      for ( int j = 0; j < summaryResults.summary.length; j++ ) {
        for ( int k = 0; k < summaryResults.summary[j].length; k++ ) {
          assertEquals(
            "(" + i + ", " + j + ", " + k + ") = " + expected[i][j][k],
            expected[i][j][k],
            summaryResults.summary[j][k]
          );
        }
      }
      logger.debug( i + " " + matrixToString( summaryResults.failures ));
      for ( int j = 0; j < summaryResults.failures.length; j++ ) {
        assertEquals(
          "correct length",
          failures[i][j].length,
          summaryResults.failures[j].length
        );
        for ( int k = 0; k < summaryResults.failures[j].length; k++ ) {
          assertEquals(
            "f(" + i + ", " + j + ", " + k + ") = " + failures[i][j][k],
            failures[i][j][k],
            summaryResults.failures[j][k]
          );
        }
      }
    }


  }

  /**
   * Create a string representation of the provided matrix.
   *
   * @param matrixValues  An array of values.
   *
   * @return A string representation of the matrix.
   */
  public StringBuffer matrixToString( int[][] matrixValues ) {
    StringBuffer matrix = new StringBuffer( "[\n" );
    for ( int j = 0; j < matrixValues.length; j++ ) {
      matrix.append( "  [" );
      for ( int k = 0; k < matrixValues[j].length; k++ ) {
        matrix.append( matrixValues[j][k] + ", " );
      }
      matrix.append( "]\n" );
    }
    matrix.append( "]\n" );
    return matrix;
  }

  /**
   * Test ability to produce a xml summary of the all-to-all test results from
   * a suite.
   *
   * @throws Exception
   */
  public void testGetAll2AllSiteSummaryXml() throws Exception {
    ConsumerTest.ConsumerTester consumer = ConsumerTest.createConsumerTester(0,1);
    try {

      String[] sums = generateSummaries( TESTS, RESOURCES, FAILED, MISSING );
      consumer.depot.addSuite(
        consumer.agent.getUri() + "/TestSuiteLocal", sums, 0
      );
      GetAll2AllSummary summary = new GetAll2AllSummary();
      summary.setSuiteName( "TestSuiteLocal" );
      ConsumerTest.startConsumerTester( consumer );
      String sumXml = summary.getAll2AllSiteSummaryXml();
      int[][][] expected = new int[][][] {
        new int[][] {
          new int[] { 5, 0, 1 },
          new int[] { 5, 0, 1 },
          new int[] { 6, 0, 1 }
        },
        new int[][] {
          new int[] { 6, 0, 0 },
          new int[] { 6, 0, 1 },
          new int[] { 5, 0, 2 }
        },
        new int[][] {
          new int[] { 5, 0, 1 },
          new int[] { 6, 0, 1 },
          new int[] { 5, 0, 1 }
        },
        new int[][] {
          new int[] { 6, 0, 1 },
          new int[] { 5, 0, 1 },
          new int[] { 6, 0, 0 }
        }
      };
      int[][][] expectedFailures = new int[][][] {
        new int[][] {
          new int[] { 8 },
          new int[] { 19 },
          new int[] { 36 },
        },
        new int[][] {
          new int[] { },
          new int[] { 25 },
          new int[] { 36, 41 },
        },
        new int[][] {
          new int[] { 8 },
          new int[] { 25 },
          new int[] { 41 },
        },
        new int[][] {
          new int[] { 15 },
          new int[] { 19 },
          new int[] { },
        }
      };
      All2AllSummariesDocument sumDoc =
        All2AllSummariesDocument.Factory.newInstance();
      Resources resources = sumDoc.addNewAll2AllSummaries().addNewResources();
      for ( int i = 0; i < RESOURCES.length; i++ ) {
        Resource resource = resources.addNewResource();
        resource.setName( RESOURCES[i] );
        TestSummaries testSummaries = resource.addNewTestSummaries();
        for ( int j = 0; j < TESTS.length; j++ ) {
          TestSummary sum = testSummaries.addNewTestSummary();
          sum.setName( TESTS[j] );
          sum.setNumAtFaultFailures(
            BigInteger.valueOf( expected[i][j][GetAll2AllSummary.AF_FAILURES])
          );
          sum.setNumNotAtFaultFailures(
            BigInteger.valueOf( expected[i][j][GetAll2AllSummary.NAF_FAILURES])
          );
          sum.setNumSuccesses(
            BigInteger.valueOf( expected[i][j][GetAll2AllSummary.SUCCESSES])
          );

          Failures failures = sum.addNewFailures();
          for ( int m = 0; m < expectedFailures[i][j].length; m++ ) {
            ReportSummaryDocument failDoc = ReportSummaryDocument.Factory.parse(
              sums[expectedFailures[i][j][m]]
            );
            Failure failure = failures.addNewFailure();
            failure.setNickname( failDoc.getReportSummary().getNickname() );
            failure.setInstanceId( failDoc.getReportSummary().getInstanceId() );
            failure.setSeriesConfigId(
              failDoc.getReportSummary().getSeriesConfigId()
            );
          }
        }
      }
      FileWriter writer = new FileWriter( "/tmp/sum.xml" );
      writer.write( sumXml );
      writer.close();
      assertEquals( "correct sum xml", sumDoc.toString(), sumXml );
    } finally {
      ConsumerTest.stopConsumerTester( consumer );
    }
  }

  /**
   * Test ability to extract all-to-all tests from report summaries.
   *
   * @throws Exception
   */
  public void testGetAll2AllTestNames() throws Exception {
    GetAll2AllSummary summary = new GetAll2AllSummary();
    String[] sums = generateSummaries( TESTS, RESOURCES, FAILED, MISSING );
    ReportSummaryDocument[] rsDocs = summary.stringsToSummaries( sums );
    String[] testNames = summary.getAll2AllTestNames( rsDocs );
    assertTrue(
      "getTestData returns resources",
      Arrays.equals( TESTS, testNames )
    );
  }

  /**
   * Test ability to extract a matrix of test results and array of resources.
   *
   * @throws Exception
   */
  public void testGetTestData() throws Exception {
    GetAll2AllSummary summary = new GetAll2AllSummary();
    String[] sums = generateSummaries( TESTS, RESOURCES, FAILED, MISSING );
    ReportSummaryDocument[] rsDocs = summary.stringsToSummaries( sums );
    GetAll2AllSummary.TestData testData = summary.getTestData( "ssh", rsDocs );
    assertNotNull(
      "getTestData returned non-null",
      testData
    );
    assertTrue(
      "getTestData returns resources",
      Arrays.equals( RESOURCES, testData.resources )
    );
    int[][] expected = new int[][] {
      new int[] { 1, 1, 1, 1 },
      new int[] { 0, 1, 1, 1 },
      new int[] { 1, 0, -1, 1 },
      new int[] { 1, 1, 1, -1 }
    };
    for ( int i = 0; i < RESOURCES.length; i++ ) {
      for ( int j = 0; j < RESOURCES.length; j++ ) {
        assertEquals(
          i + ", " + j + " is " + expected[i][j],
          expected[i][j],
          testData.rawResults[i][j]
        );
      }
    }
    ReportSummaryDocument[] sshSums = new ReportSummaryDocument[
      RESOURCES.length*RESOURCES.length
      ];
    for ( int i = 0; i < RESOURCES.length*RESOURCES.length; i++ ) {
      sshSums[i] = rsDocs[2*RESOURCES.length*RESOURCES.length+i];
    }
    assertTrue(
      "getTestData returns docs",
      Arrays.equals( sshSums, testData.docs )
    );
  }

  /**
   * Test ability to convert array of string to report summary documents
   *
   * @throws Exception
   */
  public void testStringsToSummaries() throws Exception {
    GetAll2AllSummary summary = new GetAll2AllSummary();
    String[] sums = generateSummaries( TESTS, RESOURCES, FAILED, MISSING );
    ReportSummaryDocument[] rsDoc = summary.stringsToSummaries( sums );
    assertNotNull(
      "stringsToSummaries returned non-null",
      rsDoc
    );
    assertEquals(
      "stringsToSummaries returned correct num of results",
      TESTS.length * RESOURCES.length * RESOURCES.length,
      rsDoc.length
    );
  }
}
