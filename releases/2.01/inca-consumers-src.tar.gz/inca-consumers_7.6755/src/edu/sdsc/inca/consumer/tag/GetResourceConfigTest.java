package edu.sdsc.inca.consumer.tag;

import junit.framework.TestCase;

import edu.sdsc.inca.ConsumerTest;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.dataModel.resourceConfig.ResourceConfigDocument;
import edu.sdsc.inca.util.ResourcesWrapper;

import org.apache.log4j.Logger;

import java.util.Calendar;

/**
 * Test class for JSP tag GetResourceConfig
 */
public class GetResourceConfigTest extends TestCase {
  private static Logger logger = Logger.getLogger(GetResourceConfigTest.class);

  public void testGetResourceConfig() throws Exception {

    ConsumerTest.ConsumerTester tester = ConsumerTest.createConsumerTester(1, 1);
    try {

      String xml = Util.getXMLFromClasspath( "resourceConfig.xml" );
      ResourceConfigDocument rcDoc = ResourceConfigDocument.Factory.parse( xml );
      tester.agent.setResourceConfig( rcDoc.getResourceConfig() );

      ConsumerTest.startConsumerTester( tester );


      GetResourceConfig getResourceConfig = new GetResourceConfig();
      getResourceConfig.setResourceID( "SDSC" );
      getResourceConfig.setMacros( "__regexp__" );

      long startTime = Calendar.getInstance().getTimeInMillis();
      String resources = getResourceConfig.getResourceConfig();
      ResourceConfigDocument retDoc = ResourceConfigDocument.Factory.parse(
        resources
      );
      ResourcesWrapper wrapper = new ResourcesWrapper(retDoc);
      long endTime = Calendar.getInstance().getTimeInMillis();
      logger.info( "Total time = " + ((endTime - startTime) / 1000) );
      String value = wrapper.getValue( "sdsc-ia64", Protocol.PATTERN_MACRO );
      assertEquals(
        "First time thru succeeds", "tg-login1.sdsc.teragrid.org", value
      );

      startTime = Calendar.getInstance().getTimeInMillis();
      resources = getResourceConfig.getResourceConfig();
      endTime = Calendar.getInstance().getTimeInMillis();
      logger.info( "Total time = " + ((endTime - startTime) / 1000) );
    } finally {
      ConsumerTest.stopConsumerTester( tester );
    }
  }


}
