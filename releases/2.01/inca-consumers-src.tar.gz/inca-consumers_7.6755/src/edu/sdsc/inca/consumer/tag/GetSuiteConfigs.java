package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;
import org.apache.log4j.Logger;

import edu.sdsc.inca.Consumer;

import java.io.IOException;

/**
 * Jsp tag that will query the configured Inca agent for the suites its
 * currently storing
 *
 * Required parameters are:
 *
 * retAttrName
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GetSuiteConfigs extends TagSupport {
  public static Logger logger = Logger.getLogger(GetSuiteConfigs.class);

  /**
   * Called when the jsp tag is referenced in a JSP document.  Will return
   * a resources xml document or an error (expressed in XML --
   * &lt;error&gt;...&lt;/error&gt;)
   *
   * @return SKIP_BODY as required
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {
    if ( this.getRetAttrName() == null ){
      pageContext.setAttribute(
        "resources",
        "<error>Missing return attribute name</error>"
      );
      return SKIP_BODY;
    }

    try {
      String s = getSuiteConfigs();
      if ( s == null ) {
        s = "<error>Unable to retrieve suite config xml from agent</error>";
      }
      pageContext.setAttribute( this.getRetAttrName(), s );
    } catch ( IOException e ) {
      String error =
        "<error>Unable to retrieve suite config xml: " + e + "</error>";
      pageContext.setAttribute( this.getRetAttrName(), error );
    }

    return SKIP_BODY;
  }

  /**
   * Retrieves the suite configuration from the consumer cache.
   *
   * @return A string containing the suites stored on the agent.
   *
   * @throws java.io.IOException
   */
  synchronized public String getSuiteConfigs()
    throws IOException {

    try {
      // query agent for resource configuration document
      String configs = Consumer.getSuiteConfigs(
        Consumer.getCacheMaxWaitPeriod()
      );
      if ( configs != null ) {
        return Util.stripNamespaces( configs );
      } else {
        return null;
      }
    } catch ( Exception e ) {
      logger.error( "Unable to retrieve suite configs xml", e );
      throw new IOException(
        "Unable to retrieve suite configuration from agent: " + e
      );
    }
  }
}
