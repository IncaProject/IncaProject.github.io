package edu.sdsc.inca.consumer.tag;


/*
*
*  Prints XML as HTML
*
*  Author:  Kate Ericson, kericson@sdsc.edu
*  Updated: Jan 19, 2006, 5:02:42 PM
*
*/

import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;
import java.io.*;
import org.apache.log4j.Logger;


public class PrintXML extends TagSupport {
    Logger logger = Logger.getLogger(PrintXML.class);

    private String xml;

    public int doStartTag () throws JspException {

        JspWriter out = pageContext.getOut();
        try {
            out.println(htmlEscape(xml));
        } catch (IOException e) {
            logger.error("Can't print xml: " + e);
        }
        return SKIP_BODY;
    }

    private String htmlEscape(String s) {
        StringBuffer b = new StringBuffer();
        for (int i = 0; i<s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '<': b.append("&lt;"); break;
                case '>': b.append("&gt;"); break;
                case '"': b.append("&quot;"); break;
                case '\'': b.append("&apos;"); break;
                case '&': b.append("&amp;"); break;
                default: b.append(c);
            }
        }
        return b.toString();
    }

    public int doEndTag(){
        return EVAL_PAGE;
    }

    public String getXml() {
        return xml;
    }

    public void setXml(String xml) {
        this.xml = xml;
    }

}
