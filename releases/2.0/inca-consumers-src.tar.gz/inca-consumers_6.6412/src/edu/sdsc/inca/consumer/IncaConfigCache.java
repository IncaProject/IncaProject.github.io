package edu.sdsc.inca.consumer;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;

import java.io.IOException;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.AgentClient;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.dataModel.resourceConfig.ResourceConfigDocument;
import edu.sdsc.inca.dataModel.inca.IncaDocument;
import edu.sdsc.inca.util.ResourcesWrapper;
import edu.sdsc.inca.consumer.tag.Util;

/**
 * Thread used to periodically download the latest resource config from the
 * agent and cache it.  The resource config can then be retrieved directly from
 * the cache without contacting the agent (and thus reduce the load time for a
 * web page).  Note, we cache it as ResourcesWrapper object (rather than a
 * string) because the creation of a ResourcesWrapper can be time-intensive
 * (because parents and children are determined at load time). So, we do it once
 * at load and rather than that being done in the tags themselves.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class IncaConfigCache extends Thread {
  private static Logger logger = Logger.getLogger( IncaConfigCache.class );
  private ResourcesWrapper resourceConfig = null;
  private String suites = null;
  private String[] repositories = null;

  /**
   * Create a new IncaConfigCache object.
   */
  public IncaConfigCache( ) {
  }

  /**
   * Return the list of repositories currently being cached from the agent.
   *
   * @param maxWait The maximum time in milliseconds to wait for the
   *                repositories to be initially loaded into the cache.
   *
   * @return  a list of repositories being used by the agent
   */
  public synchronized String[] getRepositories( int maxWait ) {
    try {
      if ( repositories == null ) {
        // we will be notified when the resources are loaded into the cache
        logger.debug( "Waiting for resources to load; maxWait " + maxWait );
        this.wait( maxWait );
      }
      return repositories;
    } catch ( InterruptedException e ) {
      logger.warn( "Interrupted while waiting to get repositories" );
      return null;
    }
  }

  /**
   * Return the resources with a maximum wait time.
   *
   * @param maxWait The maximum time in milliseconds to wait for the resources
   *                to be initially loaded into the cache.
   *
   * @return  The resources as a ResourceWrapper or null if the maxWait is
   * exceeded
   */
  public synchronized ResourcesWrapper getResourceConfig( int maxWait ) {
    try {
      if ( resourceConfig == null ) {
        // we will be notified when the resources are loaded into the cache
        logger.debug( "Waiting for resources to load; maxWait " + maxWait );
        this.wait( maxWait );
      }
      return resourceConfig;
    } catch ( InterruptedException e ) {
      logger.warn( "Interrupted while waiting to get resources" );
      return null;
    }
  }

  /**
   * Return the cached suite configurations from the agent.
   *
   * @param maxWait The maximum time in milliseconds to wait for the resources
   *                to be initially loaded into the cache.
   *
   * @return the suite configurations stored in the agent as XML
   */
  public synchronized String getSuites( int maxWait ) {
    try {
      if ( suites == null ) {
        // we will be notified when the resources are loaded into the cache
        logger.debug( "Waiting for resources to load; maxWait " + maxWait );
        this.wait( maxWait );
      }
      return suites;
    } catch ( InterruptedException e ) {
      logger.warn("Interrupted while waiting to get suite configs from agent");
      return null;
    }
  }


  /**
   * The functionality of the thread.  Periodically, will fetch the
   * configuration from the depot.  Will use the configured
   * cache reload period to wait in between iterations.
   */
  public void run() {
    logger.info( "Starting cache thread for inca configuration" );
    while ( true ) {
      try {
        IncaDocument configDoc = queryIncaConfig();
        if ( configDoc == null ) {
          logger.error( "Received a null inca configuration from agent" );
          continue;
        }
        ResourceConfigDocument tmpDoc =
          ResourceConfigDocument.Factory.newInstance();
        if ( configDoc.getInca().isSetResourceConfig() ) {
          tmpDoc.setResourceConfig( configDoc.getInca().getResourceConfig() );
        } else { // create a blank resources document
          tmpDoc.addNewResourceConfig();
          tmpDoc.getResourceConfig().addNewResources();
        }
        synchronized( this ) {
          this.resourceConfig = new ResourcesWrapper(tmpDoc);
          if ( configDoc.getInca().isSetSuites() ) {
            XmlOptions options = new XmlOptions();
            options.setSavePrettyPrint();
            options.setSaveOuter();
            this.suites = configDoc.getInca().getSuites().xmlText( options );
          }
          if ( configDoc.getInca().isSetRepositories() ) {
            repositories =
            configDoc.getInca().getRepositories().getRepositoryArray();
            logger.debug( "Returned " + repositories.length + " repositories" );
          }
          this.notifyAll();
        }
        logger.debug(
          "Inca config cache thread sleeping "
          + Consumer.getCacheReloadPeriod() + " millis"
        );
      } catch ( Exception e ) {
        logger.error("Unable to retrieve inca configuration", e);
      } finally {
        try {
          Thread.sleep( Consumer.getCacheReloadPeriod() );
        } catch ( InterruptedException e ) {
          logger.info("Interrupting resource config cache thread" );
          break;
        }

      }
    }
    logger.info( "Exitting cache thread for resource config" );
  }

  /**
   * Will fetch the inca configuration from the agent.
   *
   * @return A inca config XML document with the repositories, resources, and
   * suites returned by the agent
   *
   * @throws ConfigurationException
   * @throws IOException
   * @throws ProtocolException
   * @throws XmlException
   */
  private IncaDocument queryIncaConfig()
    throws ConfigurationException, IOException, ProtocolException,
           XmlException {

    AgentClient ac = new AgentClient();
    ac.setConfiguration( Consumer.getClientConfiguration() );
    long startTime = Util.getTimeNow();
    logger.info( "Contacting agent " + ac.getUri() );
    ac.connect();
    String config = ac.getConfig();
    ac.close();
    Util.printElapsedTime( startTime, "query agent" );
    if( config != null ) {
      return IncaDocument.Factory.parse(config);
    } else {
      return null;
    }
  }
}
