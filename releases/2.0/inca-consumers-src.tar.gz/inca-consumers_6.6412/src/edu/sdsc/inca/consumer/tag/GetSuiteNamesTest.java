package edu.sdsc.inca.consumer.tag;

import junit.framework.TestCase;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.ConsumerTest;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.util.ConfigProperties;
import edu.sdsc.inca.util.Constants;

import org.apache.log4j.Logger;

import java.net.InetAddress;
import java.util.regex.Pattern;

/*
*
*  Test class for GetSuiteNames jsp tag
*
* @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
*/

public class GetSuiteNamesTest extends TestCase {
  private static Logger logger = Logger.getLogger(GetSuiteNamesTest.class);

  public void testGetSuiteNames() throws Exception {

    ConsumerTest.ConsumerTester tester = ConsumerTest.createConsumerTester(1,2);

    try {
      String xml = Util.getXMLFromClasspath( "reportSummary.xml" );
      String result = xml.replaceAll("<\\?xml.*\\?>", "");
      tester.depot.addSuite(
        tester.agent.getUri() + "/" + Protocol.IMMEDIATE_SUITE_NAME,
        Util.suiteToSummaries( result ),
        10 * Constants.MILLIS_TO_SECOND
      );
      tester.depot.addSuite(
        tester.agent.getUri() + "/TestSuiteLocal2",
        Util.suiteToSummaries( result ),
        10 * Constants.MILLIS_TO_SECOND
      );
      ConsumerTest.startConsumerTester( tester );

      GetSuiteNames suite = new GetSuiteNames();
      String guids = suite.getSuiteNames();
      assertNotNull( "result returned", guids );
      assertTrue(
        "TestSuiteLocal2 found",
        Pattern.compile("TestSuiteLocal2").matcher(guids).find()
      );
      assertFalse(
        "immediate not found",
        Pattern.compile(Protocol.IMMEDIATE_SUITE_NAME).matcher(guids).find()
      );
      logger.info( guids );
    } finally {
      ConsumerTest.stopConsumerTester( tester );   
    }
  }
}
