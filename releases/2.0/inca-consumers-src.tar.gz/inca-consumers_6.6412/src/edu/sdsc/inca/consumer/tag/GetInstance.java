package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;
import org.apache.log4j.Logger;

import edu.sdsc.inca.queryResult.ReportDetailsDocument;
import edu.sdsc.inca.DepotClient;
import edu.sdsc.inca.Consumer;
import java.net.URL;
import java.io.IOException;
import java.io.File;

/**
 * Jsp tag that will query the configured Inca depot for a report instance
 * and return it as a processed report details XML document.  Required
 * parameters for the tag are configID and instanceID.
 *
 * @author Kate Ericson &lt;kericson@sdsc.edu&gt;
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GetInstance extends TagSupport {
  Logger logger = Logger.getLogger(GetInstance.class);

  private String configID = null;
  private String instanceID = null;
  public boolean debug = false;

  /**
   * Called when the jsp tag is referenced in a JSP document.  Will return
   * a processed report details document or an error (expressed in XML --
   * &lt;error&gt;...&lt;/error&gt;) in the specified return attribute.
   *
   * @return SKIP_BODY to indicate not to process the body of the tag which
   * should be empty.
   *
   * @throws JspTagException
   */
  public int doStartTag() throws JspTagException {

    if ( this.getRetAttrName() == null ){
      pageContext.setAttribute(
        "instance",
        "<error>Missing return attribute name</error>"
      );
      return SKIP_BODY;
    }
    if ( Long.parseLong(this.getInstanceID()) < 0 ){
      pageContext.setAttribute(
        this.getRetAttrName(),
        "<error>Missing instanceID: " + this.instanceID + "</error>"
      );
      return SKIP_BODY;
    }
    if ( Long.parseLong(this.getConfigID()) < 0 ){
      pageContext.setAttribute(
        this.getRetAttrName(),
        "<error>Missing configID: " + this.configID + "</error>"
      );
      return SKIP_BODY;
    }

    try {
      pageContext.setAttribute( this.getRetAttrName(), getReportDetailsXml() );
    } catch ( IOException e ) {
      logger.error( "Failed to retrieve report instance xml", e );
      pageContext.setAttribute(
        this.getRetAttrName(),
        "<error>" + e + "</error>"
      );
    }
    return SKIP_BODY;
  }

  /**
   * Get the series config identifier that will be used to query for a
   * specific report (will be called by a jsp page)
   *
   * @return A series config identifier.
   */
  public String getConfigID() {
    return configID;
  }

  /**
   * Get the report instance identifier that will be used to query for a
   * specific report  (will be called by a jsp page)
   *
   * @return A report instance identifier.
   */
  public String getInstanceID() {
    return instanceID;
  }

  /**
   * Query the depot for a report instance.  If debug is true, will return the
   * contents of "reportDetails.xml" located somewhere in the classpath.
   *
   * @return A report details XML document.
   *
   * @throws IOException
   */
  public String getReportDetailsXml() throws IOException {
    try {
      ReportDetailsDocument detailsDoc = null;
      if ( debug ) { // for debugging, load xml from file rather than query
        URL url = ClassLoader.getSystemClassLoader().getResource(
          "reportDetails.xml"
        );
        if( url == null ) {
          throw new IOException(
            "debug option - reportDetails.xml" + " not found in classpath"
          );
        }
        File detf = new File( url.getFile() );
        detailsDoc = ReportDetailsDocument.Factory.parse(detf);
      } else {
        DepotClient depotClient = new DepotClient();
        depotClient.setConfiguration( Consumer.getClientConfiguration() );
        depotClient.connect();
        detailsDoc = depotClient.queryInstance(
          Long.parseLong(instanceID), Long.parseLong(configID)
        );
        depotClient.close();
      }
      if ( detailsDoc == null ) {
        throw new IOException( "Received null instance from depot" );
      }
      return Util.formatReportDetails( detailsDoc );
    } catch ( Exception e ) {
      throw new IOException( "Unable to retrieve report instance xml: " + e );
    }
  }

  /**
   * Set the series config identifier that will be used to query for a
   * specific report (will be called by a jsp page)
   *
   * @param configID  A series config identifier
   */
  public void setConfigID(String configID) {
    this.configID = configID;
  }

  /**
   * Set the report instance identifier that will be used to query for a
   * specific report  (will be called by a jsp page)
   *
   * @param instanceID
   */
  public void setInstanceID(String instanceID) {
    this.instanceID = instanceID;
  }

}
