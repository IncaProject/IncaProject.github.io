package edu.sdsc.inca.consumer.tag;

import junit.framework.TestCase;
import junit.framework.Assert;
import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.util.ConfigProperties;
import org.apache.log4j.Logger;

import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;

/**
 * Created by IntelliJ IDEA.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GetSeriesTest extends TestCase {

  private Logger logger = Logger.getLogger( GetSeriesTest.class );
  private String reportResult =
    "<series><reportDetails>\n" +
    "  <suiteId>1</suiteId>\n" +
    "  <reportSeriesConfigId>1</reportSeriesConfigId>\n" +
    "  <reportSeriesId>1</reportSeriesId>\n" +
    "  <reportId>1</reportId>\n" +
    "  <instanceId>44</instanceId>\n" +
    "  <reportSeries>\n" +
    "    <uri>http://inca.sdsc.edu/2.0/repository/bin/cluster.compiler.gcc.version</uri>\n" +
    "    <args>\n" +
    "      <arg>\n" +
    "        <name>version</name>\n" +
    "        <value>no</value>\n" +
    "      </arg>\n" +
    "      <arg>\n" +
    "        <name>help</name>\n" +
    "        <value>no</value>\n" +
    "      </arg>\n" +
    "      <arg>\n" +
    "        <name>log</name>\n" +
    "        <value>0</value>\n" +
    "      </arg>\n" +
    "      <arg>\n" +
    "        <name>verbose</name>\n" +
    "        <value>1</value>\n" +
    "      </arg>\n" +
    "    </args>\n" +
    "    <setup/>\n" +
    "    <cleanup/>\n" +
    "    <nice>false</nice>\n" +
    "    <description/>\n" +
    "    <hostname>Catherine-Olschanowskys-Computer.local</hostname>\n" +
    "  </reportSeries>\n" +
    "  <schedule>\n" +
    "    <cron>\n" +
    "      <min>0-59/5</min>\n" +
    "      <hour>*</hour>\n" +
    "      <mday>*</mday>\n" +
    "      <wday>*</wday>\n" +
    "      <month>*</month>\n" +
    "      <suspended>false</suspended>\n" +
    "    </cron>\n" +
    "  </schedule>\n" +
    "  <report>\n" +
    "    <localtime>January 31, 2006 9:26 AM</localtime><age>156 days 21 hours 21 mins 17 secs </age>\n" +
    "    <hostname>client65-41.sdsc.edu</hostname>\n" +
    "    <name>grid.middleware.globus.unit.date</name>\n" +
    "    <version>1.9</version>\n" +
    "    <args>\n" +
    "      <arg>\n" +
    "        <name>count</name>\n" +
    "        <value/>\n" +
    "      </arg>\n" +
    "      <arg>\n" +
    "        <name>help</name>\n" +
    "        <value>no</value>\n" +
    "      </arg>\n" +
    "      <arg>\n" +
    "        <name>host</name>\n" +
    "        <value/>\n" +
    "      </arg>\n" +
    "      <arg>\n" +
    "        <name>log</name>\n" +
    "        <value>0</value>\n" +
    "      </arg>\n" +
    "      <arg>\n" +
    "        <name>service</name>\n" +
    "        <value/>\n" +
    "      </arg>\n" +
    "      <arg>\n" +
    "        <name>timeout</name>\n" +
    "        <value>60</value>\n" +
    "      </arg>\n" +
    "      <arg>\n" +
    "        <name>verbose</name>\n" +
    "        <value>1</value>\n" +
    "      </arg>\n" +
    "      <arg>\n" +
    "        <name>version</name>\n" +
    "        <value>no</value>\n" +
    "      </arg>\n" +
    "    </args>\n" +
    "    <body/>\n" +
    "    <exitStatus>\n" +
    "      <completed>false</completed>\n" +
    "      <errorMessage>test failed: call to 'globus-job-submit  -stderr -l /Users/kate/.inca.tmp.16468.err -stdout -l /Users/kate/.inca.tmp.16468.out client65-41.sdsc.edu -count 1 -maxtime 1 -x '(host_count=1)' -l /bin/date' failed: sh: line 1: globus-job-submit: command not found</errorMessage>\n" +
    "    </exitStatus>\n" +
    "  </report>\n" +
    "  <comparisonResult/>\n" +
    "  <sysusage>\n" +
    "    <wallClockTime>0.100632</wallClockTime>\n" +
    "    <memory>0.0</memory>\n" +
    "    <cpuTime>0.065082</cpuTime>\n" +
    "  </sysusage>\n" +
    "</reportDetails></series>\n";


  public void testGetSeries() throws Exception {

    GetSeries result = new GetSeries();
    result.debug = true;
    String xml = result.getSeriesXml();
    xml = Util.stripNamespaces( xml );
    assertNotNull( "xml returned", xml );
    assertEquals(
      "formatted correctly",
      reportResult.replaceAll("<age>[^<]*</age>", "").trim(),
      xml.replaceAll("<age>[^<]*</age>", "").trim()
    );

  }
}
