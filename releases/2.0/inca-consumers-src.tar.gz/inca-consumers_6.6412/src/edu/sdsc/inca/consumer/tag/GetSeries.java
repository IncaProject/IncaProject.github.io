package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;
import org.apache.log4j.Logger;

import edu.sdsc.inca.queryResult.ReportDetailsDocument;
import edu.sdsc.inca.DepotClient;
import edu.sdsc.inca.Consumer;

import java.net.URL;
import java.io.IOException;
import java.io.File;

/**
 * Jsp tag that will query the configured Inca depot for all of a series'
 * report instances.  Required parameters for the tag are configID.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GetSeries extends TagSupport {
  Logger logger = Logger.getLogger(GetSeries.class);

  private String configID = null;
  public boolean debug = false;

  /**
   * Called when the jsp tag is referenced in a JSP document.  Will return
   * a processed report details document or an error (expressed in XML --
   * &lt;error&gt;...&lt;/error&gt;) in the specified return attribute.
   *
   * @return SKIP_BODY to indicate not to process the body of the tag which
   * should be empty.
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {

    if ( this.getRetAttrName() == null ){
      pageContext.setAttribute(
        "instance",
        "<error>Missing return attribute name</error>"
      );
      return SKIP_BODY;
    }

    if ( Long.parseLong(this.getConfigID()) < 0 ){
      pageContext.setAttribute(
        this.getRetAttrName(),
        "<error>Missing configID: " + this.configID + "</error>"
      );
      return SKIP_BODY;
    }

    try {
      pageContext.setAttribute( this.getRetAttrName(), getSeriesXml() );
    } catch ( IOException e ) {
      logger.error( "Failed to retrieve report series xml", e );
      pageContext.setAttribute( 
        this.getRetAttrName(),
        "<error>" + e + "</error>"
      );
    }
    return SKIP_BODY;
  }

  /**
   * Get the series config identifier that will be used to query for a
   * specific report series (will be called by a jsp page)
   *
   * @return A series config identifier.
   */
  public String getConfigID() {
    return configID;
  }

  /**
   * Query the depot for the instances of a report series.  If debug is true,
   * will return the contents of "reportDetails.xml" located somewhere in the
   * classpath.
   *
   * @return The instances of a report series wrapped by a &lt;series&gt;
   * tag.
   *
   * @throws java.io.IOException
   */
  public String getSeriesXml() throws IOException {
    try {
      ReportDetailsDocument[] detailsDocs = null;
      if ( debug ) { // for debugging, load xml from file rather than query
        URL url = ClassLoader.getSystemClassLoader().getResource(
          "reportDetails.xml"
        );
        if( url == null ) {
          throw new IOException(
            "debug option - reportDetails.xml" + " not found in classpath"
          );
        }
        File detf = new File( url.getFile() );
        detailsDocs = new ReportDetailsDocument[1];
        detailsDocs[0] = ReportDetailsDocument.Factory.parse(detf);
      } else {
        DepotClient depotClient = new DepotClient();
        depotClient.setConfiguration( Consumer.getClientConfiguration() );
        depotClient.connect();
        detailsDocs = depotClient.querySeries(
          Long.parseLong(configID)
        );
        depotClient.close();
      }
      String docs = "<series>";
      for ( int i = 0; i < detailsDocs.length; i++ ) {
        docs += Util.formatReportDetails( detailsDocs[i] );
      }
      return docs + "</series>";
    } catch ( Exception e ) {
      throw new IOException( "Unable to retrieve report series xml: " + e );
    }
  }

  /**
   * Set the series config identifier that will be used to query for a
   * specific report series (will be called by a jsp page)
   *
   * @param configID  A series config identifier
   */
  public void setConfigID(String configID) {
    this.configID = configID;
  }

}
