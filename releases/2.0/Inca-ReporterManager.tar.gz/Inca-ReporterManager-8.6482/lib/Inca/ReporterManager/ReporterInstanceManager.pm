package Inca::ReporterManager::ReporterInstanceManager;

################################################################################

=head1 NAME

Inca::ReporterManager::ReporterInstanceManager - Manages reporter execution 

=head1 SYNOPSIS

=for example begin

  use Inca::ReporterManager::ReporterInstanceManager;
  my $rim = new Inca::ReporterManager::ReporterInstanceManager();
  my $sc = new Inca::Suite::SeriesConfig();
  $sc->setPath( "var/reporter-packages/bin/cluster.compiler.gcc.version-3" );
  $sc->setName( "cluster.compiler.gcc.version" );
  $sc->setVersion( "3" );
  $sc->setContext( "cluster.compiler.gcc.version -verbose=1 -log=3" );
  my $credentials = { cert => "t/certs/client_ca1cert.pem",
                      key => "t/certs/client_ca1keynoenc.pem", 
                      passphrase => undef,
                      trusted => "t/certs/trusted" };
  $rim = new Inca::ReporterManager::ReporterInstanceManager();
  $rim->setSeriesConfig( $sc );
  $rim->setId( "resourceA" );
  $rim->setCredentials( $credentials );
  $rim->setCheckPeriod(1);
  $rim->setPath( "t/stream_report" );
  $rim->setDepots( "incas://localhost:$port" );
  $rim->setReporterCache( $rc );
  my $success = $rim->runReporter();

=for example end

=head1 DESCRIPTION

The Reporter Instance Manager (RIM) is responsible for launching a reporter
instance and monitoring its execution.  Specifically, it forks/execs the 
reporter and then monitors its system usage (CPU time, wall clock time, and
memory) and if it exceeds a specified limit set for either wall clock time,
CPU time, or memory, it will kill the reporter and formulate an error report.
Otherwise upon reporter exit, the RIM will gather stderr, stdout, and usage
statistics and send that to the first depot in its depot list.  The depot
will then get passed to all interested parties.

=cut 
################################################################################

#=============================================================================#
# Usage
#=============================================================================#

# pragmas
use strict;
use warnings;
use vars qw($VERSION);

# Inca
use Inca::Constants qw(:params);
use Inca::IO;
use Inca::Logger;
use Inca::Net::Protocol::Statement;
use Inca::Process;
use Inca::ReporterManager::ReporterCache;
use Inca::Validate qw(:all);
use Inca::Net::Client;
use Inca::GridProxy;

# Perl standard
use Carp;
use Cwd;
use File::Basename;
use File::Spec;
use Socket qw(:crlf);

#=============================================================================#
# Global Vars
#=============================================================================#

our ( $VERSION ) = '$Revision: 1.2 $' =~ 'Revision: (.*) ';

my $SELF_PARAM_REQ = { isa => "Inca::ReporterManager::ReporterInstanceManager"};

my $CHECK_PERIOD_PARAM_OPT = { %{$POSITIVE_INTEGER_PARAM_OPT}, default => 5 };
my $DEFAULT_TMP_DIR = "/tmp";
my $TMPFILE_TEMPLATE = "inca.rm.$$";
our $DEPOT_SEND_TIMEOUT = 60; # secs
my $PROXY_MACRO = "@.incaProxy@";
 
#=============================================================================#

=head1 CLASS METHODS

=cut
#=============================================================================#

#-----------------------------------------------------------------------------#
# Public methods (documented with pod markers)
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#

=head2 new( %Options )

Class constructor which returns a new 
Inca::ReporterManager::ReporterInstanceManager object.  The constructor may be
called with any of the following attributes.

=over 2 

B<Options>:

=over 15

=item id

The resource identifier supplied by the reporter agent that the reporter
manager will use to identify itself to the reporter depot.

=item config

An object of type Inca::Suite::SeriesConfig which contains information
about the reporter to execute.

=item checkPeriod

A positive integer indicating the period in seconds of which to check the
reporter for exceeding resource limits [default: 5]

=item depotURIs

A list of depot uris.  The report will be sent to the first depot in the list.
If the first depot is unreachable, the next depots in the list will be tried.

=item reporterCache 

An object of type Inca::ReporterManager::ReporterCache which is used to map
reporter uris to a local path.

=item credentials

A reference to a hash array containing the credential information.

=item tmpDir

A string containing a path to a temporary file space that Inca can use while
executing reporters

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;
  use Test::Exception;
  lives_ok { new Inca::ReporterManager::ReporterInstanceManager() } 
           'object created';

=end testing

=cut
#-----------------------------------------------------------------------------#
sub new {
  my $this = shift;
  my $class = ref($this) || $this;
  my $self = {};
  
  bless $self, $class;

  # defaults
  $self->{logger} = Inca::Logger->get_logger( $class );
  $self->setTmpDirectory( $DEFAULT_TMP_DIR );

  # class variables
  my %options = validate( @_, { agent => $SCALAR_PARAM_OPT,
                                checkPeriod => $CHECK_PERIOD_PARAM_OPT,
                                config => $SERIESCONFIG_PARAM_OPT,
                                credentials => $HASHREF_PARAM_OPT,
                                depotURIs => $ARRAYREF_PARAM_OPT,
                                id => $SCALAR_PARAM_OPT,
                                reporterCache => $REPORTER_CACHE_PARAM_OPT,
                                tmpDir => $SCALAR_PARAM_OPT
                              } );

  $self->setAgent( $options{agent} ) if exists $options{agent};
  $self->setCheckPeriod($options{checkPeriod}) if exists $options{checkPeriod};
  $self->setCredentials($options{credentials}) if exists $options{credentials};
  $self->setDepots( @{$options{depotURIs}} ) if exists $options{depotURIs}; 
  $self->setId( $options{id} ) if exists $options{id}; 
  $self->setSeriesConfig( $options{config} ) if exists $options{config};
  $self->setReporterCache( $options{reporterCache} ) 
    if exists $options{reporterCache};
  $self->setTmpDirectory( $options{tmpDir} ) if exists $options{tmpDir}; 

  return $self;
}

#-----------------------------------------------------------------------------#

=head2 getAgent( )

Retrieve the uri of the Inca agent to contact in order to retrive a proxy 
credential to use for the reporter.

=over 2

B<Returns>:

A string containing the uri of the Inca agent to contact to retrieve a 
proxy credential.

=back

=cut
#-----------------------------------------------------------------------------#
sub getAgent {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{agent};
}

#-----------------------------------------------------------------------------#

=head2 getCheckPeriod( )

Get the period for how often to check the reporter for exceeding its limits.

=over 2

B<Returns>:

A positive integer indicating the period in seconds of which to check for
resource limits.

=back

=cut
#-----------------------------------------------------------------------------#
sub getCheckPeriod {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{check_period};
}

#-----------------------------------------------------------------------------#

=head2 getCredentials( )

Retrieve the security credentials.

=over 2

B<Returns>:

A reference to a hash array containing the paths to the security 
credentials.

=back

=cut
#-----------------------------------------------------------------------------#
sub getCredentials {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{credentials};
}

#-----------------------------------------------------------------------------#

=head2 getDepots( )

Retrieve the destination depots that are used to send the report on completion.

=over 2

B<Returns>:

An array of strings containing uris to depots [host:port, ...]

=back

=cut
#-----------------------------------------------------------------------------#
sub getDepots {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  @{$self->{depots}};
}

#-----------------------------------------------------------------------------#

=head2 getId( )

Get the resource identifier supplied by the reporter agent that the reporter
manager will use to identify itself to the depot.

=over 2

B<Returns>:

A string indicating the id of the resource.

=back

=cut
#-----------------------------------------------------------------------------#
sub getId {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{id};
}

#-----------------------------------------------------------------------------#

=head2 getReporterCache( )

Retrieve the reporter administrator to use in order to find a path to a local
copy of a reporter (from its URI).

=over 2

B<Returns>:

An object of type Inca::ReporterManager::ReporterCache which is used to map
reporter uris to a local path.

=back

=cut
#-----------------------------------------------------------------------------#
sub getReporterCache {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{reporter_cache};
}

#-----------------------------------------------------------------------------#

=head2 getSeriesConfig( )

Retrieve the series config that will be executed.

=over 2

B<Returns>:

An object of type Inca::Suite::SeriesConfig which contains information
about the reporter to execute.

=back

=cut
#-----------------------------------------------------------------------------#
sub getSeriesConfig {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{config};
}

#-----------------------------------------------------------------------------#

=head2 getTmpDirectory( )

Retrieve the path to a temporary file space that Inca can use while executing
reporters

=over 2

B<Returns>:

A string containing a path to a temporary file space.

=back

=cut
#-----------------------------------------------------------------------------#
sub getTmpDirectory {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return $self->{tmpdir};
}

#-----------------------------------------------------------------------------#

=head2 hasAgent( )

Returns true if an agent uri has been specified and false otherwise.

=over 2

B<Returns>:

True if an agent uri has been specified and false otherwise.

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager();
  my $rim = new Inca::ReporterManager::ReporterInstanceManager();
  ok( ! $rim->hasAgent(), 'hasAgent for false' );
  $rim->setAgent( "incas://inca.sdsc.edu:6233" );
  ok( $rim->hasAgent(), 'hasAgent for true' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub hasAgent {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return ( exists $self->{agent} && defined $self->{agent} );
}

#-----------------------------------------------------------------------------#

=head2 hasCredentials( )

Return true if credentials have been specified; otherwise return false.

=over 2

B<Returns>:

A boolean indicating true if credentials have been specified and false if they
has not.

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager();
  my $rim = new Inca::ReporterManager::ReporterInstanceManager();
  ok( ! $rim->hasCredentials(), 'hasCredentials for false' );
  my $credentials = { cert => 't/cert.pem', key => 't/key.pem',
                      passphrase => 'secret', trusted => 't/trusted' };
  $rim->setCredentials( $credentials );
  ok( $rim->hasCredentials(), 'hasCredentials for true' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub hasCredentials {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return exists $self->{credentials};
}

#-----------------------------------------------------------------------------#

=head2 hasSeriesConfig( )

Return true if a series config has been specified; otherwise return
false.

=over 2

B<Returns>:

Returns true if a series config has been specified and false if it has not.

=back

=begin testing

  use Inca::Suite::SeriesConfig;
  use Inca::ReporterManager::ReporterInstanceManager();
  my $rim = new Inca::ReporterManager::ReporterInstanceManager();
  ok( ! $rim->hasSeriesConfig(), 'hasSeriesConfig for false' );
  my $sc = new Inca::Suite::SeriesConfig();
  $rim->setSeriesConfig( $sc );
  ok( $rim->hasSeriesConfig(), 'hasSeriesConfig for true' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub hasSeriesConfig {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  return exists( $self->{'config'} ) && defined( $self->{'config'} );
}

#-----------------------------------------------------------------------------#

=head2 runReporter( )

Contact the reporter administrator, retrieve the local path to the
reporter, and execute it.

B<Returns:>

Returns false if there was a problem either retrieving the reporter, running it,
or sending it to the depot.  Otherwise returns true for success.

=begin testing

  untie *STDOUT;
  untie *STDERR;
  use Cwd;
  use File::Spec;
  use Inca::Logger;
  use Inca::ReporterManager::ReporterInstanceManager;
  use Inca::ReporterManager::Scheduler;
  use Inca::Net::MockAgent;
  use Inca::Net::MockDepot;

  Inca::Logger->screen_init( "FATAL" );

  my $DEPOT = "file://" . File::Spec->catfile( getcwd(), "depot.tmp.$$" );
  my $PORT = 8519;
  my $RETURN_CODE = 1;
  my $VERIFY = 1;

  sub runConfig {
    my $desc = shift;
    my $sc = shift;
    my @regexs = @_;

    my $rim = Inca::ReporterManager::ReporterInstanceManager->_createTestRM();
    $rim->setDepots( $DEPOT );
    $rim->setSeriesConfig( $sc );
    $rim->setAgent( "incas://localhost:$PORT" ) if $desc =~ /proxy/;
    my $success = $rim->runReporter();
    if ( $VERIFY ) {
      is( $success, $RETURN_CODE, "runReporter($desc) returned $RETURN_CODE" ); 
    }
    my $depot = new Inca::Net::MockDepot;
    if ( $VERIFY ) {
      ok($depot->readReportsFromFile("./depot.tmp.$$", 0), "$desc report read");
    }
    my @reports = $depot->getReports();
    for my $regex ( @regexs ) {
      like( $reports[0], qr/$regex/ms, "$desc report matches $regex" );
    }
    return $reports[0];
  }

  #-------------------------------------------
  # simple execution to file
  #-------------------------------------------
  my $sc = Inca::ReporterManager::Scheduler->_createTestConfig( "echo_report" );
  $sc->setNiced( 1 );
  $sc->setContext( "sh -c \"echo_report\"" );
  $sc->setLimits( { "wallClockTime" => 10,
                    "cpuTime" => 10,
                    "memory" => 20 } );
  my $report = runConfig( "basic", $sc, "^REPORT resourceA sh -c \".*" );
  my ($wall_secs) = $report =~ /^wall_secs=(.*)/m;
  cmp_ok( $wall_secs, "<=", 1, "wall secs is reasonable" );

  #-------------------------------------------
  # reporter that uses INSTALL_DIR
  #-------------------------------------------
  $sc = Inca::ReporterManager::Scheduler->_createTestConfig( "repo_report" );
  $sc->setContext( $sc->getName() . ' -verbose="1" -help="no"' );
  runConfig( "INSTALL_DIR", $sc, ".*<dir>" . getcwd() . "\/t<\/dir>.*" );
  
  #-------------------------------------------
  # reporter with env var as arg
  #-------------------------------------------
  $sc = Inca::ReporterManager::Scheduler->_createTestConfig( "var_reporter" );
  $sc->setContext( $sc->getName() . ' -verbose="1" -help="no" -args="$HOME"' );
  runConfig( 
    "env var in arg", $sc, 
    "<completed>true<\/completed>.*",
    "<value>-verbose=1 -help=no -args=$ENV{HOME}<\/value>.*"
  );

  #-------------------------------------------
  # reporter with non-existent env var as arg
  #-------------------------------------------
  $sc = Inca::ReporterManager::Scheduler->_createTestConfig( "var_reporter" );
  $sc->setContext( $sc->getName() . ' -verbose="1" -help="no" -args="$BLAH"' );
  runConfig( 
    "non-existent env var in arg", $sc, 
    "<completed>true<\/completed>.*",
    "<value>-verbose=1 -help=no -args=<\/value>.*"
  );
 
  #-------------------------------------------
  # not a valid reporter
  #-------------------------------------------
  $sc = Inca::ReporterManager::Scheduler->_createTestConfig( "not_a_reporter" );
  $sc->setContext( $sc->getName() . ' -verbose="1" -help="no"' );
  $sc->addArgument( "verbose", "1" );
  $sc->addArgument( "help", "no" );
  runConfig( 
    "invalid", $sc, 
    "<completed>false<\/completed>.*",
    "<errorMessage>Error, no report produced to stdout.*<\/errorMessage>.*",
    "<name>verbose<\/name>.*"
  );

  #-------------------------------------------
  # faulty reporter
  #-------------------------------------------
  $sc = Inca::ReporterManager::Scheduler->_createTestConfig( "bad_reporter" );
  runConfig( 
    "faulty", $sc, 
    "<completed>false<\/completed>.*",
    "<errorMessage>Exec of reporter .*<\/errorMessage>.*"
  );

  #-------------------------------------------
  # badly written reporter
  #-------------------------------------------
  $sc = Inca::ReporterManager::Scheduler->_createTestConfig( "bad_reporter2" );
  runConfig( 
    "poor", $sc, 
    "<completed>false<\/completed>.*",
    "<errorMessage>.*no report.*"
  );

  #-------------------------------------------
  # no report but there is stderr
  #-------------------------------------------
  $sc = Inca::ReporterManager::Scheduler->_createTestConfig( "no_report" );
  runConfig( 
    "null", $sc, 
    "<completed>false<\/completed>.*",
    "<errorMessage>.*no report.*"
  );

  #-------------------------------------------
  # report to stdout with extra junk before the xml 
  #-------------------------------------------
  $sc =Inca::ReporterManager::Scheduler->_createTestConfig("xtraStdout_report");
  runConfig( "extra stdout", $sc, "^<?" );

  #-------------------------------------------
  # report to stdout with proxy
  #-------------------------------------------
  local $SIG{CHLD} = 'DEFAULT';
  `echo bree987 | myproxy-init -s localhost -l test -S -c 2`;
   cmp_ok( $?, "==", 0, "proxy stored in myproxy server" );
  `grid-proxy-destroy >/dev/null 2>&1`;
  `grid-proxy-info >/dev/null 2>&1`;
  cmp_ok( $?, "!=", 0, "grid-proxy-info returned error" );

  my $agent = new Inca::Net::MockAgent( $PORT, "ca1", "t/certs/trusted" );
  my $proxy_reporter = Inca::ReporterManager::Scheduler->_createTestConfig(
    "grid.middleware.globus.unit.proxy"
  );
  $proxy_reporter->setContext( "bash --login -c 'export X509_USER_PROXY=@.incaProxy@;" . $proxy_reporter->getName() . " -verbose=1 -log=3'" );
  if ( fork() ) {
    runConfig( "proxy", $proxy_reporter, "completed>true" );
  } else {
    sleep 2;
    $agent->accept(
      "PROXY" => [ "HOSTNAME localhost", "PORT 7512", "USERNAME test", "PASSWORD bree987", "LIFETIME 1"],
      "OK" => []
    );
    exit;
  }
  $agent->stop();

  #-------------------------------------------
  # report to stdout with unsuccessful proxy retrieval
  #-------------------------------------------
  $RETURN_CODE = 0;
  runConfig( "unsuccessful proxy", $proxy_reporter, "completed>false" );
  $RETURN_CODE = 1;

  #-------------------------------------------
  # Limits
  #-------------------------------------------
  $sc = Inca::ReporterManager::Scheduler->_createTestConfig( "stream_report" );
  $sc->setLimits( { "cpuTime" => 1, "memory" => 100 } );
  $report = runConfig( 
    "long - limits exceeded", $sc, 
    "<completed>false<\/completed>.*",
    "<errorMessage>.*exceeded usage limits.*"
  );
  my ($memory) = $report=~ /^memory_mb=(.*)/m;
  cmp_ok( $memory, ">=", 45, "runReporter(limits) - memory is reasonable" );

  #-------------------------------------------
  # more resource intensive reporter to file
  #-------------------------------------------
  $sc->setLimits( 
    { "wallClockTime" => 100, "cpuTime" => 10, "memory" => 100 } 
  );
  $report = runConfig( "long", $sc, "completed>true" );
  ($memory) = $report =~ /^memory_mb=(.*)/m;
  cmp_ok( $memory, ">=", 45, "memory is reasonable" );

  #-------------------------------------------
  # more resource intensive reporter to ssl server
  #-------------------------------------------
  my @clientCredentials = ( { cert => "t/certs/client_ca1cert.pem",
                              key => "t/certs/client_ca1keynoenc.pem", 
                              passphrase => undef,
                              trusted => "t/certs/trusted" },
                            { cert => "t/certs/client_ca1cert.pem",
                              key => "t/certs/client_ca1key.pem", 
                              passphrase => "test",
                              trusted => "t/certs/trusted" }
                          );
  $depot = new Inca::Net::MockDepot();
  my $pid;
  if ( $pid = fork() ) {
    my $numReports = $depot->readReportsFromSSL(
      2, $PORT, "ca1", "t/certs/trusted"
    );
    is( $numReports, 2, "2 reports received from mock depot" );
  } else {
    $VERIFY = 0;
    for ( my $i = 0; $i <= $#clientCredentials; $i++ ) {
      $sc = Inca::ReporterManager::Scheduler->_createTestConfig("echo_report");
      $DEPOT = "incas://localhost:$PORT";
      runConfig( "quick ssl", $sc );
    }
    exit;
  }

=end testing

=cut
#-----------------------------------------------------------------------------#
sub runReporter {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  my $reporter_executed_n_recorded = 0;

  $self->{logger}->info( 
    "Begin executing " . $self->getSeriesConfig()->getContext() 
  );
  my $cmdline = $self->_createCmdLine();
  $self->{logger}->info( "  $cmdline" );
  if ( ! defined $cmdline ) {
    $self->_generateErrorReport( 
      "Unable to retrieve local copy of reporter for execution" 
    );
    my $success = $self->_sendReportToDepot();
    if ( ! $success ) {
      $self->{logger}->error( "  Unable to send report to available depots" );
    }
    $self->{logger}->info( "End " . $self->getSeriesConfig()->getContext() );
    return 0;
  }

  # tell the reporter where it can find the top level repository cache
  # to find any dependencies it may have
  $ENV{INSTALL_DIR} = $self->getReporterCache()->getLocation();

  # continue executing the reporter
  my $process = new Inca::Process( tmpDir => $self->getTmpDirectory() );
  if ( ! defined $process ) {
    $self->_generateErrorReport( 
      "Internal problem, unable to create temp files" 
    );
    my $success = $self->_sendReportToDepot();
    if ( ! $success ) {
      $self->{logger}->error( "  Unable to send report to available depots" );
    }
    $self->{logger}->info( "End " . $self->getSeriesConfig()->getContext() );
    return 0;
  }
  $process->setCheckPeriod( $self->getCheckPeriod() );
  if ( $self->getSeriesConfig()->hasLimits() ) {
    $process->setLimits( $self->getSeriesConfig()->getLimits() );
  }
  $process->setCommandLine( $cmdline );
  my $success;
  if ( $self->hasAgent() ) {
    my ($tfh, $tempfile) = Inca::IO->tempfile( "$TMPFILE_TEMPLATE.p" ); 
    if ( ! defined $tempfile ) {
      $self->_generateErrorReport( 
        "Unable to create temp file for storing proxy for reporter execution" 
      );
      my $success = $self->_sendReportToDepot();
      if ( ! $success ) {
        $self->{logger}->error( "  Unable to send report to available depots" );
      }
      $self->{logger}->info( "End " . $self->getSeriesConfig()->getContext() );
      return 0;
    }
    if ( $self->_fetchProxy( $tempfile ) ) {
      $cmdline =~ s/$PROXY_MACRO/$tempfile/g;
      $self->{logger}->debug( "cmdline with proxy file '$cmdline'" );
      $process->setCommandLine( $cmdline );
      $success = $process->run(); 
    } else {
      $self->_generateErrorReport( 
        "Unable to fetch proxy for reporter execution" 
      );
      my $success = $self->_sendReportToDepot();
      if ( ! $success ) {
        $self->{logger}->error( "  Unable to send report to available depots" );
      }
      $self->{logger}->info( "End " . $self->getSeriesConfig()->getContext() );
      return 0;
    }
    unlink $tempfile if -e $tempfile;
  } else {
    $success = $process->run(); 
  }
  if ( ! $success ) {
    if ( $process->hasExceededLimits() ) {
      $self->{usage} = $process->getUsage()->toString();
      $self->_generateErrorReport( 
        "Reporter exceeded usage limits --  " . $process->getExceededLimits()
      );
      $reporter_executed_n_recorded = 1;
    } else { # must have been error
      $self->_generateErrorReport( "Unable to execute reporter: error '$!'" );
    }
  } else {
    $reporter_executed_n_recorded = 1;
    $self->{stdout} = $process->getStdout();
    # strip off an leading junk to the report
    if ( defined $self->{stdout} ) {
      $self->{stdout} =~ s/^.*?(<!--.*?-->|<\?.*?\?>|<[A-Za-z:_].*?>)/$1/s;
    }
    $self->{stderr} = $process->getStderr();
    if ( ! defined $self->{stdout} || $self->{stdout} eq "" ) {
      if ( ! defined $self->{stderr} || $self->{stderr} eq "" ) {
        if ( $! ne 0 ) {
          $self->_generateErrorReport( "Exec of reporter failed: error '$!'");
        } else {
          $self->_generateErrorReport(
            "Error running reporter: no stdout, stderr, nor system error" 
          );
        }
      } else {
        $self->_generateErrorReport(
          "Error, no report produced to stdout.  " .
          "The following was printed to stderr: \n" .
          $self->{stderr} 
        );
      }
    } else {
      $self->{usage} = $process->getUsage()->toString();
    }
  }

  $success = $self->_sendReportToDepot();
  if ( ! $success ) {
    # if unsuccessful send, an error report will not be in stdout with the
    # reason so we try send this to the depot
    $success = $self->_sendReportToDepot();
  }

  if ( ! $success ) {
    $reporter_executed_n_recorded = 0;
    $self->{logger}->error( "  Unable to send report to available depots" );
  }

  $self->{logger}->info( "End " . $self->getSeriesConfig()->getContext() );
  return $reporter_executed_n_recorded;
}

#-----------------------------------------------------------------------------#

=head2 setAgent( $uri )

Set the uri of the Inca agent to contact in order to retrive a proxy 
credential to use for the reporter.

=over 2

B<Arguments>:

=over 13

=item uri

A string containing the uri of the Inca agent to contact to retrieve a 
proxy credential.

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;
  use Test::Exception;

  my $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                            agent => "cuzco.sdsc.edu:8233" );
  my $agent = $rim->getAgent();
  is( $agent, "cuzco.sdsc.edu:8233", 'Set agent works from constructor' );
  $rim->setAgent( "inca.sdsc.edu:8235" );
  $agent = $rim->getAgent();
  is( $agent, "inca.sdsc.edu:8235", 'Set depots works from function' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setAgent {
  my ( $self, $uri ) =
     validate_pos( @_, $SELF_PARAM_REQ, $URI_PARAM_REQ );
                       

  $self->{agent} = $uri;
}

#-----------------------------------------------------------------------------#

=head2 setCheckPeriod( $secs )

Set the period for how often to check the reporter for exceeding its limits.

=over 2

B<Arguments>:

=over 13

=item secs

A positive integer indicating the period in seconds of which to check for
resource limits.

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;

  my $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                                                           checkPeriod => 3 );
  is( $rim->getCheckPeriod(), 3, 'set check period from constructor' );
  $rim->setCheckPeriod( 10 );
  is( $rim->getCheckPeriod(), 10, 'set check period' );
  $rim = new Inca::ReporterManager::ReporterInstanceManager( );
  is( $rim->getCheckPeriod(), 5, 'default check period is 5' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setCheckPeriod {
  my ( $self, $secs ) =
     validate_pos( @_, $SELF_PARAM_REQ, $POSITIVE_INTEGER_PARAM_REQ );

  $self->{check_period} = $secs;
}

#-----------------------------------------------------------------------------#

=head2 setCredentials( \%credentials )

Specify the credentials to use.

=over 2

B<Arguments>:

=over 13

=item credentials

A reference to a hash array containing the credential information.

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;
  use Inca::ReporterManager::ReporterCache;
  use Test::Exception;

  my $credentials = { cert => 't/cert.pem', key => 't/key.pem',
                      passphrase => 'pwd', trusted => 't/trusted' };
  my $credentials_new = { cert => 't/new/cert.pem', key => 't/key.pem',
                      passphrase => undef, trusted => 't/trusted' };
  my $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                  credentials => $credentials );
  ok( eq_hash($rim->getCredentials(), $credentials), 
          'set credentials worked from constructor' );
  $rim->setCredentials( $credentials_new );
  ok( eq_hash($rim->getCredentials(), $credentials_new), 
          'set/get credentials worked' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setCredentials {
  my ( $self, $credentials ) =
     validate_pos( @_, $SELF_PARAM_REQ, HASHREF );

  $self->{credentials} = $credentials;
}

#-----------------------------------------------------------------------------#

=head2 setDepots( @depot_uris )

Specify the destination depots that are used to send the report on completion.
The report will be sent to the first depot in the list.  If the first depot is
unreachable, the next depots in the list will be tried.

=over 2

B<Arguments>:

=over 13

=item depot_uris

Any number of strings containing a uri to a depot [host:port, ...]

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;
  use Test::Exception;

  my $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                            depotURIs => ["cuzco.sdsc.edu:8234"] );
  my @depots = $rim->getDepots();
  is( $depots[0], "cuzco.sdsc.edu:8234", 'Set depots works from constructor' );
  $rim->setDepots( qw(inca.sdsc.edu:8235 inca.sdsc.edu:8236) );
  @depots = $rim->getDepots();
  is( $depots[0], "inca.sdsc.edu:8235", 'Set depots works from function (1)' );
  is( $depots[1], "inca.sdsc.edu:8236", 'Set depots works from function (2)' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setDepots {
  my ( $self, @depot_uris ) =
     validate_pos( @_, $SELF_PARAM_REQ, $URI_PARAM_REQ,
                       ($URI_PARAM_REQ) x (@_ - 2) );

  @{$self->{depots}} = @depot_uris;
}

#-----------------------------------------------------------------------------#

=head2 setId( $resourceId )

Set the resource identifier supplied by the reporter agent that the reporter
manager will use to identify itself to the depot.

=over 2

B<Arguments>:

=over 13

=item resourceId

A string indicating the id of the resource.

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;

  my $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                                                           id => "resourceA" );
  is( $rim->getId(), "resourceA", 'set id from constructor' );
  $rim->setId( "resourceB" );
  is( $rim->getId(), "resourceB", 'set id' );
  $rim = new Inca::ReporterManager::ReporterInstanceManager( );
  is( $rim->getId(), undef, 'default id is undef' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setId {
  my ( $self, $id ) = validate_pos( @_, $SELF_PARAM_REQ, SCALAR );

  $self->{id} = $id;
}

#-----------------------------------------------------------------------------#

=head2 setReporterCache( $reporter_cache )

Specify the reporter administrator to use in order to find a path to a local
copy of a reporter (from its URI).

=over 2

B<Arguments>:

=over 13

=item reporter_cache

An object of type Inca::ReporterManager::ReporterCache which is used to map
reporter uris to a local path.

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;
  use Inca::ReporterManager::ReporterCache;
  use Test::Exception;
  use Cwd;

  my $rc = new Inca::ReporterManager::ReporterCache( "t" );
  my $rc_new = new Inca::ReporterManager::ReporterCache( "/tmp" );
  my $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                  reporterCache => $rc );
  is( $rim->getReporterCache->getLocation(), getcwd() . "/t",
          'set reporter admin worked from constructor' );
  $rim->setReporterCache( $rc_new );
  is( $rim->getReporterCache->getLocation(), "/tmp",
          'set reporter admin worked from set/get functions' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setReporterCache {
  my ( $self, $reporter_cache) =
     validate_pos( @_, $SELF_PARAM_REQ, $REPORTER_CACHE_PARAM_REQ );

  $self->{reporter_cache} = $reporter_cache;
}

#-----------------------------------------------------------------------------#

=head2 setSeriesConfig( $config )

Set the series config to be executed.

=over 2

B<Arguments>:

=over 13

=item config

An object of type Inca::Suite::SeriesConfig which contains information
about the reporter to execute.

=back

=back

=begin testing

  use Inca::Suite::SeriesConfig;
  use Inca::ReporterManager::ReporterInstanceManager;
  use Test::Exception;

  my $config1 = new Inca::Suite::SeriesConfig( path => "path1" );
  my $config2 = new Inca::Suite::SeriesConfig( path => "path2" );
  my $rim = new Inca::ReporterManager::ReporterInstanceManager( 
    config => $config1
  );
  is ( $rim->getSeriesConfig()->getPath(), 'path1', 
       'set config worked from constructor' );
  $rim->setSeriesConfig( $config2 );
  is ( $rim->getSeriesConfig()->getPath(), 'path2', 'set/get config worked' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setSeriesConfig {
  my ( $self, $config ) = 
    validate_pos( @_, $SELF_PARAM_REQ, $SERIESCONFIG_PARAM_REQ );

  $self->{config} = $config;
}

#-----------------------------------------------------------------------------#

=head2 setTmpDirectory( $path )

Specify a temporary file space that Inca can use while executing reporters.

=over 2

B<Arguments>:

=over 13

=item path

A string containing a path to a temporary file space 

=back

=back

=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;
  use Test::Exception;

  my $rim = new Inca::ReporterManager::ReporterInstanceManager(); 
  is( $rim->getTmpDirectory(), "/tmp", 'default tmp set' );
  $rim->setTmpDirectory( "/scratch" );
  is( $rim->getTmpDirectory(), "/scratch", 'set/getTmpDirectory work' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub setTmpDirectory {
  my ( $self, $path ) = validate_pos( @_, $SELF_PARAM_REQ, SCALAR );

  $self->{tmpdir} = $path;
}

#-----------------------------------------------------------------------------#
# Private methods (not documented with pod markers and prefixed with '_' )
#-----------------------------------------------------------------------------#

#-----------------------------------------------------------------------------#
# _createCmdLine( )
#
# Create the command-line string for executing the reporter.  If execution
# priority is set, then the process is run with nice.
#
# Returns: 
#
# A string containing the command to run the reporter with its arguments
# or undefined if there is an error locating the reporter in the local cache.
#
=begin testing

  use Inca::ReporterManager::ReporterInstanceManager;
  use Inca::ReporterManager::ReporterCache;
  use Inca::Suite::SeriesConfig;
  use Test::Exception;
  use Cwd;

  my $rc = new Inca::ReporterManager::ReporterCache( "t" );
  my $sc = new Inca::Suite::SeriesConfig();
  $sc->setName( "echo_report" );
  $sc->setPath( "t/echo_report" );
  my $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                  config => $sc,
                  reporterCache => $rc );
  is( $rim->_createCmdLine(), undef,
      '_createCmdLine returns undef when context not specified' );
  $sc->setContext( $sc->getName() );
  $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                  config => $sc,
                  reporterCache => $rc );
  is( $rim->_createCmdLine(), "t/echo_report",
          '_createCmdLine works for simple case' );
  $sc->setNiced( 1 );
  $rim = new Inca::ReporterManager::ReporterInstanceManager( 
                  config => $sc,
                  reporterCache => $rc );
  is( $rim->_createCmdLine(), "nice t/echo_report",
          '_createCmdLine works for simple case with nice' );
  
  # try set context
  $sc->setNiced( 0 );
  $sc->setContext( 
    'PATH=bin:${PATH}; ' . $sc->getName() . '; rm -f /tmp/blah' 
  );
  is( $rim->_createCmdLine(), 
      'PATH=bin:${PATH}; nice t/echo_report; rm -f /tmp/blah',
       '_createCmdLine works for context' );
  
  $sc->setContext( 
    'PATH=bin:${PATH}; ' . $sc->getName() . ' -name1="value1" -name1="value2"; rm -f /tmp/blah' 
  );
  is( $rim->_createCmdLine(), 
      'PATH=bin:${PATH}; nice t/echo_report -name1="value1" -name1="value2"; rm -f /tmp/blah',
      '_createCmdLine works for with args' );

  # special chars in reporter name
  $sc->setName( "grid.security++.unit" );
  $sc->setContext( 
    'PATH=bin:${PATH}; ' . $sc->getName() . ' -name1="value1" -name1="value2"; rm -f /tmp/blah' 
  );
  is( $rim->_createCmdLine(), 
      'PATH=bin:${PATH}; nice t/echo_report -name1="value1" -name1="value2"; rm -f /tmp/blah',
      '_createCmdLine works for special chars in reporter name' );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _createCmdLine {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  # construct cmd line
  my $path = $self->getSeriesConfig()->getPath(); 
  if ( $self->getSeriesConfig()->hasContext() ) {
    if ( $self->getSeriesConfig()->hasNiced() ) {
      $path = "nice " . $path;
    }
    my $context = $self->getSeriesConfig()->getContext();
    my $name = $self->getSeriesConfig()->getName();
    $context =~ s/\Q$name\E/$path/;
    return $context; 
  } else {
    $self->{logger}->error( 
      "Reporter spec missing context field for " . 
      $self->getSeriesConfig()->getPath() 
    );
    return undef;
  }
}

#-----------------------------------------------------------------------------#
# _createTestRM()
#
# Create a sample Inca::ReporterManager::ReporterInstanceManager object.
#
# Note: for testing purposes only.
#-----------------------------------------------------------------------------#
sub _createTestRM {
  my $credentials = { 
    cert => "t/certs/client_ca1cert.pem",
    key => "t/certs/client_ca1keynoenc.pem", 
    passphrase => undef,
    trusted => "t/certs/trusted" 
  };
  my $rc = new Inca::ReporterManager::ReporterCache( "t",
    errorReporterPath => "bin/inca-null-reporter" 
  );
  my $rim = new Inca::ReporterManager::ReporterInstanceManager();
  $rim->setId( "resourceA" );
  $rim->setCredentials( $credentials );
  $rim->setCheckPeriod(1);
  $rim->setReporterCache( $rc );
  return $rim;
}

#-----------------------------------------------------------------------------#
# _fetchProxy( $tempfile )
#
# Fetch a proxy to the specified temporary file and set the X509_USER_PROXY
# environment variable.
#
# Arguments:
#
#  tempfile  A string indicating the path to store the proxy file
#-----------------------------------------------------------------------------#
sub _fetchProxy {
  my ( $self, $tempfile ) = validate_pos( @_, $SELF_PARAM_REQ, SCALAR );

  my $proxy = new Inca::GridProxy();
  my %credentials;
  # grab credentials if they're there (and needed)
  %credentials = %{ $self->getCredentials() } if $self->hasCredentials();
  my $params = $proxy->requestProxyInformation(
    $self->getId(),
    $self->getAgent(),
    %credentials
  );
  if ( ! defined $params ) {
    $self->{logger}->error("Unable to retrieve proxy renewal information from agent");
    return 0;
  }
  if( ! $proxy->getProxy( $params, $tempfile ) && ! -f $tempfile ) {
    $self->{logger}->error( "Unable to retrieve proxy from myproxy server" );
    return 0;
  }
  $self->{logger}->debug( "Proxy written to $tempfile" );
  $ENV{X509_USER_PROXY} = $tempfile;
  # explicitly clear from memory
  for my $param ( qw(dn hostname lifetime password port username) ) {
    $params->{$param} = undef;
  }
  return 1;
}

#-----------------------------------------------------------------------------#
# _generateErrorReport( $error_msg )
#
# Called after a reporter error has been detected.  Will generate a
# a special error report that can be sent to the depot.
#
# Arguments:
#
#  error_msg  A string indicating the reason for the reporter error.
#

=begin testing

  untie *STDOUT;
  untie *STDERR;
  use Inca::ReporterManager::ReporterInstanceManager;
  use Inca::ReporterManager::Scheduler;
  use Inca::Suite::SeriesConfig;
  use File::Spec;
  use Cwd;

  my $sc = Inca::ReporterManager::Scheduler->_createTestConfig( "echo_report" );
  $sc->setLimits( { "wallClockTime" => 10,
                    "cpuTime" => 10,
                    "memory" => 20 } );
  my $rim = new Inca::ReporterManager::ReporterInstanceManager->_createTestRM();
  $rim->setDepots( "file://" . File::Spec->catfile(getcwd(), "depot.tmp.$$") );
  $rim->setSeriesConfig( $sc );
  my $success = $rim->_generateErrorReport( "An Error Message" );
  like( $rim->{stdout}, qr/^<rep:report/m, "_generateErrorReport - report found");
  like( $rim->{stdout}, qr/<errorMessage>An Error Message/m, 
        "_generateErrorReport - error found" );

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _generateErrorReport {
  my ( $self, $error_msg ) = validate_pos( @_, $SELF_PARAM_REQ, SCALAR );

  # get temp file options
  my ($tfh, $tempfile) = Inca::IO->tempfile(
    "$TMPFILE_TEMPLATE.out", $self->getTmpDirectory() 
  ); 
  if ( ! defined $tfh ) {
    $self->{logger}->error( 
      "Unable to create temp file for creating error report"
    );
    return;
  }
  print $tfh $error_msg;

  my $cmdline = $self->getReporterCache()->getErrorReporterPath();
  $cmdline .= " --error_message_stdin=1";
  $cmdline .= " --name=" . $self->getSeriesConfig()->getName();
  $cmdline .= " --version=" . $self->getSeriesConfig()->getVersion();
  $cmdline .= " --workingDir=" . getcwd();
  $cmdline .= " --reporterPath=" . $self->getSeriesConfig()->getPath();
  $cmdline .= " --completed=false";
  if ( $self->getSeriesConfig()->hasArguments() ) {
    $cmdline .= " -- " . $self->getSeriesConfig()->getArgumentsAsCmdLine();
  }
  $cmdline .= " < $tempfile";
  my $report = `$cmdline`;
  close $tfh;
  unlink $tempfile;
  if ( $report eq "" ) {
    $self->{logger}->error( "  Unable to generate error report for " . 
                            $self->getSeriesConfig()->getName() . ": $!" );
  }
  $self->{logger}->info( "  Generating error report for " . 
                         $self->getSeriesConfig()->getName() . ": $error_msg ");
  $self->{stdout} = $report;
  $self->{stderr} = "";
  if ( ! exists $self->{usage} ) {
    my $zero_usage = new Inca::Process::Usage();
    $zero_usage->zeroValues();
    $self->{usage} = $zero_usage->toString();
  }
}

#-----------------------------------------------------------------------------#
# _sendReportToDepot( $process )
#
# Called from runReporter after the reporter has finished running to handle
# sending data to the depot.  We send the report to the first accessible
# depot in our list. 
#
# Arguments:
#
#  process    An object of type Inca::Process that has just finished 
#             executing a reporter
#
# Returns: 
#
# Returns 1 if the report was sent to a depot; otherwise return 0. 

=begin testing

  untie *STDOUT;
  tie *STDERR, 'Catch', '_STDERR_' or die $!;

  use Inca::IO;
  use Inca::ReporterManager::ReporterCache;
  use Inca::ReporterManager::ReporterInstanceManager;
  use Inca::ReporterManager::Scheduler;
  use Inca::Net::Protocol::Statement;
  use Inca::Net::MockAgent;
  use Inca::Suite::SeriesConfig;

  use Inca::Logger;

  Inca::Logger->screen_init( "ERROR" );

  my $PORT = 6329;

  sub runRIM {
    sleep( 2 );
    my $sc = Inca::ReporterManager::Scheduler->_createTestConfig("echo_report");
    my $credentials = { cert => "t/certs/client_ca1cert.pem",
                        key => "t/certs/client_ca1keynoenc.pem", 
                        passphrase => undef,
                        trusted => "t/certs/trusted" };
    my $rc = new Inca::ReporterManager::ReporterCache( "t",
      errorReporterPath => "bin/inca-null-reporter" 
    );
    my $rim = Inca::ReporterManager::ReporterInstanceManager->_createTestRM();
    $rim->setDepots( "incas://localhost:$PORT" );
    $rim->setSeriesConfig( $sc );
    return $rim->runReporter();
  }

  sub acceptReport {
    my $response = shift;

    my $depot = new Inca::Net::MockAgent( $PORT, "ca1", "t/certs/trusted" );
    my $responseCmd = [ undef ];
    $responseCmd =  [ "$response" ] if defined $response;
    my ($conn, $numStmts, @responses ) = $depot->accept(
      "REPORT" => [],
      "STDOUT" => [],
      "SYSUSAGE" => $responseCmd
    );
    $conn->close();
  }

  my $pid;
  $Inca::ReporterManager::ReporterInstanceManager::DEPOT_SEND_TIMEOUT = 10;
  if ( $pid = fork() ) {
    my $success = runRIM();
    is( $success, 1, "report accepted" );

    $success = runRIM( );
    is( $success, 1, "error report accepted" );
    like( $_STDERR_, qr/This is an error/, "error logged when report rejected");
    like( $_STDERR_, qr/Error writing to depot/, 
          "message logged when report not sent to the depot" );

    $_STDERR_ = "";
    $success = runRIM( );
    is( $success, 1, "error report accepted" );
    like( $_STDERR_, qr/Uknown response/, "error logged when report rejected" );

    $_STDERR_ = "";
    $success = runRIM( );
    is( $success, 0, "error report rejected" );
    like( $_STDERR_, qr/Unable to send report to available depots/, 
          "message logged when report not sent to the depot" );
  } else {
    acceptReport();
    acceptReport( "ERROR This is an error message from the depot" );
    acceptReport();
    acceptReport( "STARS shine at night" );
    acceptReport();
    acceptReport( "ERROR This is an error message from the depot" );
    acceptReport( "ERROR This is an error message from the depot" );
    exit;
  }

=end testing

=cut
#-----------------------------------------------------------------------------#
sub _sendReportToDepot {
  my ( $self ) = validate_pos( @_, $SELF_PARAM_REQ );

  my $success = 0;
  my %credentials;

  # grab credentials if they're there (and needed)
  %credentials = %{ $self->getCredentials() } if $self->hasCredentials();

  # search for depot
  my $timeout = $DEPOT_SEND_TIMEOUT;
  for my $uri ( $self->getDepots() ) {
    eval {
      local $SIG{ALRM} = sub { die "time exceeded" };
      alarm( $timeout ); 
      $self->{logger}->debug( "  Attempting to connect to depot $uri" );
      my $client = new Inca::Net::Client( $uri, %credentials ); 
      if ( defined $client ) {
        $self->{logger}->info( "  Sending report to $uri" );
        $success = $self->_sendReportToStream( $client );
        $client->close();
        alarm(0);
      } else {
        alarm(0);
        $self->{logger}->error( "Unable to connect to depot '$uri'" );
      }
    };
    if ( $@ ) {
      $self->{logger}->error("Send to depot '$uri' exceeded $timeout secs");
    }
    last if $success; 
  }

  return $success;
}

#-----------------------------------------------------------------------------#
# _sendReportToStream( $process, $client )
#
# Called from runReporter after the reporter has finished running to handle
# sending data to the depot.  This method is called from _sendReportToDepot
# (i.e., we have an open connection to a depot already and now just need
# to send data).
#
# Arguments:
#
#  process    An object of type Inca::Process that has just finished 
#             executing a reporter
#
#  client     An object of type Inca::Net::Client which is the open connection
#             we can write the report to.
#
# Returns: 
#
# Returns 1 if the report was sent to a depot; otherwise return 0. 
#-----------------------------------------------------------------------------#
sub _sendReportToStream {
  my ( $self, $client ) = validate_pos(@_, $SELF_PARAM_REQ, $CLIENT_PARAM_REQ);

  # send that a report is coming
  $client->writeStatement( 
    "REPORT", 
    $self->getId() . " " . $self->getSeriesConfig()->getContext()
  );

  # send stderr from reporter if it exists
  if ( defined $self->{stderr} && $self->{stderr} ne "" ) {
    $self->{stderr} =~ s/$CRLF/\n/g;
    $client->writeStatement( "STDERR", $self->{stderr} );
  }

  # send stdout from reporter
  $self->{stdout} =~ s/$CRLF/\n/g;
  $client->writeStatement( "STDOUT", $self->{stdout} );

  # send reporter usage information
  $client->writeStatement( "SYSUSAGE", $self->{usage} );

  # depot will either close socket when it accepts a report or send an
  # error response on error
  my $stream = $client->{stream};
  my $depot_response = <$stream>;
  if ( ! defined $depot_response or $depot_response eq "" or
       $depot_response =~ /^OK/ ) {
    return 1;
  } else {
    my $depot_stmt = new Inca::Net::Protocol::Statement();
    $depot_stmt->setStatement( $depot_response );
    if ( $depot_stmt->getCmd() eq "ERROR" ) {
      $self->_generateErrorReport( 
        "Internal Inca error: report rejected by Inca depot '" .  
        $depot_stmt->getData() . "'"
      );
      $self->{logger}->error( 
        "  Error writing to depot: " .  $depot_stmt->getData()
      );
    } else {
      $self->_generateErrorReport( 
        "Internal Inca error: unexpected response from Inca depot during " .
        "send of report '" .  $depot_stmt->getStatement() . "'"
      );
      $self->{logger}->error( 
        "  Uknown response from the depot: " .  $depot_stmt->getStatement()
      );
    }
    close $stream;
    return 0;
  }
}

1; # need to return a true value from the file

__END__


=head1 AUTHOR

Shava Smallen <ssmallen@sdsc.edu>

=head1 CAVEATS/WARNINGS

None so far.

=cut
