package edu.sdsc.inca.agent.access;

import org.globus.io.gass.server.JobOutputListener;

/**
 * A subclass of JobOutputListener that can be used store output being sent to
 * a GASS server. The output is stored in a string therefore, this class should
 * not be used for any large output.
 *
 * @hidden
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GlobusOutputListener implements JobOutputListener {
  private String buffer = "";

  /**
   * Called whenever the GASS server receives input for the stream this
   * listener was registered for.  We add the output to our internal string
   * buffer.
   *
   * @param output
   */
  public void outputChanged( String output ) {
    buffer += output;
  }

  /**
   * Called whenever the stream for the GASS server is closed.  We do nothing
   * since were using a string to store the output (and it doesn't need to be
   * closed).
   */
  public void outputClosed( ) {

  }

  /**
   * Return the output that has been collected on this GASS stream.
   *
   * @return The output received by the GASS server for the registered stream.
   */
  public String getOutput() {
    return buffer;
  }
}
