package edu.sdsc.inca.agent;

import junit.framework.TestCase;

import java.util.Hashtable;
import java.util.regex.Pattern;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.FileInputStream;
import java.security.Security;
import java.security.PrivateKey;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetSocketAddress;

import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.protocol.Statement;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.Client;
import edu.sdsc.inca.Server;
import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.AgentTest;
import edu.sdsc.inca.Agent;
import edu.sdsc.inca.util.ConfigProperties;
import edu.sdsc.inca.util.ResourcesWrapper;
import edu.sdsc.inca.util.ResourcesWrapperTest;
import edu.sdsc.inca.util.SuiteWrapper;
import edu.sdsc.inca.util.SuiteStagesWrapper;
import edu.sdsc.inca.repository.Repositories;
import edu.sdsc.inca.repository.RepositoriesTest;
import edu.sdsc.inca.dataModel.resourceConfig.ResourceConfigDocument;
import edu.sdsc.inca.dataModel.suite.SuiteDocument;
import edu.sdsc.inca.dataModel.catalog.PackageType;
import edu.sdsc.inca.dataModel.util.SeriesConfig;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMReader;
import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;
import org.globus.myproxy.MyProxy;
import org.globus.myproxy.MyProxyException;
import org.globus.gsi.gssapi.auth.IdentityAuthorization;
import org.gridforum.jgss.ExtendedGSSManager;
import org.ietf.jgss.GSSCredential;
import org.ietf.jgss.GSSException;

import javax.net.ServerSocketFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.SSLServerSocket;

/**
 * Tests for ReporterManagerController (and ReporterManagerStarter).
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class ReporterManagerControllerTest extends TestCase {
  private ConfigProperties config = null;
  private String resource = null;
  private static Logger logger = Logger.getLogger(ReporterManagerControllerTest.class);
  ReporterManagerController rmc = null;
  MockAgent mockAgent = null;

  static {
    Security.addProvider(new BouncyCastleProvider());
  }

  /**
   * Emulates the agent's tasks
   */
  static public class MockAgent extends Thread {
    public ProtocolWriter writer = null;
    public ProtocolReader reader = null;
    public int port = 8934;
    public int numConnections = 1;
    public int numConnectionsReceived = 0;
    private ServerSocket serverSocket = null;
    private Socket server = null;
    private boolean auth = false;
    private ReporterManagerController rmc = null;

    public MockAgent( boolean auth, ReporterManagerController rmc )
      throws Exception {

      this.auth = auth;
      this.rmc = rmc;
    }

    /**
     * Allows this mock agent to be run as a thread
     */
    public void run() {
      try {
        if ( auth ) {
          logger.info("Mock Agent with auth");
          serverSocket = createSSLSocket( port );
        } else {
          logger.info("Mock Agent without auth");
          ServerSocketFactory factory =  ServerSocketFactory.getDefault();
          serverSocket = factory.createServerSocket( port );
        }
        for ( int i = 0; i < numConnections; i++ ) {
          String resourceName = mockAgentRegister();
          numConnectionsReceived++;
          if ( rmc == null ) {
            Agent.getGlobalAgent().registerReporterManager(
              resourceName, reader, writer
            );
          } else {
            rmc.register( reader, writer );
          }
        }
        cleanup();
      } catch ( Exception e ) {
        e.printStackTrace();
      }
    }

    /**
     * Mimics the agent's register task
     *
     * @return  The name of the resource that registered.
     *
     * @throws Exception
     */
    public String mockAgentRegister() throws Exception {
      logger.info( "Waiting for connection");
      server = serverSocket.accept();
      logger.info( "Accepted connection");
      reader = new ProtocolReader(
        new InputStreamReader(server.getInputStream())
      );
      writer = new ProtocolWriter(
        new OutputStreamWriter(server.getOutputStream())
      );

      Statement stmt = reader.readStatement();
      String response = new String( stmt.getCmd() );
      if ( response.equals("START") ) {
        logger.info( "Mock agent received start" );
        writer.write( Statement.getOkStatement(Statement.getVersion()) );
        stmt = reader.readStatement();
      }

      response = new String( stmt.getCmd() );
      char[] pingdata = stmt.getData();

      assertTrue(
        "Received reporter manager ping",
        response.equals("PING")
      );

      writer.write(
        new Statement(
          "OK".toCharArray(),
          pingdata
        )
      );
      logger.info( "Mock agent received ping" );

      Statement register = reader.readStatement();
      response = new String( register.getCmd() );
      assertTrue(
        "Received reporter manager registration",
        response.equals("REGISTER")
      );
      String resource = new String( register.getData() );

      writer.write(
        new Statement( Protocol.SUCCESS_COMMAND.toCharArray())
      );
      logger.info( "Mock agent received register" );
      return resource;
    }

    /**
     * Ensure's correct cleanup. Shutdown the reporter manager and close the
     * streams and sockets.
     *
     * @throws java.io.IOException
     */
    public void cleanup() throws IOException {
      logger.info( "Running MockAgent finalize");
      if ( reader != null ) {
        reader.close();
      }
      if ( writer != null ) {
        writer.close();
      }
      if ( server != null ) {
        server.close();
      }
      if ( serverSocket != null ) {
        serverSocket.close();
      }
    }
  }

  /**
   * Create a SSL server socket
   *
   * @param port  The port to open the socket on.
   *
   * @return A configured SSL ServerSocket.
   *
   * @throws Exception
   */
  static public ServerSocket createSSLSocket( int port ) throws Exception {

    ServerSocket ssocket = new ServerSocket();
    // get the test agent private agentKeypair
    PEMReader pemReader = new PEMReader(
      new InputStreamReader(new FileInputStream("etc/agentkey.pem"))
    );
    PrivateKey key = ((KeyPair)(pemReader.readObject())).getPrivate();
    // get the test agent certificate
    CertificateFactory cf = CertificateFactory.getInstance("X.509");
    X509Certificate cert = (X509Certificate)cf.generateCertificate(
              new FileInputStream("etc/agentcert.pem")
            );

    // Init the keystore w/the server cert and the trusted certificates,
    // making sure we also trust our own certificate.
    KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
    ks.load(null, null);
    ks.setKeyEntry
      ("serverkey", key,
       "".toCharArray(), new Certificate[]{cert});
    ks.setCertificateEntry
      ("trusted0", cert);

    // Use an SSLContext inited from the keystore to open a server socket.
    SSLContext context = SSLContext.getInstance("SSL");
    KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
    TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
    kmf.init(ks, "".toCharArray());
    tmf.init(ks);
    context.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
    ssocket = context.getServerSocketFactory().createServerSocket();
    ((SSLServerSocket) ssocket).setNeedClientAuth(true);
    // Allow for immediate server restart w/out a wait for port release.
    ssocket.setReuseAddress(true);
    // After this call the port is actually in business.
    ssocket.bind(new InetSocketAddress(port));

    return ssocket;
  }

  /**
   * Recursively delete a directory
   *
   * Cut-n-paste from http://www.rgagnon.com/javadetails/java-0483.html
   *
   * @param path  The path to the directory to delete.
   *
   * @return True if delete successful and false otherwise.
   */
  public static boolean deleteDirectory(File path) {
    if( path.exists() ) {
      File[] files = path.listFiles();
      for(int i=0; i<files.length; i++) {
        if(files[i].isDirectory()) {
          deleteDirectory(files[i]);
        }
        else {
          files[i].delete();
        }
      }
    }
    return( path.delete() );
  }

  /**
   * Create a sample suite document and create the reporter uris
   * relative to the specified repository path.
   *
   * @return  A suite document.
   *
   * @throws XmlException
   */
  public static SuiteWrapper createSampleSuite()
    throws XmlException {

    String suiteDoc =
      "<st:suite xmlns:st = \"http://inca.sdsc.edu/dataModel/suite_2.0\" xmlns:xsi = \"http://www.w3.org/2001/XMLSchema-instance\" >\n" +
      "  <seriesConfigs>\n" +
      "  <seriesConfig>\n" +
      "    <series>\n" +
      "      <name>cluster.compiler.gcc.version</name>\n" +
      "      <version>1.5</version>\n" +
      "      <args>\n" +
      "        <arg>\n" +
      "          <name>verbose</name>\n" +
      "          <value>1</value>\n" +
      "        </arg>\n" +
      "        <arg>\n" +
      "          <name>help</name>\n" +
      "          <value>no</value>\n" +
      "        </arg>\n" +
      "      </args>\n" +
      "      <limits>\n" +
      "        <wallClockTime>300</wallClockTime>\n" +
      "      </limits>\n" +
      "      <context>cluster.compiler.gcc.version -verbose=\"1\" -help=\"no\"</context>\n" +
      "    </series>\n" +
      "    <nickname>cluster.compiler.gcc.version</nickname>\n" +
      "    <resourceSetName>localhost</resourceSetName>\n" +
      "    <schedule>\n" +
      "      <cron>\n" +
      "        <min>0-59/1</min>\n" +
      "        <hour>*</hour>\n" +
      "        <mday>*</mday>\n" +
      "        <wday>*</wday>\n" +
      "        <month>*</month>\n" +
      "      </cron>\n" +
      "    </schedule>\n" +
      "    <action>add</action>\n" +
      "  </seriesConfig>\n" +
      "  <seriesConfig>\n" +
       "    <series>\n" +
      "      <name>cluster.security.openssl.version</name>\n" +
      "      <version>1.3</version>\n" +
      "      <args>\n" +
      "        <arg>\n" +
      "          <name>verbose</name>\n" +
      "          <value>1</value>\n" +
      "        </arg>\n" +
      "        <arg>\n" +
      "          <name>help</name>\n" +
      "          <value>no</value>\n" +
      "        </arg>\n" +
      "      </args>\n" +
      "      <limits>\n" +
      "        <wallClockTime>300</wallClockTime>\n" +
      "      </limits>\n" +
      "      <context>cluster.security.openssl.version -verbose=\"1\" -help=\"no\"</context>\n" +
      "    </series>\n" +
      "    <nickname>cluster.security.openssl.version</nickname>\n" +
      "    <resourceSetName>localhost</resourceSetName>\n" +
      "    <schedule/>\n" +
      "    <action>add</action>\n" +
      "  </seriesConfig>\n" +
      "  <seriesConfig>\n" +
      "    <series>\n" +
      "      <name>user.search.output.unit</name>\n" +
      "      <version>1.1</version>\n" +
      "      <args>\n" +
      "             <arg>\n" +
      "                <name>version</name>\n" +
      "                <value>no</value>\n" +
      "              </arg>\n" +
      "              <arg>\n" +
      "                <name>verbose</name>\n" +
      "                <value>1</value>\n" +
      "              </arg>\n" +
      "              <arg>\n" +
      "                <name>com</name>\n" +
      "                <value>ls var/reporter-packages/include</value>\n" +
      "              </arg>\n" +
      "              <arg>\n" +
      "                <name>help</name>\n" +
      "                <value>no</value>\n" +
      "              </arg>\n" +
      "              <arg>\n" +
      "                <name>search</name>\n" +
      "                <value>somefile</value>\n" +
      "              </arg>\n" +
      "              <arg>\n" +
      "                <name>log</name>\n" +
      "                <value>3</value>\n" +
      "              </arg>\n" +
      "              <arg>\n" +
      "                <name>delim</name>\n" +
      "                <value>\\|</value>\n" +
      "              </arg>\n" +
      "      </args>\n" +
      "      <limits>\n" +
      "        <wallClockTime>300</wallClockTime>\n" +
      "      </limits>\n" +
      "      <context>user.search.output.unit -version=\"no\" -verbose=\"1\" -com=\"ls var/reporter-packages/include\" -help=\"no\" -search=\"somefile\" -log=\"3\" -delim=\"\\|\"</context>\n" +
      "    </series>\n" +
      "    <nickname>user.search.output.unit</nickname>\n" +
      "    <resourceSetName>localhost</resourceSetName>\n" +
      "    <schedule/>\n" +
      "    <action>add</action>\n" +
      "  </seriesConfig>\n" +
      "  </seriesConfigs>\n" +
      "  <guid>inca://localhost:6323/TestSuiteLocal</guid>\n" +
      "</st:suite>";
    return new SuiteWrapper( SuiteDocument.Factory.parse(suiteDoc) );
  }

  /**
   * Create a reporter manager object using the specified uri as the contact
   * to the agent.
   *
   * @param secure      Whether the mock agent server should be secure or not
   * @param repository  Whether or not we need to setup a temporary repository
   * @param resources   The resources the agent should be configured with
   * @param resource    The name of the resource in resources we should use to
   *                    start the reporter manager on.
   *
   * @return a new reporter mananger controller object
   *
   * @throws Exception
   */
  public ReporterManagerController createRM(
    boolean secure, boolean repository,
    ResourcesWrapper resources, String resource )
    throws Exception {

    if ( resource == null ) resource = this.resource;
    Agent agent = new Agent();
    agent.setConfiguration( config );
    if ( secure ) {
      agent.readCredentials();
      agent.setAuthenticate( true );
    } else {
      agent.setAuthenticate( false );
    }
    agent.setPassword( "topSecret!" );
    agent.setDepots( new String[]{"inca://localhost:8935"} );
    agent.setPort( 8934 );
    if ( resources == null ) {
      resources = ResourcesWrapperTest.createSampleResources();
    }
    agent.setResources( resources );
    agent.setStartAttemptWaitPeriod( 45000 );
    ReporterManagerController rm = new ReporterManagerController(
      resource, agent
    );
    if ( repository ) {
      File resourcePackages = new File( "var/rm/localhost/packages" );
      resourcePackages.deleteOnExit();
      Repositories repositories = RepositoriesTest.createSampleRepository(null);
      RepositoryCache cache = RepositoryCacheTest.createSampleRepositoryCache(
        repositories
      );
      agent.setRepositories( repositories.getRepositories() );
      agent.setRepositoryCache( cache );
    }

    return rm;
  }

  /**
   * Test the reporter manager's create and sendSuite functions.
   *
   * @param auth  whether to test with credentials or not
   *
   * @throws Exception
   */
  public void runCreateAndSubscribe( boolean auth )
    throws Exception {

    startAndRegisterRMC( auth, true, null, 1, null );

    SuiteWrapper suite = createSampleSuite();

    AgentTest.MockDepot depot = new AgentTest.MockDepot( 8935, 3 );
    depot.start();

    try {
      PackageType[] reps = rmc.extractReportersFromSuite(
        suite.getSuiteDocument()
      );
      assertEquals( "3 reporters extracted", 3, reps.length );
      rmc.sendSuite( suite.getSuiteDocument() );
    } catch( Exception e ) {
      logger.error( "Sending suite failed: ", e );
      fail( "Sending suite failed: " + e );
    }

    depot.join();
    boolean gccFound = false, opensslFound = false, searchFound = false;
    for ( int i = 0; i < depot.reports.length; i++ ) {
      if ( Pattern.compile( "gcc").matcher( depot.reports[i] ).find() ) {
        gccFound = true;
      }
      if ( Pattern.compile( "openssl").matcher( depot.reports[i] ).find() ) {
        opensslFound = true;
      }
      if ( Pattern.compile("search").matcher(depot.reports[i] ).find() &&
           Pattern.compile("<completed>true").matcher(depot.reports[i] ).find()) {
        searchFound = true;
      }
    }
    assertTrue( "gcc reporter found ", gccFound );
    assertTrue( "openssl reporter found ", opensslFound );
    assertTrue( "search reporter found ", searchFound );

  }

  /**
    * Read properties, initialize member variables, and delete var directory
    *
    * @throws Exception
    */
   public void setUp() throws Exception {
     config = new ConfigProperties();
     config.putAllTrimmed(System.getProperties(), "inca.agent.");
     config.loadFromResource("inca.properties", "inca.agent.");
     resource = AgentTest.TEST_RESOURCE;

     deleteDirectory( new File("var") );
   }

  /**
   * Start up a remote reporter manager and a mock agent.  Return when the
   * remote reporter manager has checked in and registered.
   *
   * @param secure      Whether the mock agent server should be secure or not
   * @param repository  Whether or not we need to setup a temporary repository
   * @param resources   The resources the agent should be configured with
   * @param numConnections The number of connections the mock agent should
   *                       expect before exitting.
   * @param resource
   * @throws Exception
   */
  public void startAndRegisterRMC(
    boolean secure, boolean repository, ResourcesWrapper resources,
    int numConnections, String resource )
    throws Exception {

    if ( resource == null ) resource = this.resource;    
    rmc = createRM( secure, repository, resources, resource );
    Agent.getGlobalAgent().getReporterManagerTable().put( resource, rmc );
    if ( secure ) {
      mockAgent = new MockAgent( true, rmc );
    } else {
      mockAgent = new MockAgent( false, rmc );
    }
    if ( mockAgent == null ) throw new IOException( "Unable to start server" );
    mockAgent.numConnections = numConnections;
    rmc.getReporterManagerStarter().start();
    mockAgent.start();
    rmc.getReporterManagerStarter().waitForReporterManager();
  }

  /**
   * Using the MyProxy server configuration in the resources file, store
   * a proxy in the MyProxy server.
   *
   * @param resources   A resources configuration containing a resource with
   * MyProxy server configuration information.
   *
   * @return  The proxy configuration on the MyProxy server.
   *
   * @throws ConfigurationException
   * @throws GSSException
   * @throws MyProxyException
   */
  public static Hashtable storeProxy( ResourcesWrapper resources )
    throws ConfigurationException, GSSException, MyProxyException {

    Hashtable myproxyInfo = new Hashtable();
    String[] myproxyVars = new String[] {
      Protocol.MYPROXY_HOST_MACRO,
      Protocol.MYPROXY_PORT_MACRO,
      Protocol.MYPROXY_USERNAME_MACRO,
      Protocol.MYPROXY_PASSWORD_MACRO,
      Protocol.MYPROXY_LIFETIME_MACRO,
      Protocol.MYPROXY_DN_MACRO
    };
    for ( int i = 0; i < myproxyVars.length; i++ ) {
      String myproxyValue = resources.getValue(
        AgentTest.TEST_RESOURCE, myproxyVars[i]
      );
      if ( myproxyValue == null ) {
        throw new ConfigurationException( "Missing macro " + myproxyVars[i] );
      }
      myproxyInfo.put( myproxyVars[i], myproxyValue );
    }

    ExtendedGSSManager manager;
    manager = (ExtendedGSSManager)ExtendedGSSManager.getInstance();
    GSSCredential cred;
    cred = manager.createCredential( GSSCredential.INITIATE_AND_ACCEPT);

    MyProxy myproxy = new MyProxy();
    myproxy.setHost( (String)myproxyInfo.get(Protocol.MYPROXY_HOST_MACRO) );
    myproxy.setPort( Integer.parseInt(
      (String)myproxyInfo.get(Protocol.MYPROXY_PORT_MACRO)
    ) );
    myproxy.setAuthorization( new IdentityAuthorization(
      (String)myproxyInfo.get(Protocol.MYPROXY_DN_MACRO)
    ));
    myproxy.put(
      cred,
      (String)myproxyInfo.get(Protocol.MYPROXY_USERNAME_MACRO),
      (String)myproxyInfo.get(Protocol.MYPROXY_PASSWORD_MACRO),
      Integer.parseInt(
        (String)myproxyInfo.get(Protocol.MYPROXY_LIFETIME_MACRO)
      )
    );
    return myproxyInfo;
  }

   /**
   * Close reporter manager controller and mock agent if used in test
   *
   * @throws Exception
   */
  public void tearDown() throws Exception {
    if ( rmc != null ) rmc.shutdown();
    if ( mockAgent != null ) mockAgent.join();
  }

  /**
   * Test the reporter manager's create and sendSuite functions.
   * The test emulates the real reporter agent's
   * responses to PING, REGISTER and then sends the END statement to
   * shutdown the reporter manager.
   *
   * @throws Exception
   */
  public void testCreateAndSuite() throws Exception {
    if ( AgentTest.isRunningTest() == false ) return;

    runCreateAndSubscribe( false );
  }

  /**
   * Same as testCreateAndSuite but with authentication turned on
   *
   * @throws Exception
   */
  public void testCreateAndSuiteAuth() throws Exception {
    if ( AgentTest.isRunningTest() == false ) return;

    runCreateAndSubscribe( true );
  }

  /**
   * Test the ability for the agent to generate certificates for the
   * reporter manager.
   *
   * @throws Exception
   */
  public void testGenerateCertificate() throws Exception {
    // create rm
    ReporterManagerController rm = createRM( true, false, null, null );
    rm.getReporterManagerStarter().setTempDir( "etc" );
    rm.getReporterManagerStarter().generateAuthFiles();

    Server server = new Server();
    server.setAuthenticate( true );
    server.setCertificatePath( "agentcert.pem" );
    server.setKeyPath( "agentkey.pem" );
    server.setTrustedPath( "trusted" );
    server.setPassword( "topSecret!" );
    server.readCredentials();
    server.setPort( 8888 );
    server.start();
    Thread.sleep(2);
    Client client = new Client();
    client.setAuthenticate( true );
    client.setCertificatePath( "rm/localhost/rmcert.pem");
    client.setPassword( "topSecret!" );
    client.setKeyPath( "rm/localhost/rmkey.pem");
    client.setTrustedPath( "rm/localhost/trusted" );
    client.setPort( 8888 );
    client.setHost( "localhost" );
    try {
      client.connect();
    } catch ( Exception e ) {
      fail("client unable to connect to server: " + e );
    }
    String response = client.commandPing( "ME");
    assertEquals( "Able to ping server", "ME", response );
    client.close();
    server.shutdown();

    File rmcert = new File( "etc/rm/localhost/rmcert.pem");
    rmcert.delete();
    File rmkey = new File( "etc/rm/localhost/rmkey.pem");
    rmkey.delete();
    File trustedFile = new File( "etc/rm/localhost/trusted/trusted0.pem");
    trustedFile.delete();
    File trusteddir = new File( "etc/rm/localhost/trusted");
    trusteddir.delete();
    File resourcedir = new File( "etc/rm/localhost");
    resourcedir.delete();
    resourcedir = new File( "etc/rm");
    resourcedir.delete();

  }

  /**
   * Test the ability to get URIs from a suite
   *
   * @throws Exception
   */
  public void testGetUris() throws Exception {

    ReporterManagerController rm = createRM( false, true, null, null );
    SuiteWrapper suite = createSampleSuite();

    // make numRepeats duplicates of the suite so that we can check
    // that if a reporter is listed in a suite more than once,
    // extractReportersFromSuite only lists it once
    int numRepeats = 2;
    int numConfigs = suite.getSeriesConfigCount();
    for ( int i = 0; i < numRepeats; i++ ) {
      for ( int j = 0; j < numConfigs; j++ ) {
        suite.appendSeriesConfig((SeriesConfig)suite.getSeriesConfig(j).copy());
      }
    }
    assertEquals(
      "size right",
      numRepeats*numConfigs+numConfigs,
      suite.getSeriesConfigCount()
    );

    PackageType[] reporters = rm.extractReportersFromSuite(
      suite.getSuiteDocument()
    );
    assertEquals( "3 uris extracted", 3, reporters.length );
  }

  /**
   * Test the reporter manager's isRemoteManagerAlive function
   *
   * @throws Exception
   */
  public void testIsRemoteManagerAlive() throws Exception {
    if ( ! AgentTest.isRunningTest() ) return;

    startAndRegisterRMC( true, false, null, 1, null );
    rmc.waitUntilReady();
    assertTrue( "is alive returns true", rmc.isRemoteManagerAlive() );
    rmc.shutdown();
    mockAgent.join();
    assertFalse( "is alive returns false", rmc.isRemoteManagerAlive() );
    rmc = null;
    mockAgent = null;
  }

  /**
   * Test the reporter manager's stage function which installs a reporter
   * manager distribution on a remote resource.  Tested with auth on.
   *
   * @throws Exception
   */
  public void testManual() throws Exception {

    startAndRegisterRMC( true, true, null, 1, resource + "-manual" );

    SuiteWrapper suite = createSampleSuite();
    rmc.sendSuite( suite.getSuiteDocument() );
    File rmCert = new File( "var/rm/" + resource + "-manual/rmCert.pem" );
    assertTrue( "certificate generated", rmCert.exists() );
    rmc.getReporterManagerStarter().interrupt();
  }

  /**
   * Test the reporter manager's addPackage function
   *
   * @throws Exception
   */
  public void testPackage() throws Exception {
    if ( ! AgentTest.isRunningTest() ) return;

    startAndRegisterRMC( true , true, null, 1, null );

    Thread.sleep( 5000 );
    assertFalse(
      "Inca::Reporter does not exist",
      rmc.hasPackage( "Inca::Reporter", null)
    );
    rmc.addPackage( "Inca::Reporter" );
    while( ! rmc.hasPackage( "Inca::Reporter",null) ) {
      logger.debug( "package not yet updated" );
      Thread.sleep(2000);
    }
    logger.debug( "package updated" );
  }

  /**
   * Test the reporter manager's register function when the reporter manager
   * connects using a password
   *
   * @throws Exception
   */
  public void testPasswordRegister() throws Exception {
    if ( ! AgentTest.isRunningTest() ) return;

    startAndRegisterRMC( true, false, null, 1, null );
    Thread.sleep(5000);
  }

  /**
   * Test the specified pattern to make sure it can parse out the string "inca"
   * from a glob of text.
   */
  public void testPattern() {
    String[] strings = {
      "***********************************************************************\n" +
      "* Ceci est le serveur de calcul d'IDRIS. Tout acces au systeme doit   *\n" +
      "* etre specifiquement autorise par le proprietaire du compte. Si vous *\n" +
      "* tentez de continuer a acceder cette machine alors que vous n'y etes *\n" +
      "* pas autorise, vous vous exposez a des poursuites judiciaires.       *\n" +
      "***********************************************************************\n" +
      "*                  CNRS / IDRIS  -   zahir.idris.fr                   *\n" +
      "*                  IBM 120 noeuds (1024 processeurs)                  *\n" +
      "***********************************************************************\n" +
      "inca",
      "inca",
      "inca\n"
    };
    for ( int i = 0; i < strings.length; i++ ) {
      assertTrue( "pattern " + i, Pattern.matches( "(?m)(?s).*inca.*", strings[i]) );
    }
  }

  /**
   * Test the reporter manager's register function and proxy renewal info
   *
   * @throws Exception
   */
  public void testProxy() throws Exception {
    if ( ! AgentTest.isRunningTest() ) return;

    ResourcesWrapper resources = ResourcesWrapperTest.createSampleResources();
    startAndRegisterRMC( true, false, null, 1, null );

    if ( AgentTest.hasMyProxyServer() == true ) {
      Hashtable myproxyInfo = storeProxy( resources );
      rmc.setProxy( new ReporterManagerProxy(
        (String)myproxyInfo.get(Protocol.MYPROXY_HOST_MACRO),
        Integer.parseInt(
          (String)myproxyInfo.get(Protocol.MYPROXY_PORT_MACRO)
        ),
        (String)myproxyInfo.get(Protocol.MYPROXY_USERNAME_MACRO),
        (String)myproxyInfo.get(Protocol.MYPROXY_PASSWORD_MACRO),

        (String)myproxyInfo.get(Protocol.MYPROXY_DN_MACRO ),
        Integer.parseInt(
          (String)myproxyInfo.get(Protocol.MYPROXY_LIFETIME_MACRO)
        )

      ) );
    }
  }

  /**
   * Test the reporter manager's register function
   *
   * @throws Exception
   */
  public void testRegister() throws Exception {
    if ( ! AgentTest.isRunningTest() ) return;

    startAndRegisterRMC( false, false, null, 1, null );
    Thread.sleep(5000);
  }

  /**
   * Test the reporter manager's restart function.  When manager checks in
   * the first time, we kill it and expect the isReporterManagerAlive function
   * to detect the kill.  The manager is restarted and this time is sent a
   * suite.  During the sending of the suite, we kill the reporter
   * manager again and expect those functions to detect the kill.  When the
   * manager is restarted for the second time, it should pick up a suite
   * and execute it. It will start up 3 reporters which we wait for.  Then we
   * pick the manager 3 times and then properly shut it down.
   *
   * @throws Exception
   */
  public void testRestart() throws Exception {
    if ( ! AgentTest.isRunningTest() ) return;

    // (1) reporter manager should be killed after 5 seconds and detected from
    // ping and restarted
    startAndRegisterRMC( false, true, null, 3, null );
    RepositoryCache cache = rmc.agent.getRepositoryCache();
    rmc.agent.setPingPeriod( 10000 );
    logger.info( "received first connection -- initial start " );
    logger.info( "-------------------------------------------------------" );
    rmc.getReporterManagerStarter().waitForReporterManager();

    // reporter manager should be killed after 5 seconds and detected from ping
    Thread.sleep(5000);
    mockAgent.writer.close(); // kill rm
    assertTrue( "registration returned -- detected shutdown", true );

    // (2) kill reporter manager but detected when trying to send suite
    while( mockAgent.numConnectionsReceived < 2 ) Thread.sleep( 2000 );
    logger.info( "received first connection -- 1st restart " );
    logger.info( "-------------------------------------------------------" );
    rmc.agent.setPingPeriod( 60000 );
    Thread.sleep(5000);
    SuiteWrapper suiteWrapper = createSampleSuite();
    SuiteStagesWrapper suite = new SuiteStagesWrapper(
      "var/suites/TestSuiteLocal.xml",
      ResourcesWrapperTest.createSampleResources()
    );
    cache.resolveReporters( suiteWrapper );
    suite.modify( suiteWrapper );
    suite.save();
    rmc.agent.setSuites( "var" );
    rmc.addSuite( suiteWrapper.getSuiteDocument() );
    Thread.sleep(6000);
    mockAgent.writer.close();

    while( mockAgent.numConnectionsReceived < 3 ) Thread.sleep( 2000 );
    logger.info( "received second connection -- 2nd restart" );
    logger.info( "-------------------------------------------------------" );
    AgentTest.MockDepot depot = new AgentTest.MockDepot( 8935, 3 );
    depot.start();
    logger.info( "Waiting for reports" );
    depot.join();
    logger.info( "Reports received" );
    rmc.agent.setPingPeriod( 4000 ); // at least 3 pings
    Thread.sleep( 15000 );
  }

  /**
   * Test the ability to send reporters from a suite to a RM
   *
   * @throws Exception
   */
  public void testSendReporters() throws Exception {
    if ( AgentTest.isRunningTest() == false ) return;

    startAndRegisterRMC( false, true, null, 1, null );

    SuiteWrapper suite = createSampleSuite();

    try {
      PackageType[] reps = rmc.extractReportersFromSuite(
        suite.getSuiteDocument()
      );
      logger.info( "Sending " + reps.length + " reporters" );
      assertEquals( "3 reporters extracted", 3, reps.length );
      rmc.sendReporters( reps );
      assertTrue(
        "openssl in rm cache",
        rmc.hasPackage("cluster.security.openssl.version", null) );
      assertTrue(
        "gcc in rm cache",
        rmc.hasPackage("cluster.compiler.gcc.version", null)
      );
      reps = rmc.extractReportersFromSuite( suite.getSuiteDocument() );
      assertEquals( "sending suite again, no uris", 0, reps.length );
      ReporterManagerController rm2 = createRM( false, false, null, null );
      rm2.agent.setRepositoryCache( rmc.agent.getRepositoryCache() );
      assertTrue(
        "openssl in rm cache",
        rm2.hasPackage("cluster.security.openssl.version", null) );
      assertTrue(
        "gcc in rm cache",
        rm2.hasPackage("cluster.compiler.gcc.version", null)
      );
    } catch( Exception e ) {
      fail( "Sending suite failed: " + e );
    }
  }

  /**
   * Test the reporter manager's stage function which installs a reporter
   * manager distribution on a remote resource.  Tested with auth on.
   *
   * @throws Exception
   */               /*
  public void testStage() throws Exception {
    if ( ! AgentTest.isRunningTest() ) return;

    ResourcesWrapper resources = ResourcesWrapperTest.createSampleResources();
    ReporterManagerController rm = new ReporterManagerController(
      resource,
      resources,
      null,
      "incas://localhost:8080",
      "var",
      new ReporterManagerTable(),
      email
    );
    rm.setHost( resource );
    File installDir = new File(
      resources.getValue( resource, Protocol.WORKING_DIR_MACRO)
    );
    deleteDirectory(installDir);
    assertFalse( "isStaged returns false", rm.isStaged());
    rm.stage( false );
    assertTrue( "isStaged returns true", rm.isStaged());
    deleteDirectory(installDir);
    rm = createRM( "incas://localhost:6323" );
    rm.setHost( resource );
    assertFalse( "isStaged returns false (auth)", rm.isStaged());
    rm.stage( false );
    assertTrue( "isStaged returns true (auth)", rm.isStaged());
  }             */

  /**
   * Test the reporter manager's start function.  Given a resource with 2
   * bad hosts and 1 good one
   *
   * @throws Exception
   */
  public void testStart() throws Exception {
    if ( ! AgentTest.isRunningTest() ) return;

    String resources =
      "<?xml version = \"1.0\"?>\n" +
      "<!--Generated by XML Authority.-->\n" +
      "<rc:resourceConfig xmlns:rc = \"http://inca.sdsc.edu/dataModel/resourceConfig_2.0\" xmlns:xsi = \"http://www.w3.org/2001/XMLSchema-instance\" >\n" +
      "<resources>\n" +
      "  <resource>\n" +
      "    <name>localhost</name>\n" +
      "    <xpath>//resource[matches(name, 'localhost.+')]</xpath>\n" +
      "    <macros>\n" +
      "      <macro>\n" +
      "        <name>" + Protocol.COMPUTE_METHOD_MACRO + "</name>\n" +
      "        <value>local</value>\n" +
      "      </macro>\n" +
      "      <macro>\n" +
      "        <name>" + Protocol.COMPUTE_SERVER_MACRO + "</name>\n" +
      "        <value>localhost</value>\n" +
      "      </macro>\n" +
      "      <macro>\n" +
      "        <name>" + Protocol.WORKING_DIR_MACRO + "</name>\n" +
      "        <value>/tmp/inca2install2</value>\n" +
      "      </macro>\n" +
      "    </macros>\n" +
      "  </resource>\n" +
      "  <resource>\n" +
      "    <name>localhostBad1</name>\n" +
      "    <macros>\n" +
      "      <macro>\n" +
      "        <name>" + Protocol.WORKING_DIR_MACRO + "</name>\n" +
      "        <value>/var/inca2install</value>\n" +
      "      </macro>\n" +
      "    </macros>\n" +
      "  </resource>\n" +
      "  <resource>\n" +
      "    <name>localhostBad2</name>\n" +
      "    <macros>\n" +
      "      <macro>\n" +
      "        <name>" + Protocol.WORKING_DIR_MACRO + "</name>\n" +
      "        <value>/var/inca2install2</value>\n" +
      "      </macro>\n" +
      "    </macros>\n" +
      "  </resource>\n" +
      "  <resource>\n" +
      "    <name>localhostGood</name>\n" +
      "  </resource>\n" +
      "</resources>\n" +
      "</rc:resourceConfig>";
    ResourceConfigDocument rcDoc = ResourceConfigDocument.Factory.parse(
      resources
    );
    startAndRegisterRMC( false, false, new ResourcesWrapper(rcDoc), 1, null );
    assertEquals("got right rm dir", "/tmp/inca2install2", rmc.getReporterManagerStarter().getRmRootPath());
    assertEquals("got right host", "localhostGood", rmc.getReporterManagerStarter().getCurrentHost());
    Thread.sleep(10000);
  }

  /**
   * Test the reporter manager's start function.  Given a resource which doesn't
   * work.  We then change the resource to work 10 seconds and expect start to
   * pick it up after it's next iteration.
   *
   * @throws Exception
   */
  public void testStartOnSecondTime() throws Exception {
    if ( ! AgentTest.isRunningTest() ) return;

    String resourcesBad =
      "<?xml version = \"1.0\"?>\n" +
      "<!--Generated by XML Authority.-->\n" +
      "<rc:resourceConfig xmlns:rc = \"http://inca.sdsc.edu/dataModel/resourceConfig_2.0\" xmlns:xsi = \"http://www.w3.org/2001/XMLSchema-instance\" >\n" +
      "<resources>\n" +
      "  <resource>\n" +
      "    <name>localhost</name>\n" +
      "    <macros>\n" +
      "      <macro>\n" +
      "        <name>" + Protocol.COMPUTE_METHOD_MACRO + "</name>\n" +
      "        <value>local</value>\n" +
      "      </macro>\n" +
      "      <macro>\n" +
      "        <name>" + Protocol.COMPUTE_SERVER_MACRO + "</name>\n" +
      "        <value>localhost</value>\n" +
      "      </macro>\n" +
      "      <macro>\n" +
      "        <name>" + Protocol.WORKING_DIR_MACRO + "</name>\n" +
      "        <value>/var/inca2install2</value>\n" +
      "      </macro>\n" +
      "    </macros>\n" +
      "  </resource>\n" +
      "</resources>\n" +
      "</rc:resourceConfig>";

    String resourcesGood =
      "<?xml version = \"1.0\"?>\n" +
      "<!--Generated by XML Authority.-->\n" +
      "<rc:resourceConfig xmlns:rc = \"http://inca.sdsc.edu/dataModel/resourceConfig_2.0\" xmlns:xsi = \"http://www.w3.org/2001/XMLSchema-instance\" >\n" +
      "<resources>\n" +
      "  <resource>\n" +
      "    <name>localhost</name>\n" +
      "    <macros>\n" +
      "      <macro>\n" +
      "        <name>" + Protocol.COMPUTE_METHOD_MACRO + "</name>\n" +
      "        <value>local</value>\n" +
      "      </macro>\n" +
      "      <macro>\n" +
      "        <name>" + Protocol.COMPUTE_SERVER_MACRO + "</name>\n" +
      "        <value>localhost</value>\n" +
      "      </macro>\n" +
      "      <macro>\n" +
      "        <name>" + Protocol.WORKING_DIR_MACRO + "</name>\n" +
      "        <value>/tmp/inca2install2</value>\n" +
      "      </macro>\n" +
      "    </macros>\n" +
      "  </resource>\n" +
      "</resources>\n" +
      "</rc:resourceConfig>";
    ResourceConfigDocument rcDoc = ResourceConfigDocument.Factory.parse(
      resourcesBad
    );
    startAndRegisterRMC( false, false, new ResourcesWrapper(rcDoc), 1, null );
    Thread.sleep(10000);
    logger.info( "Setting new resource document" );
    rcDoc = ResourceConfigDocument.Factory.parse( resourcesGood );
    rmc.agent.setResources( new ResourcesWrapper(rcDoc) );
    rmc.getReporterManagerStarter().refreshHosts();
    rmc.getReporterManagerStarter().waitForReporterManager();
    assertEquals("got right rm dir", "/tmp/inca2install2", rmc.getReporterManagerStarter().getRmRootPath());
    assertEquals("got right host", "localhost", rmc.getReporterManagerStarter().getCurrentHost());
  }

  /**
   * Test the reporter manager's start function.  Given a resource that doesn't
   * start the first time, and then the user realizes it's the wrong resources
   * and decides to delete it.  This thread should exit accordingly.
   *
   * @throws Exception
   */
  public void testStartStops() throws Exception {
    if ( ! AgentTest.isRunningTest() ) return;

    String noResources =
      "<?xml version = \"1.0\"?>\n" +
      "<!--Generated by XML Authority.-->\n" +
      "<rc:resourceConfig xmlns:rc = \"http://inca.sdsc.edu/dataModel/resourceConfig_2.0\" xmlns:xsi = \"http://www.w3.org/2001/XMLSchema-instance\" >\n" +
      "<resources>\n" +
      "</resources>\n" +
      "</rc:resourceConfig>";

    String resourcesBad =
      "<?xml version = \"1.0\"?>\n" +
      "<!--Generated by XML Authority.-->\n" +
      "<rc:resourceConfig xmlns:rc = \"http://inca.sdsc.edu/dataModel/resourceConfig_2.0\" xmlns:xsi = \"http://www.w3.org/2001/XMLSchema-instance\" >\n" +
      "<resources>\n" +
      "  <resource>\n" +
      "    <name>localhost</name>\n" +
      "    <macros>\n" +
      "      <macro>\n" +
      "        <name>" + Protocol.COMPUTE_METHOD_MACRO + "</name>\n" +
      "        <value>local</value>\n" +
      "      </macro>\n" +
      "      <macro>\n" +
      "        <name>" + Protocol.COMPUTE_SERVER_MACRO + "</name>\n" +
      "        <value>localhost</value>\n" +
      "      </macro>\n" +
      "      <macro>\n" +
      "        <name>" + Protocol.WORKING_DIR_MACRO + "</name>\n" +
      "        <value>/tmp/inca2install2</value>\n" +
      "      </macro>\n" +
      "    </macros>\n" +
      "  </resource>\n" +
      "</resources>\n" +
      "</rc:resourceConfig>";
    ResourceConfigDocument rcDoc = ResourceConfigDocument.Factory.parse(
      resourcesBad
    );
    startAndRegisterRMC( false, false, new ResourcesWrapper(rcDoc), 1, null );
    Thread.sleep(10000);
    logger.info( "Setting new resource document" );
    rcDoc = ResourceConfigDocument.Factory.parse( noResources );
    rmc.agent.setResources( new ResourcesWrapper(rcDoc) );
    rmc.getReporterManagerStarter().refreshHosts();
    Thread.sleep(10000);
  }

  /**
   * Test the reporter manager's stage function which installs a reporter
   * manager distribution on a remote resource.  Tested with auth on.
   *
   * @throws Exception
   */
  public void testUpgrade() throws Exception {
    if ( ! AgentTest.isRunningTest() ) return;

    ResourcesWrapper resources = ResourcesWrapperTest.createSampleResources();
    File installDir = new File(
      resources.getValue( resource, Protocol.WORKING_DIR_MACRO)
    );
    deleteDirectory(installDir);

    // first test it errors
    Agent agent = new Agent();
    agent.setConfiguration( config );
    agent.setResources( resources );
    agent.readCredentials();
    ReporterManagerStarter rm = new ReporterManagerStarter(
      "localhost-noinstallation", agent
    );
    try {
      rm.stage( true );
      fail( "Upgrade when no previous installation should fail" );
    } catch ( Exception e ) {     }

    // now expect it to succeed
    rm = new ReporterManagerStarter( "localhost", agent );

    rm.findBashLoginShellOption();
    rm.stage( false );  // just in case it's not there
    File keyFile = new File(
      installDir.getAbsolutePath() + File.separator + "etc" + File.separator +
      "rmkey.pem"
    );
    assertTrue( "rm key exists", keyFile.exists() );
    long beforeUpdateTimestamp = keyFile.lastModified();
    assertTrue( "isStaged returns true", rm.isStaged());
    rm.stage( true );
    assertTrue( "isStaged returns true", rm.isStaged());
    Thread.sleep(2);
    logger.info("Stamps " + keyFile.lastModified() + " > " + beforeUpdateTimestamp );
    assertTrue( "rm key modified",
                keyFile.lastModified() > beforeUpdateTimestamp  );
  }
}


