package edu.sdsc.inca.agent.access;

import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.AgentTest;
import edu.sdsc.inca.Agent;
import edu.sdsc.inca.util.ResourcesWrapper;
import edu.sdsc.inca.util.ResourcesWrapperTest;

import java.util.regex.Pattern;
import java.net.InetAddress;

import org.apache.log4j.Logger;


/**
 * Test the Globus class.
 */
public class GlobusTest extends AccessMethodTestCase {
  Logger logger = Logger.getLogger(this.getClass().toString());
  private String resource = null;

  public void setUp() throws Exception {
    resource = AgentTest.TEST_RESOURCE + "-globus";
    logger.info( "Looking for resource " + resource );
    ResourcesWrapper resources = ResourcesWrapperTest.createSampleResources();
    if ( resources.getResources(resource,true).length < 1 ) {
      throw new ConfigurationException(
        "Resource '" + resource + "' not in resource file '" +
        AgentTest.RESOURCES_FILE + "'"
      );
    }
    procs = new Globus[] {
      new Globus( resource, resources, "/tmp", "GT2" ),  // with proxy
      new Globus( resource, resources, "/tmp", "GT2" )  // w/o proxy
    };
    ((Globus)procs[1]).setProxy( null);
    InetAddress addr = InetAddress.getLocalHost();
    System.setProperty( Agent.GLOBUS_IP_PROPERTY, addr.getHostAddress() );
  }

  public boolean hasRequirements() {
    return AgentTest.hasGlobusServer();
  }

  /*
  * Test the constructor
  */
  public void testConfiguration() throws Exception {
    // normal
    ResourcesWrapper resources = ResourcesWrapperTest.createSampleResources();
    new Globus( resource, resources, "/tmp", "GT2" );
   }
}
