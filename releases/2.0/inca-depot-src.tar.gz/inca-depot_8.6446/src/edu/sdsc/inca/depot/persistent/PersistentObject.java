package edu.sdsc.inca.depot.persistent;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlObject;

/**
 * This is an abstract base class that defines common behavior for all objects
 * that the Depot stores in the database.
 *
 * @author jhayes
 */
public abstract class PersistentObject {

  protected static final Logger logger =
    Logger.getLogger(PersistentObject.class);

  /**
   * Maximum length for string DB fields.  MAX_STRING_LENGTH applies to those
   * fields with no length attribute in the HBM files; MAX_LONG_STRING_LENGTH
   * is the minimum upper bound across underlying DBs for those with a length
   * attribute.  Unfortunately, there seems to be no programmatic way to know
   * one from the other, so implementing classes will simply need to "know"
   * which string fields have been given the larger length bound.
   */
  public static final int MAX_DB_STRING_LENGTH = 255;
  public static final int MAX_DB_LONG_STRING_LENGTH = 4000;

  /**
   * Value used to store null/empty strings in the database.  We avoid storing
   * null because it complicates constructing select statements (must is "is
   * null" rather than "==").  We avoid "" because of Oracle bizarreness--it
   * translates "" into null when storing records in a table.
   *
   * Ideally, we'd like to limit use of this hack to DAO.java, since all DB
   * storage and retrieval goes through the class.  At the moment, though, each
   * persistent object class tests incoming values in each String setter method
   * and overrides null and "" with this value.  Trying to replace string
   * values before and after DB use seems to run afoul of Hibernates auto
   * update feature.
   */
  public static final String DB_EMPTY_STRING = "\t";

  /**
   * Copies information from an Inca schema XmlBean object so that this object
   * contains equivalent information.
   *
   * @param o the XmlBean object to copy
   * @return this, for convenience
   */
  public abstract PersistentObject fromBean(XmlObject o);

  /**
   * Returns a Inca schema XmlBean object that contains information equivalent
   * to this object.
   *
   * @return an XmlBean object that contains equivalent information
   */
  public abstract XmlObject toBean();

  /**
   * Returns XML that represents the information in this object.
   */
  public String toXml() {
    return this.toBean().xmlText();
  }

  /**
   * A convenience function for implementations that checks the length of a
   * string and truncates with a warning if it's too long.
   *
   * @param s the string to check
   * @param max the maximum length
   * @param label included in the warning message if truncation occurs
   * @return s, truncated if necessary
   */
  public String truncate(String s, int max, String label) {
    if(s != null && s.length() > max) {
      logger.warn("Truncating " + label + " '" + s +
                  "' to fit into a DB table column of " + max + " chars");
      s = s.substring(0, max);
    }
    return s;
  }

}
