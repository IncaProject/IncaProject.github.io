package edu.sdsc.inca.depot.util;

import edu.sdsc.inca.util.StringMethods;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import org.apache.log4j.Logger;

/**
 * A Notifier that executes a script.
 *
 * @author jhayes
 */
public class ScriptNotifier implements Notifier {

  private static Logger logger = Logger.getLogger(ScriptNotifier.class);

  /**
   * Invokes a script, passing info about an AcceptedOutput state change.
   *
   * @param target The script to invoke
   * @param state A string indicating the new AO state
   */
  public void notify(String comparitor, String comparison,
                     String reporter, String resource,
                     String target, String state) {
    String[] commandWords = new String[] {
      target, "--comparison=" + comparison, "--reporter=" + reporter,
      "--resource=" + resource, "--state=" + state
    };
    // Check to see if the script has either a temporary directory or the
    // working dir as an ancestor; other paths are disallowed for security.
    // Check target for initial /tmp, but check cononical path for wd to avoid
    // potential problems with ../ in path.
    try {
      String targetPath = new File(target).getCanonicalPath();
      String workingDir =
        new File(System.getProperty("user.dir")).getCanonicalPath();
      if(!target.startsWith("/tmp/") && !targetPath.startsWith(workingDir)) {
        logger.error("Invalid script file path '" + targetPath + "'");
        return;
      }
      commandWords[0] = targetPath;
    } catch(Exception e) {
      logger.error("Error examining script path: " + e);
      return;
    }
    // Now run the script
    String command = StringMethods.join(" ", commandWords);
    try {
      logger.debug(command);
      Process p = Runtime.getRuntime().exec(commandWords);
      p.waitFor();
      if(p.exitValue() != 0) {
        BufferedReader reader =
          new BufferedReader(new InputStreamReader(p.getErrorStream()));
        String error = "", line;
        while((line = reader.readLine()) != null) {
          error += line;
        }
        logger.error("Error executing script " + command + ": " + error);
      }
    } catch(InterruptedException e) {
      // empty
    } catch(IOException e) {
      logger.error("Error executing script " + command + ": " + e);
    }

  }

}
