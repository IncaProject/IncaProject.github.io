package edu.sdsc.inca.depot.util;

/**
 * An abstract class that notifies a "target" (for example, an email address)
 * about a state change in AcceptableOutput.
 *
 * @author jhayes
 */
public interface Notifier {

  /**
   * Notifies a target of an AcceptedOutput state change.
   *
   * @param comparitor the name of the class that did the test
   * @param comparison the test that changed state
   * @param reporter the name of the reporter generating the output
   * @param resource the resource where the reporter ran
   * @param target the target to notify
   * @param state a string indicating the new AO state
   */
  public void notify(String comparitor, String comparison,
                     String reporter, String resource,
                     String target, String state);

}
