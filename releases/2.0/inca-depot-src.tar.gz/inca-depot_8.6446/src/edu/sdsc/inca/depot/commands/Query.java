package edu.sdsc.inca.depot.commands;

import edu.sdsc.inca.dataModel.util.AnyXmlSequence;
import edu.sdsc.inca.dataModel.util.Log;
import edu.sdsc.inca.depot.persistent.*;
import edu.sdsc.inca.depot.util.HibernateMessageHandler;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.protocol.Statement;
import edu.sdsc.inca.queryResult.ReportSummaryDocument;
import edu.sdsc.inca.queryResult.ReportDetailsDocument;
import edu.sdsc.inca.util.StringMethods;
import org.apache.xmlbeans.XmlException;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

/**
 */
public class Query extends HibernateMessageHandler {

  private static Logger logger = Logger.getLogger(Query.class);
  private static final Statement S_FINISH =
    new Statement(Protocol.END_QUERY_RESULTS_COMMAND.toCharArray(), null);

  /**
   * Creates a ReportDetailsDocument by copying fields from a DB SeriesConfig
   * and a DB InstanceInfo.
   *
   * @param sc the SeriesConfig for the document
   * @param ii the InstanceInfo for the document
   */
  protected static ReportDetailsDocument toBean
    (SeriesConfig sc, InstanceInfo ii) throws PersistenceException {
    Report r = ReportDAO.load(ii.getReportId());
    ReportDetailsDocument result =
      ReportDetailsDocument.Factory.newInstance();
    ReportDetailsDocument.ReportDetails rd = result.addNewReportDetails();
    rd.setSuiteId(sc.getSuite().getId().longValue());
    rd.setSeriesConfigId(sc.getId().longValue());
    rd.setSeriesId(r.getSeries().getId().longValue());
    rd.setReportId(r.getId().longValue());
    rd.setInstanceId(ii.getId().longValue());
    rd.setSeriesConfig((edu.sdsc.inca.dataModel.util.SeriesConfig)sc.toBean());
    rd.setReport((edu.sdsc.inca.dataModel.util.Report)r.toBean());
    // Note: apparently getGmt() returns a copy, so the following doesn't work
    //rd.getReport().getGmt().setTime(ii.getCollected());
    GregorianCalendar gmt = new GregorianCalendar();
    gmt.setTime(ii.getCollected());
    rd.getReport().setGmt(gmt);
    String log = ii.getLog();
    if(log != null && !log.equals("") &&
       !log.equals(PersistentObject.DB_EMPTY_STRING)) {
      try {
        rd.getReport().setLog(Log.Factory.parse(log));
      } catch(Exception e) {
        logger.error("Unable to parse log stored in DB:", e);
      }
    }
    ComparisonResult cr = ComparisonResultDAO.load(sc.getLatestComparisonId());
    if(cr != null) {
      rd.setComparisonResult(cr.getResult());
    }
    rd.setSysusage((edu.sdsc.inca.dataModel.util.Limits)ii.toBean());
    rd.setStderr(r.getStderr());
    return result;
  }

  /**
   * Creates a ReportSummaryDocument by copying fields from a DB SeriesConfig.
   *
   * @param sc the SeriesConfig for the document
   */
  protected static ReportSummaryDocument toBean(SeriesConfig sc)
    throws PersistenceException {
    ReportSummaryDocument result = ReportSummaryDocument.Factory.newInstance();
    ReportSummaryDocument.ReportSummary summary = result.addNewReportSummary();
    Series s = sc.getSeries();
    summary.setUri(s.getUri());
    summary.setNickname(sc.getNickname());
    summary.setSeriesConfigId(sc.getId().longValue());
    summary.setHostname(s.getResource());
    InstanceInfo ii = InstanceInfoDAO.load(sc.getLatestInstanceId());
    if(ii != null) {
      summary.setInstanceId(ii.getId().longValue());
      GregorianCalendar gmt = new GregorianCalendar();
      gmt.setTime(ii.getCollected());
      summary.setGmt(gmt);
      Report r = ReportDAO.load(ii.getReportId());
      String bodyText = r.getBody();
      try {
        summary.setBody(AnyXmlSequence.Factory.parse(bodyText));
      } catch(XmlException e) {
        // empty
      }
      summary.setErrorMessage(r.getExit_message());
    }
    ComparisonResult cr = ComparisonResultDAO.load(sc.getLatestComparisonId());
    if(cr != null) {
      summary.setComparisonResult(cr.getResult());
    }
    return result;
  }

  /**
   * Execute queries on the depot.
   *
   * @param reader   Reader to the query request.
   * @param writer   Writer to the remote process making the request.
   * @throws Exception
   */
  public void executeHibernateAction(
    ProtocolReader reader, ProtocolWriter writer) throws Exception {

    Statement queryStatement = null;
    queryStatement = reader.readStatement();
    String cmd = new String(queryStatement.getCmd());
    String data = new String(queryStatement.getData());
    if(cmd.equals(Protocol.QUERY_GUIDS_COMMAND)) {
      getGuidList(writer);
    } else if(cmd.equals(Protocol.QUERY_HQL_COMMAND)) {
      getSelectOutput(writer, data);
    } else if(cmd.equals(Protocol.QUERY_INSTANCE_COMMAND)) {
      getInstance(writer, data);
    } else if(cmd.equals(Protocol.QUERY_SERIES_COMMAND)) {
      getSeriesInstances(writer, data);
    } else if(cmd.equals(Protocol.QUERY_SUITE_COMMAND)) {
      getLatestInstancesForSuite(writer, data);
    }
    if(!cmd.equals(Protocol.QUERY_GUIDS_COMMAND)) {
      writer.write(S_FINISH);
    }

  }

  /**
   * Return a list of the Suite guids in the database.
   *
   * @param writer Writer to the remote process making the request
   * @param request The data packaged with the request
   * @throws Exception
   */
  private void getGuidList(ProtocolWriter writer) throws Exception {
    List suites = DAO.selectMultiple("select s from Suite as s", null);
    String[] guids = new String[suites.size()];
    for(int i = 0; i < guids.length; i++) {
      guids[i] = ((Suite)suites.get(i)).getGuid();
    }
    writer.write(Statement.getOkStatement(StringMethods.join(" ", guids)));
  }

  /**
   * Return a report details document to the client for the given report
   * instance and configuration.
   *
   * @param writer  Writer to the remote process making the request.
   * @param request The instance query request which contains the
   * instance id, followed by a space, and then the report series configuration
   * id.
   *
   * @throws PersistenceException on a failed lookup
   * @throws Exception
   */
  private void getInstance(ProtocolWriter writer, String request)
    throws Exception {
    String[] pieces = request.split(" ");
    Long instanceId = null, configId = null;
    if(pieces.length != 2) {
      throw new ProtocolException
        ("Expected 'instanceId configId', got '" + request + "'");
    }
    try {
      instanceId = Long.valueOf(pieces[0]);
      configId = Long.valueOf(pieces[1]);
    } catch(NumberFormatException e) {
      throw new ProtocolException("Non-numeric id in '" + request + "'");
    }
    SeriesConfig sc = SeriesConfigDAO.load(configId);
    InstanceInfo ii = InstanceInfoDAO.load(instanceId);
    if(sc == null) {
      throw new PersistenceException("Request for unknown config " + configId);
    } else if(ii == null) {
      throw new PersistenceException
        ("Request for unknown instance " + instanceId);
    }
    writer.write
      (new Statement(Protocol.QUERY_RESULT, toBean(sc, ii).toString()));
  }

  /**
   * Return a report details document to the requester for every instance of
   * a given series.
   *
   * @param writer  Writer to the remote process making the request.
   * @param request The query request that contains the SeriesConfig id.
   * @throws Exception
   */
  private void getSeriesInstances
    (ProtocolWriter writer, String request) throws Exception {
    Long configId = null;
    try {
      configId = Long.valueOf(request);
    } catch(NumberFormatException e) {
      throw new ProtocolException("Non-numeric id in query '" + request + "'");
    }
    SeriesConfig sc = SeriesConfigDAO.load(configId);
    if(sc == null) {
      throw new PersistenceException("Request for unknown config " + configId);
    }
    Series s = sc.getSeries();
    logger.debug(s.getReports().size() + " reports for sc " + s.getReporter());
    ArrayList allInstances = new ArrayList();
    for(Iterator i = s.getReports().iterator(); i.hasNext(); ) {
      Report r = (Report)i.next();
      List reportInstances = DAO.selectMultiple
        ("select i from InstanceInfo i where i.reportId = " + r.getId(), null);
      logger.debug
        (reportInstances.size() + " instances for report " + r.getId());
      allInstances.addAll(reportInstances);
    }
    // TODO sort by time
    for(Iterator i = allInstances.iterator(); i.hasNext(); ) {
      InstanceInfo ii = (InstanceInfo)i.next();
      writer.write
        (new Statement(Protocol.QUERY_RESULT, toBean(sc, ii).toString()));
    }
  }

  /**
   * Return the output from an HQL query.
   *
   * @param writer  writer to the remote process making the request.
   * @param select the HQL select statement
   * @throws Exception
   */
  private void getSelectOutput
    (ProtocolWriter writer, String select) throws Exception {
    Session session = HibernateUtil.getCurrentSession();
    org.hibernate.Query query = session.createQuery(select);
    List l = null;
    try {
      l = query.list();
    } catch(Exception e) {
      throw new PersistenceException(e.toString());
    }
    for(int i = 0; i < l.size(); i++) {
      writer.write(new Statement(
        Protocol.QUERY_RESULT, ((PersistentObject)l.get(i)).toXml()
      ));
    }
  }

  /**
   * Return the latest report summaries for all series in a given suite.
   *
   * @param writer  Writer to the remote process making the request.
   * @param suiteGuid A suite GUID string.
   * @throws Exception
   */
  private void getLatestInstancesForSuite(
    ProtocolWriter writer, String suiteGuid) throws Exception {

    String query = "select s from Suite as s where s.guid = :p0";
    Suite suite = (Suite)DAO.selectUnique(query, new Object[] {suiteGuid});
    if(suite == null) {
      throw new PersistenceException("Suite " + suiteGuid + " not found in DB");
    }
    query = "select sc " +
            " from SeriesConfig sc " +
            " where sc.suite = :p0 and sc.deactivated <= sc.activated ";
    List results = DAO.selectMultiple(query, new Object[] {suite.getId()});
    SeriesConfig[] scs =
      (SeriesConfig[])results.toArray(new SeriesConfig[results.size()]);

    // loop through each item in the list and turn it into a BasicResult
    Statement reply = new Statement(Protocol.QUERY_RESULT, null);
    for(int i = 0; i < scs.length; i++) {
      reply.setData(toBean(scs[i]).toString().toCharArray());
      writer.write(reply);
    }
  }

}
