package edu.sdsc.inca;

import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.repository.Repository;
import edu.sdsc.inca.util.ConfigProperties;
import edu.sdsc.inca.util.ExpandablePattern;
import edu.sdsc.inca.util.StringMethods;
import edu.sdsc.inca.util.XmlWrapper;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Hashtable;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class incat extends JPanel
  implements ActionListener, ChangeListener, WindowListener {

  // Our agent and the file we're editing; both may be null
  protected AgentClient ac;
  protected String path;

  // main window components
  protected IncatList macroList;
  protected IncatList memberList;
  protected IncatList reporterList;
  protected IncatList repositoryList;
  protected IncatList reporterPropertyList;
  protected IncatList resourceList;
  protected IncatList seriesList;
  protected JCheckBox showAllRepositories;
  protected IncatList suiteList;

  // dialogs
  protected IncatAboutDialog aboutDialog;
  protected IncatHelpDialog helpDialog;
  protected IncatMacroDialog macroDialog;
  protected IncatResourceDialog resourceDialog;
  protected IncatSeriesDialog seriesDialog;
  protected IncatSuiteDialog suiteDialog;
  protected Frame waitDialog; // AWT rather than Swing
  protected Label waitMessage;

  // item currently being edited in a dialog
  protected String editMacro;
  protected WrapResource editResource;
  protected WrapSeries editSeries;
  protected WrapSuite editSuite;

  // The configs most recently saved to agent/file
  protected WrapConfig lastCommittedConfig;
  protected WrapConfig lastSavedConfig;

  public incat(String path,
               AgentClient ac) {

    super();

    // Define the main window components, ...
    this.macroList = new IncatList(null, "macroEdit", this);
    this.memberList = new IncatList(null, null);
    this.reporterList = new IncatList("reporterSelect", "reporterShow", this);
    this.reporterPropertyList = new IncatList(null, null);
    this.repositoryList = new IncatList("repositorySelect", this);
    this.resourceList = new IncatList("resourceSelect", "resourceEdit", this);
    this.seriesList = new IncatList(null, "seriesEdit", this);
    this.showAllRepositories = new JCheckBox("All Repositories");
    this.showAllRepositories.addActionListener(this);
    this.showAllRepositories.setActionCommand("repositorySelect");
    this.showAllRepositories.setSelected(true);
    this.suiteList = new IncatList("suiteSelect", "suiteEdit", this);

    // ... stick them into panels for the GUI, ...
    JPanel macroPanel = IncatComponents.JPanelFactory(new JComponent[] {
      this.macroList, null,
      new JLabel("Macros"), null,
      IncatComponents.JPanelFactory(new JComponent[] {
        IncatComponents.JButtonFactory("Add ...", "macroAdd", this),
        IncatComponents.JButtonFactory("Edit ...", "macroEdit", this),
        IncatComponents.JButtonFactory("Delete", "macroRemove", this), null
      })
    });
    JPanel memberPanel = IncatComponents.JPanelFactory(new JComponent[] {
      this.memberList, null,
      new JLabel("Members"), null
    });
    JPanel reporterPanel = IncatComponents.JPanelFactory(new JComponent[] {
      this.reporterList, null,
      new JLabel("Reporters"), null,
      this.showAllRepositories,
      IncatComponents.JButtonFactory("Show", "reporterShow", this), null
    });
    JPanel reporterPropertyPanel =
      IncatComponents.JPanelFactory(new JComponent[] {
        this.reporterPropertyList, null,
        new JLabel("Reporter Properties"), null
    });
    JPanel repositoryPanel = IncatComponents.JPanelFactory(new JComponent[] {
      this.repositoryList, null,
      new JLabel("Repositories"), null,
      IncatComponents.JPanelFactory(new JComponent[] {
        IncatComponents.JButtonFactory("Add ...", "repositoryAdd", this),
        IncatComponents.JButtonFactory("Delete", "repositoryRemove", this), null
      })
    });
    JPanel resourcePanel = IncatComponents.JPanelFactory(new JComponent[] {
      this.resourceList, null,
      new JLabel("Resource Group"), null,
      IncatComponents.JPanelFactory(new JComponent[] {
        IncatComponents.JButtonFactory("Add ...", "resourceAdd", this),
        IncatComponents.JButtonFactory("Edit ...", "resourceEdit", this),
        IncatComponents.JButtonFactory("Delete", "resourceRemove", this), null
      })
    });
    JPanel seriesPanel = IncatComponents.JPanelFactory(new JComponent[] {
      this.seriesList, null,
      new JLabel("Series"), null,
      IncatComponents.JPanelFactory(new JComponent[] {
        IncatComponents.JButtonFactory("Add ...", "seriesAdd", this),
        IncatComponents.JButtonFactory("Edit ...", "seriesEdit", this),
        IncatComponents.JButtonFactory("Delete", "seriesRemove", this),
        IncatComponents.JButtonFactory("Copy", "seriesCopy", this),
        IncatComponents.JButtonFactory("Run Now", "seriesRun", this), null
      })
    });
    JPanel suitePanel = IncatComponents.JPanelFactory(new JComponent[] {
      this.suiteList, null,
      new JLabel("Suites"), null,
      IncatComponents.JPanelFactory(new JComponent[] {
        IncatComponents.JButtonFactory("Add ...", "suiteAdd", this),
        IncatComponents.JButtonFactory("Edit ...", "suiteEdit", this),
        IncatComponents.JButtonFactory("Delete", "suiteRemove", this), null
      })
    });

    // ... and add the panels to the GUI.
    JPanel repositoryTab = IncatComponents.JPanelFactory(new JComponent[] {
      repositoryPanel, reporterPanel, reporterPropertyPanel, null
    });
    JPanel configTab = IncatComponents.JPanelFactory(new JComponent[] {
      resourcePanel, macroPanel, memberPanel, null
    });
    JPanel suiteTab = IncatComponents.JPanelFactory(new JComponent[] {
      suitePanel, seriesPanel, null
    });
    JTabbedPane tabs = new JTabbedPane();
    tabs.add("Repositories", repositoryTab);
    tabs.add("Resource Configuration", configTab);
    tabs.add("Suites", suiteTab);
    tabs.addChangeListener(this);
    this.add(tabs);

    // Define dialog windows for editing macros ...
    this.macroDialog =
      new IncatMacroDialog(this, "macroEditOk", "macroEditCancel");

    // ... editing resources ...
    this.resourceDialog =
      new IncatResourceDialog(this, "resourceEditOk", "resourceEditCancel");

    // ... editing series ...
    this.seriesDialog =
      new IncatSeriesDialog(this, "seriesEditOk", "seriesEditCancel");

    // ... editing suites ...
    this.suiteDialog =
      new IncatSuiteDialog(this, "suiteEditOk", "suiteEditCancel");

    // ... responding to the "About incat" and "Help" menu items ...
    this.aboutDialog = new IncatAboutDialog();
    this.helpDialog = new IncatHelpDialog();

    // ... and a wait message for long-running actions.  Note that this latter
    // is AWT rather than Swing to avoid refresh problems encountered when
    // opening a JDialog from a Swing event handler.
    this.waitDialog = new Frame("Incat Message");
    this.waitMessage = new Label
      ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", Label.CENTER);
    this.waitDialog.add(new Label(""), BorderLayout.NORTH);
    this.waitDialog.add(waitMessage, BorderLayout.CENTER);
    this.waitDialog.add(new Label(""), BorderLayout.SOUTH);
    this.waitDialog.pack();

    this.path = path;
    this.ac = ac == null ? new AgentClient() : ac;
    this.lastCommittedConfig = getConfig();
    this.lastSavedConfig = getConfig();

    // Initialize from agent and/or file, as appropriate.  Note that if we have
    // both an agent and file that latter overwrites the former.  We still need
    // to query the agent, though, so lastCommittedConfig is set correctly.
    if(this.ac.getPort() >= 0) {
      readFromAgent(false);
      setConfig(lastCommittedConfig);
    }
    if(this.path != null && new File(this.path).exists()) {
      readFromFile(false);
      setConfig(lastSavedConfig);
    }

  }

  /**
   * Responds to user GUI actions.  To avoid a humungous block of code, most
   * of the work of this method is divided into separate methods.  See the
   * "event methods" that follow the other listener methods.
   */
  public void actionPerformed(ActionEvent ae) {

    String action = ae.getActionCommand();

    if(action.equals("about")) {
      this.aboutDialog.setVisible(true);
    } else if(action.equals("commit")) {
      writeToAgent();
    } else if(action.equals("connect")) {
      readFromAgent(true);
      WrapConfig current = getConfig();
      if(current.getRepositories().length == 0 &&
         current.getResources().length == 0 &&
         current.getSuites().length == 0) {
        setConfig(lastCommittedConfig);
      }
    } else if(action.equals("fileOpen")) {
      readFromFile(true);
      setConfig(lastSavedConfig);
    } else if(action.equals("fileSave") || action.equals("fileSaveAs")) {
      writeToFile(this.path == null || action.equals("fileSaveAs"));
    } else if(action.equals("help")) {
      this.helpDialog.setVisible(true);
    } else if(action.equals("macroAdd")) {
      addOrEditMacro(true);
    } else if(action.equals("macroEdit")) {
      addOrEditMacro(false);
    } else if(action.equals("macroEditCancel")) {
      this.macroDialog.setVisible(false);
    } else if(action.equals("macroEditOk")) {
      updateMacro();
    } else if(action.equals("macroRemove")) {
      removeMacro();
    } else if(action.equals("quit")) {
      WrapConfig config = getConfig();
      if(!config.equals(this.lastSavedConfig)) {
        int response =
          JOptionPane.showConfirmDialog(this, "Save changes before exiting?");
        if(response == JOptionPane.YES_OPTION) {
          writeToFile(this.path == null);
        } else if(response == JOptionPane.CANCEL_OPTION) {
          return;
        }
      }
      if(this.ac.getPort() >= 0 && !config.equals(lastCommittedConfig)) {
        int response =
          JOptionPane.showConfirmDialog(this, "Commit changes before exiting?");
        if(response == JOptionPane.YES_OPTION) {
          writeToAgent();
        } else if(response == JOptionPane.CANCEL_OPTION) {
          return;
        }
      }
      System.exit(0);
    } else if(action.equals("reporterShow")) {
      showReporter();
    } else if(action.equals("reporterSelect")) {
      refreshReporterPropertyPanel();
    } else if(action.equals("repositoryAdd")) {
      addRepository();
    } else if(action.equals("repositoryRemove")) {
      removeRepository();
    } else if(action.equals("repositorySelect")) {
      refreshReporterPanel();
    } else if(action.equals("resourceAdd")) {
      addOrEditResource(true);
    } else if(action.equals("resourceEdit")) {
      addOrEditResource(false);
    } else if(action.equals("resourceEditCancel")) {
      this.resourceDialog.setVisible(false);
    } else if(action.equals("resourceEditOk")) {
      updateResource();
    } else if(action.equals("resourceRemove")) {
      removeResource();
    } else if(action.equals("resourceSelect")) {
      refreshMemberPanel();
      refreshMacroPanel();
    } else if(action.equals("seriesAdd")) {
      addOrEditSeries(true);
    } else if(action.equals("seriesEdit")) {
      addOrEditSeries(false);
    } else if(action.equals("seriesCopy")) {
      copySeries();
    } else if(action.equals("seriesEditCancel")) {
      this.seriesDialog.setVisible(false);
    } else if(action.equals("seriesEditOk")) {
      updateSeries();
    } else if(action.equals("seriesRemove")) {
      removeSeries();
    } else if(action.equals("seriesRun")) {
      runSeries();
    } else if(action.equals("suiteAdd")) {
      addOrEditSuite(true);
    } else if(action.equals("suiteEdit")) {
      addOrEditSuite(false);
    } else if(action.equals("suiteEditCancel")) {
      this.suiteDialog.setVisible(false);
    } else if(action.equals("suiteEditOk")) {
      updateSuite();
    } else if(action.equals("suiteRemove")) {
      removeSuite();
    } else if(action.equals("suiteSelect")) {
      refreshSeriesPanel();
   }

  }

  /**
   * Transforms window closing into an action event.
   */
  public void windowClosing(WindowEvent e) {
    actionPerformed
      (new ActionEvent(e.getSource(), ActionEvent.RESERVED_ID_MAX + 1, "quit"));
  }

  // Must define these to implement interface, but don't care about the events.
  public void windowActivated(WindowEvent e)   { /*empty*/ }
  public void windowClosed(WindowEvent e)      { /*empty*/ }
  public void windowDeactivated(WindowEvent e) { /*empty*/ }
  public void windowDeiconified(WindowEvent e) { /*empty*/ }
  public void windowIconified(WindowEvent e)   { /*empty*/ }
  public void windowOpened(WindowEvent e)      { /*empty*/ }

  /**
   * Invoked when the user clicks a tab.
   */
  public void stateChanged(ChangeEvent e) {
    int tabIndex = ((JTabbedPane)e.getSource()).getSelectedIndex();
    this.helpDialog.setSection(
      tabIndex == 0 ? IncatHelpDialog.REPOSITORIES_SECTION :
      tabIndex == 1 ? IncatHelpDialog.RESOURCES_SECTION :
      IncatHelpDialog.SUITES_SECTION
    );
    markFaultySeries(); // In case repository/resource lists have changed
  }

  /**
   * An event method: prompts the user for a new repository URL and adds it to
   * the repository list.
   */
  protected void addRepository() {
    Repository repo = null;
    String urlString = null;
    while(repo == null) {
      urlString=JOptionPane.showInputDialog(this, "Repository URL", urlString);
      if(urlString == null || urlString.equals("")) {
        return; // User cancel
      }
      try {
        URL url = new URL(urlString);
        if(this.ac.getPort() >= 0) {
          this.ac.connect();
          repo = new Repository(url, ac.getCatalog(urlString));
          this.ac.close();
        } else {
          repo = new Repository(url);
        }
      } catch(Exception e) {
        showErrorMessage("Unable to access repository: " + e);
      }
    }
    this.repositoryList.addElement(repo);
    this.repositoryList.setSelectedElement(repo);
    this.repositoryList.sort();
    refreshReporterPanel();
    IncatRepositoryDialog.setRepositories
      (this.repositoryList.getElementsAsStrings());
  }

  /**
   * An event method: opens the macro edit dialog on either an empty macro or
   * or the currently-selected one.
   *
   * @param add open the dialog with a new macro
   */
  protected void addOrEditMacro(boolean add) {
    WrapResource resource=(WrapResource)this.resourceList.getSelectedElement();
    if(resource == null) {
      return;
    }
    this.editMacro = add ? null : (String)this.macroList.getSelectedElement();
    this.macroDialog.setMacro(this.editMacro == null ? "" : this.editMacro);
    this.macroDialog.setVisible(true);
  }

  /**
   * An event method: opens the resource edit dialog on either an empty
   * resource or the currently-selected one.
   *
   * @param add open the dialog with a new resource
   */
  protected void addOrEditResource(boolean add) {
    this.editResource =
      add ? null : (WrapResource)this.resourceList.getSelectedElement();
    this.resourceDialog.setResource
      (this.editResource == null ? new WrapResource() : this.editResource);
    this.helpDialog.setSection(IncatHelpDialog.RESOURCE_EDITOR_SECTION);
    this.resourceDialog.setVisible(true);
  }

  /**
   * An event method: opens the series edit dialog on either an empty series or
   * or the currently-selected one.
   *
   * @param add open the dialog with a new series
   */
  protected void addOrEditSeries(boolean add) {
    WrapSuite suite = (WrapSuite)this.suiteList.getSelectedElement();
    if(suite == null) {
      return;
    }
    Object[] reporters = wrapCatalog(mergedRepositoriesCatalog());
    Object[] resources = this.resourceList.getElements();
    // Disallow add w/no reporters/resources, since these fields are required.
    // Edit is okay, since the series already has values for these.
    if(add && (resources.length == 0 || reporters.length == 0)) {
      showErrorMessage
        ("No reporters/resources available for series definition");
    } else {
      this.seriesDialog.setReporterChoices(reporters);
      this.seriesDialog.setResourceChoices(resources);
      this.editSeries =
        add ? null : (WrapSeries)this.seriesList.getSelectedElement();
      this.seriesDialog.setSeries
        (this.editSeries == null ? new WrapSeries() : this.editSeries);
      this.helpDialog.setSection(IncatHelpDialog.SERIES_EDITOR_SECTION);
      this.seriesDialog.setVisible(true);
    }
  }

  /**
   * An event method: opens the suite edit dialog on either an empty suite or
   * or the currently-selected one.
   *
   * @param add open the dialog with a new suite
   */
  protected void addOrEditSuite(boolean add) {
    this.editSuite =
      add ? null : (WrapSuite)this.suiteList.getSelectedElement();
    this.suiteDialog.setSuite
      (this.editSuite == null ? new WrapSuite("", "") : this.editSuite);
    this.suiteDialog.setVisible(true);
  }

  /**
   * An event method: adds a copy of the currently-selected series to the
   * series list.
   */
  protected void copySeries() {
    WrapSuite suite = (WrapSuite)this.suiteList.getSelectedElement();
    WrapSeries original = (WrapSeries)this.seriesList.getSelectedElement();
    if(suite == null || original == null) {
      return;
    }
    WrapSeries copy = suite.addNewSeries();
    copy.copy(original);
    String name = original.getNickname() + " copy";
    for(int i = 2; this.seriesList.findMatchingElement(name) >= 0; i++) {
      name = original.getNickname() + " copy " + i;
    }
    copy.setNickname(name);
    this.seriesList.addElement(copy);
    this.seriesList.setSelectedElement(copy);
    this.seriesList.sort();
  }

  /**
   * An event method: removes the currently-selected macro.
   */
  protected void removeMacro() {
    WrapResource resource =
      (WrapResource)this.resourceList.getSelectedElement();
    String macro = (String)this.macroList.getSelectedElement();
    if(resource == null || macro == null) {
      return;
    }
    resource.removeMacro(macro.substring(0, macro.indexOf('=')));
    refreshMacroPanel();
  }

  /**
   * An event method: removes the currently-selected repository.
   */
  protected void removeRepository() {
    int index = this.repositoryList.getSelectedIndex();
    if(index < 0) {
      return;
    }
    this.repositoryList.removeElementAt(index);
    this.repositoryList.setSelectedIndex(0);
    refreshReporterPanel();
    IncatRepositoryDialog.setRepositories
      (this.repositoryList.getElementsAsStrings());
  }

  /**
   * An event method: removes the currently-selected resource.
   */
  protected void removeResource() {
    int index = this.resourceList.getSelectedIndex();
    if(index < 0) {
      return;
    }
    this.resourceList.removeElementAt(index);
    this.resourceList.setSelectedIndex(0);
    refreshMemberPanel();
    refreshMacroPanel();
  }

  /**
   * An event method: removes the currently-selected series.
   */
  protected void removeSeries() {
    WrapSuite suite = (WrapSuite)this.suiteList.getSelectedElement();
    int index = this.seriesList.getSelectedIndex();
    if(suite == null || index < 0) {
      return;
    }
    WrapSeries series = (WrapSeries)this.seriesList.getSelectedElement();
    suite.removeSeries(series);
    this.seriesList.removeElementAt(index);
    this.seriesList.setSelectedIndex(0);
  }

  /**
   * An event method: removes the currently-selected suite.
   */
  protected void removeSuite() {
    int index = this.suiteList.getSelectedIndex();
    if(index < 0) {
      return;
    }
    this.suiteList.removeElementAt(index);
    this.suiteList.setSelectedIndex(0);
    refreshSeriesPanel();
  }

  /**
   * An event method: asks the agent to run the currently-selected series
   * immediately.
   */
  public void runSeries() {
    WrapSeries series = (WrapSeries)this.seriesList.getSelectedElement();
    if(series == null) {
      return;
    } else if(this.ac.getPort() < 0) {
      showErrorMessage("Not connected to an Inca Agent");
      return;
    }
    WrapSuite suite = new WrapSuite(Protocol.IMMEDIATE_SUITE_NAME, "");
    WrapSeries copy = suite.addNewSeries();
    copy.copy(series);
    copy.setCron(null);
    copy.setAction(Protocol.SERIES_CONFIG_ADD);
    WrapConfig config = new WrapConfig();
    config.setSuites(new WrapSuite[] {suite});
    this.waitMessage.setText("Sending info to Agent ...");
    this.waitDialog.show();
    try {
      this.ac.connect();
      this.ac.setConfig(config.toXml());
      this.ac.close();
    } catch(Exception e) {
      showErrorMessage("Run series failed: " + e);
    }
    this.waitDialog.hide();
  }

  /**
   * An event method: displays the currently-selected reporter in a dialog.
   */
  protected void showReporter() {
    String file = null;
    WrapReporter reporter=(WrapReporter)this.reporterList.getSelectedElement();
    if(reporter == null || (file = reporter.getProperty("file")) == null) {
      return;
    }
    try {
      IncatRepositoryDialog dialog = new IncatRepositoryDialog();
      dialog.setReporter(file);
      dialog.show();
    } catch(IOException e) {
      showErrorMessage(e.toString());
    }
  }

  /**
   * An event method: copies the contents of the macro edit dialog into a new
   * or existing macro.
   */
  protected void updateMacro() {
    this.macroDialog.setVisible(false);
    WrapResource resource=(WrapResource)this.resourceList.getSelectedElement();
    if(resource == null) {
      return;
    }
    String name = this.macroDialog.getName();
    String value = this.macroDialog.getValue();
    if((this.editMacro == null || !this.editMacro.startsWith(name + "=")) &&
       resource.getMacroValues(name) != null) {
      showErrorMessage("Duplicate macro name " + name);
      this.macroDialog.setVisible(true);
    } else {
      if(this.editMacro != null) {
        resource.removeMacro
          (this.editMacro.substring(0, this.editMacro.indexOf("=")));
      }
      if(value.matches("([\"']).*\\1")) {
        // quoted value
        resource.setMacroValue(name, value.substring(1, value.length() - 1));
      } else {
        resource.setMacroValues(name, value.split(" +"));
      }
      refreshMacroPanel();
    }
  }

  /**
   * An event method: copies the contents of the resource edit dialog into a
   * new or existing resource.
   */
  protected void updateResource() {
    this.resourceDialog.setVisible(false);
    String name = this.resourceDialog.getName();
    if((this.editResource==null || !name.equals(this.editResource.getName())) &&
       this.resourceList.findMatchingElement(name) >= 0) {
      showErrorMessage("Duplicate resource name " + name);
      this.resourceDialog.setVisible(true);
    } else {
      if(this.editResource == null) {
        this.editResource = new WrapResource();
        this.resourceList.addElement(this.editResource);
      }
      this.resourceDialog.getResource(this.editResource);
      this.resourceList.setSelectedElement(this.editResource);
      this.resourceList.sort();
      refreshMemberPanel();
      refreshMacroPanel();
    }
  }

  /**
   * An event method: copies the contents of the series edit dialog into a new
   * or existing series.
   */
  protected void updateSeries() {
    this.seriesDialog.setVisible(false);
    WrapSuite suite = (WrapSuite)this.suiteList.getSelectedElement();
    if(suite == null) {
      return;
    }
    WrapSeries updated = new WrapSeries();
    this.seriesDialog.getSeries(updated);
    String name = updated.toString();
    if((this.editSeries == null || !name.equals(this.editSeries.toString())) &&
       this.seriesList.findMatchingElement(name) >= 0) {
      showErrorMessage("Duplicate series name " + name);
      this.seriesDialog.setVisible(true);
    } else {
      if(this.editSeries == null) {
        this.editSeries = suite.addNewSeries();
        this.seriesList.addElement(this.editSeries);
      }
      this.seriesDialog.getSeries(editSeries);
      this.seriesList.setSelectedElement(this.editSeries);
      this.seriesList.sort();
      markFaultySeries();
    }
  }

  /**
   * An event method: copies the contents of the suite edit dialog into a new
   * or existing suite.
   */
  protected void updateSuite() {
    this.suiteDialog.setVisible(false);
    String name = this.suiteDialog.getName();
    if((this.editSuite == null || !name.equals(this.editSuite.toString())) &&
       this.suiteList.findMatchingElement(name) >= 0) {
      showErrorMessage("Duplicate suite name " + name);
      this.suiteDialog.setVisible(true);
    } else {
      if(this.editSuite == null) {
        this.editSuite = new WrapSuite("", "");
        this.suiteList.addElement(this.editSuite);
      }
      this.suiteDialog.getSuite(this.editSuite);
      this.suiteList.setSelectedElement(this.editSuite);
      this.suiteList.sort();
      refreshSeriesPanel();
    }
  }

  /**
   * Rewrites the contents of the macro list to reflect the current selection
   * in the resource list.
   */
  protected void refreshMacroPanel() {
    this.macroList.removeAllElements();
    WrapResource resource=(WrapResource)this.resourceList.getSelectedElement();
    if(resource == null) {
      return;
    }
    // Recompute the resource's inherited macro values.  Do a breadth-first
    // search for macro definitions so that macros defined by closer ancestors
    // take precedence over those of more remote ones.
    resource.removeAllInheritedMacros();
    Hashtable colors = new Hashtable();
    Hashtable macros = new Hashtable();
    ArrayList generation = getParents(resource);
    while(generation.size() > 0) {
      ArrayList nextGeneration = new ArrayList();
      for(int i = 0; i < generation.size(); i++) {
        WrapResource r = (WrapResource)generation.get(i);
        nextGeneration.addAll(getParents(r));
        String[] names = r.getMacroNames();
        for(int j = 0; j < names.length; j++) {
          String name = names[j];
          if(macros.get(name) == null) {
            String[] values = r.getMacroValues(name);
            resource.setInheritedMacroValues(name, values);
            macros.put(name, values);
            colors.put(name, Color.GRAY);
          }
        }
      }
      generation = nextGeneration;
    }
    // Add the local macro values
    String[] names = resource.getMacroNames();
    for(int i = 0; i < names.length; i++) {
      String name = names[i];
      macros.put(name, resource.getMacroValues(name));
      colors.put(name, Color.BLACK);
    }
    // Display the combined set
    for(Enumeration e = macros.keys(); e.hasMoreElements(); ) {
      String name = (String)e.nextElement();
      if(name.matches("^" + Protocol.PREDEFINED_MACRO_NAME_PATTERN + "$")) {
        continue;
      }
      String[] values = (String [])macros.get(name);
      String value = StringMethods.join(" ", values);
      if(values.length == 1 && value.indexOf(' ') >= 0) {
        char quote = value.indexOf('"') >= 0 ? '\'' : '"';
        value = quote + value + quote;
      }
      String element = name + "=" + value;
      this.macroList.addElement(element);
      this.macroList.setColor(element, (Color)colors.get(name));
    }
    this.macroList.sort();
    this.macroList.setSelectedIndex(0);
  }

  /**
   * Rewrites the contents of the member list to reflect the current selection
   * in the resource list.
   */
  protected void refreshMemberPanel() {
    this.memberList.removeAllElements();
    WrapResource resource=(WrapResource)this.resourceList.getSelectedElement();
    if(resource == null) {
      return;
    }
    this.memberList.setElements(getHosts(resource));
    this.memberList.sort();
    this.memberList.setSelectedIndex(0);
  }

  /**
   * Rewrites the contents of the reporter list to reflect the current
   * selection the repository list.
   */
  protected void refreshReporterPanel() {
    Repository selected = (Repository)this.repositoryList.getSelectedElement();
    Properties[] catalog =
      this.showAllRepositories.isSelected() ? mergedRepositoriesCatalog() :
      selected == null ? new Properties[0] : selected.getCatalog();
    this.reporterList.setElements(wrapCatalog(catalog));
    this.reporterList.sort();
    this.reporterList.setSelectedIndex(0);
    refreshReporterPropertyPanel();
  }

  /**
   * Rewrites the contents of the reporter property list to reflect the current
   * selection in the reporter list.
   */
  protected void refreshReporterPropertyPanel() {
    this.reporterPropertyList.removeAllElements();
    WrapReporter reporter=(WrapReporter)this.reporterList.getSelectedElement();
    if(reporter == null) {
      return;
    }
    for(Enumeration e = reporter.reporter.keys(); e.hasMoreElements(); ) {
      String prop = (String)e.nextElement();
      this.reporterPropertyList.addElement
        (prop + ": " + reporter.reporter.getProperty(prop));
    }
    this.reporterPropertyList.sort();
    this.reporterPropertyList.setSelectedIndex(0);
  }

  /**
   * Rewrites the contents of the Series list to reflect the current selection
   * in the suite list.
   */
  protected void refreshSeriesPanel() {
    this.seriesList.removeAllElements();
    WrapSuite suite = (WrapSuite)this.suiteList.getSelectedElement();
    if(suite == null) {
      return;
    }
    WrapSeries[] series = suite.getAllSeries();
    for(int i = 0; i < series.length; i++) {
      this.seriesList.addElement(series[i]);
    }
    this.seriesList.sort();
    this.seriesList.setSelectedIndex(0);
    markFaultySeries();
  }

  /**
   * Get configuration from the Agent and store it in lastCommittedConfig.
   *
   * @param prompt indicates whether to prompt the user for an agent spec
   */
  public void readFromAgent(boolean prompt) {
    String oldHost = this.ac.getHost();
    int oldPort = this.ac.getPort();
    if(prompt) {
      String newAgentSpec =
        JOptionPane.showInputDialog(this, "Agent to contact", "");
      if(newAgentSpec == null || newAgentSpec.equals("")) {
        return; // user cancel
      }
      this.ac.setServer(newAgentSpec, 0);
    }
    if(this.ac.getPort() < 0) {
      showErrorMessage("Not connected to an Inca Agent");
      return;
    }
    this.waitMessage.setText("Receiving info from Agent ...");
    this.waitDialog.show();
    try {
      this.ac.connect();
      String xml = this.ac.getConfig();
      this.ac.close();
      xml = XmlWrapper.cryptSensitive(xml, this.ac.getPassword(), true);
      this.lastCommittedConfig = new WrapConfig(xml);
    } catch(Exception e) {
      showErrorMessage("Error reading from agent: " + e);
      this.ac.setHost(oldHost);
      this.ac.setPort(oldPort);
    }
    this.waitDialog.hide();
  }

  /**
   * Get configuration from an XML file and store it in lastSavedConfig.
   *
   * @param prompt indicates whether to prompt the user for a file path
   */
  public void readFromFile(boolean prompt) {
    String filePath = this.path;
    if(prompt) {
      JFileChooser chooser = new JFileChooser();
      chooser.setCurrentDirectory
        (new File(filePath==null ? System.getProperty("user.dir") : filePath));
      if(chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
        return;
      }
      filePath = chooser.getSelectedFile().getAbsolutePath();
    }
    if(filePath == null || !new File(filePath).exists()) {
      showErrorMessage("No file available");
      return;
    }
    try {
      String xml = StringMethods.fileContents(filePath);
      xml = XmlWrapper.cryptSensitive(xml, this.ac.getPassword(), true);
      this.lastSavedConfig = new WrapConfig(xml);
      this.path = filePath;
    } catch(Exception e) {
      showErrorMessage("Error reading from " + filePath + ": " + e);
    }
  }

  /**
   * Sends the current configuration to the connected Agent.
   */
  protected void writeToAgent() {
    if(this.ac.getPort() < 0) {
      showErrorMessage("Not connected to an Inca Agent");
      return;
    }
    WrapConfig current = getConfig();
    if(current.equals(this.lastCommittedConfig)) {
      JOptionPane.showMessageDialog
        (this, "No commit needed; the current configuration is the same as the Agent's",
         "Incat Message", JOptionPane.INFORMATION_MESSAGE);
      return;
    }
    this.waitMessage.setText("Sending info to Agent ...");
    this.waitDialog.show();
    try {
      this.ac.connect();
      String xml = this.lastCommittedConfig.differences(current).toXml();
      xml = XmlWrapper.cryptSensitive(xml, this.ac.getPassword(), false);
      this.ac.setConfig(xml);
      this.ac.close();
      this.lastCommittedConfig = current;
    } catch(Exception e) {
      showErrorMessage("Error writing to agent: " + e);
    }
    this.waitDialog.hide();
  }

  /**
   * Writes the current configuration to a file.
   *
   * @param prompt indicates whether to prompt the user for a file path
   */
  protected void writeToFile(boolean prompt) {
    String filePath = this.path;
    if(prompt) {
      JFileChooser chooser = new JFileChooser();
      chooser.setCurrentDirectory
        (new File(filePath==null ? System.getProperty("user.dir") : filePath));
      if(chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
        return;
      }
      filePath = chooser.getSelectedFile().getAbsolutePath();
    }
    if(filePath == null) {
      showErrorMessage("No file available");
      return;
    }
    try {
      BufferedWriter bw =
        new BufferedWriter(new FileWriter(new File(filePath)));
      String xml = XmlWrapper.cryptSensitive
        (getConfig().toXml(), this.ac.getPassword(), false);
      bw.write(xml);
      bw.write("\n");
      bw.close();
      this.path = filePath;
      this.lastSavedConfig = getConfig();
    } catch(Exception e) {
      showErrorMessage("Error writing " + filePath + ": " + e);
    }
  }

  /**
   * Returns the set of strings matched by a resource's host pattern.
   *
   * @param resource the resource to retrieve the host pattern from
   * @return the set of string matched by the resource's host pattern
   */
  protected String[] expandHostPattern(WrapResource resource) {
    String pat = resource.getMacroValue(Protocol.PATTERN_MACRO);
    String[] result = new String[0];
    try {
      pat = pat.replaceAll("[ ,]", "|");
      result =
        (String[])(new ExpandablePattern(pat, true).expand().toArray(result));
    } catch(Exception e) {
      // empty
    }
    return result;
  }

  /**
   * Returns an ArrayList of all resources included in the member pattern of a
   * resource.
   *
   * @param resource the resource to search
   * @return all children of the specified resource
   */
  protected ArrayList getChildren(WrapResource resource) {
    ArrayList result = new ArrayList();
    String[] expanded = expandHostPattern(resource);
    for(int i = 0; i < expanded.length; i++) {
      String single = expanded[i];
      int index = this.resourceList.findMatchingElement(single);
      if(index >= 0) {
        result.add(this.resourceList.getElementAt(index));
      }
    }
    return result;
  }

  /**
   * Expands a resource into a set of host names.  In addition to the usual
   * pattern characters, the resource member pattern may contain names of
   * resource groups from the resource list.  These will be expanded into the
   * hosts that match the patterns for those groups.
   */
  protected String[] getHosts(WrapResource resource) {
    ArrayList generation = new ArrayList();
    ArrayList result = new ArrayList();
    generation.add(resource);
    while(generation.size() > 0) {
      ArrayList nextGeneration = new ArrayList();
      for(int i = 0; i < generation.size(); i++) {
        WrapResource r = (WrapResource)generation.get(i);
        nextGeneration.addAll(getChildren(r));
        String[] hosts = expandHostPattern(r);
        for(int j = 0; j < hosts.length; j++) {
          String host = hosts[j];
          if(this.resourceList.findMatchingElement(host) < 0) {
            result.add(host);
          }
        }
      }
      generation = nextGeneration;
    }
    return (String [])result.toArray(new String[result.size()]);
  }

  /**
   * Returns an ArrayList of all resources with a member pattern that includes
   * the resource.
   *
   * @param resource the resource to search for
   * @return all parents of the specified resource
   */
  protected ArrayList getParents(WrapResource resource) {
    String name = resource.getName();
    ArrayList result = new ArrayList();
    for(int i = 0; i < this.resourceList.getElementCount(); i++) {
      WrapResource r = (WrapResource)this.resourceList.getElementAt(i);
      String pat = r.getMacroValue(Protocol.PATTERN_MACRO);
      if(pat != null && name.matches(pat.replaceAll("[ ,]", "|"))) {
        result.add(r);
      }
    }
    return result;
  }

  /**
   * Colors the elements in the series list to indicate whether they contain
   * an unknown reporter or resource.
   */
  public void markFaultySeries() {
    for(int i = 0; i < this.seriesList.getElementCount(); i++) {
      WrapSeries s = (WrapSeries)this.seriesList.getElementAt(i);
      this.seriesList.setColor
        (s, !seriesKnownReporter(s) || !seriesKnownResource(s) ?
            Color.RED : Color.BLACK);
    }
  }

  /**
   * Returns the union of all repository catalogs.
   */
  protected Properties[] mergedRepositoriesCatalog() {
    Hashtable merged = new Hashtable();
    for(int i = 0; i < repositoryList.getElementCount(); i++) {
      Repository repo = (Repository)this.repositoryList.getElementAt(i);
      Properties[] catalog = repo.getCatalog();
      for(int j = 0; j < catalog.length; j++) {
        Properties p = catalog[j];
        String name = p.getProperty("name");
        String version = p.getProperty("version");
        if(name != null && version != null) {
          merged.put(name + " v" + version, p);
        }
      }
    }
    Properties[] result = new Properties[merged.size()];
    int i = 0;
    for(Enumeration e = merged.keys(); e.hasMoreElements(); ) {
      result[i++] = (Properties)merged.get(e.nextElement());
    }
    return result;
  }

  /**
   * Returns true iff a series references a known reporter.
   *
   * @param s the series to check
   * @return true if the series reference a known reporter, else false
   */
  public boolean seriesKnownReporter(WrapSeries s) {
    String name = s.getReporter();
    String version = s.getReporterVersion();
    Properties[] allReporters = mergedRepositoriesCatalog();
    for(int i = 0; i < allReporters.length; i++) {
      Properties r = allReporters[i];
      if(name.equals(r.getProperty("name")) &&
         (version == null || version.equals(r.getProperty("version")))) {
        return true;
      }
    }
    return false;
  }

  /**
   * Returns true iff a series references a known resource.
   *
   * @param s the series to check
   * @return true if the series reference a known resource, else false
   */
  public boolean seriesKnownResource(WrapSeries s) {
    String name = s.getResource();
    for(int i = 0; i < this.resourceList.getElementCount(); i++) {
      WrapResource r = (WrapResource)this.resourceList.getElementAt(i);
      if(name.equals(r.getName())) {
        return true;
      }
    }
    return false;
  }

  /**
   * Informs the user of an error.
   *
   * @param message the error message
   */
  protected void showErrorMessage(String message) {
    JOptionPane.showMessageDialog
      (this, message, "Incat Message", JOptionPane.ERROR_MESSAGE);
  }

  /**
   * Coverts the elements of a reporter catalog into an array of WrapReporters.
   * Filters elements that represent libraries rather than reporters.
   *
   * @param catalog the reporters to wrap
   * @return the elements of the catalog, each placed in a WrapReporter
   */
  protected WrapReporter[] wrapCatalog(Properties[] catalog) {
    ArrayList result = new ArrayList();
    for(int i = 0; i < catalog.length; i++) {
      String file = catalog[i].getProperty("file");
      if(file != null && !file.matches("^.*\\.(pm|rpm|gz|tgz|tar)$")) {
        result.add(new WrapReporter(catalog[i]));
      }
    }
    return (WrapReporter [])result.toArray(new WrapReporter[result.size()]);
  }

  /**
   * Gets the Inca configuration from the display.
   *
   * @return the Inca configuration, as specified on the incat display
   */
  protected WrapConfig getConfig() {
    WrapConfig result = new WrapConfig();
    // Retrieve repository information ...
    String[] repositories = new String[this.repositoryList.getElementCount()];
    for(int i = 0; i < repositories.length; i++) {
      repositories[i] =
       ((Repository)this.repositoryList.getElementAt(i)).getURL().toString();
    }
    result.setRepositories(repositories);
    // ... resource information ...
    Hashtable hostHash = new Hashtable();
    for(int i = 0; i < this.resourceList.getElementCount(); i++) {
      WrapResource resource = (WrapResource)this.resourceList.getElementAt(i);
      String[] members = getHosts(resource);
      for(int j = 0; j < members.length; j++) {
        WrapResource memberResource = new WrapResource();
        memberResource.setName(members[j]);
        hostHash.put(members[j], memberResource);
      }
    }
    String[] hostNames = new String[hostHash.size()];
    Enumeration e = hostHash.keys();
    for(int i = 0; i < hostNames.length; i++) {
      hostNames[i] = (String)e.nextElement();
    }
    Arrays.sort(hostNames);
    WrapResource[] resources =
      new WrapResource[this.resourceList.getElementCount() + hostNames.length];
    int j = 0;
    for(int i = 0; i < this.resourceList.getElementCount(); i++) {
      resources[j++] = (WrapResource)this.resourceList.getElementAt(i);
    }
    for(int i = 0; i < hostNames.length; i++) {
      resources[j++] = (WrapResource)hostHash.get(hostNames[i]);
    }
    result.setResources(resources);
    // ... and suite information
    WrapSuite[]suites = new WrapSuite[this.suiteList.getElementCount()];
    for(int i = 0; i < suites.length; i++) {
      suites[i] = ((WrapSuite)this.suiteList.getElementAt(i));
    }
    result.setSuites(suites);
    // NOTE: since we place objects from the config (e.g., suites) directly
    // into the GUI, we use a copy to avoid having changes to the memory and
    // GUI versions modify each other.
    return result.copy();
  }

  /**
   * Sets the display to represent a specified Inca configuration.
   *
   * @param config the Inca configuration
   */
  protected void setConfig(WrapConfig config) {
    // NOTE: since we place objects from the config (e.g., suites) directly
    // into the GUI, we use a copy to avoid having changes to the memory and
    // GUI versions modify each other.
    config = config.copy();
    // Update the repositories tab ...
    String[] repositories = config.getRepositories();
    this.repositoryList.removeAllElements();
    for(int i = 0; i < repositories.length; i++) {
      Repository repo = null;
      String urlString = repositories[i];
      try {
        URL url = new URL(urlString);
        if(this.ac.getPort() >= 0) {
          this.ac.connect();
          repo = new Repository(url, ac.getCatalog(urlString));
          this.ac.close();
        } else {
          repo = new Repository(url);
        }
        this.repositoryList.addElement(repo);
      } catch(Exception e) {
        showErrorMessage("Unable to access repository " + urlString + ": " + e);
      }
    }
    this.repositoryList.sort();
    this.repositoryList.setSelectedIndex(0);
    IncatRepositoryDialog.setRepositories
      (this.repositoryList.getElementsAsStrings());
    refreshReporterPanel();
    // ... the resource configuration tab ...
    WrapResource[] resources = config.getResources();
    this.resourceList.removeAllElements();
    for(int i = 0; i < resources.length; i++) {
      WrapResource resource = resources[i];
      if(resource.getXpath() != null) {
        this.resourceList.addElement(resource);
      }
    }
    this.resourceList.sort();
    this.resourceList.setSelectedIndex(0);
    refreshMacroPanel();
    refreshMemberPanel();
    // ... and the suites tab, testing for errors in suite series
    int errors = 0;
    WrapSuite[] suites = config.getSuites();
    this.suiteList.removeAllElements();
    for(int i = 0; i < suites.length; i++) {
      this.suiteList.addElement(suites[i]);
      WrapSeries[] series = suites[i].getAllSeries();
      for(int j = 0; j < series.length; j++) {
        WrapSeries s = series[j];
        if(!seriesKnownReporter(s) || !seriesKnownResource(s)) {
          errors++;
        }
      }
    }
    this.suiteList.sort();
    this.suiteList.setSelectedIndex(0);
    refreshSeriesPanel();
    if(errors > 0) {
      this.showErrorMessage(
        "Warning: " + errors + " series in the configuration reference " +
        "unknown reporters and/or resources"
      );
    }
  }

  /**
   * Create the GUI and show it.  For thread safety, this method should be
   * invoked from the event-dispatching thread.
   */
  protected static void createAndShowGUI(String path,
                                       AgentClient ac) {
    // Get our menus into the Mac system bar, instead of inside the frame
    System.setProperty("apple.laf.useScreenMenuBar", "true");
    // Set up the frame with an initial, empty menu bar
    JMenuBar menuBar = new JMenuBar();
    JFrame.setDefaultLookAndFeelDecorated(true);
    JFrame frame = new JFrame("Inca Administration Tool");
    frame.setJMenuBar(menuBar);
    frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    final incat contentPane = new incat(path, ac);
    frame.setContentPane(contentPane);
    frame.addWindowListener(contentPane);
    // Set up the menus
    JMenu fileMenu = new JMenu("File");
    fileMenu.add
      (IncatComponents.JMenuItemFactory("Open...","fileOpen",contentPane,'O'));
    fileMenu.add
      (IncatComponents.JMenuItemFactory("Save", "fileSave", contentPane, 'S'));
    fileMenu.add
      (IncatComponents.JMenuItemFactory("Save As...","fileSaveAs",contentPane));
    JMenu agentMenu = new JMenu("Agent");
    agentMenu.add
      (IncatComponents.JMenuItemFactory("Connect...", "connect", contentPane));
    agentMenu.add
      (IncatComponents.JMenuItemFactory("Commit", "commit", contentPane, 'K'));
    JMenu helpMenu = new JMenu("Help");
    helpMenu.add
      (IncatComponents.JMenuItemFactory("incat Help","help",contentPane,'?'));
    try {
      Portability.addMacApplicationListener(contentPane, "about", "quit");
    } catch(NoClassDefFoundError e) {
      helpMenu.add
        (IncatComponents.JMenuItemFactory("About incat", "about", contentPane));
      fileMenu.add
        (IncatComponents.JMenuItemFactory("Quit incat","quit",contentPane,'Q'));
    }
    menuBar.add(fileMenu);
    menuBar.add(agentMenu);
    menuBar.add(helpMenu);
    frame.pack();
    frame.setVisible(true);
  }

  public static void main(String[] args) {
    final AgentClient ac = new AgentClient();
    final String opts = ConfigProperties.mergeValidOptions
      (AgentClient.AGENT_CLIENT_OPTS, "  f|file  path  XML file path\n", true);
    final ConfigProperties props = new ConfigProperties();
    try {
      props.setPropertiesFromArgs(opts, args);
    } catch(ConfigurationException e) {
      System.err.println("ConfigurationException: " + e);
      System.exit(1);
    }
    if(props.getProperty("help") != null) {
      System.out.println("java incat\n" + opts);
      System.exit(1);
    } else if(props.getProperty("version") != null) {
      String version = Component.readVersion( "incat-version" );
      System.out.println("incat version " + version );
      System.exit(1);
    }
    try {
      AgentClient.configComponent
        (ac, args, opts, "inca.agent.", "edu.sdsc.inca.incat",
         "inca-common-java-version" );
    } catch(Exception e) {
      System.err.println("Configuration failed: " + e);
      System.exit(1);
    }
    // Taken verbatim from the Swing tutorial.
    javax.swing.SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        createAndShowGUI(props.getProperty("file"), ac);
      }
    });
  }

}
