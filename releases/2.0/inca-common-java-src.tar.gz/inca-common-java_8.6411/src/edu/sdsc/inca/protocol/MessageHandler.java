package edu.sdsc.inca.protocol;

import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.protocol.Statement;
import java.io.IOException;
import org.apache.log4j.Logger;

/**
 * @author Cathie Olschanowsky
 * @author Jim Hayes
 *
 * The MessageHandler class should help guide the creation of all of the
 * message handlers for each Inca server.
 *
 * @has 1..1 Has 1..1 inca.protocol.ProtocolReader
 * @has 1..1 Has 1..1 inca.protocol.ProtocolWriter
 *
 */
public abstract class MessageHandler {

  /**
   * logger that can be used by all MessageHandlers.
   */
  protected static final Logger logger = Logger.getLogger(MessageHandler.class);

  /**
   * Execute should run the task using the reader and writer for in/output.
   * Close the reader and writer to indicate that the client connection
   * should be closed.
   *
   * @throws Exception
   */
  public abstract void execute(ProtocolReader reader,
                               ProtocolWriter writer) throws Exception;

  /**
   * A convenience method that logs and writes an error message.
   *
   * @param writer the writer to use to send the error message
   * @param msg the error message
   */
  public static void errorReply(ProtocolWriter writer, String msg) {
    logger.error(msg);
    try {
      writer.write(Statement.getErrorStatement(msg));
    } catch(IOException e) {
      logger.error("Unable to send error reply", e);
    }
  }

}
