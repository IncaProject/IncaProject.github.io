#!/bin/sh

backupDir=inca-graph-extend-backup

if [ ! -d webapps/inca ]; then
  echo "Please cd to your \$INCA_DIST directory"
  exit 1
fi

# backup all files
if [ ! -d $backupDir ]; then
  mkdir $backupDir
fi

# upgrade dir
upgradeDir=`dirname $0`

echo "Updating files"
for file in `find $upgradeDir -type f`; do
  echo $file | grep -E '(install.sh|README)' > /dev/null
  if [ $? -ne 0 ]; then
    echo $file
    localfile=`echo $file | sed "s#$upgradeDir\/##"`
    if [ -f $localfile ]; then
      cp $localfile $backupDir
    fi
    cp -f $file $localfile
  fi
done

# make consumer dynamic
echo "Update web.xml"
cp -f webapps/inca/WEB-INF/web.dyn.xml webapps/inca/WEB-INF/web.xml

# add reporter to repository
echo "Add performance.hpcc to repository"
cd Inca-Reporter-*; ./sbin/incpack -I lib/perl bin/performance.hpcc bin/cluster.batch.wrapper lib/perl/Inca/Reporter.pm lib/perl/Inca/Reporter/Performance.pm; cd ..
