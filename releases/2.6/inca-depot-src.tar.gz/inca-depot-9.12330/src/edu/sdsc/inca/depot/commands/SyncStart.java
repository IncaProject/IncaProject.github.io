/*
 * SyncStart.java
 */
package edu.sdsc.inca.depot.commands;


import java.io.OutputStream;

import edu.sdsc.inca.depot.util.DepotMessageHandler;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.protocol.Statement;


/**
 *
 * @author Paul Hoover
 *
 */
public class SyncStart extends DepotMessageHandler {

	// public methods


	/**
	 *
	 * @param reader the reader connected to the client
	 * @param output the output stream connected to the client
	 * @param dn the DN of the client, null if no authentication
	 * @throws Exception
	 */
	public void execute(ProtocolReader reader, OutputStream output, String dn) throws Exception
	{
		getDepot().startSyncResponse();

		(new ProtocolWriter(output)).write(Statement.getOkStatement(""));

		reader.close();
	}
}
