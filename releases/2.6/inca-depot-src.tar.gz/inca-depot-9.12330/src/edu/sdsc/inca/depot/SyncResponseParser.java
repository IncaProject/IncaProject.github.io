/*
 * SyncResponseParser.java
 */
package edu.sdsc.inca.depot;


import java.io.InputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.hibernate.engine.SessionFactoryImplementor;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

import edu.sdsc.inca.depot.persistent.Arg;
import edu.sdsc.inca.depot.persistent.ArgSignature;
import edu.sdsc.inca.depot.persistent.HibernateUtil;


/**
 *
 * @author Paul Hoover
 *
 */
public class SyncResponseParser extends DefaultHandler {

	/**
	 *
	 */
	private interface ParserState {

		/**
		 *
		 * @param ch
		 * @param start
		 * @param length
		 * @throws SAXException
		 */
		void characters(char[] ch, int start, int length) throws SAXException;

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		void endElement(String uri, String localName, String qName) throws SAXException, SQLException;

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 * @throws SQLException
		 */
		void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException, SQLException;
	}

	/**
	 *
	 */
	private abstract class Capture implements ParserState {

		private StringBuilder m_builder = null;


		// public methods


		/**
		 *
		 * @param ch
		 * @param start
		 * @param length
		 */
		public void characters(char[] ch, int start, int length)
		{
			if (m_builder != null)
				m_builder.append(new String(ch, start, length));
		}


		// protected methods


		/**
		 *
		 */
		protected void startTextCapture()
		{
			assert m_builder == null;

			m_builder = new StringBuilder();
		}

		/**
		 *
		 * @return
		 */
		protected String getTextAsString()
		{
			assert m_builder != null;

			String text = m_builder.toString();

			m_builder = null;

			if (text.length() == 0)
				return null;

			return text;
		}

		/**
		 *
		 * @return
		 * @throws SAXException
		 */
		protected Boolean getTextAsBoolean() throws SAXException
		{
			String text = getTextAsString();

			if (text == null)
				return null;

			return Boolean.valueOf(text);
		}

		/**
		 *
		 * @return
		 * @throws SAXException
		 */
		protected Long getTextAsLong() throws SAXException
		{
			String text = getTextAsString();

			if (text == null)
				return null;

			try {
				return Long.valueOf(text);
			}
			catch (NumberFormatException numErr) {
				throw new SAXException("Can't convert value " + text + " to a Long");
			}
		}

		/**
		 *
		 * @return
		 * @throws SAXException
		 */
		protected Integer getTextAsInteger() throws SAXException
		{
			String text = getTextAsString();

			if (text == null)
				return null;

			try {
				return Integer.valueOf(text);
			}
			catch (NumberFormatException numErr) {
				throw new SAXException("Can't convert value " + text + " to an Integer");
			}
		}

		/**
		 *
		 * @return
		 * @throws SAXException
		 */
		protected Float getTextAsFloat() throws SAXException
		{
			String text = getTextAsString();

			if (text == null)
				return null;

			try {
				return Float.valueOf(text);
			}
			catch (NumberFormatException numErr) {
				throw new SAXException("Can't convert value " + text + " to a Float");
			}
		}

		/**
		 *
		 * @return
		 * @throws SAXException
		 */
		protected Timestamp getTextAsTimestamp() throws SAXException
		{
			String text = getTextAsString();

			if (text == null)
				return null;

			try {
				return Timestamp.valueOf(text);
			}
			catch (IllegalArgumentException argErr) {
				throw new SAXException("Can't convert value " + text + " to a Timestamp");
			}
		}
	}

	/**
	 *
	 */
	private abstract class ParseTableRoot implements ParserState {

		protected final BatchUpdateStatement m_insertStmt;


		// constructors


		/**
		 *
		 * @param query
		 * @throws SQLException
		 */
		protected ParseTableRoot(String query) throws SQLException
		{
			m_insertStmt = new BatchUpdateStatement(m_dbConn, query);
		}


		// public methods


		/**
		 *
		 * @param ch
		 * @param start
		 * @param length
		 */
		public void characters(char[] ch, int start, int length)
		{
			// do nothing
		}
	}

	/**
	 *
	 */
	private class ParseSuiteRows extends ParseTableRoot {

		// constructors


		/**
		 *
		 * @throws SQLException
		 */
		public ParseSuiteRows() throws SQLException
		{
			super(
				"INSERT INTO incasuite ( incaid, incaname, incaguid, incadescription, incaversion ) " +
				"VALUES ( ?, ?, ?, ?, ? )"
			);
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("suiteRows")) {
				m_insertStmt.close();

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("suite"))
				m_states.addFirst(new ParseSuite(this));
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}

		/**
		 *
		 * @param name
		 * @param guid
		 * @param description
		 * @param version
		 * @return
		 * @throws SQLException
		 */
		public long addRecord(String name, String guid, String description, Integer version) throws SQLException
		{
			long suiteId = getNextSequenceValue();

			m_insertStmt.setLong(1, suiteId);
			m_insertStmt.setString(2, name);
			m_insertStmt.setString(3, guid);
			m_insertStmt.setString(4, description);
			m_insertStmt.setInt(5, version);
			m_insertStmt.addBatch();

			return suiteId;
		}
	}

	/**
	 *
	 */
	private class ParseSuite extends Capture {

		private final ParseSuiteRows m_owner;
		private Long m_oldId = null;
		private String m_name = null;
		private String m_guid = null;
		private String m_description = null;
		private Integer m_version = null;


		// constructors


		/**
		 *
		 * @param owner
		 */
		public ParseSuite(ParseSuiteRows owner)
		{
			m_owner = owner;
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("id"))
				m_oldId = getTextAsLong();
			else if (localName.equals("name"))
				m_name = getTextAsString();
			else if (localName.equals("guid"))
				m_guid = getTextAsString();
			else if (localName.equals("description"))
				m_description = getTextAsString();
			else if (localName.equals("version"))
				m_version = getTextAsInteger();
			else if (localName.equals("suite")) {
				long newSuiteId = m_owner.addRecord(m_name, m_guid, m_description, m_version);

				m_suiteIds.put(m_oldId, newSuiteId);

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("id") || localName.equals("name") || localName.equals("guid") ||
					localName.equals("description") || localName.equals("version"))
				startTextCapture();
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}
	}

	/**
	 *
	 */
	private class ParseArgRows extends ParseTableRoot {

		// constructors


		/**
		 *
		 * @throws SQLException
		 */
		public ParseArgRows() throws SQLException
		{
			super(
				"INSERT INTO incaarg ( incaid, incaname, incavalue ) " +
				"VALUES ( ?, ?, ? )"
			);
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("argRows")) {
				m_insertStmt.close();

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("arg"))
				m_states.addFirst(new ParseArg(this));
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}

		/**
		 *
		 * @param name
		 * @param value
		 * @return
		 * @throws SQLException
		 */
		public long addRecord(String name, String value) throws SQLException
		{
			long argId = getNextSequenceValue();

			m_insertStmt.setLong(1, argId);
			m_insertStmt.setString(2, name);
			m_insertStmt.setString(3, value);
			m_insertStmt.addBatch();

			return argId;
		}
	}

	/**
	 *
	 */
	private class ParseArg extends Capture {

		private final ParseArgRows m_owner;
		private Long m_oldId = null;
		private String m_name = null;
		private String m_value = null;


		// constructors


		/**
		 *
		 * @param owner
		 */
		public ParseArg(ParseArgRows owner)
		{
			m_owner = owner;
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("id"))
				m_oldId = getTextAsLong();
			else if (localName.equals("name"))
				m_name = getTextAsString();
			else if (localName.equals("value"))
				m_value = getTextAsString();
			else if (localName.equals("arg")) {
				long newId = m_owner.addRecord(m_name, m_value);

				m_argIds.put(m_oldId, newId);

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("id") || localName.equals("name") || localName.equals("value"))
				startTextCapture();
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}
	}

	/**
	 *
	 */
	private class ParseArgSignatureRows extends ParseTableRoot {

		private final Map<String, Long> m_signatures = new TreeMap<String, Long>();
		private final Map<Long, Set<Arg>> m_mappings = new TreeMap<Long, Set<Arg>>();


		// constructors


		/**
		 *
		 * @throws SQLException
		 */
		public ParseArgSignatureRows() throws SQLException
		{
			super(
				"INSERT INTO incaargsignature ( incaid, incasignature ) " +
				"VALUES ( ?, ? )"
			);
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("argSignatureRows")) {
				m_insertStmt.close();

				insertArgMappings();

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("argSignature"))
				m_states.addFirst(new ParseArgSignature(this));
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}

		/**
		 *
		 * @param signature
		 * @param args
		 * @return
		 * @throws SQLException
		 */
		public long addRecord(String signature, Set<Arg> args) throws SQLException
		{
			long argSignatureId = getNextSequenceValue();

			m_insertStmt.setLong(1, argSignatureId);
			m_insertStmt.setString(2, signature);
			m_insertStmt.addBatch();

			m_signatures.put(signature, argSignatureId);
			m_mappings.put(argSignatureId, args);

			return argSignatureId;
		}

		/**
		 *
		 * @param signature
		 * @return
		 */
		public Long findDuplicate(String signature)
		{
			return m_signatures.get(signature);
		}


		// private methods


		/**
		 *
		 * @throws SQLException
		 */
		private void insertArgMappings() throws SQLException
		{
			BatchUpdateStatement mappingsStmt = new BatchUpdateStatement(m_dbConn,
				"INSERT INTO incaargs ( incaargs_id, incainput_id ) " +
				"VALUES ( ?, ? )"
			);

			for (Map.Entry<Long, Set<Arg>> entry : m_mappings.entrySet()) {
				Long argSignatureId = entry.getKey();

				for (Arg element : entry.getValue()) {
					mappingsStmt.setLong(1, argSignatureId);
					mappingsStmt.setLong(2, element.getId());
					mappingsStmt.addBatch();
				}
			}

			mappingsStmt.close();
		}
	}

	/**
	 *
	 */
	private class ParseArgMappings extends Capture {

		private final List<Long> m_ids = new ArrayList<Long>();
		private final Set<Arg> m_args;


		// constructors


		/**
		 *
		 * @param args
		 */
		public ParseArgMappings(Set<Arg> args)
		{
			m_args = args;
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("id")) {
				Long oldArgId = getTextAsLong();
				Long newArgId = m_argIds.get(oldArgId);

				if (newArgId != null)
					m_ids.add(newArgId);
				else
					m_logger.warn("Couldn't find an Arg record with previous id " + oldArgId);
			}
			else if (localName.equals("args")) {
				if (!m_ids.isEmpty()) {
					StringBuilder clause = new StringBuilder();
					Iterator<Long> ids = m_ids.iterator();

					clause.append(ids.next());

					while (ids.hasNext()) {
						clause.append(", ");
						clause.append(ids.next());
					}

					getArgs(clause.toString());
				}

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("id"))
				startTextCapture();
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}


		// private methods


		/**
		 *
		 * @param clause
		 * @throws SQLException
		 */
		private void getArgs(String clause) throws SQLException
		{
			String query =
				"SELECT incaname, incavalue, incaid " +
				"FROM incaarg " +
				"WHERE incaid IN ( " + clause + " )";
			Statement selectStmt = m_dbConn.createStatement();
			ResultSet rows = null;

			try {
				rows = selectStmt.executeQuery(query);

				while (rows.next()) {
					Arg newArg = new Arg(rows.getString(1), rows.getString(2));

					newArg.setId(rows.getLong(3));

					m_args.add(newArg);
				}
			}
			finally {
				if (rows != null)
					rows.close();

				selectStmt.close();
			}
		}
	}

	/**
	 *
	 */
	private class ParseArgSignature extends Capture {

		private final ParseArgSignatureRows m_owner;
		private final Set<Arg> m_args = new HashSet<Arg>();
		private Long m_oldId = null;


		// constructors


		/**
		 *
		 * @param owner
		 */
		public ParseArgSignature(ParseArgSignatureRows owner)
		{
			m_owner = owner;
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("id"))
				m_oldId = getTextAsLong();
			else if (localName.equals("argSignature")) {
				String signature = (new ArgSignature(m_args)).getSignature();
				Long newId = m_owner.findDuplicate(signature);

				if (newId == null)
					newId = m_owner.addRecord(signature, m_args);
				else
					m_logger.warn("Found a duplicate of ArgSignature record " + newId);

				m_argSignatureIds.put(m_oldId, newId);

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("id"))
				startTextCapture();
			else if (localName.equals("args"))
				m_states.addFirst(new ParseArgMappings(m_args));
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}
	}

	/**
	 *
	 */
	private class ParseSeriesRows extends ParseTableRoot {

		// constructors


		/**
		 *
		 * @throws SQLException
		 */
		public ParseSeriesRows() throws SQLException
		{
			super(
				"INSERT INTO incaseries ( incaid, incareporter, incaversion, incauri, " +
					"incacontext, incanice, incaresource, incaargSignature_id ) " +
				"VALUES ( ?, ?, ?, ?, ?, ?, ?, ? )"
			);
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("seriesRows")) {
				m_insertStmt.close();

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("series"))
				m_states.addFirst(new ParseSeries(this));
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}

		/**
		 *
		 * @param reporter
		 * @param version
		 * @param uri
		 * @param context
		 * @param nice
		 * @param resource
		 * @param argSignatureId
		 * @return
		 * @throws SQLException
		 */
		public long addRecord(String reporter, String version, String uri, String context, Boolean nice, String resource, Long argSignatureId) throws SQLException
		{
			long seriesId = getNextSequenceValue();

			m_insertStmt.setLong(1, seriesId);
			m_insertStmt.setString(2, reporter);
			m_insertStmt.setString(3, version);
			m_insertStmt.setString(4, uri);
			m_insertStmt.setString(5, context);
			m_insertStmt.setBoolean(6, nice);
			m_insertStmt.setString(7, resource);
			m_insertStmt.setLong(8, argSignatureId);
			m_insertStmt.addBatch();

			return seriesId;
		}
	}

	/**
	 *
	 */
	private class ParseSeries extends Capture {

		private final ParseSeriesRows m_owner;
		private Long m_oldId = null;
		private String m_reporter = null;
		private String m_version = null;
		private String m_uri = null;
		private String m_context = null;
		private Boolean m_nice = null;
		private String m_resource = null;
		private Long m_argSignatureId = null;


		// constructors


		/**
		 *
		 * @param owner
		 */
		public ParseSeries(ParseSeriesRows owner)
		{
			m_owner = owner;
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("id"))
				m_oldId = getTextAsLong();
			else if (localName.equals("reporter"))
				m_reporter = getTextAsString();
			else if (localName.equals("version"))
				m_version = getTextAsString();
			else if (localName.equals("uri"))
				m_uri = getTextAsString();
			else if (localName.equals("context"))
				m_context = getTextAsString();
			else if (localName.equals("nice"))
				m_nice = getTextAsBoolean();
			else if (localName.equals("resource"))
				m_resource = getTextAsString();
			else if (localName.equals("argSignatureId")) {
				Long oldSignatureId = getTextAsLong();
				Long newSignatureId = m_argSignatureIds.get(oldSignatureId);

				if (newSignatureId != null)
					m_argSignatureId = newSignatureId;
				else
					m_logger.warn("Couldn't find an ArgSignature record with previous id " + oldSignatureId + " for Series record with previous id " + m_oldId);
			}
			else if (localName.equals("series")) {
				if (m_argSignatureId != null) {
					long newId = m_owner.addRecord(m_reporter, m_version, m_uri, m_context, m_nice, m_resource, m_argSignatureId);

					m_seriesIds.put(m_oldId, newId);
				}

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("id") || localName.equals("reporter") || localName.equals("version") ||
					localName.equals("uri") || localName.equals("context") || localName.equals("nice") ||
					localName.equals("resource") || localName.equals("argSignatureId"))
				startTextCapture();
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}
	}

	/**
	 *
	 */
	private class ParseSeriesConfigRows extends ParseTableRoot {

		private final Map<Long, Set<Long>> m_mappings = new TreeMap<Long, Set<Long>>();


		// constructors


		/**
		 *
		 * @param SQLException
		 */
		public ParseSeriesConfigRows() throws SQLException
		{
			super(
				"INSERT INTO incaseriesconfig ( incaid, incaactivated, incadeactivated, incanickname, " +
					"incawallClockTime, incacpuTime, incamemory, incacomparitor, " +
					"incacomparison, incanotifier, incatarget, incatype, incaminute, " +
					"incahour, incamonth, incamday, incawday, incanumOccurs, " +
					"incasuspended, incaseries_id, incalatestInstanceId, incalatestComparisonId ) " +
				"VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )"
			);
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("seriesConfigRows")) {
				m_insertStmt.close();

				insertSuiteConfigMappings();

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("seriesConfig"))
				m_states.addFirst(new ParseSeriesConfig(this));
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}

		/**
		 *
		 * @param activated
		 * @param deactivated
		 * @param nickname
		 * @param wallClockTime
		 * @param cpuTime
		 * @param memory
		 * @param comparitor
		 * @param comparison
		 * @param notifier
		 * @param target
		 * @param type
		 * @param minute
		 * @param hour
		 * @param month
		 * @param mday
		 * @param wday
		 * @param numOccurs
		 * @param suspended
		 * @param seriesId
		 * @param latestInstanceId
		 * @param latestComparisonId
		 * @param suites
		 * @return
		 * @throws SQLException
		 */
		public long addRecord(Timestamp activated, Timestamp deactivated, String nickname, Float wallClockTime, Float cpuTime, Float memory, String comparitor, String comparison, String notifier, String target, String type, String minute, String hour, String month, String mday, String wday, Integer numOccurs, Boolean suspended, Long seriesId, Long latestInstanceId, Long latestComparisonId, Set<Long> suites) throws SQLException
		{
			long seriesConfigId = getNextSequenceValue();

			m_insertStmt.setLong(1, seriesConfigId);
			m_insertStmt.setTimestamp(2, activated);
			m_insertStmt.setTimestamp(3, deactivated);
			m_insertStmt.setString(4, nickname);
			m_insertStmt.setFloat(5, wallClockTime);
			m_insertStmt.setFloat(6, cpuTime);
			m_insertStmt.setFloat(7, memory);
			m_insertStmt.setString(8, comparitor);
			m_insertStmt.setString(9, comparison);
			m_insertStmt.setString(10, notifier);
			m_insertStmt.setString(11, target);
			m_insertStmt.setString(12, type);
			m_insertStmt.setString(13, minute);
			m_insertStmt.setString(14, hour);
			m_insertStmt.setString(15, month);
			m_insertStmt.setString(16, mday);
			m_insertStmt.setString(17, wday);
			m_insertStmt.setInt(18, numOccurs);
			m_insertStmt.setBoolean(19, suspended);
			m_insertStmt.setLong(20, seriesId);
			m_insertStmt.setLong(21, latestInstanceId);
			m_insertStmt.setLong(22, latestComparisonId);
			m_insertStmt.addBatch();

			m_mappings.put(seriesConfigId, suites);

			return seriesConfigId;
		}


		// private methods


		/**
		 *
		 * @throws SQLException
		 */
		private void insertSuiteConfigMappings() throws SQLException
		{
			BatchUpdateStatement mappingsStmt = new BatchUpdateStatement(m_dbConn,
				"INSERT INTO incasuitesseriesconfigs ( incasuite_id, incaseriesconfig_id ) " +
				"VALUES ( ?, ? )"
			);

			for (Map.Entry<Long, Set<Long>> entry : m_mappings.entrySet()) {
				Long configId = entry.getKey();

				for (Long suiteId : entry.getValue()) {
					mappingsStmt.setLong(1, suiteId);
					mappingsStmt.setLong(2, configId);
					mappingsStmt.addBatch();
				}
			}

			mappingsStmt.close();
		}
	}

	/**
	 *
	 */
	private class ParseSuiteConfigMappings extends Capture {

		private final Set<Long> m_suites;


		// constructors


		/**
		 *
		 * @param suites
		 */
		public ParseSuiteConfigMappings(Set<Long> suites)
		{
			m_suites = suites;
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("id")) {
				Long oldSuiteId = getTextAsLong();
				Long newSuiteId = m_suiteIds.get(oldSuiteId);

				if (newSuiteId != null)
					m_suites.add(newSuiteId);
				else
					m_logger.warn("Couldn't find a Suite record with previous id " + oldSuiteId);
			}
			else if (localName.equals("suites")) {
				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("id"))
				startTextCapture();
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}
	}

	/**
	 *
	 */
	private class ParseSeriesConfig extends Capture {

		private final ParseSeriesConfigRows m_owner;
		private final Set<Long> m_suites = new HashSet<Long>();
		private Long m_oldId = null;
		private Timestamp m_activated = null;
		private Timestamp m_deactivated = null;
		private String m_nickname = null;
		private Float m_wallClockTime = null;
		private Float m_cpuTime = null;
		private Float m_memory = null;
		private String m_comparitor = null;
		private String m_comparison = null;
		private String m_notifier = null;
		private String m_target = null;
		private String m_type = null;
		private String m_minute = null;
		private String m_hour = null;
		private String m_month = null;
		private String m_mday = null;
		private String m_wday = null;
		private Integer m_numOccurs = null;
		private Boolean m_suspended = null;
		private Long m_seriesId = null;
		private Long m_latestInstanceId = null;
		private Long m_latestComparisonId = null;


		// constructors


		/**
		 *
		 * @param owner
		 */
		public ParseSeriesConfig(ParseSeriesConfigRows owner)
		{
			m_owner = owner;
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("id"))
				m_oldId = getTextAsLong();
			else if (localName.equals("activated"))
				m_activated = getTextAsTimestamp();
			else if (localName.equals("deactivated"))
				m_deactivated = getTextAsTimestamp();
			else if (localName.equals("nickname"))
				m_nickname = getTextAsString();
			else if (localName.equals("wallClockTime"))
				m_wallClockTime = getTextAsFloat();
			else if (localName.equals("cpuTime"))
				m_cpuTime = getTextAsFloat();
			else if (localName.equals("memory"))
				m_memory = getTextAsFloat();
			else if (localName.equals("comparitor"))
				m_comparitor = getTextAsString();
			else if (localName.equals("comparison"))
				m_comparison = getTextAsString();
			else if (localName.equals("notifier"))
				m_notifier = getTextAsString();
			else if (localName.equals("target"))
				m_target = getTextAsString();
			else if (localName.equals("type"))
				m_type = getTextAsString();
			else if (localName.equals("minute"))
				m_minute = getTextAsString();
			else if (localName.equals("hour"))
				m_hour = getTextAsString();
			else if (localName.equals("month"))
				m_month = getTextAsString();
			else if (localName.equals("mday"))
				m_mday = getTextAsString();
			else if (localName.equals("wday"))
				m_wday = getTextAsString();
			else if (localName.equals("numOccurs"))
				m_numOccurs = getTextAsInteger();
			else if (localName.equals("suspended"))
				m_suspended = getTextAsBoolean();
			else if (localName.equals("seriesId")) {
				Long oldSeriesId = getTextAsLong();
				Long newSeriesId = m_seriesIds.get(oldSeriesId);

				if (newSeriesId != null)
					m_seriesId = newSeriesId;
				else
					m_logger.warn("Couldn't find a Series record with previous id " + oldSeriesId + " for SeriesConfig record with previous id " + m_oldId);
			}
			else if (localName.equals("latestInstanceId"))
				m_latestInstanceId = getTextAsLong();
			else if (localName.equals("latestComparisonId"))
				m_latestComparisonId = getTextAsLong();
			else if (localName.equals("seriesConfig")) {
				if (m_seriesId != null) {
					long newId = m_owner.addRecord(m_activated, m_deactivated, m_nickname, m_wallClockTime, m_cpuTime, m_memory, m_comparitor, m_comparison, m_notifier, m_target, m_type, m_minute, m_hour, m_month, m_mday, m_wday, m_numOccurs, m_suspended, m_seriesId, m_latestInstanceId, m_latestComparisonId, m_suites);

					m_seriesConfigIds.put(m_oldId, newId);

					if (m_latestInstanceId >= 0)
						m_latestInstanceIds.put(m_latestInstanceId, newId);

					if (m_latestComparisonId >= 0)
						m_latestComparisonIds.put(m_latestComparisonId, newId);
				}

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("id") || localName.equals("activated") || localName.equals("deactivated") ||
					localName.equals("nickname") || localName.equals("wallClockTime") || localName.equals("cpuTime") ||
					localName.equals("memory") || localName.equals("comparitor") || localName.equals("comparison") ||
					localName.equals("notifier") || localName.equals("target") || localName.equals("type") ||
					localName.equals("minute") || localName.equals("hour") || localName.equals("month") ||
					localName.equals("mday") || localName.equals("wday") || localName.equals("numOccurs") ||
					localName.equals("suspended") || localName.equals("seriesId") || localName.equals("latestInstanceId") ||
					localName.equals("latestComparisonId"))
				startTextCapture();
			else if (localName.equals("suites"))
				m_states.addFirst(new ParseSuiteConfigMappings(m_suites));
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}
	}

	/**
	 *
	 */
	private class ParseRunInfoRows extends ParseTableRoot {

		// constructors


		/**
		 *
		 * @throws SQLException
		 */
		public ParseRunInfoRows() throws SQLException
		{
			super(
				"INSERT INTO incaruninfo ( incaid, incahostname, incaworkingDir, incareporterPath, " +
					"incaargSignature_id ) " +
				"VALUES ( ?, ?, ?, ?, ? )"
			);
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("runInfoRows")) {
				m_insertStmt.close();

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("runInfo"))
				m_states.addFirst(new ParseRunInfo(this));
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}

		/**
		 *
		 * @param hostname
		 * @param workingDir
		 * @param reporterPath
		 * @param argSignatureId
		 * @return
		 * @throws SQLException
		 */
		public long addRecord(String hostname, String workingDir, String reporterPath, Long argSignatureId) throws SQLException
		{
			long runInfoId = getNextSequenceValue();

			m_insertStmt.setLong(1, runInfoId);
			m_insertStmt.setString(2, hostname);
			m_insertStmt.setString(3, workingDir);
			m_insertStmt.setString(4, reporterPath);
			m_insertStmt.setLong(5, argSignatureId);
			m_insertStmt.addBatch();

			return runInfoId;
		}
	}

	/**
	 *
	 */
	private class ParseRunInfo extends Capture {

		private final ParseRunInfoRows m_owner;
		private Long m_oldId = null;
		private String m_hostname = null;
		private String m_workingDir = null;
		private String m_reporterPath = null;
		private Long m_argSignatureId = null;


		// constructors


		/**
		 *
		 * @param owner
		 */
		public ParseRunInfo(ParseRunInfoRows owner)
		{
			m_owner = owner;
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("id"))
				m_oldId = getTextAsLong();
			else if (localName.equals("hostname"))
				m_hostname = getTextAsString();
			else if (localName.equals("workingDir"))
				m_workingDir = getTextAsString();
			else if (localName.equals("reporterPath"))
				m_reporterPath = getTextAsString();
			else if (localName.equals("argSignatureId")) {
				Long oldSignatureId = getTextAsLong();
				Long newSignatureId = m_argSignatureIds.get(oldSignatureId);

				if (newSignatureId != null)
					m_argSignatureId = newSignatureId;
				else
					m_logger.warn("Couldn't find an ArgSignature record with previous id " + oldSignatureId + " for RunInfo record with previous id " + m_oldId);
			}
			else if (localName.equals("runInfo")) {
				if (m_argSignatureId != null) {
					long newId = m_owner.addRecord(m_hostname, m_workingDir, m_reporterPath, m_argSignatureId);

					m_runInfoIds.put(m_oldId, newId);
				}

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("id") || localName.equals("hostname") || localName.equals("workingDir") ||
					localName.equals("reporterPath") || localName.equals("argSignatureId"))
				startTextCapture();
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}
	}

	/**
	 *
	 */
	private class ParseReportRows extends ParseTableRoot {

		// constructors


		/**
		 *
		 * @throws SQLException
		 */
		public ParseReportRows() throws SQLException
		{
			super(
				"INSERT INTO incareport ( incaid, incaexit_status, incaexit_message, incabodypart1, " +
					"incabodypart2, incabodypart3, incastderr, incaseries_id, " +
					"incarunInfo_id ) " +
				"VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ? )"
			);
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("reportRows")) {
				m_insertStmt.close();

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("report"))
				m_states.addFirst(new ParseReport(this));
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}

		/**
		 *
		 * @param exitStatus
		 * @param exitMessage
		 * @param bodypart1
		 * @param bodypart2
		 * @param bodypart3
		 * @param stderr
		 * @param seriesId
		 * @param runInfoId
		 * @return
		 * @throws SQLException
		 */
		public long addRecord(Boolean exitStatus, String exitMessage, String bodypart1, String bodypart2, String bodypart3, String stderr, Long seriesId, Long runInfoId) throws SQLException
		{
			long reportId = getNextSequenceValue();

			m_insertStmt.setLong(1, reportId);
			m_insertStmt.setBoolean(2, exitStatus);
			m_insertStmt.setString(3, exitMessage);
			m_insertStmt.setString(4, bodypart1);
			m_insertStmt.setString(5, bodypart2);
			m_insertStmt.setString(6, bodypart3);
			m_insertStmt.setString(7, stderr);
			m_insertStmt.setLong(8, seriesId);
			m_insertStmt.setLong(9, runInfoId);
			m_insertStmt.addBatch();

			return reportId;
		}
	}

	/**
	 *
	 */
	private class ParseReport extends Capture {

		private final ParseReportRows m_owner;
		private Long m_oldId = null;
		private Boolean m_exitStatus = null;
		private String m_exitMessage = null;
		private String m_bodypart1 = null;
		private String m_bodypart2 = null;
		private String m_bodypart3 = null;
		private String m_stderr = null;
		private Long m_seriesId = null;
		private Long m_runInfoId = null;


		// constructors


		/**
		 *
		 * @param owner
		 */
		public ParseReport(ParseReportRows owner)
		{
			m_owner = owner;
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("id"))
				m_oldId = getTextAsLong();
			else if (localName.equals("exitStatus"))
				m_exitStatus = getTextAsBoolean();
			else if (localName.equals("exitMessage"))
				m_exitMessage = getTextAsString();
			else if (localName.equals("bodypart1"))
				m_bodypart1 = getTextAsString();
			else if (localName.equals("bodypart2"))
				m_bodypart2 = getTextAsString();
			else if (localName.equals("bodypart3"))
				m_bodypart3 = getTextAsString();
			else if (localName.equals("stderr"))
				m_stderr = getTextAsString();
			else if (localName.equals("seriesId")) {
				Long oldSeriesId = getTextAsLong();
				Long newSeriesId = m_seriesIds.get(oldSeriesId);

				if (newSeriesId != null)
					m_seriesId = newSeriesId;
				else
					m_logger.warn("Couldn't find a Series record with previous id " + oldSeriesId + " for Report record with previous id " + m_oldId);
			}
			else if (localName.equals("runInfoId")) {
				Long oldRunInfoId = getTextAsLong();
				Long newRunInfoId = m_runInfoIds.get(oldRunInfoId);

				if (newRunInfoId != null)
					m_runInfoId = newRunInfoId;
				else
					m_logger.warn("Couldn't find a RunInfo record with previous id " + oldRunInfoId + " for Report record with previous id " + m_oldId);
			}
			else if (localName.equals("report")) {
				if (m_seriesId != null && m_runInfoId != null) {
					long newId = m_owner.addRecord(m_exitStatus, m_exitMessage, m_bodypart1, m_bodypart2, m_bodypart3, m_stderr, m_seriesId, m_runInfoId);

					m_reportIds.put(m_oldId, newId);
				}

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("id") || localName.equals("exitStatus") || localName.equals("exitMessage") ||
					localName.equals("bodypart1") || localName.equals("bodypart2") || localName.equals("bodypart3") ||
					localName.equals("stderr") || localName.equals("seriesId") || localName.equals("runInfoId"))
				startTextCapture();
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}
	}

	/**
	 *
	 */
	private class ParseComparisonResultRows extends ParseTableRoot {

		private final BatchUpdateStatement m_fixRefsStmt;


		// constructors


		/**
		 *
		 * @throws SQLException
		 */
		public ParseComparisonResultRows() throws SQLException
		{
			super(
				"INSERT INTO incacomparisonresult ( incaid, incaresult, incareportId, incaseriesConfigId ) " +
				"VALUES ( ?, ?, ?, ? )"
			);

			m_fixRefsStmt = new BatchUpdateStatement(m_dbConn,
				"UPDATE incaseriesconfig " +
				"SET incalatestComparisonId = ? " +
				"WHERE incaid = ?"
			);
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("comparisonResultRows")) {
				m_insertStmt.close();
				m_fixRefsStmt.close();

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("comparisonResult"))
				m_states.addFirst(new ParseComparisonResult(this));
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}

		/**
		 *
		 * @param result
		 * @param reportId
		 * @param seriesConfigId
		 * @return
		 * @throws SQLException
		 */
		public long addRecord(String result, Long reportId, Long seriesConfigId) throws SQLException
		{
			long comparisonResultId = getNextSequenceValue();

			m_insertStmt.setLong(1, comparisonResultId);
			m_insertStmt.setString(2, result);
			m_insertStmt.setLong(3, reportId);
			m_insertStmt.setLong(4, seriesConfigId);
			m_insertStmt.addBatch();

			return comparisonResultId;
		}

		/**
		 *
		 * @param comparisonId
		 * @param seriesConfigId
		 * @throws SQLException
		 */
		public void fixReferences(long comparisonId, long seriesConfigId) throws SQLException
		{
			m_fixRefsStmt.setLong(1, comparisonId);
			m_fixRefsStmt.setLong(2, seriesConfigId);
			m_fixRefsStmt.addBatch();
		}
	}

	/**
	 *
	 */
	private class ParseComparisonResult extends Capture {

		private final ParseComparisonResultRows m_owner;
		private Long m_oldId = null;
		private String m_result = null;
		private Long m_reportId = null;
		private Long m_seriesConfigId = null;


		// constructors


		/**
		 *
		 * @param owner
		 */
		public ParseComparisonResult(ParseComparisonResultRows owner)
		{
			m_owner = owner;
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("id"))
				m_oldId = getTextAsLong();
			else if (localName.equals("result"))
				m_result = getTextAsString();
			else if (localName.equals("reportId")) {
				Long oldReportId = getTextAsLong();
				Long newReportId = m_reportIds.get(oldReportId);

				if (newReportId != null)
					m_reportId = newReportId;
				else
					m_logger.warn("Couldn't find a Report record with previous id " + oldReportId + " for ComparisonResult record with previous id " + m_oldId);
			}
			else if (localName.equals("seriesConfigId")) {
				Long oldSeriesConfigId = getTextAsLong();
				Long newSeriesConfigId = m_seriesConfigIds.get(oldSeriesConfigId);

				if (newSeriesConfigId != null)
					m_seriesConfigId = newSeriesConfigId;
				else
					m_logger.warn("Couldn't find a SeriesConfig record with previous id " + oldSeriesConfigId + " for ComparisonResult record with previous id " + m_oldId);
			}
			else if (localName.equals("comparisonResult")) {
				if (m_reportId != null && m_seriesConfigId != null) {
					long newId = m_owner.addRecord(m_result, m_reportId, m_seriesConfigId);

					Long seriesConfigId = m_latestComparisonIds.get(m_oldId);

					if (seriesConfigId != null)
						m_owner.fixReferences(newId, seriesConfigId);
				}

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("id") || localName.equals("result") || localName.equals("reportId") ||
					localName.equals("seriesConfigId"))
				startTextCapture();
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}
	}

	/**
	 *
	 */
	private class ParseInstanceInfoRows extends ParseTableRoot {

		private final Map<Long, Set<Long>> m_mappings = new TreeMap<Long, Set<Long>>();
		private final BatchUpdateStatement m_fixRefsStmt;


		// constructors


		/**
		 *
		 * @throws SQLException
		 */
		public ParseInstanceInfoRows() throws SQLException
		{
			super(
				"INSERT INTO incainstanceinfo ( incaid, incacollected, incacommited, incamemoryUsageMB, " +
					"incacpuUsageSec, incawallClockTimeSec, incalog, incareportId ) " +
				"VALUES ( ?, ?, ?, ?, ?, ?, ?, ? )"
			);

			m_fixRefsStmt = new BatchUpdateStatement(m_dbConn,
				"UPDATE incaseriesconfig " +
				"SET incalatestInstanceId = ? " +
				"WHERE incaid = ?"
			);
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("instanceInfoRows")) {
				m_insertStmt.close();
				m_fixRefsStmt.close();

				insertConfigInstanceMappings();

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("instanceInfo"))
				m_states.addFirst(new ParseInstanceInfo(this));
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}

		/**
		 *
		 * @param collected
		 * @param commited
		 * @param memoryUsageMB
		 * @param cpuUsageSec
		 * @param wallClockTimeSec
		 * @param log
		 * @param reportId
		 * @param seriesConfigs
		 * @return
		 * @throws SQLException
		 */
		public long addRecord(Timestamp collected, Timestamp commited, Float memoryUsageMB, Float cpuUsageSec, Float wallClockTimeSec, String log, Long reportId, Set<Long> seriesConfigs) throws SQLException
		{
			long instanceInfoId = getNextSequenceValue();

			m_insertStmt.setLong(1, instanceInfoId);
			m_insertStmt.setTimestamp(2, collected);
			m_insertStmt.setTimestamp(3, commited);
			m_insertStmt.setFloat(4, memoryUsageMB);
			m_insertStmt.setFloat(5, cpuUsageSec);
			m_insertStmt.setFloat(6, wallClockTimeSec);
			m_insertStmt.setString(7, log);
			m_insertStmt.setLong(8, reportId);
			m_insertStmt.addBatch();

			m_mappings.put(instanceInfoId, seriesConfigs);

			return instanceInfoId;
		}

		/**
		 *
		 * @param instanceId
		 * @param seriesConfigId
		 * @throws SQLException
		 */
		public void fixReferences(long instanceId, long seriesConfigId) throws SQLException
		{
			m_fixRefsStmt.setLong(1, instanceId);
			m_fixRefsStmt.setLong(2, seriesConfigId);
			m_fixRefsStmt.addBatch();
		}


		// private methods


		/**
		 *
		 * @throws SQLException
		 */
		private void insertConfigInstanceMappings() throws SQLException
		{
			BatchUpdateStatement mappingsStmt = new BatchUpdateStatement(m_dbConn,
				"INSERT INTO incaseriesconfigsinstances ( incaseriesconfig_id, incainstance_id ) " +
				"VALUES ( ?, ? )"
			);

			for (Map.Entry<Long, Set<Long>> entry : m_mappings.entrySet()) {
				Long instanceId = entry.getKey();

				for (Long configId : entry.getValue()) {
					mappingsStmt.setLong(1, configId);
					mappingsStmt.setLong(2, instanceId);
					mappingsStmt.addBatch();
				}
			}

			mappingsStmt.close();
		}
	}

	/**
	 *
	 */
	private class ParseConfigInstanceMappings extends Capture {

		private final Set<Long> m_seriesConfigs;


		// constructors


		/**
		 *
		 * @param seriesConfigs
		 */
		public ParseConfigInstanceMappings(Set<Long> seriesConfigs)
		{
			m_seriesConfigs = seriesConfigs;
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("id")) {
				Long oldSeriesConfigId = getTextAsLong();
				Long newSeriesConfigId = m_seriesConfigIds.get(oldSeriesConfigId);

				if (newSeriesConfigId != null)
					m_seriesConfigs.add(newSeriesConfigId);
				else
					m_logger.warn("Couldn't find a SeriesConfig record with previous id " + oldSeriesConfigId);
			}
			else if (localName.equals("seriesConfigs")) {
				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("id"))
				startTextCapture();
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}
	}

	/**
	 *
	 */
	private class ParseInstanceInfo extends Capture {

		private final ParseInstanceInfoRows m_owner;
		private final Set<Long> m_seriesConfigs = new HashSet<Long>();
		private Long m_oldId = null;
		private Timestamp m_collected = null;
		private Timestamp m_commited = null;
		private Float m_memoryUsageMB = null;
		private Float m_cpuUsageSec = null;
		private Float m_wallClockTimeSec = null;
		private String m_log = null;
		private Long m_reportId = null;


		// constructors


		/**
		 *
		 * @param owner
		 */
		public ParseInstanceInfo(ParseInstanceInfoRows owner)
		{
			m_owner = owner;
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("id"))
				m_oldId = getTextAsLong();
			else if (localName.equals("collected"))
				m_collected = getTextAsTimestamp();
			else if (localName.equals("commited"))
				m_commited = getTextAsTimestamp();
			else if (localName.equals("memoryUsageMB"))
				m_memoryUsageMB = getTextAsFloat();
			else if (localName.equals("cpuUsageSec"))
				m_cpuUsageSec = getTextAsFloat();
			else if (localName.equals("wallClockTimeSec"))
				m_wallClockTimeSec = getTextAsFloat();
			else if (localName.equals("log"))
				m_log = getTextAsString();
			else if (localName.equals("reportId")) {
				Long oldReportId = getTextAsLong();
				Long newReportId = m_reportIds.get(oldReportId);

				if (newReportId != null)
					m_reportId = newReportId;
				else
					m_logger.warn("Couldn't find a Report record with previous id " + oldReportId + " for InstanceInfo record with previous id " + m_oldId);
			}
			else if (localName.equals("instanceInfo")) {
				if (m_reportId != null) {
					long newId = m_owner.addRecord(m_collected, m_commited, m_memoryUsageMB, m_cpuUsageSec, m_wallClockTimeSec, m_log, m_reportId, m_seriesConfigs);

					Long seriesConfigId = m_latestInstanceIds.get(m_oldId);

					if (seriesConfigId != null)
						m_owner.fixReferences(newId, seriesConfigId);
				}

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("id") || localName.equals("collected") || localName.equals("commited") ||
					localName.equals("memoryUsageMB") || localName.equals("cpuUsageSec") || localName.equals("wallClockTimeSec") ||
					localName.equals("log") || localName.equals("reportId"))
				startTextCapture();
			else if (localName.equals("seriesConfigs"))
				m_states.addFirst(new ParseConfigInstanceMappings(m_seriesConfigs));
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}
	}

	/**
	 *
	 */
	private class ParseKbArticleRows extends ParseTableRoot {

		// constructors


		/**
		 *
		 * @throws SQLException
		 */
		public ParseKbArticleRows() throws SQLException
		{
			super(
				"INSERT INTO incakbarticle ( incaid, incaentered, incaerrormsg, incaseries, incareporter, " +
					"incaauthorname, incaauthoremail, incaarticletitle, incaarticletext ) " +
				"VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ? )"
			);
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("kbArticleRows")) {
				m_insertStmt.close();

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("kbArticle"))
				m_states.addFirst(new ParseKbArticle(this));
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}

		/**
		 *
		 * @param entered
		 * @param errorMsg
		 * @param series
		 * @param reporter
		 * @param authorName
		 * @param authorEmail
		 * @param articleTitle
		 * @param articleText
		 * @return
		 * @throws SQLException
		 */
		public long addRecord(Timestamp entered, String errorMsg, String series, String reporter, String authorName, String authorEmail, String articleTitle, String articleText) throws SQLException
		{
			long articleId = getNextSequenceValue();

			m_insertStmt.setLong(1, articleId);
			m_insertStmt.setTimestamp(2, entered);
			m_insertStmt.setString(3, errorMsg);
			m_insertStmt.setString(4, series);
			m_insertStmt.setString(5, reporter);
			m_insertStmt.setString(6, authorName);
			m_insertStmt.setString(7, authorEmail);
			m_insertStmt.setString(8, articleTitle);
			m_insertStmt.setString(9, articleText);
			m_insertStmt.addBatch();

			return articleId;
		}
	}

	/**
	 *
	 */
	private class ParseKbArticle extends Capture {

		private final ParseKbArticleRows m_owner;
		private Timestamp m_entered = null;
		private String m_errorMsg = null;
		private String m_series = null;
		private String m_reporter = null;
		private String m_authorName = null;
		private String m_authorEmail = null;
		private String m_articleTitle = null;
		private String m_articleText = null;


		// constructors


		/**
		 *
		 * @param owner
		 */
		public ParseKbArticle(ParseKbArticleRows owner)
		{
			m_owner = owner;
		}


		// public methods


		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @throws SAXException
		 * @throws SQLException
		 */
		public void endElement(String uri, String localName, String qName) throws SAXException, SQLException
		{
			if (localName.equals("entered"))
				m_entered = getTextAsTimestamp();
			else if (localName.equals("errorMsg"))
				m_errorMsg = getTextAsString();
			else if (localName.equals("series"))
				m_series = getTextAsString();
			else if (localName.equals("reporter"))
				m_reporter = getTextAsString();
			else if (localName.equals("authorName"))
				m_authorName = getTextAsString();
			else if (localName.equals("authorEmail"))
				m_authorEmail = getTextAsString();
			else if (localName.equals("articleTitle"))
				m_articleTitle = getTextAsString();
			else if (localName.equals("articleText"))
				m_articleText = getTextAsString();
			else if (localName.equals("kbArticle")) {
				m_owner.addRecord(m_entered, m_errorMsg, m_series, m_reporter, m_authorName, m_authorEmail, m_articleTitle, m_articleText);

				assert m_states.getFirst() == this;

				m_states.removeFirst();
			}
			else
				throw new SAXException("Unexpected end tag for element " + localName);
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SAXException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
		{
			if (localName.equals("entered") || localName.equals("errorMsg") || localName.equals("series") ||
					localName.equals("reporter") || localName.equals("authorName") || localName.equals("authorEmail") ||
					localName.equals("articleTitle") || localName.equals("articleText"))
				startTextCapture();
			else
				throw new SAXException("Unexpected start tag for element " + localName);
		}
	}

	/**
	 *
	 */
	private class Start implements ParserState {

		// public methods


		/**
		 *
		 * @param ch
		 * @param start
		 * @param length
		 */
		public void characters(char[] ch, int start, int length)
		{
			// do nothing
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 */
		public void endElement(String uri, String localName, String qName)
		{
			// do nothing
		}

		/**
		 *
		 * @param uri
		 * @param localName
		 * @param qName
		 * @param atts
		 * @throws SQLException
		 */
		public void startElement(String uri, String localName, String qName, Attributes atts) throws SQLException
		{
			if (localName.equals("suiteRows")) {
				m_logger.debug("Parsing Suite records...");

				m_states.addFirst(new ParseSuiteRows());
			}
			else if (localName.equals("argRows")) {
				m_logger.debug("Parsing Arg records...");

				m_states.addFirst(new ParseArgRows());
			}
			else if (localName.equals("argSignatureRows")) {
				m_logger.debug("Parsing ArgSignature records...");

				m_states.addFirst(new ParseArgSignatureRows());
			}
			else if (localName.equals("seriesRows")) {
				m_logger.debug("Parsing Series records...");

				m_states.addFirst(new ParseSeriesRows());
			}
			else if (localName.equals("seriesConfigRows")) {
				m_logger.debug("Parsing SeriesConfig records...");

				m_states.addFirst(new ParseSeriesConfigRows());
			}
			else if (localName.equals("runInfoRows")) {
				m_logger.debug("Parsing RunInfo records...");

				m_states.addFirst(new ParseRunInfoRows());
			}
			else if (localName.equals("reportRows")) {
				m_logger.debug("Parsing Report records...");

				m_states.addFirst(new ParseReportRows());
			}
			else if (localName.equals("comparisonResultRows")) {
				m_logger.debug("Parsing ComparisonResult records...");

				m_states.addFirst(new ParseComparisonResultRows());
			}
			else if (localName.equals("instanceInfoRows")) {
				m_logger.debug("Parsing InstanceInfo records...");

				m_states.addFirst(new ParseInstanceInfoRows());
			}
			else if (localName.equals("kbArticleRows")) {
				m_logger.debug("Parsing KbArticle records...");

				m_states.addFirst(new ParseKbArticleRows());
			}
		}
	}


	private static final Logger m_logger = Logger.getLogger(SyncResponseParser.class);

	private final Map<Long, Long> m_suiteIds = new TreeMap<Long, Long>();
	private final Map<Long, Long> m_argIds = new TreeMap<Long, Long>();
	private final Map<Long, Long> m_argSignatureIds = new TreeMap<Long, Long>();
	private final Map<Long, Long> m_seriesIds = new TreeMap<Long, Long>();
	private final Map<Long, Long> m_seriesConfigIds = new TreeMap<Long, Long>();
	private final Map<Long, Long> m_runInfoIds = new TreeMap<Long, Long>();
	private final Map<Long, Long> m_reportIds = new TreeMap<Long, Long>();
	private final Map<Long, Long> m_latestComparisonIds = new TreeMap<Long, Long>();
	private final Map<Long, Long> m_latestInstanceIds = new TreeMap<Long, Long>();
	private final LinkedList<ParserState> m_states = new LinkedList<ParserState>();
	private final Connection m_dbConn;
	private final String m_nextSeqValQuery;


	// constructors


	/**
	 *
	 * @param dbConn
	 */
	public SyncResponseParser(Connection dbConn)
	{
		m_dbConn = dbConn;
		m_nextSeqValQuery = ((SessionFactoryImplementor) HibernateUtil.getSessionFactory()).getDialect().getSequenceNextValString("hibernate_sequence");
	}


	// public methods


	/**
	 *
	 * @param ch
	 * @param start
	 * @param length
	 * @throws SAXException
	 */
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException
	{
		m_states.getFirst().characters(ch, start, length);
	}

	/**
	 *
	 */
	@Override
	public void endDocument()
	{
		m_suiteIds.clear();
		m_argIds.clear();
		m_argSignatureIds.clear();
		m_seriesIds.clear();
		m_seriesConfigIds.clear();
		m_runInfoIds.clear();
		m_reportIds.clear();
		m_latestComparisonIds.clear();
		m_latestInstanceIds.clear();
		m_states.clear();
	}

	/**
	 *
	 * @param uri
	 * @param localName
	 * @param qName
	 * @throws SAXException
	 */
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException
	{
		try {
			m_states.getFirst().endElement(uri, localName, qName);
		}
		catch (SQLException sqlErr) {
			SQLException nextErr = sqlErr.getNextException();

			while (nextErr != null) {
				m_logger.error(nextErr.getMessage());

				nextErr = nextErr.getNextException();
			}

			throw new SAXException(sqlErr.getMessage());
		}
	}

	/**
	 *
	 * @throws SAXException
	 */
	@Override
	public void startDocument() throws SAXException
	{
		try {
			m_dbConn.setAutoCommit(false);

			m_states.addFirst(new Start());
		}
		catch (SQLException sqlErr) {
			throw new SAXException(sqlErr.getMessage());
		}
	}

	/**
	 *
	 * @param uri
	 * @param localName
	 * @param qName
	 * @param atts
	 * @throws SAXException
	 */
	@Override
	public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException
	{
		try {
			m_states.getFirst().startElement(uri, localName, qName, atts);
		}
		catch (SQLException sqlErr) {
			throw new SAXException(sqlErr.getMessage());
		}
	}

	/**
	 *
	 * @param inStream
	 * @throws SQLException
	 * @throws IOException
	 * @throws SAXException
	 */
	public static void parseResponse(InputStream inStream) throws SQLException, IOException, SAXException
	{
		Connection dbConn = ((SessionFactoryImplementor) HibernateUtil.getSessionFactory()).getConnectionProvider().getConnection();

		try {
			parseResponse(dbConn, inStream);
		}
		finally {
			dbConn.close();
		}
	}


	// private methods


	/**
	 *
	 * @param dbConn
	 * @param inStream
	 * @throws IOException
	 * @throws SAXException
	 */
	private static void parseResponse(Connection dbConn, InputStream inStream) throws IOException, SAXException
	{
		SyncResponseParser handler = new SyncResponseParser(dbConn);
		XMLReader reader = XMLReaderFactory.createXMLReader();

		reader.setContentHandler(handler);
		reader.setDTDHandler(handler);
		reader.setEntityResolver(handler);
		reader.setErrorHandler(handler);

		reader.parse(new InputSource(inStream));
	}

	/**
	 *
	 * @return
	 * @throws SQLException
	 */
	private long getNextSequenceValue() throws SQLException
	{
		Statement selectStmt = m_dbConn.createStatement();
		ResultSet row = null;

		try {
			row = selectStmt.executeQuery(m_nextSeqValQuery);

			if (!row.next())
				return -1;

			return row.getLong(1);
		}
		finally {
			if (row != null)
				row.close();

			selectStmt.close();
		}
	}
}
