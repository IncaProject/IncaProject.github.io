/*
 * DepotMessageHandler.java
 */
package edu.sdsc.inca.depot.util;


import edu.sdsc.inca.Depot;
import edu.sdsc.inca.protocol.MessageHandler;


/**
 *
 * @author Paul Hoover
 *
 */
public abstract class DepotMessageHandler extends MessageHandler {

	protected static final byte SP = ' ';
	protected static final byte[] CRLF = "\r\n".getBytes();

	private static Depot m_depot = null;


	// public methods


	/**
	 *
	 * @param depot
	 */
	public static void setDepot(Depot depot)
	{
		m_depot = depot;
	}

	/**
	 *
	 * @return
	 */
	public static Depot getDepot()
	{
		return m_depot;
	}
}
