/*
 * UpdateDBSchema.java
 */
package edu.sdsc.inca.depot;


import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.log4j.Logger;
import org.hibernate.engine.SessionFactoryImplementor;

import edu.sdsc.inca.depot.persistent.HibernateUtil;


/**
 *
 * @author Paul Hoover
 *
 */
public class UpdateDBSchema {

	/**
	 *
	 */
	private static class ConfigRecord implements Comparable<ConfigRecord> {

		public final long configId;
		public int activated;
		public int deactivated;
		public long latestId;
		public boolean isActive;
		public Timestamp activatedDate;
		public Timestamp deactivatedDate;
		public String nickname;


		/**
		 *
		 * @param id
		 * @param act
		 * @param deact;
		 * @param latest
		 * @param nick
		 */
		private ConfigRecord(long id, int act, int deact, long latest, String nick)
		{
			configId = id;
			activated = act;
			deactivated = deact;
			latestId = latest;
			isActive = act >= deact;
			nickname = nick;
		}

		/**
		 *
		 * @param other
		 * @return
		 */
		@Override
		public boolean equals(Object other)
		{
			if (other == null)
				return false;

			if (this == other)
				return true;

			if (other instanceof ConfigRecord == false)
				return false;

			ConfigRecord otherConfig = (ConfigRecord) other;

			return configId == otherConfig.configId;
		}

		/**
		 *
		 * @return
		 */
		@Override
		public int hashCode()
		{
			return (new Long(configId)).hashCode();
		}

		/**
		 *
		 * @param other
		 * @return
		 */
		public int compareTo(ConfigRecord other)
		{
			if (other == null)
				throw new NullPointerException("other");

			if (this == other)
				return 0;

			return (int) (configId - other.configId);
		}
	}


	/**
	 *
	 */
	private static class ConfigLinkingRecord implements Comparable<ConfigLinkingRecord> {

		public final long configId;
		public Timestamp activated;
		public Timestamp deactivated;


		/**
		 *
		 * @param id
		 * @param act
		 * @param deact
		 */
		private ConfigLinkingRecord(long id, Timestamp act, Timestamp deact)
		{
			configId = id;
			activated = act;
			deactivated = deact;
		}

		/**
		 *
		 * @param other
		 * @return
		 */
		@Override
		public boolean equals(Object other)
		{
			if (other == null)
				return false;

			if (this == other)
				return true;

			if (other instanceof ConfigLinkingRecord == false)
				return false;

			ConfigLinkingRecord otherConfig = (ConfigLinkingRecord) other;

			return configId == otherConfig.configId;
		}

		/**
		 *
		 * @return
		 */
		@Override
		public int hashCode()
		{
			return (new Long(configId)).hashCode();
		}

		/**
		 *
		 * @param other
		 * @return
		 */
		public int compareTo(ConfigLinkingRecord other)
		{
			if (other == null)
				throw new NullPointerException("other");

			if (this == other)
				return 0;

			return (int) (configId - other.configId);
		}
	}


	/**
	 *
	 */
	private static class ConfigInstanceLink {

		public final long configId;
		public final long instanceId;

		/**
		 *
		 * @param config
		 * @param instance
		 */
		private ConfigInstanceLink(long config, long instance)
		{
			configId = config;
			instanceId = instance;
		}
	}


	private static final int FETCH_SIZE = 100;
	private static final int BATCH_SIZE = 100;
	private static final String HSQL_DB_NAME = "HSQL Database Engine";
	private static final String ORACLE_DB_NAME = "Oracle";
	private static final String POSTGRESQL_DB_NAME = "PostgreSQL";
	private static final String ARTICLE_TABLE_NAME = "incakbarticle";
	private static final String SUITE_LINKING_TABLE_NAME = "incasuitesseriesconfigs";
	private static final String INSTANCE_LINKING_TABLE_NAME = "incaseriesconfigsinstances";
	private static final String SERIES_TABLE_NAME = "incaseries";
	private static final String CONFIG_TABLE_NAME = "incaseriesconfig";
	private static final String ACTIVATED_COLUMN_NAME = "incaactivated";
	private static final String SUITE_ID_COLUMN_NAME = "incasuite_id";
	private static final String TARGET_COLUMN_NAME = "incatargethostname";

	private static final Logger m_logger = Logger.getLogger(UpdateDBSchema.class);


	// public methods


	/**
	 *
	 * @return
	 * @throws SQLException
	 */
	public static boolean update() throws SQLException
	{
		Connection dbConn = ((SessionFactoryImplementor) HibernateUtil.getSessionFactory()).getConnectionProvider().getConnection();
		boolean updated = false;

		try {
			dbConn.setAutoCommit(false);

			DatabaseMetaData dbData = dbConn.getMetaData();

			if (!hasTable(dbData, ARTICLE_TABLE_NAME)) {
				m_logger.info("Creating KbArticle table...");

				createArticleTable(dbConn, dbData);

				updated = true;
			}

			if (!hasTable(dbData, SUITE_LINKING_TABLE_NAME)) {
				m_logger.info("Creating Suite/SeriesConfig linking table...");

				createSuiteConfigLinkingTable(dbConn, dbData);

				m_logger.debug("Populating linking table...");

				populateSuiteConfigLinkingTable(dbConn);

				m_logger.debug("Dropping SuiteId column...");

				dropSuiteIdColumn(dbConn, dbData);

				updated = true;
			}

			if (!hasColumnDataType(dbData, CONFIG_TABLE_NAME, ACTIVATED_COLUMN_NAME, getDateTypeName(dbData))) {
				m_logger.info("Altering SeriesConfig table activated/deactivated columns...");

				m_logger.debug("Fetching SeriesConfig records...");

				Map<Long, Set<ConfigRecord>> configRecords = getConfigRecords(dbConn);

				m_logger.debug("Creating new activated/deactivated columns...");

				alterActivatedColumns(dbConn, dbData);

				m_logger.debug("Populating new activated/deactivated columns...");

				populateActivatedColumns(dbConn, configRecords);

				updated = true;
			}

			if (!hasTable(dbData, INSTANCE_LINKING_TABLE_NAME)) {
				m_logger.info("Creating SeriesConfig/Instance linking table...");

				createConfigInstanceLinkingTable(dbConn, dbData);

				m_logger.debug("Fetching SeriesConfig records...");

				Map<Long, Set<ConfigLinkingRecord>> configRecords = getConfigLinkingRecords();

				m_logger.debug("Populating linking table...");

				populateConfigInstanceLinkingTable(dbConn, configRecords);

				updated = true;
			}

			if (!hasColumn(dbData, SERIES_TABLE_NAME, TARGET_COLUMN_NAME)) {
				m_logger.info("Adding target hostname column to Series table...");

				alterSeriesTable(dbConn, dbData);

				updated = true;
			}
		}
		finally {
			dbConn.close();
		}

		return updated;
	}


	// private methods


	/**
	 *
	 * @param dbData
	 * @param table
	 * @return
	 * @throws SQLException
	 */
	private static boolean hasTable(DatabaseMetaData dbData, String table) throws SQLException
	{
		String tableName = dbData.storesUpperCaseIdentifiers() ? table.toUpperCase() : table;
		ResultSet row = dbData.getTables(null, null, tableName, null);

		try {
			return row.next();
		}
		finally {
			row.close();
		}
	}

	/**
	 *
	 * @param dbData
	 * @param table
	 * @param column
	 * @return
	 * @throws SQLException
	 */
	private static boolean hasColumn(DatabaseMetaData dbData, String table, String column) throws SQLException
	{
		boolean upperCase = dbData.storesUpperCaseIdentifiers();
		String tableName = upperCase ? table.toUpperCase() : table;
		String columnName = upperCase ? column.toUpperCase() : column;
		ResultSet row = dbData.getColumns(null, null, tableName, columnName);

		try {
			return row.next();
		}
		finally {
			row.close();
		}
	}

	/**
	 *
	 * @param dbData
	 * @param table
	 * @param column
	 * @param type
	 * @return
	 * @throws SQLException
	 */
	private static boolean hasColumnDataType(DatabaseMetaData dbData, String table, String column, String type) throws SQLException
	{
		boolean upperCase = dbData.storesUpperCaseIdentifiers();
		String tableName = upperCase ? table.toUpperCase() : table;
		String columnName = upperCase ? column.toUpperCase() : column;
		ResultSet row = dbData.getColumns(null, null, tableName, columnName);

		try {
			if (!row.next())
				return false;

			String typeName = row.getString(6);

			return typeName.equalsIgnoreCase(type);
		}
		finally {
			row.close();
		}
	}

	/**
	 *
	 * @param dbData
	 * @return
	 * @throws SQLException
	 */
	private static String getLongTypeName(DatabaseMetaData dbData) throws SQLException
	{
		String name = dbData.getDatabaseProductName();

		if (name.equals(HSQL_DB_NAME))
			return "bigint";
		else if (name.equals(ORACLE_DB_NAME))
			return "number(19,0)";
		else if (name.equals(POSTGRESQL_DB_NAME))
			return "int8";
		else
			return null;
	}

	/**
	 *
	 * @param dbData
	 * @return
	 * @throws SQLException
	 */
	private static String getStringTypeName(DatabaseMetaData dbData) throws SQLException
	{
		String name = dbData.getDatabaseProductName();

		if (name.equals(HSQL_DB_NAME) || name.equals(POSTGRESQL_DB_NAME))
			return "varchar";
		else if (name.equals(ORACLE_DB_NAME))
			return "varchar2";
		else
			return null;
	}

	/**
	 *
	 * @param dbData
	 * @return
	 * @throws SQLException
	 */
	private static String getDateTypeName(DatabaseMetaData dbData) throws SQLException
	{
		String name = dbData.getDatabaseProductName();

		if (name.equals(HSQL_DB_NAME) || name.equals(POSTGRESQL_DB_NAME))
			return "timestamp";
		else if (name.equals(ORACLE_DB_NAME))
			return "date";
		else
			return null;
	}

	/**
	 *
	 * @param dbData
	 * @return
	 * @throws SQLException
	 */
	private static String getTextTypeName(DatabaseMetaData dbData) throws SQLException
	{
		String name = dbData.getDatabaseProductName();

		if (name.equals(HSQL_DB_NAME))
			return "longvarchar";
		else if (name.equals(ORACLE_DB_NAME))
			return "clob";
		else if (name.equals(POSTGRESQL_DB_NAME))
			return "text";
		else
			return null;
	}

	/**
	 *
	 * @param dbConn
	 * @param dbData
	 * @throws SQLException
	 */
	private static void createArticleTable(Connection dbConn, DatabaseMetaData dbData) throws SQLException
	{
		String longTypeName = getLongTypeName(dbData);
		String dateTypeName = getDateTypeName(dbData);
		String stringTypeName = getStringTypeName(dbData);
		String textTypeName = getTextTypeName(dbData);
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("CREATE TABLE " + ARTICLE_TABLE_NAME + " ( incaid ");
		queryBuilder.append(longTypeName);
		queryBuilder.append(" NOT NULL, incaentered ");
		queryBuilder.append(dateTypeName);
		queryBuilder.append(" NOT NULL, incaerrormsg ");
		queryBuilder.append(stringTypeName);
		queryBuilder.append("(4000), incaseries ");
		queryBuilder.append(stringTypeName);
		queryBuilder.append("(255) NOT NULL, incareporter ");
		queryBuilder.append(stringTypeName);
		queryBuilder.append("(255) NOT NULL, incaauthorname ");
		queryBuilder.append(stringTypeName);
		queryBuilder.append("(255) NOT NULL, incaauthoremail ");
		queryBuilder.append(stringTypeName);
		queryBuilder.append("(255) NOT NULL, incaarticletitle ");
		queryBuilder.append(stringTypeName);
		queryBuilder.append("(2000) NOT NULL, incaarticletext ");
		queryBuilder.append(textTypeName);
		queryBuilder.append(" NOT NULL, PRIMARY KEY (incaid) )");

		Statement updateStmt = dbConn.createStatement();

		try {
			updateStmt.executeUpdate(queryBuilder.toString());

			dbConn.commit();
		}
		finally {
			updateStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param dbData
	 * @throws SQLException
	 */
	private static void createSuiteConfigLinkingTable(Connection dbConn, DatabaseMetaData dbData) throws SQLException
	{
		String longTypeName = getLongTypeName(dbData);
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("CREATE TABLE " + SUITE_LINKING_TABLE_NAME + " ( incasuite_id ");
		queryBuilder.append(longTypeName);
		queryBuilder.append(" NOT NULL, incaseriesconfig_id ");
		queryBuilder.append(longTypeName);
		queryBuilder.append(" NOT NULL, PRIMARY KEY (incasuite_id, incaseriesconfig_id), " +
				"FOREIGN KEY (incasuite_id) REFERENCES incasuite (incaid), " +
				"FOREIGN KEY (incaseriesconfig_id) REFERENCES " + CONFIG_TABLE_NAME + " (incaid) )");

		Statement updateStmt = dbConn.createStatement();

		try {
			updateStmt.executeUpdate(queryBuilder.toString());

			dbConn.commit();
		}
		finally {
			updateStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @return
	 * @throws SQLException
	 */
	private static Map<Long, List<Long>> getSuiteConfigLinkingIds(Connection dbConn) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaid, incasuite_id " +
				"FROM " + CONFIG_TABLE_NAME
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			Map<Long, List<Long>> result = new TreeMap<Long, List<Long>>();

			while (rows.next()) {
				long seriesConfigId = rows.getLong(1);
				long suiteId = rows.getLong(2);
				List<Long> configIds = result.get(suiteId);

				if (configIds == null) {
					configIds = new ArrayList<Long>();

					result.put(suiteId, configIds);
				}

				configIds.add(seriesConfigId);
			}

			return result;
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @throws SQLException
	 */
	private static void populateSuiteConfigLinkingTable(Connection dbConn) throws SQLException
	{
		Map<Long, List<Long>> suiteConfigIds = getSuiteConfigLinkingIds(dbConn);

		if (m_logger.isDebugEnabled()) {
			int numConfigs = 0;

			for (List<Long> configIds : suiteConfigIds.values())
				numConfigs += configIds.size();

			m_logger.debug("Linking " + suiteConfigIds.size() + " Suites with " + numConfigs + " SeriesConfigs...");
		}

		BatchUpdateStatement insertStmt = new BatchUpdateStatement(dbConn,
				"INSERT INTO " + SUITE_LINKING_TABLE_NAME + " ( incasuite_id, incaseriesconfig_id ) " +
				"VALUES ( ?, ? )"
		);

		try {
			for (Map.Entry<Long, List<Long>> entry : suiteConfigIds.entrySet()) {
				Long suiteId = entry.getKey();
				List<Long> configIds = entry.getValue();

				m_logger.debug("Linking Suite " + suiteId + " with " + configIds.size() + " SeriesConfigs...");

				for (Long seriesConfigId : configIds) {
					insertStmt.setLong(1, suiteId);
					insertStmt.setLong(2, seriesConfigId);
					insertStmt.addBatch();
				}
			}
		}
		finally {
			insertStmt.close();
		}

		m_logger.debug("Finished linking Suites with SeriesConfigs");
	}

	/**
	 *
	 * @param dbData
	 * @return
	 * @throws SQLException
	 */
	private static String getForeignKeyName(DatabaseMetaData dbData) throws SQLException
	{
		boolean upperCase = dbData.storesUpperCaseIdentifiers();
		String tableName = upperCase ? CONFIG_TABLE_NAME.toUpperCase() : CONFIG_TABLE_NAME;
		String columnName = upperCase ? SUITE_ID_COLUMN_NAME.toUpperCase() : SUITE_ID_COLUMN_NAME;
		ResultSet rows = dbData.getImportedKeys(null, null, tableName);

		try {
			while (rows.next()) {
				if (rows.getString(8).equals(columnName))
					return rows.getString(12);
			}

			return null;
		}
		finally {
			rows.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param dbData
	 * @throws SQLException
	 */
	private static void dropSuiteIdColumn(Connection dbConn, DatabaseMetaData dbData) throws SQLException
	{
		String keyName = getForeignKeyName(dbData);
		Statement updateStmt = dbConn.createStatement();

		try {
			updateStmt.executeUpdate(
					"ALTER TABLE " + CONFIG_TABLE_NAME +
					" DROP CONSTRAINT " + keyName
			);

			updateStmt.executeUpdate(
					"ALTER TABLE " + CONFIG_TABLE_NAME +
					" DROP COLUMN incasuite_id"
			);

			dbConn.commit();
		}
		catch (SQLException sqlErr) {
			dbConn.rollback();

			throw sqlErr;
		}
		finally {
			updateStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @return
	 * @throws SQLException
	 */
	private static Map<Long, Set<ConfigRecord>> getConfigRecords(Connection dbConn) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaseries_id, incaseriesconfig.incaid, incaactivated, " +
					"incadeactivated, incalatestinstanceid, incanickname " +
				"FROM incaseriesconfig " +
					"INNER JOIN incaseries ON incaseriesconfig.incaseries_id = incaseries.incaid"
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			Map<Long, Set<ConfigRecord>> result = new TreeMap<Long, Set<ConfigRecord>>();

			while (rows.next()) {
				long seriesId = rows.getLong(1);
				long configId = rows.getLong(2);
				int activated = rows.getInt(3);
				int deactivated = rows.getInt(4);
				long latestId = rows.getLong(5);
				String nickname = rows.getString(6);
				ConfigRecord newRecord = new ConfigRecord(configId, activated, deactivated, latestId, nickname);
				Set<ConfigRecord> configs = result.get(seriesId);

				if (configs == null) {
					configs = new TreeSet<ConfigRecord>();

					result.put(seriesId, configs);
				}

				configs.add(newRecord);
			}

			return result;
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param dbData
	 * @throws SQLException
	 */
	private static void alterActivatedColumns(Connection dbConn, DatabaseMetaData dbData) throws SQLException
	{
		String dateTypeName = getDateTypeName(dbData);
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("ALTER TABLE " + CONFIG_TABLE_NAME);
		queryBuilder.append(" ADD COLUMN incaactivated ");
		queryBuilder.append(dateTypeName);
		queryBuilder.append(", ADD COLUMN incadeactivated ");
		queryBuilder.append(dateTypeName);

		Statement updateStmt = dbConn.createStatement();

		try {
			updateStmt.executeUpdate(
					"ALTER TABLE " + CONFIG_TABLE_NAME +
					" DROP COLUMN incaactivated," +
					" DROP COLUMN incadeactivated"
			);

			updateStmt.executeUpdate(queryBuilder.toString());

			dbConn.commit();
		}
		catch (SQLException sqlErr) {
			dbConn.rollback();

			throw sqlErr;
		}
		finally {
			updateStmt.close();
		}
	}

	/**
	 *
	 * @param reportId
	 * @return
	 * @throws SQLException
	 */
	private static Map<Long, Timestamp> getInstanceDates(long reportId) throws SQLException
	{
		Connection dbConn = ((SessionFactoryImplementor) HibernateUtil.getSessionFactory()).getConnectionProvider().getConnection();
		PreparedStatement selectStmt = null;
		ResultSet rows = null;

		try {
			selectStmt = dbConn.prepareStatement(
					"SELECT incaid, incacollected " +
					"FROM incainstanceinfo " +
					"WHERE incareportid = ?"
			);

			selectStmt.setFetchSize(FETCH_SIZE);
			selectStmt.setLong(1, reportId);

			rows = selectStmt.executeQuery();

			Map<Long, Timestamp> result = new TreeMap<Long, Timestamp>();

			while (rows.next()) {
				long instanceId = rows.getLong(1);
				Timestamp collected = rows.getTimestamp(2);

				result.put(instanceId, collected);
			}

			return result;
		}
		finally {
			if (rows != null)
				rows.close();

			if (selectStmt != null)
				selectStmt.close();

			dbConn.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param seriesId
	 * @return
	 * @throws SQLException
	 */
	private static Map<Long, Map<Long, Timestamp>> getReportDates(Connection dbConn, long seriesId) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaid " +
				"FROM incareport " +
				"WHERE incaseries_id = ?"
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);
			selectStmt.setLong(1, seriesId);

			rows = selectStmt.executeQuery();

			Map<Long, Map<Long, Timestamp>> result = new TreeMap<Long, Map<Long, Timestamp>>();

			while (rows.next()) {
				long reportId = rows.getLong(1);
				Map<Long, Timestamp> instances = getInstanceDates(reportId);

				result.put(reportId, instances);
			}

			return result;
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param configId
	 * @return
	 * @throws SQLException
	 */
	private static List<Long> getReportIdsFromComparisons(Connection dbConn, long configId) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT DISTINCT incareportid " +
				"FROM incacomparisonresult " +
				"WHERE incaseriesconfigid = ?"
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);
			selectStmt.setLong(1, configId);

			rows = selectStmt.executeQuery();

			if (!rows.next())
				return null;

			List<Long> result = new ArrayList<Long>();

			do {
				result.add(rows.getLong(1));
			}
			while (rows.next());

			return result;
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param seriesId
	 * @return
	 * @throws SQLException
	 */
	private static List<Long> getReportIdsFromReports(Connection dbConn, long seriesId) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaid " +
				"FROM incareport " +
				"WHERE incaseries_id = ?"
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);
			selectStmt.setLong(1, seriesId);

			rows = selectStmt.executeQuery();

			if (!rows.next())
				return null;

			List<Long> result = new ArrayList<Long>();

			do {
				result.add(rows.getLong(1));
			}
			while (rows.next());

			return result;
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param configId
	 * @param seriesId
	 * @return
	 * @throws SQLException
	 */
	private static List<Long> getReportIds(Connection dbConn, long configId, long seriesId) throws SQLException
	{
		List<Long> reportIds = getReportIdsFromComparisons(dbConn, configId);

		if (reportIds == null)
			reportIds = getReportIdsFromReports(dbConn, seriesId);

		if (reportIds == null)
			return new ArrayList<Long>();

		return reportIds;
	}

	/**
	 *
	 * @param dbConn
	 * @param records
	 * @throws SQLException
	 */
	private static void updateConfigColumns(Connection dbConn, List<ConfigRecord> records) throws SQLException
	{
		PreparedStatement updateStmt = dbConn.prepareStatement(
				"UPDATE " + CONFIG_TABLE_NAME +
				" SET incaactivated = ?, incadeactivated = ?" +
				" WHERE incaid = ?"
		);

		try {
			for (ConfigRecord record : records) {
				updateStmt.setTimestamp(1, record.activatedDate);
				updateStmt.setTimestamp(2, record.deactivatedDate);
				updateStmt.setLong(3, record.configId);
				updateStmt.addBatch();
			}

			updateStmt.executeBatch();

			dbConn.commit();
		}
		catch (SQLException sqlErr) {
			dbConn.rollback();

			throw sqlErr;
		}
		finally {
			updateStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param configRecords
	 * @throws SQLException
	 */
	private static void populateActivatedColumns(Connection dbConn, Map<Long, Set<ConfigRecord>> configRecords) throws SQLException
	{
		if (m_logger.isDebugEnabled()) {
			int numConfigs = 0;

			for (Set<ConfigRecord> configs : configRecords.values())
				numConfigs += configs.size();

			m_logger.debug("Updating columns for " + numConfigs + " SeriesConfigs...");
		}

		int totalUpdates = 0;
		List<ConfigRecord> updates = new ArrayList<ConfigRecord>();

		for (Map.Entry<Long, Set<ConfigRecord>> entry : configRecords.entrySet()) {
			long seriesId = entry.getKey();
			Set<ConfigRecord> configs = entry.getValue();
			Map<Long, Map<Long, Timestamp>> reportDates = getReportDates(dbConn, seriesId);
			Map<String, Map<Integer, Timestamp>> deactivationDates = new TreeMap<String, Map<Integer, Timestamp>>();

			for (ConfigRecord record : configs) {
				if (!record.isActive && record.latestId >= 0) {
					for (Map<Long, Timestamp> instances : reportDates.values()) {
						Timestamp collected = instances.get(record.latestId);

						if (collected != null) {
							Calendar adjusted = Calendar.getInstance();

							adjusted.setTime(collected);
							adjusted.add(Calendar.SECOND, 1);

							record.deactivatedDate = new Timestamp(adjusted.getTimeInMillis());

							Map<Integer, Timestamp> versions = deactivationDates.get(record.nickname);

							if (versions == null) {
								versions = new TreeMap<Integer, Timestamp>();

								deactivationDates.put(record.nickname, versions);
							}

							versions.put(record.deactivated, record.deactivatedDate);

							break;
						}
					}
				}
			}

			for (ConfigRecord record : configs) {
				Map<Integer, Timestamp> versions = deactivationDates.get(record.nickname);
				List<Long> reportIds = null;

				if (versions != null)
					record.activatedDate = versions.get(record.activated);

				if (record.activatedDate == null) {
					reportIds = getReportIds(dbConn, record.configId, seriesId);

					for (Long reportId : reportIds) {
						Map<Long, Timestamp> instances = reportDates.get(reportId);

						if (instances != null) {
							for (Timestamp collected : instances.values()) {
								if (record.activatedDate == null || record.activatedDate.after(collected))
									record.activatedDate = collected;
							}
						}
					}

					if (record.activatedDate == null)
						record.activatedDate = new Timestamp(1);
					else {
						Calendar adjusted = Calendar.getInstance();

						adjusted.setTime(record.activatedDate);
						adjusted.add(Calendar.SECOND, -1);

						record.activatedDate.setTime(adjusted.getTimeInMillis());
					}
				}

				if (!record.isActive && record.deactivatedDate == null) {
					if (reportIds == null)
						reportIds = getReportIds(dbConn, record.configId, seriesId);

					for (Long reportId : reportIds) {
						Map<Long, Timestamp> instances = reportDates.get(reportId);

						if (instances != null) {
							for (Timestamp collected : instances.values()) {
								if (record.deactivatedDate == null || record.deactivatedDate.before(collected))
									record.deactivatedDate = collected;
							}
						}
					}

					if (record.deactivatedDate == null)
						record.deactivatedDate = record.activatedDate;

					Calendar cal = Calendar.getInstance();

					cal.setTime(record.deactivatedDate);
					cal.add(Calendar.SECOND, 1);

					record.deactivatedDate = new Timestamp(cal.getTimeInMillis());
				}

				updates.add(record);

				if (updates.size() >= BATCH_SIZE) {
					updateConfigColumns(dbConn, updates);

					updates.clear();

					if (m_logger.isDebugEnabled()) {
						totalUpdates += BATCH_SIZE;

						m_logger.debug("Updated " + totalUpdates + " rows so far...");
					}
				}
			}
		}

		if (updates.size() > 0)
			updateConfigColumns(dbConn, updates);

		m_logger.debug("Finished updating columns for SeriesConfigs");
	}

	/**
	 *
	 * @param dbConn
	 * @param dbData
	 * @throws SQLException
	 */
	private static void createConfigInstanceLinkingTable(Connection dbConn, DatabaseMetaData dbData) throws SQLException
	{
		String longTypeName = getLongTypeName(dbData);
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("CREATE TABLE " + INSTANCE_LINKING_TABLE_NAME + " ( incaseriesconfig_id ");
		queryBuilder.append(longTypeName);
		queryBuilder.append(" NOT NULL, incainstance_id ");
		queryBuilder.append(longTypeName);
		queryBuilder.append(" NOT NULL, PRIMARY KEY (incaseriesconfig_id, incainstance_id), " +
				"FOREIGN KEY (incaseriesconfig_id) REFERENCES " + CONFIG_TABLE_NAME + " (incaid), " +
				"FOREIGN KEY (incainstance_id) REFERENCES incainstanceinfo (incaid) )");

		Statement updateStmt = dbConn.createStatement();

		try {
			updateStmt.executeUpdate(queryBuilder.toString());

			dbConn.commit();
		}
		finally {
			updateStmt.close();
		}
	}

	/**
	 *
	 * @return
	 * @throws SQLException
	 */
	private static Map<Long, Set<ConfigLinkingRecord>> getConfigLinkingRecords() throws SQLException
	{
		Connection dbConn = ((SessionFactoryImplementor) HibernateUtil.getSessionFactory()).getConnectionProvider().getConnection();
		PreparedStatement selectStmt = null;
		ResultSet rows = null;

		try {
			selectStmt = dbConn.prepareStatement(
					"SELECT incaid, incaseries_id, incaactivated, incadeactivated " +
					"FROM " + CONFIG_TABLE_NAME
			);

			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			Map<Long, Set<ConfigLinkingRecord>> result = new TreeMap<Long, Set<ConfigLinkingRecord>>();

			while (rows.next()) {
				long configId = rows.getLong(1);
				long seriesId = rows.getLong(2);
				Timestamp activated = rows.getTimestamp(3);
				Timestamp deactivated = rows.getTimestamp(4);
				ConfigLinkingRecord newRecord = new ConfigLinkingRecord(configId, activated, deactivated);
				Set<ConfigLinkingRecord> configs = result.get(seriesId);

				if (configs == null) {
					configs = new TreeSet<ConfigLinkingRecord>();

					result.put(seriesId, configs);
				}

				configs.add(newRecord);
			}

			return result;
		}
		finally {
			if (rows != null)
				rows.close();

			if (selectStmt != null)
				selectStmt.close();

			dbConn.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param links
	 * @throws SQLException
	 */
	private static void insertLinkingRows(Connection dbConn, List<ConfigInstanceLink> links) throws SQLException
	{
		PreparedStatement insertStmt = dbConn.prepareStatement(
				"INSERT INTO " + INSTANCE_LINKING_TABLE_NAME + " ( incaseriesconfig_id, incainstance_id ) " +
				"VALUES ( ?, ? )"
		);

		try {
			for (ConfigInstanceLink link : links) {
				insertStmt.setLong(1, link.configId);
				insertStmt.setLong(2, link.instanceId);
				insertStmt.addBatch();
			}

			insertStmt.executeBatch();

			dbConn.commit();
		}
		catch (SQLException sqlErr) {
			dbConn.rollback();

			throw sqlErr;
		}
		finally {
			insertStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param configRecords
	 * @throws SQLException
	 */
	private static void populateConfigInstanceLinkingTable(Connection dbConn, Map<Long, Set<ConfigLinkingRecord>> configRecords) throws SQLException
	{
		if (m_logger.isDebugEnabled()) {
			int numConfigs = 0;

			for (Set<ConfigLinkingRecord> configs : configRecords.values())
				numConfigs += configs.size();

			m_logger.debug("Links will be created for " + numConfigs + " SeriesConfigs...");
		}

		int totalUpdates = 0;
		List<ConfigInstanceLink> updates = new ArrayList<ConfigInstanceLink>();

		for (Map.Entry<Long, Set<ConfigLinkingRecord>> configEntry : configRecords.entrySet()) {
			long seriesId = configEntry.getKey();
			Set<ConfigLinkingRecord> configs = configEntry.getValue();
			Map<Long, Map<Long, Timestamp>> reportDates = getReportDates(dbConn, seriesId);

			for (ConfigLinkingRecord record : configs) {
				List<Long> reportIds = getReportIds(dbConn, record.configId, seriesId);

				for (Long reportId : reportIds) {
					Map<Long, Timestamp> instances = reportDates.get(reportId);

					if (instances != null) {
						for (Map.Entry<Long, Timestamp> instanceEntry : instances.entrySet()) {
							long instanceId = instanceEntry.getKey();
							Timestamp collected = instanceEntry.getValue();

							if (record.activated.before(collected) && (record.deactivated == null || record.deactivated.after(collected))) {
								updates.add(new ConfigInstanceLink(record.configId, instanceId));

								if (updates.size() >= BATCH_SIZE) {
									insertLinkingRows(dbConn, updates);

									updates.clear();

									if (m_logger.isDebugEnabled()) {
										totalUpdates += BATCH_SIZE;

										m_logger.debug("Inserted " + totalUpdates + " rows so far...");
									}
								}
							}
						}
					}
				}
			}
		}

		if (updates.size() > 0)
			insertLinkingRows(dbConn, updates);

		m_logger.debug("Finished linking SeriesConfigs with Instances");
	}

	/**
	 *
	 * @param dbConn
	 * @param dbData
	 * @throws SQLException
	 */
	private static void alterSeriesTable(Connection dbConn, DatabaseMetaData dbData) throws SQLException
	{
		String stringTypeName = getStringTypeName(dbData);
		StringBuilder queryBuilder = new StringBuilder();

		queryBuilder.append("ALTER TABLE " + SERIES_TABLE_NAME);
		queryBuilder.append(" ADD COLUMN " + TARGET_COLUMN_NAME + " ");
		queryBuilder.append(stringTypeName);
		queryBuilder.append("(255)");

		Statement updateStmt = dbConn.createStatement();

		try {
			updateStmt.executeUpdate(queryBuilder.toString());

			dbConn.commit();
		}
		finally {
			updateStmt.close();
		}
	}
}
