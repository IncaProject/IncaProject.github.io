package edu.sdsc.inca.depot.persistent;


import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Iterator;

import org.hibernate.engine.SessionFactoryImplementor;


/**
 * This class transfers InstanceInfo objects between memory and the DB.
 */
public class InstanceInfoDAO extends DAO {

  private static final int FETCH_SIZE = 100;
  private static final int MAX_ARGS = 10000;


  /**
   * Returns an InstanceInfo object from the DB with the id specified, null if
   * no such object appears in the DB.
   *
   * @param id the id of the object to be retrieved
   * @return an object from the DB marked with the given id
   * @throws PersistenceException on err
   */
  public static InstanceInfo load(Long id) throws PersistenceException {
    String query = "select ii from InstanceInfo ii where ii.id = " + id;
    InstanceInfo result = (InstanceInfo)DAO.selectUnique(query, null);
    // TODO: this hack deals with the special "null instance" that we used to
    // enter in the II table.  Remove the hack once we're sure it's not needed.
    return result!=null && result.getReportId().longValue()<0 ? null : result;
  }

  /**
   * Returns an InstanceInfo object from the DB with the parameters specified,
   * null if no such object appears in the DB.
   *
   * @param nickname
   * @param resource
   * @param collected
   * @return
   * @throws PersistenceException on err
   */
  public static InstanceInfo load(String nickname, String resource, Date collected) throws PersistenceException {

    String query = "SELECT sc.id " +
                   "FROM SeriesConfig AS sc " +
                   "WHERE sc.nickname = :p0 " +
                     "AND sc.series.resource = :p1";
    Object[] firstParams = { nickname, resource };
    Iterator<?> configIds = DAO.selectMultiple(query, firstParams);

    if (!configIds.hasNext())
      return null;

    StringBuilder queryBuilder = new StringBuilder();

    queryBuilder.append(
        "SELECT incainstance_id " +
        "FROM incaseriesconfigsinstances " +
        "WHERE incaseriesconfig_id IN ( "
    );

    queryBuilder.append(configIds.next());

    while (configIds.hasNext()) {
      queryBuilder.append(", ");
      queryBuilder.append(configIds.next());
    }

    queryBuilder.append(" )");

    try {
      Connection dbConn = ((SessionFactoryImplementor) HibernateUtil.getSessionFactory()).getConnectionProvider().getConnection();
      Statement selectStmt = null;
      ResultSet rows = null;

      try {
        selectStmt = dbConn.createStatement();

        selectStmt.setFetchSize(FETCH_SIZE);

        rows = selectStmt.executeQuery(queryBuilder.toString());

        while (rows.next()) {
          queryBuilder = new StringBuilder();

          queryBuilder.append(
            "SELECT ii " +
            "FROM InstanceInfo AS ii " +
            "WHERE ii.id IN ( "
          );

          queryBuilder.append(rows.getLong(1));

          for (int i = 1 ; i < MAX_ARGS && rows.next() ; i += 1) {
            queryBuilder.append(", ");
            queryBuilder.append(rows.getLong(1));
          }

          queryBuilder.append(" ) AND ii.collected = :p0");

          Object[] secondParams = { collected };
          InstanceInfo instance = (InstanceInfo)DAO.selectUnique(queryBuilder.toString(), secondParams);

          // TODO: this hack deals with the special "null instance" that we used to
          // enter in the II table.  Remove the hack once we're sure it's not needed.
          if (instance != null && instance.getReportId() >= 0)
            return instance;
        }
      }
      finally {
        if (rows != null)
          rows.close();

        if (selectStmt != null)
          selectStmt.close();

        dbConn.close();
      }
    }
    catch (SQLException sqlErr) {
      throw new PersistenceException(sqlErr.getMessage());
    }

    return null;
  }

  /**
   * Returns an InstanceInfo object from the DB with the same field values
   * as one specified, or the saved version of the specified object if no such
   * object appears in the DB.  Synchronized to avoid race conditions that
   * could result in DB duplicates.
   *
   * @param ii an object that contains field values used in the retrieval
   * @return an object from the DB that contains the same values
   * @throws PersistenceException on err
   */
  public static synchronized InstanceInfo loadOrSave(InstanceInfo ii)
    throws PersistenceException {
    InstanceInfo dbIi = null;
    if(ii.getId() != null) {
      dbIi = InstanceInfoDAO.load(ii.getId());
    }
    return dbIi == null ? (InstanceInfo)DAO.save(ii) : dbIi;
  }

  /**
   * A wrapper around DAO.update that handles the necessary casting.
   *
   * @param ii the object to update
   * @return ii for convenience
   * @throws PersistenceException on error
   */
  public static InstanceInfo update(InstanceInfo ii)
      throws PersistenceException {
    return (InstanceInfo)DAO.update(ii);
  }
}
