/*
 * BatchUpdateStatement.java
 */
package edu.sdsc.inca.depot;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;


/**
 *
 * @author Paul Hoover
 *
 */
class BatchUpdateStatement {

	private static final int MAX_BATCH_SIZE = 100;

	private final Connection m_dbConn;
	private final PreparedStatement m_updateStmt;
	private int m_batchSize = 0;


	// constructors


	/**
	 *
	 * @param dbConn
	 * @param query
	 * @throws SQLException
	 */
	public BatchUpdateStatement(Connection dbConn, String query) throws SQLException
	{
		assert !dbConn.getAutoCommit();

		m_updateStmt = dbConn.prepareStatement(query);
		m_dbConn = dbConn;
	}


	// public methods


	/**
	 *
	 * @param index
	 * @param value
	 * @throws SQLException
	 */
	public void setBoolean(int index, Boolean value) throws SQLException
	{
		if (value == null)
			m_updateStmt.setNull(index, Types.BOOLEAN);
		else
			m_updateStmt.setBoolean(index, value);
	}

	/**
	 *
	 * @param index
	 * @param value
	 * @throws SQLException
	 */
	public void setFloat(int index, Float value) throws SQLException
	{
		if (value == null)
			m_updateStmt.setNull(index, Types.FLOAT);
		else
			m_updateStmt.setFloat(index, value);
	}

	/**
	 *
	 * @param index
	 * @param value
	 * @throws SQLException
	 */
	public void setInt(int index, Integer value) throws SQLException
	{
		if (value == null)
			m_updateStmt.setNull(index, Types.INTEGER);
		else
			m_updateStmt.setInt(index, value);
	}

	/**
	 *
	 * @param index
	 * @param value
	 * @throws SQLException
	 */
	public void setLong(int index, Long value) throws SQLException
	{
		if (value == null)
			m_updateStmt.setNull(index, Types.BIGINT);
		else
			m_updateStmt.setLong(index, value);
	}

	/**
	 *
	 * @param index
	 * @param value
	 * @throws SQLException
	 */
	public void setString(int index, String value) throws SQLException
	{
		if (value == null)
			m_updateStmt.setNull(index, Types.VARCHAR);
		else
			m_updateStmt.setString(index, value);
	}

	/**
	 *
	 * @param index
	 * @param value
	 * @throws SQLException
	 */
	public void setTimestamp(int index, Timestamp value) throws SQLException
	{
		if (value == null)
			m_updateStmt.setNull(index, Types.TIMESTAMP);
		else
			m_updateStmt.setTimestamp(index, value);
	}

	/**
	 *
	 * @throws SQLException
	 */
	public void close() throws SQLException
	{
		if (m_batchSize > 0) {
			m_updateStmt.executeBatch();

			m_dbConn.commit();
		}

		m_updateStmt.close();
	}

	/**
	 *
	 * @throws SQLException
	 */
	public void addBatch() throws SQLException
	{
		m_updateStmt.addBatch();

		m_batchSize += 1;

		if (m_batchSize >= MAX_BATCH_SIZE) {
			m_updateStmt.executeBatch();

			m_dbConn.commit();

			m_batchSize = 0;
		}
	}
}
