/*
 * SyncResponse.java
 */
package edu.sdsc.inca.depot.commands;


import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.codec.binary.Base64OutputStream;
import org.apache.log4j.Logger;
import org.hibernate.engine.SessionFactoryImplementor;

import edu.sdsc.inca.depot.DepotPeerClient;
import edu.sdsc.inca.depot.persistent.HibernateUtil;
import edu.sdsc.inca.depot.persistent.PersistentObject;
import edu.sdsc.inca.depot.util.DepotMessageHandler;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.protocol.ProtocolReader;


/**
 *
 * @author Paul Hoover
 *
 */
public class SyncResponse extends DepotMessageHandler {

	/**
	 * An <code>OutputStream</code> wrapper that doesn't propagate a <code>close</code>
	 * call to the wrapped stream
	 */
	private static class ClonedOutputStream extends OutputStream {

		private final OutputStream m_out;


		// constructors


		/**
		 *
		 * @param out
		 */
		public ClonedOutputStream(OutputStream out)
		{
			m_out = out;
		}


		// public methods


		/**
		 *
		 * @throws IOException
		 */
		@Override
		public void close() throws IOException
		{
			m_out.flush();
		}

		/**
		 *
		 * @throws IOException
		 */
		@Override
		public void flush() throws IOException
		{
			m_out.flush();
		}

		/**
		 *
		 * @param b
		 * @param off
		 * @param len
		 * @throws IOException
		 */
		@Override
		public void write(byte[] b, int off, int len) throws IOException
		{
			m_out.write(b, off, len);
		}

		/**
		 *
		 * @param b
		 * @throws IOException
		 */
		@Override
		public void write(int b) throws IOException
		{
			m_out.write(b);
		}
	}


	private static final int FETCH_SIZE = 100;

	private static final Logger m_logger = Logger.getLogger(SyncResponse.class);


	// public methods


	/**
	 *
	 * @param reader the reader connected to the client
	 * @param output the output stream connected to the client
	 * @param dn the DN of the client, null if no authentication
	 * @throws Exception
	 */
	public void execute(ProtocolReader reader, OutputStream output, String dn) throws Exception
	{
		if (getDepot().syncInProgress())
			throw new Exception("synchronizing");

		String peerUri = new String(reader.readStatement().getData());

		if (peerUri == null || peerUri.length() == 0)
			throw new ProtocolException("Peer URI missing from " + Protocol.SYNC_COMMAND + " command");

		if(!isPermitted(dn, Protocol.SYNC_ACTION))
			throw new ProtocolException(Protocol.SYNC_ACTION + " not allowed by " + dn);

		String peerAddress = extractAddress(peerUri);
		List<DepotPeerClient> peers = new ArrayList<DepotPeerClient>();

		for (Iterator<Properties> elements = getDepot().getPeerConfigs().iterator() ; elements.hasNext() ; ) {
			Properties config = elements.next();
			String address = extractAddress(config.getProperty("peer"));

			if (!address.equals(peerAddress))
				peers.add(new DepotPeerClient(config));
		}

		getDepot().startSyncResponse();

		for (Iterator<DepotPeerClient> elements = peers.iterator() ; elements.hasNext() ; ) {
			DepotPeerClient peer = elements.next();

			try {
				peer.connect();
				peer.sendSyncStart();
			}
			catch (Exception err) {
				m_logger.error("Unable to send " + Protocol.SYNC_START_COMMAND + " command to " + peer.getUri() + ": " + err.getMessage());

				elements.remove();
			}
			finally {
				if (peer.isConnected())
					peer.close();
			}
		}

		try {
			output.write(Protocol.SUCCESS_COMMAND.getBytes());

			try {
				output.write(SP);

				writeResponse(output);
			}
			finally {
				output.write(CRLF);
				output.flush();
			}
		}
		catch (Exception err) {
			ByteArrayOutputStream logMessage = new ByteArrayOutputStream();
			PrintStream stream = new PrintStream(logMessage);

			stream.print("Synchronization response failed: ");
			err.printStackTrace(stream);

			m_logger.error(logMessage.toString());

			errorReply(output, err.getMessage());
		}

		for (Iterator<DepotPeerClient> elements = peers.iterator() ; elements.hasNext() ; ) {
			DepotPeerClient peer = elements.next();

			try {
				peer.connect();
				peer.sendSyncEnd();
			}
			catch (Exception err) {
				m_logger.error("Unable to send " + Protocol.SYNC_END_COMMAND + " command to " + peer.getUri() + ": " + err.getMessage());
			}
			finally {
				if (peer.isConnected())
					peer.close();
			}
		}

		getDepot().endSync();

		reader.close();
	}


	// private methods


	/**
	 *
	 * @param uri
	 * @return
	 */
	private String extractAddress(String uri)
	{
		int offset = uri.indexOf("://");

		if (offset < 0)
			return uri;

		return uri.substring(offset + 3);
	}

	/**
	 *
	 * @param row
	 * @param index
	 * @param output
	 * @throws SQLException
	 */
	private void writeBooleanValue(ResultSet row, int index, PrintStream output) throws SQLException
	{
		boolean value = row.getBoolean(index);

		if (!row.wasNull())
			output.print(value);
	}

	/**
	 *
	 * @param row
	 * @param index
	 * @param output
	 * @throws SQLException
	 */
	private void writeIntegerValue(ResultSet row, int index, PrintStream output) throws SQLException
	{
		int value = row.getInt(index);

		if (!row.wasNull())
			output.print(value);
	}

	/**
	 *
	 * @param row
	 * @param index
	 * @param output
	 * @throws SQLException
	 */
	private void writeLongValue(ResultSet row, int index, PrintStream output) throws SQLException
	{
		long value = row.getLong(index);

		if (!row.wasNull())
			output.print(value);
	}

	/**
	 *
	 * @param row
	 * @param index
	 * @param output
	 * @throws SQLException
	 */
	private void writeFloatValue(ResultSet row, int index, PrintStream output) throws SQLException
	{
		float value = row.getFloat(index);

		if (!row.wasNull())
			output.print(value);
	}

	/**
	 *
	 * @param row
	 * @param index
	 * @param output
	 * @throws SQLException
	 */
	private void writeStringValue(ResultSet row, int index, PrintStream output) throws SQLException
	{
		String value = row.getString(index);

		if (!row.wasNull()) {
			if (value.length() > 0)
				output.print(value);
			else
				output.print(PersistentObject.DB_EMPTY_STRING);
		}
	}

	/**
	 *
	 * @param row
	 * @param index
	 * @param output
	 * @throws SQLException
	 */
	private void writeTimestampValue(ResultSet row, int index, PrintStream output) throws SQLException
	{
		Timestamp value = row.getTimestamp(index);

		if (!row.wasNull())
			output.print(value.toString());
	}

	/**
	 *
	 * @param row
	 * @param index
	 * @param output
	 * @throws SQLException
	 */
	private void writeCdataValue(ResultSet row, int index, PrintStream output) throws SQLException
	{
		String value = row.getString(index);

		output.print("<![CDATA[");

		if (!row.wasNull()) {
			if (value.length() > 0)
				output.print(value.replaceAll("]]>", "]]]]><![CDATA[>"));
			else
				output.print(PersistentObject.DB_EMPTY_STRING);
		}

		output.print("]]>");
	}

	/**
	 *
	 * @param dbConn
	 * @param output
	 * @throws SQLException
	 */
	private void writeSuites(Connection dbConn, PrintStream output) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaid, incaname, incaguid, incadescription, incaversion " +
				"FROM incasuite"
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			output.print("<suiteRows>");

			while (rows.next()) {
				output.print("<suite><id>");

				writeLongValue(rows, 1, output);

				output.print("</id><name>");

				writeStringValue(rows, 2, output);

				output.print("</name><guid>");

				writeStringValue(rows, 3, output);

				output.print("</guid><description>");

				writeStringValue(rows, 4, output);

				output.print("</description><version>");

				writeIntegerValue(rows, 5, output);

				output.print("</version></suite>");
			}

			output.print("</suiteRows>");
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param output
	 * @throws SQLException
	 */
	private void writeArgs(Connection dbConn, PrintStream output) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaid, incaname, incavalue " +
				"FROM incaarg"
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			output.print("<argRows>");

			while (rows.next()) {
				output.print("<arg><id>");

				writeLongValue(rows, 1, output);

				output.print("</id><name>");

				writeStringValue(rows, 2, output);

				output.print("</name><value>");

				writeCdataValue(rows, 3, output);

				output.print("</value></arg>");
			}

			output.print("</argRows>");
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param output
	 * @param argsId
	 * @throws SQLException
	 */
	private void writeArgMappings(Connection dbConn, PrintStream output, long argsId) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incainput_id " +
				"FROM incaargs " +
				"WHERE incaargs_id = ?"
		);
		ResultSet rows = null;

		try {
			selectStmt.setLong(1, argsId);
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			output.print("<args>");

			while (rows.next()) {
				output.print("<id>");

				writeLongValue(rows, 1, output);

				output.print("</id>");
			}

			output.print("</args>");
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param output
	 * @throws SQLException
	 */
	private void writeArgSignatures(Connection dbConn, PrintStream output) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaid " +
				"FROM incaargsignature"
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			output.print("<argSignatureRows>");

			while (rows.next()) {
				long id = rows.getLong(1);

				output.print("<argSignature><id>");
				output.print(id);
				output.print("</id>");

				writeArgMappings(dbConn, output, id);

				output.print("</argSignature>");
			}

			output.print("</argSignatureRows>");
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param output
	 * @throws SQLException
	 */
	private void writeSeries(Connection dbConn, PrintStream output) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaid, incareporter, incaversion, incauri, " +
					"incacontext, incanice, incaresource, incaargSignature_id " +
				"FROM incaseries"
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			output.print("<seriesRows>");

			while (rows.next()) {
				output.print("<series><id>");

				writeLongValue(rows, 1, output);

				output.print("</id><reporter>");

				writeStringValue(rows, 2, output);

				output.print("</reporter><version>");

				writeStringValue(rows, 3, output);

				output.print("</version><uri>");

				writeStringValue(rows, 4, output);

				output.print("</uri><context>");

				writeCdataValue(rows, 5, output);

				output.print("</context><nice>");

				writeBooleanValue(rows, 6, output);

				output.print("</nice><resource>");

				writeStringValue(rows, 7, output);

				output.print("</resource><argSignatureId>");

				writeLongValue(rows, 8, output);

				output.print("</argSignatureId></series>");
			}

			output.print("</seriesRows>");
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param output
	 * @param configId
	 * @throws SQLException
	 */
	private void writeSuiteConfigMappings(Connection dbConn, PrintStream output, long configId) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incasuite_id " +
				"FROM incasuitesseriesconfigs " +
				"WHERE incaseriesconfig_id = ?"
		);
		ResultSet rows = null;

		try {
			selectStmt.setLong(1, configId);
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			output.print("<suites>");

			while (rows.next()) {
				output.print("<id>");

				writeLongValue(rows, 1, output);

				output.print("</id>");
			}

			output.print("</suites>");
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param output
	 * @throws SQLException
	 */
	private void writeSeriesConfigs(Connection dbConn, PrintStream output) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaid, incaactivated, incadeactivated, incanickname, " +
					"incawallClockTime, incacpuTime, incamemory, incacomparitor, " +
					"incacomparison, incanotifier, incatarget, incatype, incaminute, " +
					"incahour, incamonth, incamday, incawday, incanumOccurs, " +
					"incasuspended, incaseries_id, incalatestInstanceId, " +
					"incalatestComparisonId " +
				"FROM incaseriesconfig"
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			output.print("<seriesConfigRows>");

			while (rows.next()) {
				long id = rows.getLong(1);

				output.print("<seriesConfig><id>");
				output.print(id);
				output.print("</id><activated>");

				writeTimestampValue(rows, 2, output);

				output.print("</activated><deactivated>");

				writeTimestampValue(rows, 3, output);

				output.print("</deactivated><nickname>");

				writeStringValue(rows, 4, output);

				output.print("</nickname><wallClockTime>");

				writeFloatValue(rows, 5, output);

				output.print("</wallClockTime><cpuTime>");

				writeFloatValue(rows, 6, output);

				output.print("</cpuTime><memory>");

				writeFloatValue(rows, 7, output);

				output.print("</memory><comparitor>");

				writeStringValue(rows, 8, output);

				output.print("</comparitor><comparison>");

				writeCdataValue(rows, 9, output);

				output.print("</comparison><notifier>");

				writeStringValue(rows, 10, output);

				output.print("</notifier><target>");

				writeStringValue(rows, 11, output);

				output.print("</target><type>");

				writeStringValue(rows, 12, output);

				output.print("</type><minute>");

				writeStringValue(rows, 13, output);

				output.print("</minute><hour>");

				writeStringValue(rows, 14, output);

				output.print("</hour><month>");

				writeStringValue(rows, 15, output);

				output.print("</month><mday>");

				writeStringValue(rows, 16, output);

				output.print("</mday><wday>");

				writeStringValue(rows, 17, output);

				output.print("</wday><numOccurs>");

				writeIntegerValue(rows, 18, output);

				output.print("</numOccurs><suspended>");

				writeBooleanValue(rows, 19, output);

				output.print("</suspended><seriesId>");

				writeLongValue(rows, 20, output);

				output.print("</seriesId><latestInstanceId>");

				writeLongValue(rows, 21, output);

				output.print("</latestInstanceId><latestComparisonId>");

				writeLongValue(rows, 22, output);

				output.print("</latestComparisonId>");

				writeSuiteConfigMappings(dbConn, output, id);

				output.print("</seriesConfig>");
			}

			output.print("</seriesConfigRows>");
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param output
	 * @throws SQLException
	 */
	private void writeRunInfo(Connection dbConn, PrintStream output) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaid, incahostname, incaworkingDir, incareporterPath, " +
					"incaargSignature_id " +
				"FROM incaruninfo"
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			output.print("<runInfoRows>");

			while (rows.next()) {
				output.print("<runInfo><id>");

				writeLongValue(rows, 1, output);

				output.print("</id><hostname>");

				writeStringValue(rows, 2, output);

				output.print("</hostname><workingDir>");

				writeStringValue(rows, 3, output);

				output.print("</workingDir><reporterPath>");

				writeStringValue(rows, 4, output);

				output.print("</reporterPath><argSignatureId>");

				writeLongValue(rows, 5, output);

				output.print("</argSignatureId></runInfo>");
			}

			output.print("</runInfoRows>");
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param output
	 * @throws SQLException
	 */
	private void writeReports(Connection dbConn, PrintStream output) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaid, incaexit_status, incaexit_message, incabodypart1, " +
					"incabodypart2, incabodypart3, incastderr, incaseries_id, " +
					"incarunInfo_id " +
				"FROM incareport"
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			output.print("<reportRows>");

			while (rows.next()) {
				output.print("<report><id>");

				writeLongValue(rows, 1, output);

				output.print("</id><exitStatus>");

				writeBooleanValue(rows, 2, output);

				output.print("</exitStatus><exitMessage>");

				writeCdataValue(rows, 3, output);

				output.print("</exitMessage><bodypart1>");

				writeCdataValue(rows, 4, output);

				output.print("</bodypart1><bodypart2>");

				writeCdataValue(rows, 5, output);

				output.print("</bodypart2><bodypart3>");

				writeCdataValue(rows, 6, output);

				output.print("</bodypart3><stderr>");

				writeCdataValue(rows, 7, output);

				output.print("</stderr><seriesId>");

				writeLongValue(rows, 8, output);

				output.print("</seriesId><runInfoId>");

				writeLongValue(rows, 9, output);

				output.print("</runInfoId></report>");
			}

			output.print("</reportRows>");
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param output
	 * @throws SQLException
	 */
	private void writeComparisonResults(Connection dbConn, PrintStream output) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaid, incaresult, incareportId, incaseriesConfigId " +
				"FROM incacomparisonresult"
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			output.print("<comparisonResultRows>");

			while (rows.next()) {
				output.print("<comparisonResult><id>");

				writeLongValue(rows, 1, output);

				output.print("</id><result>");

				writeCdataValue(rows, 2, output);

				output.print("</result><reportId>");

				writeLongValue(rows, 3, output);

				output.print("</reportId><seriesConfigId>");

				writeLongValue(rows, 4, output);

				output.print("</seriesConfigId></comparisonResult>");
			}

			output.print("</comparisonResultRows>");
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param output
	 * @param instanceId
	 * @throws SQLException
	 */
	private void writeConfigInstanceMappings(Connection dbConn, PrintStream output, long instanceId) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaseriesconfig_id " +
				"FROM incaseriesconfigsinstances " +
				"WHERE incainstance_id = ?"
		);
		ResultSet rows = null;

		try {
			selectStmt.setLong(1, instanceId);
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			output.print("<seriesConfigs>");

			while (rows.next()) {
				output.print("<id>");

				writeLongValue(rows, 1, output);

				output.print("</id>");
			}

			output.print("</seriesConfigs>");
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param output
	 * @throws SQLException
	 */
	private void writeInstanceInfo(Connection dbConn, PrintStream output) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaid, incacollected, incacommited, incamemoryUsageMB, " +
					"incacpuUsageSec, incawallClockTimeSec, incalog, incareportId " +
				"FROM incainstanceinfo"
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			output.print("<instanceInfoRows>");

			while (rows.next()) {
				long id = rows.getLong(1);

				output.print("<instanceInfo><id>");
				output.print(id);
				output.print("</id><collected>");

				writeTimestampValue(rows, 2, output);

				output.print("</collected><commited>");

				writeTimestampValue(rows, 3, output);

				output.print("</commited><memoryUsageMB>");

				writeFloatValue(rows, 4, output);

				output.print("</memoryUsageMB><cpuUsageSec>");

				writeFloatValue(rows, 5, output);

				output.print("</cpuUsageSec><wallClockTimeSec>");

				writeFloatValue(rows, 6, output);

				output.print("</wallClockTimeSec><log>");

				writeCdataValue(rows, 7, output);

				output.print("</log><reportId>");

				writeLongValue(rows, 8, output);

				output.print("</reportId>");

				writeConfigInstanceMappings(dbConn, output, id);

				output.print("</instanceInfo>");
			}

			output.print("</instanceInfoRows>");
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param dbConn
	 * @param output
	 * @throws SQLException
	 */
	private void writeKbArticles(Connection dbConn, PrintStream output) throws SQLException
	{
		PreparedStatement selectStmt = dbConn.prepareStatement(
				"SELECT incaentered, incaerrormsg, incaseries, incareporter, " +
					"incaauthorname, incaauthoremail, incaarticletitle, incaarticletext " +
				"FROM incakbarticle"
		);
		ResultSet rows = null;

		try {
			selectStmt.setFetchSize(FETCH_SIZE);

			rows = selectStmt.executeQuery();

			output.print("<kbArticleRows>");

			while (rows.next()) {
				output.print("<kbArticle><entered>");

				writeTimestampValue(rows, 1, output);

				output.print("</entered><errorMsg>");

				writeStringValue(rows, 2, output);

				output.print("</errorMsg><series>");

				writeStringValue(rows, 3, output);

				output.print("</series><reporter>");

				writeStringValue(rows, 4, output);

				output.print("</reporter><authorName>");

				writeStringValue(rows, 5, output);

				output.print("</authorName><authorEmail>");

				writeStringValue(rows, 6, output);

				output.print("</authorEmail><articleTitle>");

				writeStringValue(rows, 7, output);

				output.print("</articleTitle><articleText>");

				writeCdataValue(rows, 8, output);

				output.print("</articleText></kbArticle>");
			}

			output.print("</kbArticleRows>");
		}
		finally {
			if (rows != null)
				rows.close();

			selectStmt.close();
		}
	}

	/**
	 *
	 * @param outStream
	 * @throws IOException
	 * @throws SQLException
	 */
	private void writeResponse(OutputStream outStream) throws IOException, SQLException
	{
		PrintStream output = new PrintStream(new BufferedOutputStream(new GZIPOutputStream(new Base64OutputStream(new ClonedOutputStream(outStream), true, 0, CRLF))));
		Connection dbConn = ((SessionFactoryImplementor) HibernateUtil.getSessionFactory()).getConnectionProvider().getConnection();

		try {
			output.print("<syncResponse>");

			m_logger.debug("Writing Suite records...");

			writeSuites(dbConn, output);

			m_logger.debug("Writing Arg records...");

			writeArgs(dbConn, output);

			m_logger.debug("Writing ArgSignature records...");

			writeArgSignatures(dbConn, output);

			m_logger.debug("Writing Series records...");

			writeSeries(dbConn, output);

			m_logger.debug("Writing SeriesConfig records...");

			writeSeriesConfigs(dbConn, output);

			m_logger.debug("Writing RunInfo records...");

			writeRunInfo(dbConn, output);

			m_logger.debug("Writing Report records...");

			writeReports(dbConn, output);

			m_logger.debug("Writing ComparisonResult records...");

			writeComparisonResults(dbConn, output);

			m_logger.debug("Writing InstanceInfo records...");

			writeInstanceInfo(dbConn, output);

			m_logger.debug("Writing KbArticle records...");

			writeKbArticles(dbConn, output);

			output.print("</syncResponse>");
		}
		finally {
			output.close();
			dbConn.close();
		}
	}
}
