/*
 * KbArticleInsert.java
 */
package edu.sdsc.inca.depot.commands;


import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;

import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.dataModel.article.KbArticleDocument;
import edu.sdsc.inca.depot.DepotPeerClient;
import edu.sdsc.inca.depot.persistent.DAO;
import edu.sdsc.inca.depot.persistent.KbArticle;
import edu.sdsc.inca.depot.persistent.PersistenceException;
import edu.sdsc.inca.depot.util.HibernateMessageHandler;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.protocol.Statement;
import edu.sdsc.inca.util.WorkItem;
import edu.sdsc.inca.util.Worker;


/**
 *
 * @author Paul Hoover
 *
 */
public class KbArticleInsert extends HibernateMessageHandler {

	/**
	 *
	 */
	private static class NotifyKbArticleInsert implements WorkItem<Worker> {

		private final Properties m_peerConfig;
		private final String m_xml;


		/**
		 *
		 * @param config
		 * @param xml
		 */
		public NotifyKbArticleInsert(Properties config, String xml)
		{
			m_peerConfig = config;
			m_xml = xml;
		}


		/**
		 *
		 * @param context
		 * @throws ConfigurationException
		 */
		public void doWork(Worker context) throws ConfigurationException
		{
			DepotPeerClient peer = new DepotPeerClient(m_peerConfig);

			try {
				peer.connect();
				peer.sendNotifyKbArticleInsert(m_xml);
			}
			catch (Exception err) {
				m_logger.warn("Unable to send " + Protocol.NOTIFY_KBARTICLE_INSERT_COMMAND + " command to " + peer.getUri() + ": " + err.getMessage());
			}
			finally {
				if (peer.isConnected())
					peer.close();
			}
		}
	}

	/**
	 *
	 */
	private static class DelayedKbArticleInsert implements WorkItem<Worker> {

		private final KbArticle m_article;


		/**
		 *
		 * @param article
		 */
		public DelayedKbArticleInsert(KbArticle article)
		{
			m_article = article;
		}


		/**
		 *
		 * @param context
		 */
		public void doWork(Worker context)
		{
			try {
				DAO.save(m_article);
			}
			catch (PersistenceException persistErr) {
				ByteArrayOutputStream logMessage = new ByteArrayOutputStream();

				persistErr.printStackTrace(new PrintStream(logMessage));

				m_logger.error(logMessage.toString());
			}
		}
	}


	private static final Logger m_logger = Logger.getLogger(KbArticleInsert.class);


	/**
	 *
	 * @param reader
	 * @param writer
	 * @param dn
	 * @throws Exception
	 */
	public void executeHibernateAction(ProtocolReader reader, ProtocolWriter writer, String dn) throws Exception
	{
		Statement stmt = reader.readStatement();
		String xml = new String(stmt.getData());
		KbArticle article = null;

		try {
			KbArticleDocument doc = KbArticleDocument.Factory.parse(xml);

			if(!doc.validate())
				throw new XmlException("Invalid article XML '" + xml + "'");

			article = (new KbArticle()).fromBean(doc.getKbArticle());
		}
		catch(XmlException xmlErr) {
			throw new ProtocolException("Unable to parse article XML: " + xmlErr);
		}

		if (getDepot().syncInProgress()) {
			if (getDepot().addDelayedWork(new DelayedKbArticleInsert(article))) {
				writer.write(Statement.getOkStatement(""));

				return;
			}
		}

		DAO.save(article);

		writer.write(Statement.getOkStatement(""));

		if ((new String(stmt.getCmd())).equals(Protocol.NOTIFY_KBARTICLE_INSERT_COMMAND))
			return;

		for (Properties config : getDepot().getPeerConfigs())
			getDepot().addWork(new NotifyKbArticleInsert(config, xml));
	}
}
