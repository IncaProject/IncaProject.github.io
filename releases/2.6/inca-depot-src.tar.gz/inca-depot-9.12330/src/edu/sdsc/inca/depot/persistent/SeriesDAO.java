package edu.sdsc.inca.depot.persistent;


/**
 * This class transfers Series objects between memory and the DB.
 */
public class SeriesDAO extends DAO {

  /**
   * Returns a Series from the DB with the same field values as one specified,
   * null if no such Series appears in the DB.
   *
   * @param s an object that contains field values used in the retrieval
   * @return an object from the DB that contains the same values
   * @throws PersistenceException on err
   */
  public static Series load(Series s) throws PersistenceException {
    String query =
      "select s from Series as s " +
              " where s.resource = :p0" +
              " and s.context = :p1" +
              " and s.version = :p2";
    Object[] params =
      new Object[] {s.getResource(), s.getContext(), s.getVersion()};
    return (Series)DAO.selectUnique(query, params);
  }

  /**
   * Returns a Series object from the DB with the id specified, or null if no
   * such object appears in the DB.
   *
   * @param id the id of the object to be retrieved
   * @return an object from the DB marked with the given id
   * @throws PersistenceException on err
   */
  public static Series load(Long id) throws PersistenceException {
    String query = "select s from Series as s where s.id = :p0";
    Object[] params = new Object[] { id };
    return (Series)DAO.selectUnique(query, params);
  }

  /**
   * Returns a Series object from the DB with the same field values as one
   * specified, or the saved version of the specified object if no such object
   * appears in the DB.  Synchronized to avoid race conditions that could
   * result in DB duplicates.
   *
   * @param s an object that contains field values used in the retrieval
   * @return an object from the DB that contains the same values
   * @throws PersistenceException on err
   */
  public static synchronized Series loadOrSave(Series s)
    throws PersistenceException {
    Series dbSeries = SeriesDAO.load(s);
    if(dbSeries != null) {
      return dbSeries;
    }
    return save(s);
  }

  /**
   * Saves the specified Series object
   *
   * @param s an object that contains field values used in the retrieval
   * @return an object from the DB that contains the same values
   * @throws PersistenceException on err
   */
  public static Series save(Series s) throws PersistenceException {

    s.setArgSignature(ArgSignatureDAO.loadOrSave(s.getArgSignature()));

    return (Series)DAO.save(s);
  }

  /**
   * A wrapper around DAO.update that handles the necessary casting.
   *
   * @param s the Series to update
   * @return s for convenience
   * @throws PersistenceException on error
   */
  public static Series update(Series s) throws PersistenceException {
    s.setArgSignature(ArgSignatureDAO.loadOrSave(s.getArgSignature()));
    return (Series)DAO.update(s);
  }

}
