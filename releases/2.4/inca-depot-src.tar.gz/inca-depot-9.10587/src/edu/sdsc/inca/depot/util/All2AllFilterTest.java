package edu.sdsc.inca.depot.util;

import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import junit.framework.TestCase;
import org.apache.log4j.Logger;

/**
 *
 * @author jhayes
 *
 */
public class All2AllFilterTest extends TestCase {

  private static final String SUMMARY_FILENAME = "summary.properties";

  static {
    try {
      createSummaryFile("1");
      new File(SUMMARY_FILENAME).deleteOnExit();
    } catch(Exception e) {
      // empty
    }
  }

  private static Logger logger = Logger.getLogger(ExprComparitor.class);
  private static final String REPORT_BODY =
    "    <package>\n" +
    "      <ID>gcc</ID>\n" +
    "      <version>4.0.1</version>\n" +
    "    </package>\n";
  private static final String REPORTER = "cluster.compiler.gcc.version";
  private static final String RESOURCE_SOURCE_BASE = "ab";
  private static final String RESOURCE_TARGET_BASE = "cd";
  private static final String RESOURCE_SOURCE = RESOURCE_SOURCE_BASE + "1";
  private static final String RESOURCE_TARGET = RESOURCE_TARGET_BASE + "3";
  private static final String SEP = System.getProperty("line.separator");
  private static final String CONTEXT_ALL2ALL =
    "prefix;nickname=all2all:telnet_to_" + RESOURCE_TARGET +
    ";" + REPORTER + ";suffix";
  private static final String CONTEXT_NOTALL2ALL =
    CONTEXT_ALL2ALL.replaceFirst("all2all", "other");
  private static final String REPORT_SUCCEEDED =
    "<rep:report xmlns:rep='http://inca.sdsc.edu/dataModel/report_2.1'>\n" +
    "  <gmt>2008-06-19T17:18:46Z</gmt>\n" +
    "  <hostname>" + RESOURCE_SOURCE + "</hostname>\n" +
    "  <name>" + REPORTER + "</name>\n" +
    "  <version>2</version>\n" +
    "  <workingDir>/Inca/reporters/bin</workingDir>\n" +
    "  <reporterPath>" + REPORTER + "</reporterPath>\n" +
    "  <body>\n" +
    REPORT_BODY +
    "  </body>\n" +
    "  <exitStatus>\n" +
    "    <completed>true</completed>\n" +
    "  </exitStatus>\n" +
    "</rep:report>\n";
  private static final String REPORT_FAILED =
    REPORT_SUCCEEDED.replaceFirst("true</completed>", "false</completed>\n<errorMessage>Houston, we have a problem</errorMessage>");

  private static final String SUMMARY_REPORTER =
    "summary.successpct.performance";
  private static final String SUMMARY_RESOURCE = "localhost";
  private static final String SUMMARY_CONTEXT =
    CONTEXT_ALL2ALL.replaceFirst(REPORTER, SUMMARY_REPORTER);
  private static final String SUMMARY_SUCCEEDED =
    "<rep:report xmlns:rep='http://inca.sdsc.edu/dataModel/report_2.1'>\n" +
    "  <gmt>2008-06-19T17:18:46Z</gmt>\n" +
    "  <hostname>" + SUMMARY_RESOURCE + "</hostname>\n" +
    "  <name>" + SUMMARY_REPORTER + "</name>\n" +
    "  <version>2</version>\n" +
    "  <workingDir>/Inca/reporters/bin</workingDir>\n" +
    "  <reporterPath>" + SUMMARY_REPORTER + "</reporterPath>\n" +
    "  <body>\n" +
    "    <performance>\n" +
    "      <ID>successpct</ID>\n" +
    "      <benchmark>\n" +
    "        <ID>successpct</ID>\n" +
    "        <statistics>\n" +
    "          <statistic>\n" +
    "            <ID>all2all:telnet_to_" + RESOURCE_TARGET + "-pct</ID>\n" +
    "            <value>86</value>\n" +
    "          </statistic>\n" +
    "        </statistics>\n" +
    "      </benchmark>\n" +
    "    </performance>\n" +
    "  </body>\n" +
    "  <exitStatus>\n" +
    "    <completed>true</completed>\n" +
    "  </exitStatus>\n" +
    "</rep:report>\n";
  private static final String SUMMARY_FAILED =
    SUMMARY_SUCCEEDED.replaceFirst
      ("-pct</ID>\\s*<value>[\\d\\.]+", "-pct</ID><value>0");

  protected static void createSummaryFile(String value) throws Exception {
    BufferedWriter bw = new BufferedWriter(new FileWriter(SUMMARY_FILENAME));
    for(int i = 0; i < 4; i++) {
      bw.write("telnet_to_" + RESOURCE_TARGET_BASE + i + "=" + value + SEP);
    }
    bw.close();
  }

  public void testMissingFile() throws Exception {
    All2AllFilter af = new All2AllFilter();
    af.setContext(CONTEXT_NOTALL2ALL);
    af.setResource(RESOURCE_SOURCE);
    af.setStderr(null);
    af.setStdout(REPORT_SUCCEEDED);
    String filteredStdout = af.getStdout();
    assertEquals(REPORT_SUCCEEDED, filteredStdout);
  }
  
  public void testAtFaultFailure() throws Exception {
    createSummaryFile("1");
    All2AllFilter af = new All2AllFilter();
    af.setContext(CONTEXT_ALL2ALL);
    af.setResource(RESOURCE_SOURCE);
    af.setStderr(null);
    af.setStdout(REPORT_FAILED);
    String filteredStdout = af.getStdout();
    assertEquals(REPORT_FAILED, filteredStdout);
  }

  public void testNotAtFaultFailure() throws Exception {
    createSummaryFile("0");
    All2AllFilter af = new All2AllFilter();
    af.setContext(CONTEXT_ALL2ALL);
    af.setResource(RESOURCE_SOURCE);
    af.setStderr(null);
    af.setStdout(REPORT_FAILED);
    String filteredStdout = af.getStdout();
    assertFalse(REPORT_FAILED.equals(filteredStdout));
    assertTrue(filteredStdout.indexOf("NOT_AT_FAULT:") >= 0);
  }

  public void testSummaryReport() throws Exception {
    createSummaryFile("1");
    All2AllFilter af = new All2AllFilter();

    af.setContext(SUMMARY_CONTEXT);
    af.setResource(SUMMARY_RESOURCE);
    af.setStderr(null);
    af.setStdout(SUMMARY_SUCCEEDED);
    af.getStdout();

    af.setContext(CONTEXT_ALL2ALL);
    af.setResource(RESOURCE_SOURCE);
    af.setStderr(null);
    af.setStdout(REPORT_FAILED);
    String filteredStdout = af.getStdout();
    assertEquals(REPORT_FAILED, filteredStdout);

    af.setContext(SUMMARY_CONTEXT);
    af.setResource(SUMMARY_RESOURCE);
    af.setStderr(null);
    af.setStdout(SUMMARY_FAILED);
    af.getStdout();

    af.setContext(CONTEXT_ALL2ALL);
    af.setResource(RESOURCE_SOURCE);
    af.setStderr(null);
    af.setStdout(REPORT_FAILED);
    filteredStdout = af.getStdout();
    assertFalse(REPORT_FAILED.equals(filteredStdout));
    assertTrue(filteredStdout.indexOf("NOT_AT_FAULT:") >= 0);

  }

}
