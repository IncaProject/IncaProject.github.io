package edu.sdsc.inca.depot.commands;

import edu.sdsc.inca.dataModel.graphSeries.GraphInstance;
import edu.sdsc.inca.dataModel.graphSeries.GraphSeries;
import edu.sdsc.inca.dataModel.reportDetails.ReportDetailsDocument;
import edu.sdsc.inca.dataModel.util.AnyXmlSequence;
import edu.sdsc.inca.dataModel.util.Log;
import edu.sdsc.inca.dataModel.util.ReportDetails;
import edu.sdsc.inca.depot.persistent.*;
import edu.sdsc.inca.depot.util.HibernateMessageHandler;
import edu.sdsc.inca.protocol.*;
import edu.sdsc.inca.queryResult.ReportSummaryDocument;
import edu.sdsc.inca.util.StringMethods;
import edu.sdsc.inca.util.XmlWrapper;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;
import org.hibernate.Session;
import org.hibernate.metadata.ClassMetadata;

/**
 */
public class Query extends HibernateMessageHandler {

  private static Logger logger = Logger.getLogger(Query.class);
  private static final Statement S_FINISH =
    new Statement(Protocol.END_QUERY_RESULTS_COMMAND.toCharArray(), null);

  /**
   * Execute queries on the depot.
   *
   * @param reader   Reader to the query request.
   * @param writer   Writer to the remote process making the request.
   * @throws Exception
   */
  public void executeHibernateAction(
    ProtocolReader reader, ProtocolWriter writer) throws Exception {

    Statement queryStatement = null;
    queryStatement = reader.readStatement();
    String cmd = new String(queryStatement.getCmd());
    String data = new String(queryStatement.getData());
    try {
      if(cmd.equals(Protocol.QUERY_DB_COMMAND)) {
        getDbInfo(writer);
      } else if(cmd.equals(Protocol.QUERY_GUIDS_COMMAND)) {
        getGuidList(writer);
      } else if(cmd.equals(Protocol.QUERY_HQL_COMMAND)) {
        getSelectOutput(writer, data, true);
        writer.write(S_FINISH);
      } else if(cmd.equals(Protocol.QUERY_INSTANCE_COMMAND)) {
        getInstance(writer, data);
        writer.write(S_FINISH);
      } else if(cmd.equals(Protocol.QUERY_LATEST_COMMAND)) {
        getLatestInstances(writer, data);
        writer.write(S_FINISH);
      } else if(cmd.equals(Protocol.QUERY_PERIOD_COMMAND)) {
        getPeriodInstances(writer, data);
        writer.write(S_FINISH);
      } else if(cmd.equals(Protocol.QUERY_SQL_COMMAND)) {
        getSelectOutput(writer, data, false);
        writer.write(S_FINISH);
      } else if(cmd.equals(Protocol.QUERY_STATUS_COMMAND)) {
        getStatusHistory(writer, data);
        writer.write(S_FINISH);
      }
    } catch(Exception e) {
      e.printStackTrace();
      throw e;
    }

  }

  /**
   * Return XML that represents the structure of the database.
   *
   * @param writer Writer to the remote process making the request
   * @throws Exception
   */
  private void getDbInfo(ProtocolWriter writer) throws Exception {
    StringBuffer response = new StringBuffer("<incadb>\n");
    Map metadata = HibernateUtil.getSessionFactory().getAllClassMetadata();
    String[] names = (String [])metadata.keySet().toArray(new String[0]);
    for(int i = 0; i < names.length; i++) {
      String name = names[i];
      response.append("  <dbclass>\n    <name>").
               append(name.replaceAll(".*\\.", "")).append("</name>\n");
      String[] properties =
        ((ClassMetadata)metadata.get(name)).getPropertyNames();
      for(int j = 0; j < properties.length; j++) {
        name = properties[j];
        // For client convenience, lie about how the Report body is stored
        if(name.equals("bodypart1")) {
          name = "body";
        } else if(name.equals("bodypart2") || name.equals("bodypart3")) {
          continue;
        }
        response.append("    <field>\n      <name>").append(name).
                 append("</name>\n    </field>\n");
      }
      response.append("  </dbclass>\n");
    }
    response.append("</incadb>");
    writer.write(Statement.getOkStatement(response.toString()));
  }

  /**
   * Return a list of the Suite guids in the database.
   *
   * @param writer Writer to the remote process making the request
   * @throws Exception
   */
  private void getGuidList(ProtocolWriter writer) throws Exception {
    List guids = DAO.selectMultiple("select s.guid from Suite as s", null);
    String[] result = new String[guids.size()];
    for(int i = 0; i < result.length; i++) {
      result[i] = (String)guids.get(i);
    }
    writer.write(Statement.getOkStatement(StringMethods.join("\n", result)));
  }

  /**
   * Return a report details document to the client for the given report
   * instance and configuration.
   *
   * @param writer  Writer to the remote process making the request.
   * @param request The instance query request which contains the
   * instance id, followed by a space, and then the report series configuration
   * id.
   *
   * @throws PersistenceException on a failed lookup
   * @throws Exception
   */
  private void getInstance(ProtocolWriter writer, String request)
    throws Exception {
    String[] pieces = request.split(" ");
    Long instanceId = null, configId = null;
    if(pieces.length != 2) {
      throw new ProtocolException
        ("Expected 'instanceId configId', got '" + request + "'");
    }
    try {
      instanceId = Long.valueOf(pieces[0]);
      configId = Long.valueOf(pieces[1]);
    } catch(NumberFormatException e) {
      throw new ProtocolException("Non-numeric id in '" + request + "'");
    }
    SeriesConfig sc = SeriesConfigDAO.load(configId);
    InstanceInfo ii = InstanceInfoDAO.load(instanceId);
    if(sc == null) {
      throw new PersistenceException("Request for unknown config " + configId);
    } else if(ii == null) {
      throw new PersistenceException
        ("Request for unknown instance " + instanceId);
    }
    Report r = ReportDAO.load(ii.getReportId());
    String query = "select cr from ComparisonResult cr " +
                   "  where cr.reportId = " + r.getId() +
                   "  and cr.seriesConfigId = " + configId;
    ComparisonResult cr = (ComparisonResult)DAO.selectUnique(query, null);
    ReportDetailsDocument rdd = toBean(sc, r, ii, cr);
    String response = rdd.toString();
    writer.write(new Statement(Protocol.QUERY_RESULT, response));
  }

  /**
   * Return the output from an HQL/SQL query.
   *
   * @param writer  writer to the remote process making the request.
   * @param select the HQL/SQL select statement
   * @param isHql indicates whether the select is HQL or SQL
   * @throws Exception
   */
  private void getSelectOutput
    (ProtocolWriter writer, String select, boolean isHql) throws Exception {
    // Allow only query HQL/SQL, to avoid a client modifying tables
    if(!select.matches("(?i)^\\s*(SELECT|FROM)\\s.*$")) {
      throw new PersistenceException("Not a SELECT: " + select);
    }
    // Parse the column names from the select statement so that we can use them
    // as XML tags in the reply.  A token is a quoted literal, a name/number, a
    // paren, comma, or operator.  Take care not to treat comma in a function
    // invocation (e.g., concat(a,b) as terminating a column name.
    ArrayList names = new ArrayList();
    Matcher m = Pattern.compile
      ("('[^']*'|\"[^\"]\"|[\\w\\.\\-]+|[\\(\\),]|[^\\w\\(\\),]+)\\s*").
      matcher(select.replaceFirst("(?i)^SELECT\\s+(DISTINCT\\s+)?", ""));
    int parenDepth = 0;
    String name = "";
    while(true) {
      m.find();
      String token = m.group(1);
      if(parenDepth == 0 && token.matches("(?i)as")) {
        name = ""; // Use the subsequent AS name as the entire name
      } else if(parenDepth == 0 && (token.matches("(?i),|FROM"))) {
        name = name.replaceAll("[^\\w\\.\\-]", "_");
        names.add(name);
        name = "";
        if(!token.equals(",")) {
          break;
        }
      } else {
        name += token;
        if(token.equals("(")) {
          parenDepth++;
        } else if(token.equals(")")) {
          parenDepth--;
        }
      }
    }
    // For client convenience, automatic translate references to report body
    // into bodypart1||bodypart2||bodypart3
    select = select.replaceFirst("\\b[aA][sS]\\s+body\\b", "as xBODYx");
    while(true) {
      m = (Pattern.compile("\\b((\\w+)\\.)?body\\b")).matcher(select);
      if(!m.find()) {
        break;
      }
      String prefix = m.group(1) == null ? "" : m.group(1);
      select = select.substring(0, m.start()) +
               prefix + "bodypart1 || " +
               prefix + "bodypart2 || " +
               prefix + "bodypart3" +
               select.substring(m.end());
    }
    select = select.replaceFirst("xBODYx", "body");
    // Make the query
    Session session = HibernateUtil.getCurrentSession();
    List l = null;
    try {
      l = isHql ? session.createQuery(select).list() :
                  session.createSQLQuery(select).list();
    } catch(Exception e) {
      e.printStackTrace();
      throw new PersistenceException(e.toString());
    }
    // Send one response per row.  If the row is a PersistentObject (e.g.,
    // "select sc from SeriesConfig sc", then we can use its toXml() method to
    // translate it; otherwise, we'll have an object array which we'll
    // translate to XML using the parsed names above.
    for(int i = 0; i < l.size(); i++) {
      Object o = l.get(i);
      String xml = null;
      if(o instanceof PersistentObject) {
        xml = ((PersistentObject)o).toXml();
      } else {
        StringBuffer sb = new StringBuffer();
        Object[] values = null;
        try {
          values = (Object [])o;
        } catch(Exception e) {
          values = new Object[] {o};
        }
        sb.append("<object>\n");
        for(int j = 0; j < values.length; j++) {
          name = names.get(j) == null ? j + "" : (String)names.get(j);
          Object value = values[j];
          String s = value == null ? "null" :
            value instanceof PersistentObject?((PersistentObject)value).toXml():
            XmlWrapper.escape( value.toString() );
          sb.append("<").append(name).append(">").
             append(s).
             append("</").append(name).append(">\n");
        }
        sb.append("</object>");
        xml = sb.toString();
      }
      writer.write(new Statement(Protocol.QUERY_RESULT, xml));
    }
  }

  /**
   * Return the latest report summaries for all series selected by an HQL
   * WHERE clause expression.
   *
   * @param writer  Writer to the remote process making the request.
   * @param expr An HQL WHERE clause expression specifying the series of
   *             interest
   * @throws Exception
   */
  private void getLatestInstances(ProtocolWriter writer, String expr)
    throws Exception {

    String query =
      "SELECT config " +
      "FROM Suite suite, SeriesConfig config, Series series " +
      "WHERE config.suite=suite AND config.series=series AND " +
            "config.activated >= config.deactivated AND (" + expr + ")";
    List scList = DAO.selectMultiple(query, null);
    StringBuffer crIds = new StringBuffer();
    StringBuffer iiIds = new StringBuffer();
    for(int i = 0; i < scList.size(); i++) {
      SeriesConfig config = (SeriesConfig)scList.get(i);
      Long crId = config.getLatestComparisonId();
      Long iiId = config.getLatestInstanceId();
      if(crId != null && crId.longValue() >= 0) {
        crIds.append(crId.toString()).append(",");
      }
      if(iiId != null && iiId.longValue() >= 0) {
        iiIds.append(iiId.toString()).append(",");
      }
    }
    Hashtable crsById = new Hashtable();
    if(crIds.length() > 0) {
      crIds.deleteCharAt(crIds.length() - 1); // Trim trailing ,
      query =
        "SELECT cr FROM ComparisonResult cr WHERE cr.id IN (" + crIds + ")";
      List crList = DAO.selectMultiple(query, null);
      for(int i = 0; i < crList.size(); i++) {
        ComparisonResult cr = (ComparisonResult)crList.get(i);
        crsById.put(cr.getId(), cr);
      }
    }
    Hashtable iisById = new Hashtable();
    Hashtable reportsById = new Hashtable();
    if(iiIds.length() > 0) {
      iiIds.deleteCharAt(iiIds.length() - 1); // Trim trailing ,
      query = "SELECT ii, r " +
              "FROM InstanceInfo ii, Report r " +
              "WHERE ii.id IN (" + iiIds + ") " +
              "AND r.id = ii.reportId";
      List iiList = DAO.selectMultiple(query, null);
      for(int i = 0; i < iiList.size(); i++) {
        Object[] row = (Object [])iiList.get(i);
        InstanceInfo ii = (InstanceInfo)row[0];
        Report r = (Report)row[1];
        iisById.put(ii.getId(), ii);
        reportsById.put(r.getId(), r);
      }
    }
    // Loop through each item in the sc list and turn it into a BasicResult.
    Statement reply = new Statement(Protocol.QUERY_RESULT, null);
    for(int i = 0; i < scList.size(); i++) {
      ComparisonResult cr = null;
      InstanceInfo ii = null;
      Report r = null;
      SeriesConfig sc = (SeriesConfig)scList.get(i);
      Long id = sc.getLatestInstanceId();
      if(id != null && id.longValue() >= 0) {
        ii = (InstanceInfo)iisById.get(id);
      }
      if(ii == null) {
        logger.debug("No latest instance for SC " + sc);
      }
      id = ii == null ? null : ii.getReportId();
      if(id != null && id.longValue() >= 0) {
        r = (Report)reportsById.get(id);
      }
      if(r == null) {
        logger.debug("No latest report for SC " + sc);
      }
      id = sc.getLatestComparisonId();
      if(id != null && id.longValue() >= 0) {
        cr = (ComparisonResult)crsById.get(id);
      }
      if(cr == null) {
        logger.debug("No latest comparison for SC " + sc);
      }
      ReportSummaryDocument rsd = toBean(sc, cr, ii, r);
      String s = rsd.toString();
      reply.setData(s.toCharArray());
      writer.write(reply);
    }
  }

  /**
   * Return the a set of GraphInstances for all series selected by an HQL
   * WHERE clause expression.
   *
   * @param writer  Writer to the remote process making the request.
   * @param request a space-separated string specifying the beginning and
   *        ending timestamps and an HQL WHERE clause expression that selects
   *        the desired series.
   * @throws Exception
   */
  private void getPeriodInstances(ProtocolWriter writer, String request)
    throws Exception {

    // Parse the request
    String[] pieces = request.split(" ", 3);
    if(pieces.length != 3) {
      throw new ProtocolException
        ("Expected 'first last expr', got '" + request + "'");
    }
    long begin = 0;
    long end = 0;
    if(pieces[0].matches("^\\d+$")) {
      begin = Long.parseLong(pieces[0]);
    } else {
      throw new ProtocolException("Bad value '" + pieces[0] + "' for begin");
    }
    if(pieces[1].matches("^\\d+$")) {
      end = Long.parseLong(pieces[1]);
    } else {
      throw new ProtocolException("Bad value '" + pieces[1] + "' for end");
    }

    // Get the complete list of SeriesConfigs to report.
    String query =
      "SELECT config, series " +
      "FROM Suite suite, SeriesConfig config, Series series " +
      "WHERE config.suite = suite AND config.series = series AND " +
            "config.activated >= config.deactivated AND (" + pieces[2] + ")";
    List configAndSeriesList = DAO.selectMultiple(query, null);
    if(configAndSeriesList.size() == 0) {
      return;
    }

    // Return each in-range instance for each series
    Statement reply = new Statement(Protocol.QUERY_RESULT, null);
    for(int i = 0; i < configAndSeriesList.size(); i++) {

      SeriesConfig sc =
        (SeriesConfig)((Object [])configAndSeriesList.get(i))[0];
      Series s = (Series)((Object [])configAndSeriesList.get(i))[1];

      query =
        "SELECT r FROM Report r " +
        "WHERE r.series.id = " + s.getId();
      List reportList = DAO.selectMultiple(query, null);
      StringBuffer reportIdList = new StringBuffer();
      HashMap<Long,Report> reportsById = new HashMap<Long,Report>();
      for(int j = 0; j < reportList.size(); j++) {
        Report r = (Report)reportList.get(j);
        reportIdList.append(r.getId()).append(",");
        reportsById.put(r.getId(), r);
      }
      if(reportIdList.length() == 0) {
        continue; // No reports for this series
      }
      reportIdList.deleteCharAt(reportIdList.length() - 1);

      query =
        "SELECT ii FROM InstanceInfo ii " +
        "WHERE ii.reportId IN (" + reportIdList + ") " +
        "AND ii.collected >= :p0 AND ii.collected <= :p1 " +
        "ORDER BY ii.collected";
      List iiList =
        DAO.selectMultiple(query, new Object[] {new Date(begin),new Date(end)});
      if(iiList.size() == 0) {
        continue; // No instances w/in time range
      }

      query =
        "SELECT cr FROM ComparisonResult cr " +
        "WHERE cr.seriesConfigId = " + sc.getId();
      List crList = DAO.selectMultiple(query, null);
      HashMap<Long,ComparisonResult> crsByReportId =
        new HashMap<Long,ComparisonResult>();
      for(int j = 0; j < crList.size(); j++) {
        ComparisonResult cr = (ComparisonResult)crList.get(j);
        crsByReportId.put(cr.getReportId(), cr);
      }

      for(int j = 0; j < iiList.size(); j++) {

        InstanceInfo ii = (InstanceInfo)iiList.get(j);
        Report r = reportsById.get(ii.getReportId());
        ComparisonResult cr = crsByReportId.get(ii.getReportId());

        GraphSeries gs = GraphSeries.Factory.newInstance();
        GraphInstance gi = gs.addNewObject();
        gi.setResource(s.getResource());
        gi.setNickname(sc.getNickname());
        gi.setInstanceId(ii.getId().toString());
        gi.setReportId(ii.getReportId().toString());
        gi.setConfigId(sc.getId().toString());
        Date collected = StringMethods.convertDateString
          (ii.getCollected().toString(), "yyyy-MM-dd HH:mm:ss.S");
        Calendar cal = Calendar.getInstance();
        cal.setTime(collected);
        gi.setCollected(cal);
        String message = reportsById.get(ii.getReportId()).getExit_message();
        boolean success =
          cr == null ? r.getExit_status() : cr.getResult().matches("^Success");
        gi.setExitStatus(success ? "Success" : "Failure");
        gi.setExitMessage(message == null ? "" : message);
        gi.setComparisonResult(cr == null ? "" : cr.getResult());

        reply.setData(gs.xmlText().toCharArray());
        writer.write(reply);

      }

    }

  }

  private static final int SERIES_PER_BATCH = 5;
  /**
   * Return the success/failure counts over a given period for all series in a
   * given newline-delimited list of suites and/or series.
   *
   * @param writer  Writer to the remote process making the request.
   * @param request a space-separated string specifying the period length,
   *   beginning and ending timestamps, and an HQL WHERE clause expression
   *   that selects the desired series.
   * @throws Exception
   */
  private void getStatusHistory(ProtocolWriter writer, String request)
    throws Exception {

    // Parse the request
    String[] pieces = request.split(" ", 4);
    if(pieces.length != 4) {
      throw new ProtocolException
        ("Expected 'period first last expr', got '" + request + "'");
    }
    long periodInMillis = 0;
    long begin = 0;
    long end = 0;
    if(pieces[0].equals("DAY")) {
      periodInMillis = 24L * 60L * 60L * 1000L;
    } else if(pieces[0].equals("WEEK")) {
      periodInMillis = 7L * 24L * 60L * 60L * 1000L;
    } else if(pieces[0].equals("MONTH")) {
      periodInMillis = 30L * 24L * 60L * 60L * 1000L;
    } else if(pieces[0].equals("QUARTER")) {
      periodInMillis = 90L * 24L * 60L * 60L * 1000L;
    } else if(pieces[0].matches("^\\d+$")) {
      periodInMillis = Long.parseLong(pieces[0]) * 60L * 1000L;
    } else {
      throw new ProtocolException("Bad value '" + pieces[0] + "' for period");
    }
    if(pieces[1].matches("^\\d+$")) {
      begin = Long.parseLong(pieces[1]);
    } else {
      throw new ProtocolException("Bad value '" + pieces[1] + "' for begin");
    }
    if(pieces[2].matches("^\\d+$")) {
      end = Long.parseLong(pieces[2]);
    } else {
      throw new ProtocolException("Bad value '" + pieces[2] + "' for end");
    }

    // Get the complete list of SeriesConfigs to report.
    String query =
      "SELECT config " +
      "FROM Suite suite, SeriesConfig config, Series series " +
      "WHERE config.suite = suite AND config.series = series AND " +
            "config.activated >= config.deactivated AND (" + pieces[3] + ")";
    List scList = DAO.selectMultiple(query, null);

    // Construct a separate query result for each SeriesConfig, processing them
    // in batches for efficiency
    Statement reply = new Statement(Protocol.QUERY_RESULT, null);
    for(int i = 0; i < scList.size(); i += SERIES_PER_BATCH) {

      StringBuffer configIdList = new StringBuffer();
      StringBuffer seriesIdList = new StringBuffer();
      for(int j = 0; j < SERIES_PER_BATCH && i + j < scList.size(); j++) {
        SeriesConfig sc = (SeriesConfig)scList.get(i + j);
        configIdList.append(sc.getId().toString()).append(",");
        seriesIdList.append(sc.getSeries().getId().toString()).append(",");
      }
      configIdList.deleteCharAt(configIdList.length() - 1); // trim trailing ,
      seriesIdList.deleteCharAt(seriesIdList.length() - 1); // trim trailing ,

      // Retrieve fields from associated Reports, ComparisonResults, and
      // InstanceInfos that fall w/in the specified time range
      query = "SELECT r.id, r.exit_message, r.series.id " +
              "FROM Report r " +
              "WHERE r.series.id IN (" + seriesIdList + ")";
      List reportList = DAO.selectMultiple(query, null);
      Hashtable reportMessagesByReportId = new Hashtable();
      Hashtable reportSeriesByReportId = new Hashtable();
      for(int j = 0; j < reportList.size(); j++) {
        Object info[] = (Object[])reportList.get(j);
        reportMessagesByReportId.put(info[0], info[1]);
        reportSeriesByReportId.put(info[0], info[2]);
      }
      query = "SELECT cr.reportId, cr.result FROM ComparisonResult cr " +
              "WHERE cr.seriesConfigId IN (" + configIdList + ")";
      List crList = DAO.selectMultiple(query, null);
      Hashtable crResultsByReportId = new Hashtable();
      for(int j = 0; j < crList.size(); j++) {
        Object[] info = (Object[])crList.get(j);
        crResultsByReportId.put(info[0], info[1]);
      }
      List iiList = new ArrayList();
      if(reportList.size() > 0) {
        StringBuffer reportIdList = new StringBuffer();
        for(Enumeration e=reportMessagesByReportId.keys();e.hasMoreElements();){
          reportIdList.append(e.nextElement().toString()).append(",");
        }
        reportIdList.deleteCharAt(reportIdList.length() - 1); // trim trailing ,
        query = "SELECT ii.reportId, ii.collected " +
                "FROM InstanceInfo ii " +
                "WHERE ii.reportId IN (" + reportIdList + ") " +
                "  AND ii.collected >= :p0 " +
                "  AND ii.collected <= :p1 " +
                "ORDER BY ii.collected";
        iiList = DAO.selectMultiple
          (query, new Object[] {new Date(begin), new Date(end)});
      }

      // Construct the return XML for each SeriesConfig
      for(int j = 0; j < SERIES_PER_BATCH && i + j < scList.size(); j++) {

        SeriesConfig sc = (SeriesConfig)scList.get(i + j);
        Series series = sc.getSeries();
        StringBuffer xml = new StringBuffer();
        Long count;
        xml.append("<series>\n")
           .append("  <guid>").append(sc.getSuite().getGuid()).append("</guid>\n")
           .append("  <nickname>").append(sc.getNickname()).append("</nickname>\n")
           .append("  <resource>").append(series.getResource()).append("</resource>\n");
        int nextInstance = 0;
        // For each period, from least recent to most recent ...
        for(long lowBound=begin; lowBound<=end; lowBound+=periodInMillis) {

          Hashtable messageCounts = new Hashtable();
          long highBound = lowBound + periodInMillis - 1;

          // Count the occurences for each message associated with the instances
          // that fall w/in this period, if any
          for( ; nextInstance < iiList.size(); nextInstance++) {
            Object[] info = (Object[])iiList.get(nextInstance);
            Long reportId = (Long)info[0];
            Date collected = (Date)info[1];
            if(collected.getTime() > highBound) {
              break;
            }
            if(!reportSeriesByReportId.get(reportId).equals(series.getId())) {
              continue;
            }
            String message = (String)crResultsByReportId.get(reportId);
            if(message == null) {
              message = (String)reportMessagesByReportId.get(reportId);
            }
            count = (Long)messageCounts.get(message);
            count = new Long((count == null ? 0 : count.longValue()) + 1);
            messageCounts.put(message, count);
          }
          // Add XML for the successes and failures in this period
          xml.append("  <period>\n")
             .append("    <begin>").append(lowBound + "").append("</begin>\n")
             .append("    <end>").append(highBound + "").append("</end>\n");
          long successes = 0;
          count = (Long)messageCounts.get("Success");
          if(count != null) {
            messageCounts.remove("Success");
            successes += count.longValue();
          }
          count = (Long)messageCounts.get(PersistentObject.DB_EMPTY_STRING);
          if(count != null) {
            messageCounts.remove(PersistentObject.DB_EMPTY_STRING);
            successes += count.longValue();
          }
          xml.append("    <success>").append(successes).append("</success>\n");
          for(Enumeration e = messageCounts.keys(); e.hasMoreElements(); ) {
            String message = (String)e.nextElement();
            xml.append("    <failure><message>")
               .append(XmlWrapper.escape(message))
               .append("</message><count>")
               .append(messageCounts.get(message))
               .append("</count></failure>\n");
          }
          xml.append("  </period>\n" );
        }

        // Send the reply
        xml.append("</series>");
        reply.setData(xml.toString().toCharArray());
        writer.write(reply);

      }

    }

  }

  /**
   * Creates a ReportDetailsDocument by copying fields from a DB SeriesConfig,
   * a DB report, and a DB InstanceInfo.
   *
   * @param sc the SeriesConfig for the document
   * @param r the Report for the document
   * @param ii the latest InstanceInfo for the document
   * @param cr the latest ComparisonResult for the document
   */
  protected static ReportDetailsDocument toBean
    (SeriesConfig sc, Report r, InstanceInfo ii, ComparisonResult cr)
    throws PersistenceException {
    ReportDetailsDocument result =
      ReportDetailsDocument.Factory.newInstance();
    ReportDetails rd = result.addNewReportDetails();
    rd.setSuiteId(sc.getSuite().getId().longValue());
    rd.setSeriesConfigId(sc.getId().longValue());
    rd.setSeriesId(r.getSeries().getId().longValue());
    rd.setReportId(r.getId().longValue());
    rd.setInstanceId(ii.getId().longValue());
    rd.setSeriesConfig((edu.sdsc.inca.dataModel.util.SeriesConfig)sc.toBean());
    rd.setReport((edu.sdsc.inca.dataModel.util.Report)r.toBean());
    // Note: apparently getGmt() returns a copy, so the following doesn't work
    //rd.getReport().getGmt().setTime(ii.getCollected());
    GregorianCalendar gmt = new GregorianCalendar();
    gmt.setTime(ii.getCollected());
    rd.getReport().setGmt(gmt);
    String log = ii.getLog();
    if(log != null && !log.equals("") &&
       !log.equals(PersistentObject.DB_EMPTY_STRING)) {
      try {
        rd.getReport().setLog(Log.Factory.parse(log));
      } catch(Exception e) {
        logger.error("Unable to parse log stored in DB:", e);
      }
    }
    if(cr != null) {
      rd.setComparisonResult(cr.getResult());
    }
    rd.setSysusage((edu.sdsc.inca.dataModel.util.Limits)ii.toBean());
    rd.setStderr(r.getStderr());
    return result;
  }

  /**
   * Creates a ReportSummaryDocument by copying fields from a DB SeriesConfig.
   *
   * @param sc the SeriesConfig for the document
   * @param cr the latest comparison result for sc
   * @param ii the latest instance info for sc
   * @param r the latest report for sc
   */
  protected static ReportSummaryDocument toBean
    (SeriesConfig sc, ComparisonResult cr, InstanceInfo ii, Report r)
    throws PersistenceException {
    ReportSummaryDocument result = ReportSummaryDocument.Factory.newInstance();
    ReportSummaryDocument.ReportSummary summary = result.addNewReportSummary();
    Series s = sc.getSeries();
    summary.setHostname(s.getResource());
    summary.setUri(s.getUri());
    summary.setNickname(sc.getNickname());
    summary.setSeriesConfigId(sc.getId().longValue());
    if(ii != null) {
      summary.setInstanceId(ii.getId().longValue());
      GregorianCalendar gmt = new GregorianCalendar();
      gmt.setTime(ii.getCollected());
      summary.setGmt(gmt);
      Schedule sched = sc.getSchedule();
      if(sched != null) {
        // Note that the instance expires two cycles after it was collected
        Date expires = sched.nextEvent(ii.getCollected());
        if(expires != null) {
          expires = sched.nextEvent(expires);
        }
        if(expires != null) {
          GregorianCalendar gmtExpires = new GregorianCalendar();
          gmtExpires.setTime(expires);
          summary.setGmtExpires(gmtExpires);
        }
      }
    }
    if(r != null) {
      String bodyText = r.getBody();
      try {
        summary.setBody(AnyXmlSequence.Factory.parse(bodyText));
      } catch(XmlException e) {
        // empty
      }
      summary.setErrorMessage(r.getExit_message());
    }
    if(cr != null) {
      summary.setComparisonResult(cr.getResult());
    }
    return result;
  }

}
