package edu.sdsc.inca.depot.commands;

import edu.sdsc.inca.Depot;
import edu.sdsc.inca.depot.persistent.*;
import edu.sdsc.inca.depot.util.ReportFilter;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import java.io.BufferedReader;
import java.io.CharArrayWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.StringReader;
import java.util.List;

/**
 * User: cmills
 * Date: Mar 24, 2005
 * Time: 3:25:08 PM
 * For now this class is just required to be able to have the following conversation
 * REPORT SP bogus.name CRLF
 * STDOUT SP {xml data} CRLF
 * SYSUSAGE SP ignored CRLF
 * <p/>
 * This implies that the depot will be able to injest a report that has no errors.
 */

public class InsertTest extends PersistentTest {

  public static final String CRLF = "\r\n";

  private String report
    (String resource, String context, String stdout, String stderr,
     boolean addSysusage) {
    String result = "REPORT " + resource + " " + context + CRLF;
    if(stderr != null) {
      result += "STDERR " + stderr + CRLF;
    }
    if(stdout != null) {
      result += "STDOUT " + stdout + CRLF;
    }
    if(addSysusage) {
      result += "SYSUSAGE cpu_secs=12\nwall_secs=13\nmemory_mb=14\n" + CRLF;
    }
    return result;
  }

  private String report(String resource, String context, String stdout) {
    return report(resource, context, stdout, null, true);
  }

  public void testDuplicateInsert() throws Exception {

    Series s = Series.generate("localhost", "myreporter", 3);
    String report = s.generateReport();

    logger.debug("Insert the first");
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    CharArrayWriter caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    String reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));

    logger.debug("Insert the second");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));

    // make sure that the report was put in the db
    Series dbSeries = SeriesDAO.load(s);
    assertNotNull(dbSeries);
    Object[] reports = dbSeries.getReports().toArray();
    assertEquals(1, reports.length);

    // now try a duplicate w/a different timestamp
    String report2 = report.replaceFirst("<gmt>\\d+", "<gmt>2007");
    logger.debug("Insert the third");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report2)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));

    logger.debug("Query the second");
    dbSeries = SeriesDAO.load(s);
    assertNotNull(dbSeries);
    reports = dbSeries.getReports().toArray();
    assertEquals(1, reports.length);

    // we now should have three instances
    assertEquals(3, DAO.selectMultiple("select i from InstanceInfo as i where i.reportId = :p0", new Object[] {((Report)reports[0]).getId()}).size());

  }

  /** Tests reports for a SeriesConfig that includes a comparitor. */
  public void testWithComparitor() throws Exception {

    SuiteUpdateTest sut = new SuiteUpdateTest();
    Suite suite = Suite.generate("aSuite", 1);
    SeriesConfig sc = suite.getSeriesConfig(0);
    Series s = sc.getSeries();
    AcceptedOutput ao = new AcceptedOutput("ExprComparitor", "body !~ /GOOgi/");
    sc.setAcceptedOutput(ao);
    sut.updateSuite(suite);
    String report = s.generateReport();

    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    CharArrayWriter caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    String reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);

    // See if a ComparisonResult was placed into the DB
    SeriesConfig dbSc =
      (SeriesConfig)DAO.selectUnique("select sc from SeriesConfig as sc", null);
    assertNotNull(dbSc);
    Long crId = dbSc.getLatestComparisonId();
    assertTrue(crId.longValue() >= 0);

    // An identical report should not trigger a second CR
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    dbSc =
      (SeriesConfig)DAO.selectUnique("select sc from SeriesConfig as sc", null);
    assertNotNull(dbSc);
    assertTrue(crId.equals(dbSc.getLatestComparisonId()));

    // But a different one should
    String report2 =
      report.replaceAll("<body[^>]*>.*</body>", "<body><x>GOOgi</x></body>");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report2)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    dbSc =
      (SeriesConfig)DAO.selectUnique("select sc from SeriesConfig as sc", null);
    assertNotNull(dbSc);
    assertFalse(crId.equals(dbSc.getLatestComparisonId()));

  }

  /** Tests reports for a SeriesConfig that includes a log notifier. */
  public void testWithLogNotifier() throws Exception {

    String logPath = "/tmp/InsertLogOutput.txt";
    File logFile = new File(logPath);

    SuiteUpdateTest sut = new SuiteUpdateTest();
    Suite suite = Suite.generate("aSuite", 1);
    SeriesConfig sc = suite.getSeriesConfig(0);
    Series s = sc.getSeries();
    AcceptedOutput ao = new AcceptedOutput("ExprComparitor", "body !~ /GOOgi/");
    Notification n = new Notification();
    n.setNotifier("LogNotifier");
    n.setTarget(logPath);
    ao.setNotification(n);
    sc.setAcceptedOutput(ao);
    sut.updateSuite(suite);

    FileWriter fw = new FileWriter(logPath);
    fw.close();
    long emptyLength = logFile.length();

    String report = s.generateReport();

    // Successful comparison should not generate a notification
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    CharArrayWriter caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    String reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(emptyLength == logFile.length());
    long notifyLength = logFile.length();

    // A failed comparison should also
    String report2 =
      report.replaceAll("<body[^>]*>.*</body>", "<body><x>GOOgi</x></body>");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report2)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(emptyLength == notifyLength);
    notifyLength = logFile.length();

    // An identical failure should not
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report2)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertEquals(notifyLength, logFile.length());

    // A return to success should
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(notifyLength == logFile.length());

    logFile.delete();

  }

  /** Tests backward compatibility for notifiers that specify a Java class. */
  public void testWithClassNotifier() throws Exception {

    String logPath = "/tmp/InsertClassLogOutput.txt";
    File logFile = new File(logPath);

    SuiteUpdateTest sut = new SuiteUpdateTest();
    Suite suite = Suite.generate("xSuite", 1);
    SeriesConfig sc = suite.getSeriesConfig(0);
    Series s = sc.getSeries();
    AcceptedOutput ao = new AcceptedOutput("ExprComparitor", "body !~ /GOOgi/");
    Notification n = new Notification();
    n.setNotifier("edu.sdsc.inca.depot.util.LogNotifier");
    n.setTarget(logPath);
    ao.setNotification(n);
    sc.setAcceptedOutput(ao);
    sut.updateSuite(suite);

    FileWriter fw = new FileWriter(logPath);
    fw.close();
    long emptyLength = logFile.length();

    String report = s.generateReport();
    report =
      report.replaceAll("<body[^>]*>.*</body>", "<body><x>GOOgi</x></body>");

    // failed comparison should not generate a notification
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    CharArrayWriter caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    String reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(emptyLength == logFile.length());
    long notifyLength = logFile.length();

    logFile.delete();

  }

  /** Tests that Insert picks up CRs from equivalent series configs. */
  public void testEquivalentConfigs() throws Exception {

    String logPath = "/tmp/xInsertLogOutput.txt";
    File logFile = new File(logPath);

    SuiteUpdateTest sut = new SuiteUpdateTest();
    Suite suite = Suite.generate("aSuite", 1);

    SeriesConfig sc = suite.getSeriesConfig(0);
    Series s = sc.getSeries();
    AcceptedOutput ao = new AcceptedOutput("ExprComparitor", "body !~ /GOOg/");
    Notification n = new Notification();
    n.setNotifier("LogNotifier");
    n.setTarget(logPath);
    ao.setNotification(n);
    sc.setAcceptedOutput(ao);
    sc.setNickname("Series Nickname");
    sut.updateSuite(suite);

    FileWriter fw = new FileWriter(logPath);
    fw.close();
    long emptyLength = logFile.length();

    // Generate a fail CR from the first SC
    String report = s.generateReport().replaceAll
      ("<body[^>]*>.*</body>", "<body><x>GOOg</x></body>");
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    CharArrayWriter caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    String reply = caw.toString();
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    long notifyLength = logFile.length();
    assertFalse(emptyLength == notifyLength);

    // Deactivate the SC, then add another w/the same nickname and resource
    sc.setAction(SuiteUpdate.DELETE);
    sut.updateSuite(suite);
    ao.setComparison("body =~ /Noon/");
    sc.setAction(SuiteUpdate.ADD);
    sut.updateSuite(suite);

    // An identical CR on the new SC should not notify
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertTrue(logFile.length() == notifyLength);

    logFile.delete();

  }

  /** Tests reports for a SeriesConfig that includes a script notifier. */
  public void testWithScriptNotifier() throws Exception {

    String logPath = "/tmp/InsertScriptOutput.txt";
    String scriptPath = "InsertOutputScript.sh";
    File logFile = new File(logPath);
    File scriptFile = new File(scriptPath);

    SuiteUpdateTest sut = new SuiteUpdateTest();
    Suite suite = Suite.generate("aSuite", 1);
    SeriesConfig sc = suite.getSeriesConfig(0);
    Series s = sc.getSeries();
    AcceptedOutput ao = new AcceptedOutput("ExprComparitor", "body !~ /GOOgi/");
    Notification n = new Notification();
    n.setNotifier("ScriptNotifier");
    n.setTarget(scriptPath);
    ao.setNotification(n);
    sc.setAcceptedOutput(ao);
    sut.updateSuite(suite);
    String report = s.generateReport();

    FileWriter fw = new FileWriter(logPath);
    fw.close();
    long emptyLength = logFile.length();
    fw = new FileWriter(scriptPath);
    fw.write(
      "#!/bin/sh\n" +
      "set | grep '^inca' >> " + logPath + "\n"
    );
    fw.close();
    try {
      Process p = Runtime.getRuntime().exec("chmod +x " + scriptPath);
      p.waitFor();
    } catch(Exception e) {
      // empty
    }

    // Successful comparison should generate a notification
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    CharArrayWriter caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    String reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(emptyLength == logFile.length());
    long notifyLength = logFile.length();

    // A failed comparison should also
    String report2 =
      report.replaceAll("<body[^>]*>.*</body>", "<body><x>GOOgi</x></body>");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report2)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(notifyLength == logFile.length());
    notifyLength = logFile.length();

    // An identical failure should not
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report2)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertEquals(notifyLength, logFile.length());

    // A return to success should
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(notifyLength == logFile.length());

    //logFile.delete();
    scriptFile.delete();

  }

  /** Tests a malformed report. */
  public void testInvalidXml() throws Exception {

    Series s = Series.generate("localhost", "myreporter", 3);
    String report = s.generateReport();
    // Remove hostname--a required tag
    report = report.replaceAll("<hostname>.*</hostname>", "");

    logger.debug("Insert the first");
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    // Should throw a protocol exception
    try {
      new Insert().execute(in, new ProtocolWriter(new CharArrayWriter()));
    } catch(ProtocolException e) {
      assertTrue(e.toString().indexOf("Invalid") >= 0);
      return;
    }
    fail("Invalid XML does not raise an exception");

  }

  /** Tests a series w/no arguments. */
  public void testNoArgs() throws Exception {

    Series s = Series.generate("localhost", "myreporter", 0);
    String report = s.generateReport();

    logger.debug("Insert the first");
    logger.info(report);
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    CharArrayWriter caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    String reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));

    // make sure that the report was put in the db
    Series dbSeries = SeriesDAO.load(s);
    assertNotNull(dbSeries);
    Object[] reports = dbSeries.getReports().toArray();
    assertEquals(1, reports.length);

  }

  /** Tests an excessive report log section. */
  public void testLongLog() throws Exception {

    Series s = Series.generate("localhost", "myreporter", 3);
    String report = s.generateReport();
    String logContent = "";
    while(logContent.length() <= PersistentObject.MAX_DB_LONG_STRING_LENGTH) {
      logContent += "<debug><gmt>0001-01-01T00:00:00</gmt><message>" +
                    logContent.length() + "</message></debug>\n";
    }
    report = report.replaceFirst
      ("</args>", "</args>\n<log>\n" + logContent + "</log>\n");

    logger.debug("Insert the first");
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    new Insert().execute(in, new ProtocolWriter(new CharArrayWriter()));

    logger.debug("Query the first");
    Series dbSeries = SeriesDAO.load(s);
    assertNotNull(dbSeries);
    Object[] reports = dbSeries.getReports().toArray();
    InstanceInfo ii =
      (InstanceInfo)DAO.selectUnique("select i from InstanceInfo as i", null);
    assertTrue(ii != null);
    String dbLogContent = ii.getLog();
    assertTrue
      (dbLogContent.length() <= PersistentObject.MAX_DB_LONG_STRING_LENGTH);
    while(dbLogContent.indexOf(logContent) < 0) {
      logContent = logContent.replaceFirst("<debug>.*?</debug>\n", "");
    }
    assertTrue(!logContent.equals(""));

  }

  public void testReportFilter() throws Exception {

    Series s = Series.generate("localhost", "myreporter", 3);
    String report = s.generateReport();

    logger.debug("Insert the first");
    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    new Insert().execute(in, new ProtocolWriter(new CharArrayWriter()));

    logger.debug("Query the first");
    List instances =
      DAO.selectMultiple("select i from InstanceInfo as i", null);
    assertEquals(1, instances.size());

    System.setProperty("inca.depot.reportFilter", ReportFilter.class.getName());

    logger.debug("Insert the second");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    new Insert().execute(in, new ProtocolWriter(new CharArrayWriter()));

    logger.debug("Query the second");
    instances = DAO.selectMultiple("select i from InstanceInfo as i", null);
    assertEquals(2, instances.size());

    System.setProperty
      ("inca.depot.reportFilter", SuppressingFilter.class.getName());

    logger.debug("Insert the third");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    new Insert().execute(in, new ProtocolWriter(new CharArrayWriter()));

    logger.debug("Query the third");
    instances = DAO.selectMultiple("select i from InstanceInfo as i", null);
    assertEquals(2, instances.size());

    System.setProperty
      ("inca.depot.reportFilter", ModifyingFilter.class.getName());
    List reports = DAO.selectMultiple("select r from Report as r", null);
    assertEquals(1, reports.size());

    logger.debug("Insert the fourth");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    new Insert().execute(in, new ProtocolWriter(new CharArrayWriter()));

    logger.debug("Query the fourth");
    reports = DAO.selectMultiple("select r from Report as r", null);
    assertEquals(2, reports.size());

    System.setProperty
      ("inca.depot.reportFilter", TestReportFilter.class.getName());
    logger.debug("Insert the fifth");
    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report)));
    new Insert().execute(in, new ProtocolWriter(new CharArrayWriter()));
    assertTrue(TestReportFilter.invoked);

  }

  /** Tests what happens when reports arrive out-of-order. */
  public void testOutOfOrder() throws Exception {

    String logPath = "/tmp/InsertLogOutput.txt";
    File logFile = new File(logPath);

    SuiteUpdateTest sut = new SuiteUpdateTest();
    Suite suite = Suite.generate("aSuite", 1);
    SeriesConfig sc = suite.getSeriesConfig(0);
    Series s = sc.getSeries();
    AcceptedOutput ao = new AcceptedOutput("ExprComparitor", "body !~ /GOOgi/");
    Notification n = new Notification();
    n.setNotifier("LogNotifier");
    n.setTarget(logPath);
    ao.setNotification(n);
    sc.setAcceptedOutput(ao);
    sut.updateSuite(suite);

    FileWriter fw = new FileWriter(logPath);
    fw.close();
    long emptyLength = logFile.length();

    String report1 = s.generateReport()
      .replaceAll("<body[^>]*>.*</body>", "<body><x>GOOgi</x></body>");
    Thread.sleep(1);
    String report2 = s.generateReport();
    Thread.sleep(1);
    String report3 = s.generateReport()
      .replaceAll("<body[^>]*>.*</body>", "<body><x>GOOgi</x></body>");
    Thread.sleep(1);
    String report4 = s.generateReport();

    ProtocolReader in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report4)));
    CharArrayWriter caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    String reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(emptyLength == logFile.length());
    long notifyLength = logFile.length();

    in = new ProtocolReader
      (new StringReader(report(s.getResource(), s.getContext(), report3)));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertFalse(logFile.length() == notifyLength);
    notifyLength = logFile.length();

    String message = report(s.getResource(), s.getContext(), report2)
      .replaceFirst("REPORT", "RESEND");
    in = new ProtocolReader(new StringReader(message));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertTrue(logFile.length() == notifyLength);

    message = report(s.getResource(), s.getContext(), report1)
      .replaceFirst("REPORT", "RESEND");
    in = new ProtocolReader(new StringReader(message));
    caw = new CharArrayWriter();
    new Insert().execute(in, new ProtocolWriter(caw));
    reply = caw.toString();
    assertNotNull(reply);
    assertFalse(reply, reply.startsWith("ERROR"));
    Thread.sleep(3);
    assertTrue(logFile.length() == notifyLength);

    logFile.delete();

  }

  public static class ModifyingFilter extends ReportFilter {
    public String getStdout() {
      return this.stdout.replaceFirst
        ("(?s)<body>.*</body>", "<body><different>5</different></body>");
    }
  }

  public static class SuppressingFilter extends ReportFilter {
    public String getContext() {
      return null;
    }
  }

  public static class TestReportFilter
    extends edu.sdsc.inca.depot.util.ReportFilter {
    public static boolean invoked = false;
    public String getStdout() {
      invoked = true;
      return super.getStdout();
    }
  }

}
