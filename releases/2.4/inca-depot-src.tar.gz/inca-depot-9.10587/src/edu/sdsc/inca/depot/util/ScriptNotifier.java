package edu.sdsc.inca.depot.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;
import java.util.Enumeration;
import org.apache.log4j.Logger;

/**
 * A class that notifies a target script about a state change in
 * AcceptableOutput.
 *
 * @author jhayes
 */
public class ScriptNotifier {

  private static Logger logger = Logger.getLogger(ScriptNotifier.class);

  /**
   * Invokes a script, w/info about an AcceptedOutput state change in stdin.
   *
   * @param target the script to notify
   * @param props property values that describe the series and instance
   */
  public void doNotification(String target, Properties props) {
    String[] words = target.split("\\s+");
    String path = words[0];
    // If the script path isn't absolute, search for it in a specified set of
    // directories.
    if(path.indexOf("/") != 0) {
      String searchPath = null; // TODO pick up from property
      if(searchPath == null) {
        searchPath =
          "." + File.pathSeparator + "bin" + File.pathSeparator + "sbin";
      }
      String[] dirs = searchPath.split(File.pathSeparator);
      for(int i = 0; i < dirs.length; i++) {
        File f = new File(dirs[i] + File.separator + path);
        if(f.exists()) {
          path = f.getPath();
          break;
        }
      }
    }
    // Check to see if the script has the working dir as an ancestor; other
    // paths are disallowed for security.  Check cononical path for wd to avoid
    // potential problems with ../ in path.
    try {
      path = new File(path).getCanonicalPath();
      String workingDir =
        new File(System.getProperty("user.dir")).getCanonicalPath();
      if(!path.startsWith(workingDir)) {
        logger.error("Invalid script file path '" + path + "'");
        return;
      }
      words[0] = path;
    } catch(Exception e) {
      logger.error("Error examining script path: " + e);
      return;
    }
    // Store the values of props in environment variables
    String[] environment = new String[props.size()];
    Enumeration keys = props.keys();
    for(int i = 0; i < environment.length; i++) {
      String key = (String)keys.nextElement();
      environment[i] = "inca" + key + "=" + props.getProperty(key);
    }
    // Now run the script
    try {
      Process p = Runtime.getRuntime().exec(words, environment);
      p.waitFor();
      if(p.exitValue() != 0) {
        BufferedReader reader =
          new BufferedReader(new InputStreamReader(p.getErrorStream()));
        String stderr = "", line;
        while((line = reader.readLine()) != null) {
          stderr += line;
        }
        logger.error("Error executing script " + target + ": " + stderr);
      }
    } catch(InterruptedException e) {
      // empty
    } catch(IOException e) {
      logger.error("Error executing script " + target + ": " + e);
    }

  }

}
