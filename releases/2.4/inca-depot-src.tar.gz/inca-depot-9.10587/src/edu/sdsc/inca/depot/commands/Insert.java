package edu.sdsc.inca.depot.commands;

import edu.sdsc.inca.dataModel.report.ReportDocument;
import edu.sdsc.inca.depot.persistent.*;
import edu.sdsc.inca.depot.util.ExprComparitor;
import edu.sdsc.inca.depot.util.HibernateMessageHandler;
import edu.sdsc.inca.depot.util.ReportFilter;
import edu.sdsc.inca.depot.util.ScriptNotifier;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.protocol.Statement;
import edu.sdsc.inca.util.XmlWrapper;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;

/**
 * The task that will take a report and insert it to the database.
 * the REPORT and RESEND commands are supported by this class.
 */
public class Insert extends HibernateMessageHandler {

  private static Logger logger = Logger.getLogger(Insert.class);

  /**
   * Execute the insert task.
   *
   * @throws Exception
   */
  public void executeHibernateAction(ProtocolReader reader,
                                     ProtocolWriter writer) throws Exception {

    String command = null;
    String context = null;
    String resource = null;
    String stderr = null;
    String stdout = null;
    Statement stmt = null;
    String sysusage = null;
    Properties timings = new Properties();
    long before = System.currentTimeMillis();

    // read everything needed from the socket
    stmt = reader.readStatement();
    boolean assumeLatest =
      Protocol.INSERT_COMMAND.equals(new String(stmt.getCmd()));
    String[] pieces = new String(stmt.getData()).split("\\s+", 2);
    resource = pieces[0];
    context = pieces[1];
    command = reader.peekCommand();

    if(command != null && command.equals(Protocol.INSERT_STDERR_COMMAND)) {
      stmt = reader.readStatement();
      stderr = new String(stmt.getData());
      command = reader.peekCommand();
    }

    if(command == null || !command.equals(Protocol.INSERT_STDOUT_COMMAND)) {
      throw new ProtocolException("STDOUT section missing from REPORT message");
    }
    stmt = reader.readStatement();
    stdout = new String(stmt.getData());
    command = reader.peekCommand();

    if(command == null || !command.equals(Protocol.INSERT_SYSUSAGE_COMMAND)) {
      throw new ProtocolException
        ("SYSUSAGE section missing from REPORT message");
    }
    stmt = reader.readStatement();
    sysusage = new String(stmt.getData());
    timings.setProperty("Read", (System.currentTimeMillis()-before) + "");
    before = System.currentTimeMillis();

    String reportFilterProperty = System.getProperty("inca.depot.reportFilter");
    if(reportFilterProperty != null) {
      ClassLoader cl = ClassLoader.getSystemClassLoader();
      String origContext = context;
      String origResource = resource;
      String[] reportFilterNames = reportFilterProperty.split("[\\s,;]+");
      ReportFilter rf = null;
      for(int i = 0; i < reportFilterNames.length; i++) {
        try {
          rf = (ReportFilter)(cl.loadClass(reportFilterNames[i]).newInstance());
        } catch(Exception e) {
          logger.warn
            ("Unable to load ReportFilter '" + reportFilterNames[i] + "' " + e);
          continue;
        }
        rf.setContext(context);
        rf.setResource(resource);
        rf.setStderr(stderr);
        rf.setStdout(stdout);
        rf.setSysusage(sysusage);
        context = rf.getContext();
        resource = rf.getResource();
        stderr = rf.getStderr();
        stdout = rf.getStdout();
        sysusage = rf.getSysusage();
        if(context==null || resource==null || stdout==null || sysusage==null) {
          logger.warn("Report '" + context + "' from " + resource +
                      " suppressed by filter " + reportFilterNames[i]);
          writer.write(Statement.getOkStatement(origContext));
          return;
        }
      }
    }
    timings.setProperty("Filter", (System.currentTimeMillis()-before) + "");
    before = System.currentTimeMillis();

    Report dbReport = null;
    RunInfo dbRunInfo = null;
    Series dbSeries = null;
    edu.sdsc.inca.dataModel.util.Report report = null;

    try {
      ReportDocument doc = ReportDocument.Factory.parse(stdout);
      if(!doc.validate()) {
        throw new XmlException("Invalid report XML '" + stdout + "'");
      }
      report = doc.getReport();
    } catch(XmlException e) {
      throw new ProtocolException("Unable to parse report XML: " + e);
    }
    timings.setProperty("Parse", (System.currentTimeMillis()-before) + "");
    before = System.currentTimeMillis();

    // Let the client know everything went well.
    writer.write(Statement.getOkStatement(context));

    // Construct the four database entities contained in the text of the
    // report--a Series, a Report, an InstanceInfo, and a RunInfo.
    Series s = new Series().fromBean(report);
    s.setResource(resource);
    s.setContext(context);
    Report r = new Report().fromBean(report);
    r.setStderr(stderr);
    InstanceInfo ii = new InstanceInfo(report.getGmt().getTime(), sysusage);
    if(report.getLog() != null) {
      ii.setLog(report.getLog().xmlText());
    }
    RunInfo ri = new RunInfo().fromBean(report);

    // Retrieve them from (existing) or store them in (new) the DB.
    if((dbSeries = SeriesDAO.load(s)) == null) {
      logger.warn
        ("Report of " + s.getReporter() + " unattached to any DB series");
      logger.debug("Auto-add new series to DB");
      dbSeries = SeriesDAO.loadOrSave(s);
    }
    dbRunInfo = RunInfoDAO.loadOrSave(ri);
    r.setSeries(dbSeries);  // ReportDAO.load depends on these being set
    r.setRunInfo(dbRunInfo);
    if((dbReport = ReportDAO.load(r)) == null) {
      logger.debug("Auto-add new report to DB");
      dbReport = ReportDAO.loadOrSave(r);
    }
    dbSeries.addReport(dbReport);
    SeriesDAO.update(dbSeries);
    ReportDAO.update(dbReport);
    logger.debug("Add new instance to DB");
    ii.setReportId(dbReport.getId());
    InstanceInfoDAO.loadOrSave(ii);
    timings.setProperty("DB Records", (System.currentTimeMillis()-before) + "");
    before = System.currentTimeMillis();

    // Update all related SeriesConfigs
    if(dbSeries.getSeriesConfigs().size() < 1) {
      logger.warn
        ("Series of " + s.getReporter() + " unattached to any DB config");
    }

    int i = 0;
    for(Iterator it = dbSeries.getSeriesConfigs().iterator(); it.hasNext(); ) {

      i++;
      SeriesConfig dbSc = (SeriesConfig)it.next();
      // If multiple configs feed into the same series, we could receive
      // reports attached to deactivated series.  Do no processing for these.
      if(dbSc.getDeactivated() > dbSc.getActivated()) {
        continue;
      }

      boolean isLatest =
        assumeLatest ||
        dbSc.getLatestInstanceId().longValue() < 0 ||
        InstanceInfoDAO.load(dbSc.getLatestInstanceId()).getCollected().
          before(ii.getCollected());
      if(isLatest) {
        // Update the SeriesConfig's latest instance field
        dbSc.setLatestInstanceId(ii.getId());
        try {
          SeriesConfigDAO.update(dbSc);
        } catch(PersistenceException e) {
          logger.error("Error storing report series config:" + e);
        }
      }
      timings.setProperty("SC update "+i, (System.currentTimeMillis()-before) + "");
      before = System.currentTimeMillis();

      // Generate and save any comparison the SeriesConfig specifies
      AcceptedOutput ao = dbSc.getAcceptedOutput();
      if(ao == null) {
        continue;
      }
      String comparitor = ao.getComparitor();
      if(comparitor == null || comparitor.equals("") ||
         comparitor.equals(PersistentObject.DB_EMPTY_STRING)) {
        continue;
      }

      String result = new ExprComparitor().compare(ao, dbReport);
      ComparisonResult cr = new ComparisonResult();
      cr.setResult(result);
      cr.setReportId(dbReport.getId());
      cr.setSeriesConfigId(dbSc.getId());
      ComparisonResult dbCr = null;
      try {
        dbCr = ComparisonResultDAO.loadOrSave(cr);
      } catch(Exception e) {
        logger.error("Error storing comparison result:" + e);
      }

      // Update the id in the SeriesConfig if the comparison result changed
      Long priorComparisonId = dbSc.getLatestComparisonId();
      if(!isLatest ||
         dbCr.getId().longValue() == priorComparisonId.longValue()) {
        continue;
      }
      try {
        dbSc.setLatestComparisonId(dbCr.getId());
        SeriesConfigDAO.update(dbSc);
      } catch(Exception e) {
        logger.error("Error updating series config:" + e);
      }
      timings.setProperty("SC compare "+i, (System.currentTimeMillis()-before) + "");
      before = System.currentTimeMillis();
      Notification dbN = ao.getNotification();
      if(dbN == null) {
        continue;
      }
      // Notify only if the result text of the new comparison diffs from the
      // old (as opposed to a new report generating the same result text).
      ComparisonResult priorCr = ComparisonResultDAO.load(priorComparisonId);
      if(priorCr == null && dbSc.getNickname() != null) {
        // Test for the latest comparison result from an equivalent series
        String dbResource = dbSc.getSeries().getResource();
        String query = "Select sc from SeriesConfig AS sc " +
          "WHERE sc.nickname = :p0 AND sc.id != " + dbSc.getId();
        List scs = DAO.selectMultiple(query, new Object[] {dbSc.getNickname()});
        for(int j = 0; j < scs.size(); j++) {
          SeriesConfig likeSc = (SeriesConfig)scs.get(j);
          if(!dbResource.equals(likeSc.getSeries().getResource())) {
            continue;
          }
          ComparisonResult likeCr =
            ComparisonResultDAO.load(likeSc.getLatestComparisonId());
          if(likeCr != null &&
             (priorCr == null ||
              priorCr.getId().longValue() < likeCr.getId().longValue())) {
            priorCr = likeCr;
          }
        }
      }
      timings.setProperty("Notify check " + i, (System.currentTimeMillis()-before) + "");
      before = System.currentTimeMillis();
      if(priorCr != null && result.equals(priorCr.getResult())) {
        continue;
      }
      String notifier = dbN.getNotifier();
      if(notifier == null || notifier.equals("") ||
         notifier.equals(PersistentObject.DB_EMPTY_STRING)) {
        continue;
      }
      Properties props = new Properties();
      // Populate props from the DB fields.  For now we use brute force;
      // Java reflection would be more elegant and maintainable.
      props.setProperty("reportId", dbReport.getId() + "");
      props.setProperty("completed", dbReport.getExit_status() + "");
      String field = dbReport.getExit_message();
      if(field != null && !field.equals("") &&
         !field.equals(PersistentObject.DB_EMPTY_STRING)) {
        props.setProperty("errorMessage", field);
      }
      props.setProperty("body", dbReport.getBody());
      field = dbReport.getStderr();
      if(field != null && !field.equals("") &&
         !field.equals(PersistentObject.DB_EMPTY_STRING)) {
        props.setProperty("stderr", dbReport.getStderr());
      }
      props.setProperty("instanceId", ii.getId() + "");
      props.setProperty("collected", ii.getCollected() + "");
      props.setProperty("commited", ii.getCommited() + "");
      props.setProperty("memoryUsage", ii.getMemoryUsageMB() + "");
      props.setProperty("cpuUsage", ii.getCpuUsageSec() + "");
      props.setProperty("wallClockUsage", ii.getWallClockTimeSec() + "");
      field = ii.getLog();
      if(field != null && !field.equals("") &&
         !field.equals(PersistentObject.DB_EMPTY_STRING)) {
        // Transform log messages from XML format, e.g.,
        // <info><gmt>time</gmt><message>text</message></info>
        // to more readable (info time) text
        field = field.replaceAll("</?xml-fragment[^>]*>", "").
                replaceAll("(?s)<(\\w+)[^>]*>.*?<gmt[^>]*>([^<]+)</gmt>.*?<message[^>]*>([^<]*)</message>.*?</\\w+>", "($1 $2) $3");
        props.setProperty("log", "\n" + XmlWrapper.unescape(field));
      }
      props.setProperty("runInfoId", dbRunInfo.getId() + "");
      props.setProperty("hostname", dbRunInfo.getHostname());
      props.setProperty("workingDir", dbRunInfo.getWorkingDir());
      props.setProperty("reporterPath", dbRunInfo.getReporterPath());
      props.setProperty("seriesId", dbSeries.getId() + "");
      props.setProperty("reporter", dbSeries.getReporter());
      props.setProperty("version", dbSeries.getVersion());
      props.setProperty("uri", dbSeries.getUri());
      props.setProperty("context", dbSeries.getContext());
      props.setProperty("nice", dbSeries.getNice() + "");
      props.setProperty("resource", dbSeries.getResource());
      props.setProperty("args", dbSeries.getArgSignature() + "");
      props.setProperty("configId", dbSc.getId() + "");
      props.setProperty("activated", dbSc.getActivated() + "");
      props.setProperty("deactivated", dbSc.getDeactivated() + "");
      field = dbSc.getNickname();
      if(field != null && !field.equals("") &&
         !field.equals(PersistentObject.DB_EMPTY_STRING)) {
        props.setProperty("nickname", field);
      }
      if(dbSc.getLimits() != null) {
        props.setProperty("memoryLimit", dbSc.getLimits().getMemory() + "");
        props.setProperty("cpuLimit", dbSc.getLimits().getCpuTime() + "");
        props.setProperty
          ("wallClockLimit", dbSc.getLimits().getWallClockTime() + "");
      }
      Schedule sched = dbSc.getSchedule();
      if(sched != null) {
        props.setProperty("schedule", sched.toString());
      }
      props.setProperty("comparitor", ao.getComparitor());
      props.setProperty("comparison", ao.getComparison());
      props.setProperty("notifier", dbN.getNotifier());
      props.setProperty("target", dbN.getTarget());
      props.setProperty("comparisonId", dbCr.getId() + "");
      String res = dbCr.getResult();
      props.setProperty("comparisonResult", res);
      props.setProperty
        ("result", res.startsWith(ExprComparitor.FAILURE_RESULT)?"FAIL":"PASS");
      // Strip any package prefix from notifier and toss "ScriptNotifier"
      // (holdovers from when notification was handled via Java classes).
      notifier = notifier.replaceFirst("edu\\.sdsc\\.inca\\..*\\.", "");
      String target = !notifier.equals("ScriptNotifier") ? notifier + " " : "";
      target += ao.getNotification().getTarget();
      timings.setProperty("Notify init "+i, (System.currentTimeMillis()-before) + "");
      before = System.currentTimeMillis();
      new ScriptNotifier().doNotification(target, props);
      timings.setProperty("Notify "+i, (System.currentTimeMillis()-before) + "");
      before = System.currentTimeMillis();

    }

    StringBuffer timeString = new StringBuffer();
    for(Enumeration e = timings.propertyNames(); e.hasMoreElements(); ) {
      String key = (String)e.nextElement();
      timeString.append(" ").append(key).append(" ")
                .append(timings.getProperty(key));
    }
    logger.debug("Insert times:" + timeString);

  }

}
