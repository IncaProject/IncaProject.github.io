package edu.sdsc.inca.consumer;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.impl.values.XmlAnyTypeImpl;

import edu.sdsc.inca.dataModel.all2all.All2AllSummariesDocument;
import edu.sdsc.inca.dataModel.all2all.Resource;
import edu.sdsc.inca.dataModel.all2all.Resources;
import edu.sdsc.inca.dataModel.all2all.TestSummary;
import edu.sdsc.inca.dataModel.all2all.TestSummaries;
import edu.sdsc.inca.dataModel.all2all.Failures;
import edu.sdsc.inca.dataModel.all2all.Failure;
import edu.sdsc.inca.dataModel.queryResults.ObjectDocument;

import java.util.Properties;
import java.util.Arrays;
import java.util.Vector;
import java.util.HashMap;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.math.BigInteger;

/**
 * Jsp bean that will query the given depot bean for the specified latest
 * suite instances containing all-to-all tests and will return a summary.  It
 * will pick out all-to-all tests by looking for nicknames matching this
 * pattern:
 *
 * all2all:(\S+)_to_(\S+)
 *
 * The first parameter will be taken as the all-to-all test name and the
 * second will be taken as the resource.  The summary will contain for each
 * resource, the number of successes (numSuccesses), the number of at-fault
 * failures (numAtFaultFailures), the number of not-at-fault failures
 * numNotAtFaultFailures, and list of failed
 * tests (e.g., ssh_to_B, ssh_to_D).  The xml will be formatted as:
 *
 * &lt;all2all-test-summary&gt;
 *   &lt;resource&gt;
 *     &lt;testname&gt;
 *       &lt;numSuccesses&gt;
 *       &lt;numAtFaultFailures&gt;
 *       &lt;numNotAtFaultFailures&gt;
 *       &lt;failures&gt;
 *         &lt;nickname&gt;
 *         ...
 *       &lt;/failures&gt;
 *     &lt;/testname&gt;
 *   ...
 *   &lt;/resource&gt;
 * ...
 * &lt;/all2all-test-summary&gt;

 *
 * Required parameters are:
 *
 * suiteName
 * retAttrName
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class All2AllBean {
  final public String NAMESPACE_DECLS =
    "declare namespace q='http://inca.sdsc.edu/dataModel/queryResults_2.0';"+
    "declare namespace r='http://inca.sdsc.edu/queryResult/reportSummary_2.0';";

  public static Logger logger = Logger.getLogger(All2AllBean.class);

  // types of test results
  public enum RESULT { MISSING, FAILURE, SUCCESS }

  // summary stats
  public static int NUM_STATS = 3;
  public static int SUCCESSES = 0;
  public static int NAF_FAILURES = 1;
  public static int AF_FAILURES = 2;

  // member variables
  private String suiteGuid = null;
  private DepotBean depotBean = null;

  // convert report summaries into a R X R matrix of results that can be
  // manipulated
  public class TestData {
    public String[] resources = new String[0];
    public RESULT[][] rawResults = new RESULT[0][0];
    public TestResult[] docs = new TestResult[0];
  }

  public class TestSummaryResults {
    public int[][] summary = new int[0][0];
    public int[][] failures = new int[0][0];
  }

  public static class TestResult {
    public String client = null;
    public int instanceId = 0;
    public int seriesConfigId = 0;
    public String server = null;
    public RESULT result = RESULT.SUCCESS;
    public String testName = null;

    public TestResult() {
    }

    public TestResult(String client, int instanceId, RESULT result,
                      int seriesConfigId, String server, String testName) {
      this.client = client;
      this.instanceId = instanceId;
      this.result = result;
      this.seriesConfigId = seriesConfigId;
      this.server = server;
      this.testName = testName;
    }

    public String toString() {
      return this.testName + " from " + this.client + " to " + this.server +
        " = " + this.result + " (" + this.seriesConfigId + ", " +
        this.instanceId + ")";
    }
  }

  /**
   * Return the name of the suite where all-2-all summary results will be
   * extracted from.
   *
   * @return the name of a suite.
   */
  public String getSuiteGuid() {
    return suiteGuid;
  }

  /**
   * Extract the list of all-to-all test names found in the provided report
   * summaries.
   *
   * @param suite A cached suite document.
   *
   * @return  An array of strings containing the all-to-all test names.
   */
  public String[] getTestNames( ObjectDocument suite ) {
    Properties testNames = new Properties();
    XmlObject[] objects = suite.selectPath
      ( NAMESPACE_DECLS + "/q:object/row/r:reportSummary/nickname" );
    if ( objects == null ) {
      logger.debug( "No nicknames found in suite" );
      return new String[0];
    }
    for ( XmlObject object : objects ) {
      String nickname = object.toString();
      if ( nickname == null ) continue;
      String testName = findValue( "all2all:(\\S+)_to_\\S+", nickname );
      if ( testName != null ) testNames.setProperty( testName, "" );
    }
    return testNames.keySet().toArray(new String[testNames.size()]);
  }

  /**
   * Retrieves the suite configuration from the consumer cache, finds all
   * all-to-all test results, and returns a summary of the results per resource.
   *
   * @return A string containing the summary of all-to-all test results per
   * resources or null if problem getting results.
   */
  public String getXml() {

    // query agent for resource configuration document
    String xml =
      depotBean.getQueryResult( DepotBean.getCacheName(this.getSuiteGuid()) );
    if ( xml == null ) {
      logger.error( "Retrieved null suite from consumer depot cache" );
      return null;
    }
    logger.debug( "Searching latest suite instances for all-to-all tests" );
    ObjectDocument doc = null;
    try {
      doc = ObjectDocument.Factory.parse( xml );
    } catch (XmlException e) {
      logger.error( "Unable to parse xml", e );
      return null;
    }
    String[] all2alls = getTestNames( doc );
    Arrays.sort( all2alls );
    HashMap<String,TestSummaries> resourceTotals =
      new HashMap<String,TestSummaries>();
    for ( String all2all : all2alls ) {
      logger.debug( "Computing all to all summary for test " + all2all );
      TestData testData = extractTestData( all2all, doc );
      TestSummaryResults summaryResults = computeSummary(testData.rawResults);
      for ( int j = 0; j < summaryResults.summary.length; j++ ) {
        if ( !resourceTotals.containsKey(testData.resources[j]) ) {
          resourceTotals.put(
            testData.resources[j],
            TestSummaries.Factory.newInstance()
          );
        }
        TestSummaries resourceSummaries =
          resourceTotals.get( testData.resources[j] );
        TestSummary testSummary = resourceSummaries.addNewTestSummary();
        testSummary.setName( all2all );
        testSummary.setNumSuccesses(
          BigInteger.valueOf(summaryResults.summary[j][SUCCESSES])
        );
        testSummary.setNumAtFaultFailures(
          BigInteger.valueOf(summaryResults.summary[j][AF_FAILURES])
        );
        testSummary.setNumNotAtFaultFailures(
          BigInteger.valueOf(summaryResults.summary[j][NAF_FAILURES])
        );
        Failures failures = testSummary.addNewFailures();
        for ( int m = 0; m < summaryResults.failures[j].length; m++ ) {
          TestResult result =
            testData.docs[summaryResults.failures[j][m]];
          Failure failure = failures.addNewFailure();
          failure.setNickname( result.testName );
          failure.setInstanceId( result.instanceId );
          failure.setSeriesConfigId( result.seriesConfigId );
        }
        resourceTotals.put( testData.resources[j], resourceSummaries );
      }
    }
    String[] resourceNames =
      resourceTotals.keySet().toArray(new String[resourceTotals.size()]);
    Arrays.sort( resourceNames );
    All2AllSummariesDocument sumDoc =
      All2AllSummariesDocument.Factory.newInstance();
    sumDoc.addNewAll2AllSummaries();
    Resources resources = sumDoc.getAll2AllSummaries().addNewResources();
    for ( int i = 0; i < resourceTotals.size(); i++ ) {
      Resource resource = resources.addNewResource();
      resource.setName( resourceNames[i] );
      resource.setTestSummaries( resourceTotals.get( resourceNames[i] ) );
    }
    return sumDoc.toString();
  }

  /**
   * Set the depot bean where suite information can be retrieved from.
   *
   * @param depotBean A depot bean object
   */
  public void setDepotBean( DepotBean depotBean ) {
    this.depotBean = depotBean;
  }

  /**
   * Set the name of the suite where all-2-all summary results will be
   * extracted from.
   *
   * @param suiteGuid  the name of a suite
   */
  public void setSuiteGuid( String suiteGuid) {
    this.suiteGuid = suiteGuid;
  }

  // Protected Functions

  /**
   * Compute the number of successes and failures for each resource
   * given an R X R array of all-to-all integer test results where
   *
   * R = set of resources
   *
   * r[i][j] = 1 if the test from the ith resource to jth resource succeeds,
   * r[i][j] = 0 if test from the ith resource to jth resource fails,
   * r[i][j] = -1 if the result of the test from the ith resource to jth
   * resource is missing
   *
   * The following rules will be used to count the number of successes and
   * failures:
   *
   * 1) if r[i][j] == 1, a success is added to resource i and resource j
   * 2) if r[i][j] == 0, a failure is added to resource i if i == j or
   *    r[k][j] == 1 where resource k != i and k != j or
   *    it's the only result so far (i.e., if a resource is testing to itself
   *    or if at least one other resource successfully tests to resource j or
   *    it's the only result so far, then we assume the failure is
   *    on resource i).
   * 3) if r[i][j] == 0, a failure is added to resource j if r[i][k] == 1 where
   *    k != j and k != i or it's the only result so far (i.e., if resource i
   *    successfully tests to at least one other
   *    resource, then we assume the failure is on resource j).
   *
   * @param results     An R X R array of all-to-all boolean test results.
   *
   * @return  An R X 3 array of summary results S, where
   * s[i][0] = number of i successes for resource j
   * s[i][1] = number of i not-at-fault failures for resource j
   * s[i][2] = number of i at fault failures for resource j
   */
  protected TestSummaryResults computeSummary( RESULT [][] results ) {

    // initialized to 0's
    TestSummaryResults summaryResults = new TestSummaryResults();
    summaryResults.summary = new int[results.length][NUM_STATS];
    Vector[] failures = new Vector[results.length];
    for ( int i = 0; i < failures.length; i++ ) {
      failures[i] = new Vector<BigInteger>();
    }

    // if r[i][j] == 1, a success is added to resource i and resource j
    for( int i = 0; i < results.length; i++ ) {
      for( int j = 0; j < results[i].length; j++ ) {
        if ( results[i][j] == RESULT.SUCCESS ) {
          summaryResults.summary[i][SUCCESSES]++;
          if ( i != j ) summaryResults.summary[j][SUCCESSES]++;
        }
      }
    }

    for( int j = 0; j < results.length; j++ ) {
      // if r[i][j] == 0, a failure is added to resource i if i == j or
      // r[k][j] == 1 where resource k != i and k != j or
      // it's the only result so far
      boolean oneSuccess = false;
      int numResults = 0;
      for( int i = 0; i < results[j].length; i++ ) {
        if ( results[i][j] == RESULT.SUCCESS && i != j) oneSuccess = true;
        if ( results[i][j] != RESULT.MISSING && i != j ) numResults++;
      }
      for( int i = 0; i < results[j].length; i++ ) {
        if ( results[i][j] == RESULT.FAILURE ) {
          if ( numResults < 2 || oneSuccess || i == j ) {
            logger.debug(
              "jloop at fault failure added to " + i + " for " + i + "," + j
            );
            summaryResults.summary[i][AF_FAILURES]++;
            failures[i].add( BigInteger.valueOf(i * results.length + j) );
          } else {
            logger.debug(
              "jloop not at fault failure added to " + i + " for " + i + "," + j
            );
            summaryResults.summary[i][NAF_FAILURES]++;
          }
        }
      }
    }

    for( int i = 0; i < results.length; i++ ) {
      // if r[i][j] == 0, a failure is added to resource j if r[i][k] == 1 where
      // k != j and k != i or it's the only result so far
      boolean oneSuccess = false;
      int numResults = 0;
      for( int j = 0; j < results[i].length; j++ ) {
        if ( results[i][j] == RESULT.SUCCESS ) oneSuccess = true;
        if ( results[i][j] != RESULT.MISSING && i != j ) numResults++;
      }
      for( int j = 0; j < results[i].length; j++ ) {
        if ( results[i][j] == RESULT.FAILURE ) {
          if ( numResults < 2  || oneSuccess || i == j ) {
            // if to itself, let's only count in once in above loop
            if ( i != j ) {
              logger.debug(
                "iloop at fault failure added to " + j + " for " + i + "," + j
              );
              summaryResults.summary[j][AF_FAILURES]++;
              failures[j].add( BigInteger.valueOf(i * results.length + j) );
            }
          } else {
            logger.debug(
              "iloop not at fault failure added to " + j + " for " + i + "," + j
            );
            summaryResults.summary[j][NAF_FAILURES]++;
          }
        }
      }
    }

    summaryResults.failures = new int[results.length][];
    for ( int i = 0; i < results.length; i++ ) {
      summaryResults.failures[i] = new int[failures[i].size()];
      for ( int j = 0; j < failures[i].size(); j++ ) {
        summaryResults.failures[i][j] =
        ((BigInteger)failures[i].get(j)).intValue();
      }
    }
    return summaryResults;
  }

  /**
   * Search the given report summaries for those that match our test name
   * and create a R X R matrix of test results, where R is the set of
   * resources involved in the all-to-all test.
   *
   * @param testName  The name of the all-to-all test running on the set of
   * resources R.
   * @param suite   The suite results
   *
   * @return  The matrix of test results and array of resources returned in a
   * TestData object.
   */
  protected TestData extractTestData( String testName, ObjectDocument suite ) {

    Properties resources = new Properties();
    Vector<TestResult> testSummaries = new Vector<TestResult>();
    TestData testData = new TestData();
    XmlObject[] objects = suite.selectPath
      ( NAMESPACE_DECLS + "/q:object/row/r:reportSummary" );
    if ( objects == null ) {
      logger.warn( "Unable to find report summaries" );
      return testData;
    }
    logger.debug("Found " + objects.length + " " + testName + " test results");
    for ( XmlObject object: objects ) {
      String nickname = selectString( object, "nickname ");
      String server = findValue( "all2all:"+testName+"_to_(\\S+)", nickname );
      String client = selectString( object, "hostname" );
      if ( server != null && client != null ) {
        TestResult result = new TestResult();
        result.server = server;
        resources.put( server, "" );
        resources.put( client, "" );
        result.client = client;
        XmlObject[] bodies = object.selectPath( "body" );
        if ( bodies.length < 1 ) {
          result.result = RESULT.MISSING;
        } else {
          XmlOptions xmlOptions = new XmlOptions();
          xmlOptions.setSaveOuter();
          if ( bodies[0].xmlText(xmlOptions).matches( "^<body[^>]*/>$") ) {
            result.result = RESULT.FAILURE;
          } else {
            result.result= RESULT.SUCCESS;
          }
        }
        result.testName = nickname;
        String instanceIdString = selectString( object, "instanceId ");
        if ( instanceIdString != null ) {
          result.instanceId = Integer.parseInt( instanceIdString );
        }
        result.seriesConfigId = Integer.parseInt
          ( selectString( object, "seriesConfigId ") );
        testSummaries.add( result );
      }
    }
    testData.resources =
      resources.keySet().toArray(new String[resources.size()]);
    Arrays.sort( testData.resources );

    testData.rawResults =
      new RESULT[testData.resources.length][testData.resources.length];
    testData.docs = new TestResult
      [ testData.resources.length*testData.resources.length ];
    for ( int i = 0; i < testData.resources.length; i++ ) {
      Arrays.fill( testData.rawResults[i], RESULT.MISSING );
    }
    for ( TestResult result : testSummaries ) {
      int serverIndex = Arrays.binarySearch(testData.resources, result.server);
      int clientIndex = Arrays.binarySearch(testData.resources, result.client);
      testData.docs[(clientIndex*testData.resources.length)+serverIndex]=result;
      testData.rawResults[clientIndex][serverIndex] = result.result;
    }

    return testData;
  }

  // Private Functions

  /**
   * Extract a value from the provided string using the provided pattern.
   *
   * @param pattern    A pattern containing one group.
   * @param searchString  A string containing the desired value.
   *
   * @return The value of the matched pattern or null if it is not found.
   */
  private static String findValue( String pattern, String searchString ) {

    Pattern thePattern = Pattern.compile(pattern);
    Matcher theMatcher = thePattern.matcher( searchString );
    if ( theMatcher.find() ) {
      return theMatcher.group(1);
    } else {
      return null;
    }
  }

  /**
   * Retrieve a string from an xml document using an xpath expression
   *
   * @param object  An XmlObject object that contains xml
   *
   * @param xpath An xpath expression to a string value
   *
   * @return  The string that was searched for or null if it doesn't exist
   */
  private String selectString(XmlObject object, String xpath ) {
    XmlObject[] objects = object.selectPath( xpath );
    if ( objects.length > 0 ) {
      return ((XmlAnyTypeImpl)objects[0]).stringValue();
    } else {
      return null;
    }
  }


}