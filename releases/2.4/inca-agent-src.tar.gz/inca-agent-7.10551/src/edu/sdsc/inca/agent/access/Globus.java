package edu.sdsc.inca.agent.access;

import org.globus.cog.abstraction.interfaces.Task;
import org.globus.cog.abstraction.interfaces.JobSpecification;
import org.globus.cog.abstraction.interfaces.Service;
import org.globus.cog.abstraction.interfaces.SecurityContext;
import org.globus.cog.abstraction.interfaces.ServiceContact;
import org.globus.cog.abstraction.interfaces.TaskHandler;
import org.globus.cog.abstraction.interfaces.Status;
import org.globus.cog.abstraction.interfaces.StatusListener;
import org.globus.cog.abstraction.interfaces.FileResource;
import org.globus.cog.abstraction.impl.common.task.TaskImpl;
import org.globus.cog.abstraction.impl.common.task.JobSpecificationImpl;
import org.globus.cog.abstraction.impl.common.task.ServiceImpl;
import org.globus.cog.abstraction.impl.common.task.ServiceContactImpl;
import org.globus.cog.abstraction.impl.common.task.ExecutionTaskHandler;
import org.globus.cog.abstraction.impl.common.AbstractionFactory;
import org.globus.cog.abstraction.impl.common.StatusEvent;
import org.globus.cog.abstraction.impl.file.gridftp.FileResourceImpl;
import org.globus.myproxy.MyProxyException;
import org.apache.log4j.Logger;
import org.gridforum.jgss.ExtendedGSSManager;
import org.ietf.jgss.GSSCredential;
import org.ietf.jgss.GSSException;

import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.agent.AccessMethod;
import edu.sdsc.inca.agent.ReporterManagerProxy;
import edu.sdsc.inca.util.ResourcesWrapper;
import edu.sdsc.inca.util.Constants;
import edu.sdsc.inca.util.StringMethods;
import edu.sdsc.inca.agent.AccessMethodException;
import edu.sdsc.inca.agent.AccessMethodOutput;
import edu.sdsc.inca.protocol.Protocol;

import java.io.File;
import java.io.FileWriter;


/**
 * A class that implements AccessMethod using Globus commands
 * (i.e., gridFTP and GRAM) for transferring files and running processes on
 * remote resources.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class Globus extends AccessMethod {
  // Constants
  public static final int MINIMUM_LIFETIME = 4 * Constants.SECONDS_TO_HOUR;
  public static final String GRIDFTP_PROVIDER = "GridFTP";

  // Member variables
  protected String gridFtpContact = null;
  protected String gramContact = null;
  Logger logger = Logger.getLogger(this.getClass().toString());
  private TaskHandler activeHandler = null;
  private Task activeTask = null;
  private String provider = null;
  private ReporterManagerProxy proxy = null;
  private GSSCredential credential = null;
  private String tempDir = null;

  /**
   * A subclass of StatusListener will be notified when our job's status has
   * changed
   */
  public class GlobusStatusListener implements StatusListener {

    /**
     * Called whenever the job status has changed.  We notify whoever is
     * waiting on this listener when the job has been changed to active or
     * failed.
     *
     * @param event  The new status of the job.
     */
    public void statusChanged( StatusEvent event ) {
      if ( event.getStatus().getStatusCode() == Status.SUBMITTED ) {
        logger.debug( "Job summitted" );
      } else {
        synchronized( this ) {
          this.notifyAll();
        }
        logger.debug( "Job status: " + event.getStatus().getStatusString() );
      }
    }

  }


  /**
   * Create a new remote process controlling it via Globus commands. The given
   * resource should exist in the resource configuration file and have the
   * following fields defined:  gridFtpServer, gridFtpPort, gramServer,
   * and gramPort.  If one of those fields is missing, a ConfigurationException
   * is thrown.
   *
   * @param resource  The name of the resource to start the process on
   *
   * @param resources  The resource configuration information.
   *
   * @param temp      Path to a directory for temporary files to be stored
   *
   * @param provider  Indicate version of globus to use (i.e., GT2 or GT4)
   * 
   * @throws ConfigurationException  if trouble configuring globus resource
   */
  public Globus(
    String resource, ResourcesWrapper resources, String temp, String provider )
    throws ConfigurationException {

    // Transfer info - <gridftp server>:<gridftp port>[:<gridftp server dn>]
    this.gridFtpContact = resources.getValue
      ( resource, Protocol.FILE_SERVER_MACRO );
    if ( this.gridFtpContact == null ) {
      this.gridFtpContact = resource;
    }
    String portString = resources.getValue(resource, Protocol.FILE_PORT_MACRO);
    if ( portString == null ) {
      portString = Protocol.FILE_PORT_MACRO_DEFAULT;
    }
    this.gridFtpContact += ":" + portString;
    String dn = resources.getValue(resource, Protocol.GRIDFTP_DN_MACRO);
    if ( dn != null ) {
      this.gridFtpContact += ":" + dn;
    }
    logger.debug( "gridftp contact: " + this.gridFtpContact );

    // Remote invocation
    //   <gram server>:<gram port>[/gram service][:<gram server dn>]
    String gramServer = resources.getValue
      ( resource, Protocol.COMPUTE_SERVER_MACRO );
    if ( gramServer == null ) gramServer = resource;
    portString = resources.getValue( resource, Protocol.COMPUTE_PORT_MACRO );
    if ( provider.equals("GT4") ) {
      this.gramContact = "https://" + gramServer;
      if ( portString != null ) {
        this.gramContact += ":" + portString;
      }
      this.gramContact += "/wsrf/services/ManagedJobFactoryService";
    } else {
      if ( portString == null ) {
        portString = Protocol.GLOBUS_SERVER_PORT_MACRO_DEFAULT;
      }
      this.gramContact = gramServer + ":" + portString;
      String service = resources.getValue(resource,Protocol.GRAM_SERVICE_MACRO);
      if ( service == null ) service = Protocol.GRAM_SERVICE_MACRO_DEFAULT;
      this.gramContact += "/" + service;
      dn = resources.getValue( resource, Protocol.GRAM_DN_MACRO );
      if ( dn != null ) {
        this.gramContact += ":" + dn;
      }
    }
    logger.debug( "gram contact: " + this.gramContact );

    // proxy for launching jobs
    try {
      this.proxy = new ReporterManagerProxy( resource, resources );
    } catch ( ConfigurationException e ) {
      logger.info(
        "Proxy renewal turned off for resource '" + resource + "': " + e
      );
      this.proxy = null;
    }

    this.provider = provider;
    this.tempDir = temp;
  }

  /**
   * Transfer a list of remote files to a directory on the local machine using
   * GridFTP.
   *
   * @param remoteFiles  Array of paths to remote files that will be transfered
   *
   * @param localDirPath    Path to the local directory where the remote file
   *                        will be placed
   *
   * @throws AccessMethodException if unable to put file
   */
  public void get( String[] remoteFiles, String localDirPath )
    throws AccessMethodException
  {

    try {
      // create connection
      FileResource file = connectGridftp();

      // make dir if it doesn't already exist.
      File localDirHandle = new File( localDirPath );
      if ( ! localDirHandle.exists() ) {
        if ( ! localDirHandle.mkdirs() ) {
          throw new AccessMethodException(
            "Failed to create directory '" + localDirPath + "'"
          );
        }
      }

      // get files
      for ( int i = 0; i < remoteFiles.length; i++ ) {
        // Strip off $(HOME)/ if it exists because only gram recognizes it
        String remoteFilePath = remoteFiles[i].replaceFirst
          ( "\\$\\(HOME\\)/", "" );
        File remoteFileHandle = new File( remoteFilePath );
        String localFilePath = localDirPath + "/" + remoteFileHandle.getName();
        logger.debug
          ( "Get of remote file " + remoteFilePath + " to " + localFilePath );
        file.getFile( remoteFilePath, localFilePath );
      }
      file.stop();
    } catch ( Exception e ) {
      throw new AccessMethodException( "Unable to get files", e );
    }

  }

  /**
   * Check whether the remote process is alive.
   *
   * @return true if the remote process is alive; false otherwise.
   */
  public boolean isActive() {
    return this.activeTask != null && this.activeTask.isActive();
  }

  /**
   * Given a path relative to the home directory, prepend '$(HOME)/'
   * to the path and return the new string.
   *
   * @param path   A path relative to the user's home directory
   *
   * @return  A new string that contains '$(HOME)/' prepended to the
   * provided path.
   */
  public String prependHome( String path ) {
    return "$(HOME)/" + path;
  }

  /**
   * Execute the specified process on the remote resource.  This call will block
   * until the process has completed.
   *
   * @param executable Path to the remote executable.
   * @param arguments  Contains the arguments that should be passed to the
   *                   executable
   * @param stdin      A string that will be passedd in as stdin to the process
   *                   when it is started

   * @param directory  Path to the directory where the process will be executed
   *                   from
   * @return The stdout and stderr of the executed process in
   * RemoteProcessObject.
   */
  public AccessMethodOutput run ( String executable, String[] arguments,
                                  String stdin, String directory )
    throws AccessMethodException, InterruptedException {

    logger.debug( "Exec: " + executable );
    logger.debug( "Args: " + StringMethods.join(" ", arguments) );    
    File stdinFile = null;
    Task task = null;
    try {
      if ( stdin != null ) {
        stdinFile = File.createTempFile("inca", "tmp", new File(this.tempDir));
      }
      task = createJob
        ( executable, arguments, stdin, directory, stdinFile, true, true );
    } catch ( Exception e ) {
      if ( stdinFile != null ) stdinFile.delete();
      throw new AccessMethodException( "Globus remote run failed", e );
    }

    // Submit request and error checking
    String errorMsg = "Globus call failed to " + gramContact;
    TaskHandler taskHandler = new ExecutionTaskHandler();
    try {
      logger.info( "GRAM CONTACT = " + gramContact );
      taskHandler.submit( task );
      logger.debug( "Waiting for Globus task to complete" );
      task.waitFor();
      logger.debug( "Globus task completed" );
    } catch( InterruptedException e ) {
      throw e;
    } catch ( Exception e ) {
      logger.error( errorMsg, e );
      throw new AccessMethodException( errorMsg, e );
    } finally {
      logger.debug( "Cleaning up temporary stdin file" );
      if ( stdinFile != null ) stdinFile.delete();
    }
    if ( task.getStatus().getStatusCode() != Status.COMPLETED ) {
      if ( task.getStatus().getException() != null) {
        logger.error( errorMsg, task.getStatus().getException() );
      }
      if ( task.getStatus().getMessage() != null) {
        logger.error( errorMsg + ": " + task.getStatus().getMessage() );
      }
      throw new AccessMethodException(
        errorMsg + ": " + task.getStatus().getStatusString()
      );
    }

    // return stdout and stderr
    AccessMethodOutput result = new AccessMethodOutput();
    result.setStdout( task.getStdOutput() );
    result.setStderr( task.getStdError() );
    return result;
  }

  /**
   * Set the proxy for Globus related tasks.
   *
   * @param proxy  The reporter manager proxy object that can be used to
   * retrieve a proxy from the MyProxy server if available 
   */
  public void setProxy( ReporterManagerProxy proxy ) {
    this.proxy = proxy;
  }

  /**
   * Start a process on a remote machine.  This is a non-blocking call.
   *
   * @param executable  Path to the remote executable.
   * @param arguments   Contains the arguments that should be passed to the
   *                    executable
   * @param stdin      A string that will be passedd in as stdin to the process
   *                   when it is started
   * @param directory  Path to the directory where the process will be executed
   *                   from
   */
  public void start(String executable, String[] arguments, String stdin,
                    String directory) throws AccessMethodException {

    if ( this.activeTask != null || this.activeHandler != null ) {
      throw new AccessMethodException(
        "An existing job is already running; " +
        "only one process at a time currently supported"
      );
    }

    File stdinFile = null;
    try {
      if ( stdin != null ) {
        stdinFile = File.createTempFile( "inca", "tmp", new File(this.tempDir) );
      }
      this.activeTask = createJob(
        executable, arguments, stdin, directory, stdinFile, false, false
      );
      GlobusStatusListener listener = new GlobusStatusListener();
      this.activeTask.addStatusListener( listener );

      // Submit GRAM request and error checking
      this.activeHandler = new ExecutionTaskHandler();

      logger.info( "GRAM CONTACT = " + gramContact );
      this.activeHandler.submit( this.activeTask );
      synchronized( listener ) {
        listener.wait();
      }
    } catch ( Exception e ) {
      throw new AccessMethodException("Unable to start remote globus process",e);
    } finally {
      if ( stdinFile != null && stdinFile.exists() ) stdinFile.delete();
    }
  }

  /**
   * Kill the remote process that was started by the start() call.
   *
   * @throws AccessMethodException
   */
  public void stop() throws AccessMethodException {
    if ( this.activeTask != null && this.activeHandler != null ) {
      try {
        this.activeHandler.cancel( this.activeTask );
      } catch ( Exception e ) {
        throw new AccessMethodException(
          "Stop of remote Globus process failed", e
        );
      }
      this.activeHandler = null;
      this.activeTask = null;
    }
  }

  /**
   * Transfer a list of local files to a directory on a remote machine using
   * GridFTP.
   *
   * @param localFiles       Array of local file paths that will be transfered
   *
   * @param remoteDirPath    Path to the directory on the remote machine where
   *                         the local file will be placed
   *
   * @throws AccessMethodException if unable to transfer files
   */
  public void put( String[] localFiles, String remoteDirPath )
    throws AccessMethodException
  {

    try {
      // create connection
      FileResource file = connectGridftp();

      // Strip off $(HOME)/ if it exists because only gram recognizes it
      remoteDirPath = remoteDirPath.replaceFirst( "\\$\\(HOME\\)/", "" );

      // make dir if it doesn't already exist.  Since there is no mkdirs option,
      // we have to start with the beginning of the path and check that each
      // dir exists.
      String[] remoteDir = remoteDirPath.split( "/" );
      String remoteDirPath2;
      if ( remoteDirPath.startsWith("/") ) {
        remoteDirPath2 = "/";
      } else {
        remoteDirPath2 = file.getCurrentDirectory() + "/";
      }
      for ( int i = 0; i < remoteDir.length; i++ ) {
        remoteDirPath2 += remoteDir[i] + "/";
        if ( ! file.exists( remoteDirPath2 ) ) {
          file.createDirectory(remoteDirPath2);
        }
        if ( file.isDirectory( remoteDirPath2 ) ) {
          file.setCurrentDirectory( remoteDirPath2 );
        } else {
          throw new AccessMethodException(
            "Unable to create remote directory: " + remoteDirPath2
          );
        }
      }
      // put files
      for ( int i = 0; i < localFiles.length; i++ ) {
        File localFile = new File( localFiles[i] );
        String remotePath = remoteDirPath2 + "/" + localFile.getName();
        logger.debug("Put of local file " + localFiles[i] + " to " +remotePath);
        file.putFile( localFiles[i], remotePath );
      }
      file.stop();
    } catch ( Exception e ) {
      throw new AccessMethodException( "Unable to put files", e );
    }

  }

  /**
   * Open a new GridFTP connection.
   *
   * @return A new GridFTP connection.
   *
   * @throws Exception  If unable to connect to remote gridftp server
   */
  private FileResource connectGridftp() throws Exception {
    FileResource file = new FileResourceImpl();
    ServiceContact serviceContact = new ServiceContactImpl();
    serviceContact.setContact( this.gridFtpContact );
    file.setServiceContact(serviceContact);
    SecurityContext securityContext = AbstractionFactory.newSecurityContext(
      GRIDFTP_PROVIDER
    );
    securityContext.setCredentials(this.getCredential());
    file.setSecurityContext(securityContext);
    file.start();
    return file;
  }

  /**
   * Create a globus job task using the specified parameters
   *
   * @param executable Path to the remote executable.
   * @param arguments  Contains the arguments that should be passed to the
   *                   executable
   * @param stdin      A string that will be passedd in as stdin to the process
   *                   when it is started

   * @param directory  Path to the directory where the process will be executed
   *                   from
   *
   * @param stdinFile  Temporary file to which to write stdin.
   *
   * @param stdout     True if we want stdout returned.
   *
   * @param stderr     True if we want stderr returned.
   *
   * @return  A newly created task representing the job specification.
   *
   * @throws Exception If problem creating the task.
   */
  private Task createJob( String executable, String[] arguments,
                          String stdin, String directory,
                          File stdinFile, boolean stdout, boolean stderr )
    throws Exception {

    // create a task
    Task task = new TaskImpl( "incaRunTask", Task.JOB_SUBMISSION );
    // deprecated but needed or we get null pointer exception
    // when we attempt to cancel job - submitted bug
    task.setProvider( this.provider );

    // Create job specification
    JobSpecification spec = new JobSpecificationImpl();
    spec.setExecutable( executable );
    for ( int i = 0; i < arguments.length; i++ ) {
      // when quoted, Globus won't interpret $(VAR) so we replace HOME with
      // the environment variable.
      spec.addArgument
        ("\"" + arguments[i].replaceAll("\\$\\(HOME\\)", "\\${HOME}") + "\"");
    }
    if (directory != null) {
      spec.setDirectory( directory );
    }
    if ( stdout ) {
      spec.setRedirected( true );
      spec.setStdOutput( null );
    }
    if ( stderr ) {
      spec.setRedirected( true );
      spec.setStdError( null );
    }
    if ( stdin != null ) {
      Runtime.getRuntime().exec(
        "chmod 600 " + stdinFile.getAbsolutePath()
      ).waitFor();
      FileWriter writer = new FileWriter( stdinFile );
      writer.write( stdin );
      writer.close();
      spec.setLocalInput( true );
      spec.setStdInput( "/" + stdinFile.getAbsolutePath() );
    }
    // associate job spec with task
    task.setSpecification( spec );

    // Describe the service that can execute the job task
    Service service = new ServiceImpl( Service.JOB_SUBMISSION );
    service.setProvider( this.provider );
    ServiceContact serviceContact = new ServiceContactImpl( gramContact );
    service.setServiceContact( serviceContact );
    // Set authentication for service
    SecurityContext secContext = AbstractionFactory.newSecurityContext(
      this.provider
    );
    secContext.setCredentials( getCredential() );
    service.setSecurityContext( secContext );

    // associate remote service description with our task
    task.setService( Service.JOB_SUBMISSION_SERVICE, service );
    return task;
  }

  /**
   * Get a proxy credential from the myproxy server if provided or from
   * default environment.
   *
   * @return  A valid proxy credential.
   *
   * @throws GSSException  If problem retrieving the credential.
   */
  private GSSCredential getCredential() throws GSSException {
    // check if existing credential is okay
    if ( credential != null &&
         credential.getRemainingLifetime() > MINIMUM_LIFETIME ) {
      logger.debug( "Remaining lifetime on credential is " +
                    credential.getRemainingLifetime() + " seconds");
      return credential;
    }

    // next try MyProxy if it's an option
    if ( proxy != null ) {
      try {
        credential = proxy.getProxy();
        logger.debug( "Remaining lifetime on credential is " +
                      credential.getRemainingLifetime() + " seconds" );
        return credential;
      } catch ( MyProxyException e ) {
        logger.error( "Unable to retrieve proxy credential: " + e );
      }
    }

    logger.info( "Attempting to retrieve default proxy credential" );
    ExtendedGSSManager manager =
      (ExtendedGSSManager)ExtendedGSSManager.getInstance();
    credential = manager.createCredential( GSSCredential.INITIATE_AND_ACCEPT);
    return credential;
  }
}
