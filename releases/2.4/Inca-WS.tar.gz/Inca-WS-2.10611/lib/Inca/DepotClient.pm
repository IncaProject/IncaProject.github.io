package Inca::DepotClient;

################################################################################

=head1 NAME

Inca::DepotClient - A perl module for defining clients of Inca depots.

=head1 SYNOPSIS

  use Inca::DepotClient;
  my $client = new Inca::DepotClient(
    host => 'localhost',
    port => 6362,
    auth => 1,
    cert => 'etc/mycert.pem',
    init => 'etc/inca.properties',
    key => 'etc/mykey.pem',
    prefix => 'inca.depot.',
    trusted => 'etc/mycert.pem',
    password => '1ncaD1nkaD00'
  );

=head1 DESCRIPTION

This module creates clients for Inca depots.  It handles both unauthenticated
and (where available) authenticated communication between client and server
and implements methods that are supported by the inca depot.

=cut
################################################################################

use Inca::Client;
use strict;
use vars qw(@ISA);
@ISA = qw(Inca::Client);

#=============================================================================#

=head1 CLASS METHODS

=cut

#=============================================================================#

#-----------------------------------------------------------------------------#

=head2 new

Class constructor which returns a new Inca::DepotClient object.  The constructor
may be called with any of the following named parameters.

=over 13

=item auth

A boolean value indicating whether or not the connection to the depot should
use certificate-based authentication.  The default is false.

=item cert

The path to the certificate file.  Required for authenticated connections.

=item host

The IP or DNS name of the depot to contact.  Required.

=item init

Optional path to an Inca properties file specifying values for other parameters.

=item key

The path to the private key file.  Required for authenticated connections.

=item password

The password for decripting the private key file.  Required for authenticated
connections.

=item port

The server port to contact.  Required.

=item prefix

Optional prefix for properties in the init file.  The constructor ignores
properties that lack this prefix and strips the prefix from those that have it.
Default 'inca.depot.'.

=item trusted

The path to the trusted ca certificate file.  Required for authenticated
connections.

=back

=cut

#-----------------------------------------------------------------------------#
sub new {
  my ($this, %config) = @_;
  my $class = ref($this) || $this;
  $config{prefix} = 'inca.depot.' if !defined($config{prefix});
  my $self = $class->SUPER::new(%config);
  bless($self, $class);
  return $self;
}

#-----------------------------------------------------------------------------#

=head2 insertReport($resource, $context, $reportDoc, $sysusage, $stderr)

Asks the depot to insert a new report into the database.  $resource is the
name of the resource that generated the report; $context is the execution
context for the reporter; $reportDoc the XML for the report itself (see Inca
Report schema); $sysusage a string indicating cpu, wall clock, and memory
usage, and $stderr optional stderr output from the reporter.  Returns any
successful reply from the depot.

=cut

#-----------------------------------------------------------------------------#
sub insertReport {
  my ($self, $resource, $context, $reportDoc, $sysusage, $stderr) = @_;
  my $message = "REPORT $resource $context\r\n" .
                (defined($stderr) ? "STDERR $stderr\r\n" : "") .
                "STDOUT $reportDoc\r\n" .
                "SYSUSAGE $sysusage";
  return $self->_dialog($message);
}

#-----------------------------------------------------------------------------#

=head2 queryDb( )

Asks the depot to return XML that represents the structure of its database.
Returns any succesful reply from the depot.

=cut

#-----------------------------------------------------------------------------#
sub queryDb {
  my ($self) = @_;
  my $response = $self->_dialog("QUERYDB ");
  return defined($response) && $response =~ s/^OK // ? $response : undef;
}

#-----------------------------------------------------------------------------#

=head2 queryGuids( )

Asks the depot to return a newline-separated list of known suite guids.
Returns any succesful reply from the depot.

=cut

#-----------------------------------------------------------------------------#
sub queryGuids {
  my ($self) = @_;
  my $response = $self->_dialog("QUERYGUIDS ");
  return defined($response) && $response =~ s/^OK // ? $response : undef;
}

#-----------------------------------------------------------------------------#

=head2 queryHql($hql)

Asks the depot use the HQL select statement $hql to extract and return
information from the DB.  On success, returns a reference to an array
that contains the objects selected by the select statement.

=cut

#-----------------------------------------------------------------------------#
sub queryHql {
  my ($self, $hql) = @_;
  $self->_write("QUERYHQL $hql");
  return $self->_readQueryResults();
}

#-----------------------------------------------------------------------------#

=head2 queryInstance($instanceId, $configId)

Asks the depot to report details about one particular invocation of a reporter.
$instanceId is the DB id of the instance for the invocation; $configId the
related series configuration DB id.  On success, returns a reference to a
single-element array that contains a ReportDetails document (see ReportDetails
schema) describing the instance.

=cut

#-----------------------------------------------------------------------------#
sub queryInstance {
  my ($self, $instanceId, $configId) = @_;
  $self->_write("QUERYINSTANCE $instanceId $configId");
  return $self->_readQueryResults();
}

#-----------------------------------------------------------------------------#

=head2 querySeries($period, $begin, $end, @items)

Asks the depot to retrieve information that summarizes the success/failure
history over a given period for all the series listed in @items, each element
of which is either a suite guid or a nickname[@host] series spec.  $period is
the summarizing period; it may be one of "DAY", "WEEK", "MONTH", "QUARTER" or
a number of minutes.  Both $begin and $end are a number of seconds since the
epoch; only series instances collected on or after $begin and before $end are
considered.  On success, returns a reference to an array that contains a set of
SeriesHistory documents (see SeriesHistory schema) related to the series
configurations of the suite.

=cut

#-----------------------------------------------------------------------------#
sub querySeries {
  my ($self, $period, $begin, $end, @items) = @_;
  $self->_write("QUERYSERIES $period $begin $end " . join("\n", @items));
  return $self->_readQueryResults();
}

#-----------------------------------------------------------------------------#

=head2 querySuite(@items)

Asks the depot to retrieve information about all the series listed in @items,
each element of which is either a suite guid or a nickname[@host] series spec.
On success, returns a reference to an array that contains a set of
ReportSummary documents (see ReportSummary schema) related to the series
configurations of the suite.

=cut

#-----------------------------------------------------------------------------#
sub querySuite {
  my ($self, @items) = @_;
  $self->_write("QUERYSUITE " . join("\n", @items));
  return $self->_readQueryResults();
}

#-----------------------------------------------------------------------------#

=head2 updateSuite($suiteDoc)

Asks the depot to update its information about a suite configuration based on
the contents of the Suite document $suiteDoc (see Suite schema).  Returns any
successful reply from the depot.

=cut

#-----------------------------------------------------------------------------#
sub updateSuite {
  my ($self, $suiteDoc) = @_;
  my $response = $self->_dialog("SUITE $suiteDoc");
  return defined($response) && $response =~ s/^OK // ? $response : undef;
}

#-----------------------------------------------------------------------------#

=head2 readQueryResults( )

An internal method that reads a list of QUERYRESULT message from the depot and
returns their data in an array reference.

=cut

#-----------------------------------------------------------------------------#
sub _readQueryResults {
  my ($self) = @_;
  my ($response, @result);
  while(defined($response = $self->_read()) && $response =~ s/^QUERYRESULT //) {
    push(@result, $response);
  }
  return undef if !defined($response);
  if($response =~ /^ERROR (.*)/) {
    $self->setError($1);
  }
  return \@result;
}

1;
