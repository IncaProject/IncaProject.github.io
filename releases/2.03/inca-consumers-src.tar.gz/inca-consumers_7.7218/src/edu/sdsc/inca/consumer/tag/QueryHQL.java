package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;

import org.apache.log4j.Logger;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.DepotClient;
import edu.sdsc.inca.util.StringMethods;
import edu.sdsc.inca.protocol.ProtocolException;

import java.io.IOException;

/**
 * Jsp tag to query the Inca depot with HQL.
 * Required parameter: query
 *
 * @author Kate Ericson &lt;kericson@sdsc.edu&gt;
 */
public class QueryHQL extends TagSupport {
  private static Logger logger = Logger.getLogger(QueryHQL.class);
  private String query;

  /**
   * Called when the jsp tag is referenced in a JSP document.
   * Will return XML HQL query results or an error
   * (expressed in XML -- &lt;error&gt;...&lt;/error&gt;)
   *
   * @return SKIP_BODY as required
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {
    if ( this.getQuery() == null ){
      pageContext.setAttribute(
        "query",
        "<error>Missing query</error>"
      );
      return SKIP_BODY;
    }

    JspWriter out = pageContext.getOut();
       try {
        out.println(getQueryResults());
       } catch (Exception e ) {
        logger.error("Can't print query: " + e);
       }
    return SKIP_BODY;
   }

  /**
   * Query the depot based on the HQL string.
   * Returns an XML string with query results.
   *
   * @return A string with query results
   *
   * @throws java.io.IOException
   */
  public String getQueryResults()
    throws IOException, ConfigurationException, ProtocolException {

    String[] queryresult;
    DepotClient depotClient = new DepotClient();
    depotClient.setConfiguration( Consumer.getClientConfiguration() );
    logger.info( "Contacting depot " + depotClient.getUri() );
    depotClient.connect();
    queryresult = depotClient.queryHql(query);
    depotClient.close();

    StringBuffer xml = new StringBuffer();
    if ( queryresult != null ) {
      for ( int i = 0; i < queryresult.length; i++ ) {
        if ( Consumer.IMMEDIATE_PATTERN.matcher(queryresult[i]).find() ) continue;
        xml.append( queryresult[i].trim() );
      }
    }
    String html = StringMethods.xmlContentToHtml(xml.toString(), "");
    return html;
  }

  public int doEndTag(){
    return EVAL_PAGE;
  }

  /**
   * Get the query string for the hql (will be called by a jsp page)
   * @return An hql string
   */
  public String getQuery() {
    return query;
  }

  /**
   * Set the query string for the hql (will be called by a jsp page)
   * @param query  An hql string
   */
  public void setQuery(String query) {
    this.query = query;
  }

}
