package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;
import org.apache.log4j.Logger;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.DepotClient;
import edu.sdsc.inca.AgentClient;
import edu.sdsc.inca.protocol.ProtocolException;

import java.io.IOException;

/**
 * Jsp tag that will query the configured Inca depot for a list of suite
 * names.  Required parameters are:
 *
 * retAttrName
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GetSuiteNames extends TagSupport {
  private static Logger logger = Logger.getLogger(GetSuiteNames.class);

  /**
   * Called when the jsp tag is referenced in a JSP document.  Will return
   * a xml document with a list of suite names stored in the configured
   * depot or an error (expressed in XML --
   * &lt;error&gt;...&lt;/error&gt;)
   *
   * @return SKIP_BODY as required
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {
    if ( this.getRetAttrName() == null ){
      pageContext.setAttribute(
        "suite",
        "<error>Missing return attribute name</error>"
      );
      return SKIP_BODY;
    }

    try {
      pageContext.setAttribute(
        this.getRetAttrName(),
        getSuiteNames()
      );
    } catch ( Exception e ) {
      logger.error( "Unable to retrieve suite names xml", e );
      pageContext.setAttribute(
        this.getRetAttrName(),
        "<error>" + e + "</error>"
      );
    }

    return SKIP_BODY;
  }

  /**
   * Query the depot for the list of suites stored in it.  Will return
   * a XML document in the form of
   *
   * &lt;suites&gt;
   *   &lt;suite&gt;suiteNameA&lt;/&gt;
   *   ...
   * &lt;suites/&gt;
   *
   * @return A XML document containing a list of suite names.
   *
   * @throws java.io.IOException
   */
  public String getSuiteNames()
    throws IOException, ConfigurationException, ProtocolException {

    String[] guids = new String[0];
    DepotClient depotClient = new DepotClient();
    depotClient.setConfiguration( Consumer.getClientConfiguration() );
    logger.info( "Contacting depot " + depotClient.getUri() );
    depotClient.connect();
    guids = depotClient.queryGuids();
    depotClient.close();

    // get uri of agent client -- agent client resolves localhost
    AgentClient agentClient = new AgentClient();
    agentClient.setConfiguration( Consumer.getClientConfiguration() );
    String agentUri = agentClient.getUri();
    if ( agentUri == null ) logger.warn( "Unable to locate agent uri" );

    StringBuffer xml = new StringBuffer( "<suites>\n" );
    if ( guids != null ) {
      for ( int i = 0; i < guids.length; i++ ) {
        if ( Consumer.IMMEDIATE_PATTERN.matcher(guids[i]).find() ) continue;
        xml.append( "  <suite>" );
        if ( agentUri != null ) {
          xml.append( guids[i].replaceAll(agentUri+"/", "").trim() );
        } else {
          xml.append( guids[i].trim() );
        }
        xml.append( "</suite>\n" );
      }
    }
    xml.append( "</suites>\n" );
    return xml.toString();

  }

}
