package edu.sdsc.inca.consumer.tag;

import org.apache.log4j.Logger;

/**
 * Serve as the base class for Inca tags.  Provides the common retAttrName
 * attribute which allows the caller to specify what attribute they want the
 * returning xml to be returned as.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class TagSupport extends javax.servlet.jsp.tagext.TagSupport {
  private static Logger logger = Logger.getLogger( TagSupport.class );
  private String retAttrName = null;

  /**
   * Return the return attribute name that will be used to store the result
   * of the tag (xml).
   *
   * @return  The name of the return attribute.
   */
  public String getRetAttrName() {
    return retAttrName;
  }

  /**
   * Set the return attribute name that will be used to store the result
   * of the tag (xml).
   *
   * @param retAttrName The name of the return attribute.
   */
  public void setRetAttrName( String retAttrName ) {
    this.retAttrName = retAttrName;
  }
}
