package edu.sdsc.inca.depot.util;

import edu.sdsc.inca.depot.persistent.AcceptedOutput;
import edu.sdsc.inca.depot.persistent.Report;

/**
 * An abstract class that compares a report against a specification of
 * acceptable output.
 *
 * @author cmills
 */
public interface Comparitor {

  public static final String FAILURE_RESULT = "Failure";
  public static final String SUCCESS_RESULT = "Success";

  /**
   * Compares a report against acceptable output.
   *
   * @param ao the acceptable output secification
   * @param report the report to compare
   * @return a string that starts with either FAILURE_RESULT or SUCCESS_RESULT,
   *         depending on whether or not the comparision succeeded
   */
  public String compare(AcceptedOutput ao, Report report);

}
