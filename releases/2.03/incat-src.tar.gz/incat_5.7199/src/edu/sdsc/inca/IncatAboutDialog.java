package edu.sdsc.inca;

import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;

/**
 * A Dialog window that gives basic information about the incat tool.
 */
public class IncatAboutDialog extends JDialog {

  /**
   * Constructs an IncatAboutDialog.
   */
  public IncatAboutDialog() {
    this.setContentPane(IncatComponents.JPanelFactory(new JComponent[] {
      new JLabel(" "), null,
      new JLabel("   Inca Administration Tool   "), null,
      new JLabel("   Inca v2.0   "), null,
      new JLabel(" "), null,
      new JLabel("   Copyright \u00A9 2007, SDSC   "), null,
      new JLabel(" "), null
    }));
    this.setTitle("About Incat");
    this.pack();
  }

}
