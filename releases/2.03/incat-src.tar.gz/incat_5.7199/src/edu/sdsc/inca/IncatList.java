package edu.sdsc.inca;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Hashtable;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.ListSelectionModel;

/**
 * A convenience class that combines a scrollable JList and its Model.  It
 * allows listening for list selections via an ActionListener instead of a
 * ListSelectionListener.
 */
public class IncatList extends JPanel
  implements KeyListener, ListSelectionListener, MouseListener {

  private String doubleCommand;
  private String lastFind = null;
  private JList list;
  private ActionListener listener;
  private DefaultListModel model;
  private String selectCommand;

  /**
   * A ListCellRenderer that allows elements to appear in different colors.
   */
  protected class Colorizer extends JLabel implements ListCellRenderer {

    private Hashtable colors = new Hashtable();

    /**
     * Returns the color associated with a specified element, null if none.
     *
     * @param element the element associated with a color
     * @return the color associated with the element
     */
    public Color getColor(Object element) {
      return (Color)this.colors.get(element);
    }

    /**
     * See ListCellRenderer
     */
    public Component getListCellRendererComponent
      (JList list, Object value, int index, boolean isSelected,
       boolean cellHasFocus) {
      Color c = (Color)this.colors.get(value);
      this.setText(value.toString());
      this.setBackground
        (isSelected ? list.getSelectionBackground() : list.getBackground());
      this.setForeground(c == null ? Color.black : c);
      this.setEnabled(list.isEnabled());
      this.setFont(list.getFont());
      this.setOpaque(true);
      return this;
    }

    /**
     * Associates a color with an element.
     *
     * @param element the element to color
     * @param color to color to use, null for default
     */
    public void setColor(Object element, Color color) {
      if(color == null) {
        this.colors.remove(element);
      } else {
        this.colors.put(element, color);
      }
    }

  }

  /**
   * Constructs an IncatList.
   *
   * @param selectCommand the command to pass to the listener when the user
   *                      selects an element
   * @param doubleCommand the command to pass to the listener when the user
   *                      double-clicks an element
   * @param listener listener to notify when the user selects an element
   */
  public IncatList(String selectCommand,
                   String doubleCommand,
                   ActionListener listener) {
    super();
    this.model = new DefaultListModel();
    this.list = new JList(this.model);
    JScrollPane scroller = new JScrollPane(this.list);
    scroller.setPreferredSize(new Dimension(250, 200));
    this.add(scroller);
    this.list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    this.list.addMouseListener(this);
    this.list.addListSelectionListener(this);
    this.list.setCellRenderer(new Colorizer());
    this.setSelectCommand(selectCommand);
    this.setDoubleCommand(doubleCommand);
    this.setActionListener(listener);
    this.list.addKeyListener(this);
  }

  /**
   * Constructs an IncatList.
   *
   * @param selectCommand the command to pass to the listener when the user
   *                      selects an element
   * @param listener listener to notify when the user selects an element
   */
  public IncatList(String selectCommand,
                   ActionListener listener) {
    this(selectCommand, null, listener);
  }

  /**
   * Appends an element to the end of the list.
   *
   * @param o the element to append
   */
  public void addElement(Object o) {
    this.model.addElement(o);
  }

  /**
   * Returns the index of the element that matches a specific string; returns
   * -1 if no element matches.
   *
   * @param s the string to match
   * @return the index of the matching element; -1 if none
   */
  public int findMatchingElement(String s) {
    for(int i = 0; i < this.getElementCount(); i++) {
      if(this.getElementAt(i).toString().equals(s)) {
        return i;
      }
    }
    return -1;
  }

  /**
   * Returns the listener notified when the user selects an element.
   *
   * @return the listener
   */
  public ActionListener getActionListener() {
    return this.listener;
  }

  /**
   * Returns the color associated with a specified element, null if none.
   *
   * @param element the element associated with a color
   * @return the color associated with the element
   */
  public Color getColor(Object element) {
    return ((Colorizer)this.list.getCellRenderer()).getColor(element);
  }

  /**
   * Returns the command given to the listener when the user double-clicks an
   * element.
   *
   * @return the command
   */
  public String getDoubleCommand() {
    return this.doubleCommand;
  }

  /**
   * Returns an array of all the elements in the IncatList.
   *
   * @return an array of all elements in the list
   */
  public Object[] getElements() {
    Object[] result = new Object[this.model.getSize()];
    for(int i = 0; i < result.length; i++) {
      result[i] = this.model.getElementAt(i);
    }
    return result;
  }

  /**
   * Returns the toString() version of all the elements in the IncatList.
   *
   * @return an array of the toString() version of all elements in the list
   */
  public String[] getElementsAsStrings() {
    String[] result = new String[this.model.getSize()];
    for(int i = 0; i < result.length; i++) {
      result[i] = this.model.getElementAt(i).toString();
    }
    return result;
  }

  /**
   * Return the element at a specified index.
   *
   * @param index the requested index
   * @return the element at index, null if none
   */
  public Object getElementAt(int index) {
    return index>=this.model.getSize() ? null : this.model.getElementAt(index);
  }

  /**
   * Returns the length of the list.
   *
   * @return the length of the panel list
   */
  public int getElementCount() {
    return this.model.getSize();
  }

  /**
   * Returns the first selected element; returns null if none.
   *
   * @return the first selected element; null if none
   */
  public Object getSelectedElement() {
    int index = this.getSelectedIndex();
    return index < 0 ? null : this.getElementAt(index);
  }

  /**
   * Returns the first selected index; returns -1 if none.
   *
   * @return the first selected index; -1 if none
   */
  public int getSelectedIndex() {
    // NOTE: JList.getSelectedIndex() is supposed to return -1 if no value
    // is selected, but it seems to throw an exception instead
    try {
      return this.list.getSelectedIndex();
    } catch(ArrayIndexOutOfBoundsException e) {
      return -1;
    }
  }

  /**
   * Returns the command given to the listener when the user selects an element.
   *
   * @return the command
   */
  public String getSelectCommand() {
    return this.selectCommand;
  }

  /**
   * Removes all elements from the list.
   */
  public void removeAllElements() {
    this.model.removeAllElements();
    this.list.setCellRenderer(new Colorizer());
  }

  /**
   * Removes the element, if any, at a specified index.
   *
   * @param index the requested index
   */
  public void removeElementAt(int index) {
    if(index < this.model.getSize()) {
      ((Colorizer)this.list.getCellRenderer()).setColor
        (this.getElementAt(index), null);
      this.model.removeElementAt(index);
    }
  }

  /**
   * Selects the element that matches a specified string.
   *
   * @param s the value to match
   * @return true if the specified string was found/selected, otherwise false
   */
  public boolean selectMatchingElement(String s) {
    int index = this.findMatchingElement(s);
    if(index < 0) {
      return false;
    }
    this.setSelectedIndex(index);
    return true;
  }

  /**
   * Sets the listener notified when the user selects an element.
   *
   * @param listener the listener
   */
  public void setActionListener(ActionListener listener) {
    this.listener = listener;
  }

  /**
   * Sets the color of a list element.
   *
   * @param element the element to color
   * @param color the color to use for the element text
   */
  public void setColor(Object element, Color color) {
    ((Colorizer)this.list.getCellRenderer()).setColor(element, color);
  }

  /**
   * Sets the command given to the listener when the user double-clicks an
   * element.
   *
   * @param command the command
   */
  public void setDoubleCommand(String command) {
    this.doubleCommand = command;
  }

  /**
   * Removes all existing elements from the list and adds a specified set.
   *
   * @param elements the set of elements to add
   */
  public void setElements(Object[] elements) {
    this.removeAllElements();
    for(int i = 0; i < elements.length; i++) {
      this.addElement(elements[i]);
    }
  }

  /**
   * Selects a specified element.
   *
   * @param o the element to select
   * @return true if the specified element is found/selected, false otherwise
   */
  public boolean setSelectedElement(Object o) {
    for(int i = 0; i < this.getElementCount(); i++) {
      if(this.getElementAt(i) == o) {
        this.setSelectedIndex(i);
        return true;
      }
    }
    return false;
  }

  /**
   * Selects the element, if any, at the specified index.
   *
   * @param index the requested index
   */
  public void setSelectedIndex(int index) {
    if(index < this.model.getSize()) {
      this.list.setSelectedIndex(index);
      this.list.ensureIndexIsVisible(index);
    }
  }

  /**
   * Sets the command given to the listener when the user selects an element.
   *
   * @param command the command
   */
  public void setSelectCommand(String command) {
    this.selectCommand = command;
  }

  /**
   * Rearranges the list to display the elements in increasing alpha order.
   */
  public void sort() {
    Object selected = this.getSelectedElement();
    // NOTE: the model removals in the sort routine apparently trigger list
    // selection events.  Suppress reporting of these to the client.
    ActionListener l = this.listener;
    this.listener = null;
    this.sort(0, this.getElementCount() - 1);
    if(selected != null) {
      this.setSelectedElement(selected);
    }
    this.listener = l;
  }

  /**
   * Forwards list selections to the ActionListener passed to the constructor.
   */
  public void valueChanged(ListSelectionEvent e) {
    if(!e.getValueIsAdjusting() &&
       this.listener != null && this.selectCommand != null) {
      this.listener.actionPerformed(
        new ActionEvent(e.getSource(), ActionEvent.RESERVED_ID_MAX + 1,
                        this.selectCommand)
      );
    }
  }

  /**
   * Forwards list selections to the ActionListener passed to the constructor.
   */
  public void mouseClicked(MouseEvent e) {
    if(this.listener != null && this.doubleCommand != null &&
       e.getClickCount() == 2) {
      this.listener.actionPerformed(
        new ActionEvent(e.getSource(), ActionEvent.RESERVED_ID_MAX + 1,
                        this.doubleCommand)
      );
    }
  }

  public void mouseEntered(MouseEvent e) {}
  public void mouseExited(MouseEvent e) {}
  public void mousePressed(MouseEvent e) {}
  public void mouseReleased(MouseEvent e) {}

  /**
   * Traps list key events to allow searches.
   */
  public void keyTyped(KeyEvent e) {
    if(this.getElementCount() == 0 ||
       e.getKeyChar() != 'f' || !(e.isMetaDown() || e.isControlDown())) {
      return;
    }
    String s = JOptionPane.showInputDialog("Find:", this.lastFind);
    if(s == null) {
      return;
    }
    this.lastFind = s;
    int current = this.getSelectedIndex();
    int i = current;
    int max = this.getElementCount() - 1;
    do {
      i = i < max ? i + 1 : 0;
      if(this.getElementAt(i).toString().indexOf(s) >= 0) {
        this.setSelectedIndex(i);
        return;
      }
    } while(i != current);
  }

  public void keyPressed(KeyEvent e) {}
  public void keyReleased(KeyEvent e) {}

  /**
   * Performs an alpha sort on the specified range of elements.
   *
   * @param low the lowest index to sort
   * @param high the highest index to sort
   */
  protected void sort(int low,
                      int high) {
    if(low >= high) {
      return;
    }
    int mid = (low + high) / 2;
    sort(low, mid);
    sort(mid + 1, high);
    for(int i = low, j = mid + 1; i < j && j <= high; i++) {
      Object ith = this.model.getElementAt(i);
      Object jth = this.model.getElementAt(j);
      if(ith.toString().compareTo(jth.toString()) > 0) {
        this.model.removeElementAt(j);
        this.model.insertElementAt(jth, i);
        j++;
      }
    }
  }

}
