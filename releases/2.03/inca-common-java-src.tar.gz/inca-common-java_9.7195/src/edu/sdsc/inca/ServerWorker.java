package edu.sdsc.inca;

import edu.sdsc.inca.protocol.MessageHandler;
import edu.sdsc.inca.protocol.MessageHandlerFactory;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.util.WorkQueue;
import edu.sdsc.inca.util.Worker;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.SocketTimeoutException;
import org.apache.log4j.Logger;

/**
 *
 * @depend - Uses - inca.protocol.ProtocolReader
 * @depend - Uses - inca.protocol.ProtocolWriter
 * @depend - Uses - inca.util.protocol.MessageHandlerFactory
 * @depend - Uses - inca.util.protocol.MessageHandler
 */
public class ServerWorker extends Worker {

  protected static final Logger logger = Logger.getLogger(ServerWorker.class);

  /**
   * Create the worker object associated with the named queue.
   *
   * @param q
   */
  public ServerWorker(WorkQueue q) {
    super(q);
  }

  /**
   *
   * @param work the socket that was queued
   */
  protected void doWork(Object work) {

    Socket socket = (Socket)work;
    ProtocolReader reader;
    ProtocolWriter writer;

    // Try to open input and output streams
    try {
      reader =
        new ProtocolReader(new InputStreamReader(socket.getInputStream()));
      writer =
        new ProtocolWriter(new OutputStreamWriter(socket.getOutputStream()));
    } catch(IOException e) {
      logger.error("Unable to access socket stream", e);
      try {
        socket.close();
      } catch(IOException e1) {
        logger.warn("Unable to close socket", e1);
      }
      return;
    }

    // Now that we can read and write to the socket create a task and execute
    try {
      while(!reader.isClosed() && !this.isInterrupted()) {
        MessageHandler handler = null;
        try {
          handler = MessageHandlerFactory.newInstance(reader);
        } catch(SocketTimeoutException e) {
          continue; // allows periodic interrupt check
        }
        if(handler == null) { // Peer closed the connection
          logger.debug("Ending conversation");
          break;
        }
        logger.debug("Running "+ handler.getClass().getName());
        handler.execute(reader, writer);
      }
    } catch(Exception e) {
      MessageHandler.errorReply(writer, e.toString());
    }
    if(!reader.isClosed()) {
      try {
        reader.close();
      } catch(IOException e) {
        logger.warn("Unable to close reader", e);
      }
    }
    if(!writer.isClosed()) {
      try {
        writer.close();
      } catch(IOException e) {
        logger.warn("Unable to close writer", e);
      }
    }
    if(!socket.isClosed()) {
      try {
        socket.close();
       } catch(IOException e) {
         logger.warn("Unable to close socket", e);
       }
    }

  }

}
