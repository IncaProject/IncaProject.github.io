package edu.sdsc.inca.util;

import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.io.File;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Arrays;

import edu.sdsc.inca.dataModel.suite.SuiteDocument;
import edu.sdsc.inca.dataModel.util.SeriesConfig;

/**
 * Convenience object for accessing suite documents and persisting changes
 * to them.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class SuiteWrapper extends XmlWrapper {
  private static Logger logger = Logger.getLogger(SuiteWrapper.class);
  private SuiteDocument suiteDoc;

 /**
   * Create a new SuiteWrapper object containing a blank suite.
   *
   */
 public SuiteWrapper( ) {
   this.suiteDoc = SuiteDocument.Factory.newInstance();
   this.suiteDoc.addNewSuite().addNewSeriesConfigs();
   this.suiteDoc.getSuite().setGuid( "Unnamed" );
   this.suiteDoc.getSuite().setName( "Unnamed" );

 }

  /**
   * Create a new SuiteWrapper object from an XML Beans class instance.
   *
   * @param suiteDoc  An instance of SuiteDocument, a class generated
   */
  public SuiteWrapper( SuiteDocument suiteDoc ) throws XmlException {
    this.suiteDoc = suiteDoc;
    validate( this.suiteDoc );
  }

  /**
   * Create a new SuiteWrapper object from a suite XML file.
   *
   * @param filename  Path to a file containing suite XML.
   *
   * @throws IOException
   * @throws XmlException
   */
  public SuiteWrapper( String filename )
    throws IOException, XmlException {

    File suiteFile  = new File( filename );
    if ( suiteFile.exists() ) {
      XmlOptions xmlOptions = new XmlOptions();
      xmlOptions.setLoadStripWhitespace();
      this.suiteDoc = SuiteDocument.Factory.parse( suiteFile, xmlOptions );
      logger.debug(
        "Loading suite '" + this.suiteDoc.getSuite().getName() + "' at " +
        filename
      );
      validate( this.suiteDoc );
    } else {
      throw new IOException(
        "Suite file '" + filename + "' does not exist"
      );
    }
  }

  /**
   * Append a new series config to the existing suite.
   *
   * @param seriesConfig A new series config object to be added to the end
   * of the existing suite.
   */
  public void appendSeriesConfig( SeriesConfig seriesConfig ) {

    int lastIndex = this.getSeriesConfigCount();
    suiteDoc.getSuite().getSeriesConfigs().
      insertNewSeriesConfig( lastIndex );
    suiteDoc.getSuite().getSeriesConfigs().
      setSeriesConfigArray( lastIndex, seriesConfig );
  }

  /**
   * Change the action in all series configs found in the suite document.
   *
   * @param action   The action to use in all series configs.
   */
  public void changeAction( String action ) {
    SeriesConfig[] configs = this.getSeriesConfigs();
    for ( int i = 0; i < configs.length; i++ ) {
      configs[i].setAction( action );
    }
  }

  /**
    * Copy the top level suite attributes: name, guid, and description to
    * supplied suite document.
    *
    * @param suiteDoc  A suite that where the top level suite attributes will be
    * copied to
    */
   public void copySuiteAttributes( SuiteDocument suiteDoc ) {
     // apply top level document attributes to document
     if ( suiteDoc.getSuite().isSetName() ) {
       this.suiteDoc.getSuite().setName( suiteDoc.getSuite().getName() );
     }
     if ( suiteDoc.getSuite().isSetDescription() ) {
       this.suiteDoc.getSuite().setDescription(
         suiteDoc.getSuite().getDescription()
       );
     }
     if ( suiteDoc.getSuite().isSetVersion() ) {
       this.suiteDoc.getSuite().setVersion( suiteDoc.getSuite().getVersion() );
     }
     this.suiteDoc.getSuite().setGuid( suiteDoc.getSuite().getGuid() );
   }

  /**
   * Compare the existing suite against the passed in suite and return the
   * differences as adds and deletes.
   *
   * @param suiteDoc   Another suite document to compare to the object's suite
   * document.
   *
   * @return  The differences between the suites returned as a suite document
   * represented as adds and deletes.
   *
   * @throws XmlException
   */
  public SuiteDocument diff( SuiteDocument suiteDoc ) throws XmlException {

    SuiteWrapper suite = new SuiteWrapper( suiteDoc );
    SuiteWrapper diffs = new SuiteWrapper();
    if ( this.suiteDoc.getSuite().isSetDescription() ) {
      diffs.getSuiteDocument().getSuite().setDescription(
        this.suiteDoc.getSuite().getDescription()
      );
    }
    if ( this.suiteDoc.getSuite().isSetName() ) {
      diffs.getSuiteDocument().getSuite().setName(
        this.suiteDoc.getSuite().getName()
      );
    }
    if ( this.suiteDoc.getSuite().isSetVersion() ) {
      diffs.getSuiteDocument().getSuite().setVersion(
        this.suiteDoc.getSuite().getVersion()
      );
    }
    diffs.getSuiteDocument().getSuite().setGuid(
      this.suiteDoc.getSuite().getGuid()
    );

   // first loop through our own series and for every one of our series
    // that is not in the other suite, it indicates a delete
    for ( int i = 0; i < this.getSeriesConfigCount(); i++ ) {
      SeriesConfig ourConfig = this.getSeriesConfig( i );
      for( int j = 0; j < suite.getSeriesConfigCount(); j++ ) {
        SeriesConfig otherConfig = suite.getSeriesConfig( j );
        if ( configEqual(ourConfig, otherConfig) ) {
          break; // found one of our series in their series
        }
        if ( j == suite.getSeriesConfigCount() - 1) {
          SeriesConfig deleted = (SeriesConfig)this.getSeriesConfig(i).copy();
          deleted.setAction( "delete" );
          diffs.appendSeriesConfig( deleted );
        }
      }
    }

    // then loop through the other series and for every one of their series
    // that is not in our suite, it indicates an add
    for ( int i = 0; i < suite.getSeriesConfigCount(); i++ ) {
      SeriesConfig otherConfig = suite.getSeriesConfig(i);
      for( int j = 0; j < this.getSeriesConfigCount(); j++ ) {
        SeriesConfig ourConfig = this.getSeriesConfig( j );
        if ( configEqual(otherConfig, ourConfig) ) {
          break; // found one of their series in our series
        }
        if ( j == this.getSeriesConfigCount() - 1) {
          SeriesConfig added = (SeriesConfig)suite.getSeriesConfig(i).copy();
          added.setAction( "add" );
          diffs.appendSeriesConfig( added );
        }
      }
    }
    return diffs.getSuiteDocument();
  }

  /**
   * Return a series config from the suite.
   *
   * @param index   The index of the series config to return.
   *
   * @return The series config object.
   */
  public SeriesConfig getSeriesConfig( int index ) {
    return suiteDoc.getSuite().getSeriesConfigs().getSeriesConfigArray( index );
  }

  /**
   * Return all series configs in the suite as an array.
   *
   * @return  An array of series config objects from the suite document.
   */
  public SeriesConfig[] getSeriesConfigs() {
    return suiteDoc.getSuite().getSeriesConfigs().getSeriesConfigArray();
  }

  /**
   * Return the number of series config objects contained in the suite document.
   *
   * @return  An integer containing the number of series config objects.
   */
  public int getSeriesConfigCount() {
    return this.suiteDoc.getSuite().getSeriesConfigs().
      sizeOfSeriesConfigArray();
  }

  /**
   * Count the number of series configs that match the provided patterns.
   *
   * @param nicknamePatterns Patterns that should be matched against the
   *                         series nickname
   *
   * @param namePatterns Patterns that should be matched against the
   *                     series reporter name
   *
   * @return  An integer array of size
   * nicknamePatterns.length + namePatterns.length + 1
   */
  public int[] getSeriesConfigCountByPattern( String[] nicknamePatterns,
                                              String[] namePatterns ) {

    int[] patternCounts =new int[nicknamePatterns.length+namePatterns.length+1];
    Arrays.fill( patternCounts, 0 );
    SeriesConfig[] configs = this.getSeriesConfigs();
    for ( int i = 0; i < configs.length; i++ ) {
      boolean nicknameMatch = false;
      for ( int j = 0; j < nicknamePatterns.length; j++ ) {
        Pattern pattern = Pattern.compile( nicknamePatterns[j] );
        if ( pattern.matcher(configs[i].getNickname()).find() ) {
          nicknameMatch = true;
          patternCounts[j]++;
          break;
        }
      }
      if ( nicknameMatch ) continue;
      boolean categoryMatch = false;
      for ( int j = 0; j < namePatterns.length; j++ ) {
        Pattern pattern = Pattern.compile( namePatterns[j] );
        if ( pattern.matcher(configs[i].getSeries().getName()).find() ) {
          categoryMatch = true;
          patternCounts[nicknamePatterns.length+j]++;
          break;
        }
      }
      if ( categoryMatch ) continue;
      logger.warn( "leftover config " + configs[i].getSeries().getName() );
    }
    int total = 0;
    for ( int i = 0; i < patternCounts.length; i++ ) total += patternCounts[i];
    if ( total > this.getSeriesConfigCount() ) {
      logger.warn(
        "Pattern matches " + total + " exceeds series config count " +
        this.getSeriesConfigCount()
      );
    }
    patternCounts[nicknamePatterns.length+namePatterns.length] = total;
    return patternCounts;
 }

  /**
   * Return the root element of the suite document.
   *
   * @return The suite root element of the suite document.
   */
  public SuiteDocument getSuiteDocument() {
    return this.suiteDoc;
  }

}