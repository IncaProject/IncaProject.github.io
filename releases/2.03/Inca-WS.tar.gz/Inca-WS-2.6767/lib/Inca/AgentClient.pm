package Inca::AgentClient;

################################################################################

=head1 NAME

Inca::AgentClient - A perl module for defining clients of Inca agents.

=head1 SYNOPSIS

  use Inca::AgentClient;
  my $client = new Inca::AgentClient(
    host => 'localhost',
    port => 6362,
    auth => 1,
    cert => 'etc/mycert.pem',
    init => 'etc/inca.properties',
    key => 'etc/mykey.pem',
    prefix => 'inca.agent.',
    trusted => 'etc/mycert.pem',
    password => '1ncaD1nkaD00'
  );

=head1 DESCRIPTION

This module creates clients for Inca agents.  It handles both unauthenticated
and (where available) authenticated communication between client and server
and implements methods that are supported by the inca depot.

=cut
################################################################################

use Inca::Client;
use strict;
use vars qw(@ISA);
@ISA = qw(Inca::Client);

#=============================================================================#

=head1 CLASS METHODS

=cut

#=============================================================================#

#-----------------------------------------------------------------------------#

=head2 new

Class constructor which returns a new Inca::AgentClient object.  The constructor
may be called with any of the following named parameters.

=over 13

=item auth

A boolean value indicating whether or not the connection to the agent should
use certificate-based authentication.  The default is false.

=item cert

The path to the certificate file.  Required for authenticated connections.

=item host

The IP or DNS name of the agent to contact.  Required.

=item init

Optional path to an Inca properties file specifying values for other parameters.

=item key

The path to the private key file.  Required for authenticated connections.

=item password

The password for decripting the private key file.  Required for authenticated
connections.

=item port

The server port to contact.  Required.

=item prefix

Optional prefix for properties in the init file.  The constructor ignores
properties that lack this prefix and strips the prefix from those that have it.
Default 'inca.agent.'.

=item trusted

The path to the trusted ca certificate file.  Required for authenticated
connections.

=back

=cut

#-----------------------------------------------------------------------------#
sub new {
  my ($this, %config) = @_;
  my $class = ref($this) || $this;
  $config{prefix} = 'inca.agent.' if !defined($config{prefix});
  my $self = $class->SUPER::new(%config);
  bless($self, $class);
  return $self;
}

#-----------------------------------------------------------------------------#

=head2 getCatalog($url)

Asks the agent to retrieve and return the package catalog from the reporter
repository accessed via $url.  An undefined $url indicates that the agent
should return a merged catalog for all known repositories.  Returns any
successful reply from the agent.

=cut

#-----------------------------------------------------------------------------#
sub getCatalog {
  my ($self, $url) = @_;
  my $response = $self->_dialog("GETCATALOG " . (defined($url) ? $url : ""));
  return defined($response) && $response =~ s/^OK ?// ? $response : undef;
}

#-----------------------------------------------------------------------------#

=head2 getConfig( )

Asks the agent to return XML for the Inca deployment configuration (see the
Inca schema).  Returns any successful reply from the agent.

=cut

#-----------------------------------------------------------------------------#
sub getConfig {
  my ($self) = @_;
  my $response = $self->_dialog("GETCONFIG");
  return defined($response) && $response =~ s/^OK // ? $response : undef;
}

#-----------------------------------------------------------------------------#

=head2 getProxy($hostname)

=cut

#-----------------------------------------------------------------------------#
sub getProxy {
  my ($self, $hostname) = @_;
  return undef; # TODO
}

#-----------------------------------------------------------------------------#

=head2 register($hostname)

Registers this Reporter Manager with the agent.  $hostname is the
fully-qualified DNS name of this host.  Returns any successful reply from
the agent.

=cut

#-----------------------------------------------------------------------------#
sub register {
  my ($self, $hostname) = @_;
  my $response = $self->_dialog("REGISTER $hostname");
  return defined($response) && $response =~ s/^OK // ? $response : undef;
}

#-----------------------------------------------------------------------------#

=head2 setConfig($xml)

Replaces or updates the Inca deployment configuration based on the contents
of $xml (see the Inca schema).  Returns any successful reply from the agent.

=cut

#-----------------------------------------------------------------------------#
sub setConfig {
  my ($self, $xml) = @_;
  my $response = $self->_dialog("SETCONFIG $xml");
  return defined($response) && $response =~ s/^OK// ? '' : undef;
}

1;
