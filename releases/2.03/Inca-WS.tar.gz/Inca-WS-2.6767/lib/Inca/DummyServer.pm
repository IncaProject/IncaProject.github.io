package Inca::DummyServer;

use strict;
use warnings;
use Socket;

sub new {
  my($this, $port, @dialogs) = @_;
  my $class = ref($this) || $this;
  my $self = {port => $port};
  my $patterns = [];
  my $responses = [];
  for(my $i = 0; $i <= $#dialogs; $i += 2) {
    push(@$patterns, $dialogs[$i]);
    push(@$responses, $dialogs[$i + 1]);
  }
  $self->{patterns} = $patterns;
  $self->{responses} = $responses;
  bless($self, $class);
  return $self;
}

sub run {
  my($self) = @_;
  socket(SERVER, PF_INET, SOCK_STREAM, getprotobyname('tcp'))
    or die "socket: $!";
  setsockopt(SERVER, SOL_SOCKET, SO_REUSEADDR, 1) or die "setsock: $!";
  bind(SERVER, sockaddr_in($self->{port}, INADDR_ANY)) or die "bind: $!";
  listen(SERVER, SOMAXCONN) or die "listen: $!";
  if(accept(CLIENT, SERVER)) {
    select CLIENT;
    $| = 1;
    my $patterns = $self->{patterns};
    my $responses = $self->{responses};
    while(defined(my $message = <CLIENT>)) {
      $message .= <CLIENT> while $message !~ s/\r\n//;
      my $i = 0;
      $i++ while defined($$patterns[$i]) && $message !~ $$patterns[$i];
      if(defined($$patterns[$i])) {
        $message = eval($$responses[$i]);
      } else {
        $message = "ERROR Unknown message '$message'";
      }
      print CLIENT "$message\r\n";
    }
    close CLIENT;
  }
}

1;
