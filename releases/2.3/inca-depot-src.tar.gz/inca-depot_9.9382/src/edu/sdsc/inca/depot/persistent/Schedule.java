package edu.sdsc.inca.depot.persistent;

import java.math.BigInteger;
import java.util.Date;
import java.util.GregorianCalendar;
import org.apache.xmlbeans.XmlObject;

/**
 * Schedule holds the information for a cron-like schedule that we use.  In the
 * future there will be other schedule types as well.
 *
 * @author cmills
 */
public class Schedule extends PersistentObject {

  private String minute;
  private String hour;
  private String month;
  private String mday;
  private String wday;
  private String type;
  private Integer numOccurs;
  private boolean suspended;

  /**
   * Default constructor.
   */
  public Schedule() {
    this("*", "*", "*", "*", "*", "cron", new Integer(-1));
  }

  /**
   * Full constructor.
   *
   * @param min
   * @param hour
   * @param mday
   * @param month
   * @param wday
   * @param type
   * @param numOccurs
   */
  public Schedule(String min, String hour, String mday, String month,
                  String wday, String type, Integer numOccurs) {
    this.setMinute(min);
    this.setHour(hour);
    this.setMonth(month);
    this.setMday(mday);
    this.setWday(wday);
    this.setType(type);
    this.setNumOccurs(numOccurs);
    this.setSuspended(false);
  }

  /**
   * Copies information from an Inca schema XmlBean Schedule object so that
   * this object contains equivalent information.
   *
   * @param o the XmlBean Schedule object to copy
   * @return this, for convenience
   */
  public PersistentObject fromBean(XmlObject o) {
    return this.fromBean((edu.sdsc.inca.dataModel.util.Schedule)o);
  }

  /**
   * Copies information from an Inca schema XmlBean Schedule object so that
   * this object contains equivalent information.
   *
   * @param s the XmlBean Schedule object to copy
   * @return this, for convenience
   */
  public Schedule fromBean(edu.sdsc.inca.dataModel.util.Schedule s) {
    edu.sdsc.inca.dataModel.util.Cron cron = s.getCron();
    if(cron == null) {
      this.setType("immediate");
    } else {
      this.setType("cron");
      this.setMday(cron.getMday());
      this.setHour(cron.getHour());
      this.setMinute(cron.getMin());
      this.setMonth(cron.getMonth());
      this.setWday(cron.getWday());
      BigInteger numOccurs = cron.getNumOccurs();
      if(numOccurs != null) {
        this.setNumOccurs(new Integer(numOccurs.intValue()));
      }
      this.setSuspended(cron.getSuspended());
    }
    return this;
  }

  /**
   * Return the minute portion of the cron schedule.
   *
   * @return the minute cron field
   */
  public String getMinute() {
    return this.minute;
  }

  /**
   * Returns the first date/time after a specified date/time that this schedule
   * will cause an event.  Return null if no later event will ever occur.
   *
   * @param d a date/time preceding the returned value
   * @return the next date/time an event will occur
   */
  public Date nextEvent(Date d) {
    if(this.suspended ||
       (this.numOccurs != null && this.numOccurs.intValue() >= 0)) {
      // TODO: Debatable assumption that a non-null numOccurs means the final
      // event has already occurred.
      return null;
    }
    GregorianCalendar dAsCal = new GregorianCalendar();
    dAsCal.setTime(d);
    int dSecond = dAsCal.get(GregorianCalendar.SECOND);
    int dMinute = dAsCal.get(GregorianCalendar.MINUTE);
    int dHour = dAsCal.get(GregorianCalendar.HOUR_OF_DAY);
    int dMday = dAsCal.get(GregorianCalendar.DAY_OF_MONTH);
    int dMonth = dAsCal.get(GregorianCalendar.MONTH);
    int dWday = dAsCal.get(GregorianCalendar.DAY_OF_WEEK);
    int dYear = dAsCal.get(GregorianCalendar.YEAR);
    int nextSecond = dSecond;
    int nextMinute = dMinute + 1;
    int nextHour = dHour;
    int nextMday = dMday;
    int nextMonth = dMonth;
    int nextWday = dWday;
    int nextYear = dYear;
    nextMinute = this.getClosest(nextMinute, this.minute, 0, 59);
    if(nextMinute < 0) {
      nextHour++;
    }
    nextHour = this.getClosest(nextHour, this.hour, 0, 23);
    if(nextHour < 0) {
      nextMinute = -1;
      nextMday++;
    }
    nextMday = this.getClosest(nextMday, this.mday, 1, 31);
    if(nextMday < 0) {
      nextHour = -1;
      nextMinute = -1;
      nextMonth++;
    }
    nextMonth = this.getClosest(nextMonth, this.month, 0, 11);
    if(nextMonth < 0) {
      nextHour = -1;
      nextMinute = -1;
      nextMday = -1;
      nextYear++;
    }
    if(nextMinute < 0) {
       nextMinute = this.getClosest(0, this.minute, 0, 59);
    }
    if(nextHour < 0) {
       nextHour = this.getClosest(0, this.hour, 0, 23);
    }
    if(nextMday < 0) {
       nextMday = this.getClosest(0, this.mday, 1, 31);
    }
    if(nextMonth < 0) {
       nextMonth = this.getClosest(0, this.month, 0, 11);
    }
    GregorianCalendar result = new GregorianCalendar();
    result.set(GregorianCalendar.SECOND, nextSecond);
    result.set(GregorianCalendar.MINUTE, nextMinute);
    result.set(GregorianCalendar.HOUR_OF_DAY, nextHour);
    result.set(GregorianCalendar.DAY_OF_MONTH, nextMday);
    result.set(GregorianCalendar.MONTH, nextMonth);
    result.set(GregorianCalendar.YEAR, nextYear);
    // java.util.Calendar wdays are 1-based (Sunday = 1, Monday = 2, etc.)
    dWday = result.get(GregorianCalendar.DAY_OF_WEEK) - 1;
    nextWday = this.getClosest(dWday, this.wday, 0, 6);
    if(nextWday < 0) {
      nextWday = this.getClosest(0, this.wday, 0, 6);
    }
    if(dWday < nextWday) {
      result.add(GregorianCalendar.DAY_OF_MONTH, nextWday - dWday);
    } else if(dWday > nextWday) {
      result.add(GregorianCalendar.DAY_OF_MONTH, 7 - (dWday - nextWday));
    }
    return result.getTime();
  }

  public int getClosest(int target, String spec, int lowest, int highest) {
    spec =
      spec.replaceAll("\\?=", "").replaceFirst("\\*", lowest + "-" + highest);
    int step = 1;
    int pos = spec.indexOf("/");
    if(pos >= 0) {
      step = Integer.parseInt(spec.substring(pos + 1));
      spec = spec.substring(0, pos);
    }
    String[] pieces = spec.split(",");
    for(int i = 0; i < pieces.length; i++) {
      String piece = pieces[i];
      pos = piece.indexOf("-");
      int rangeLow = Integer.parseInt(pos<0 ? piece : piece.substring(0, pos));
      int rangeHigh =
        pos < 0 ? rangeLow : Integer.parseInt(piece.substring(pos + 1));
      for(int q = rangeLow; q <= rangeHigh; q += step) {
        if(q >= target) {
          return q;
        }
      }
    }
    return -1;
  }

  /**
   * Set the minute portion of the cron schedule.
   *
   * @param minute this minute portion of the schedule
   */
  public void setMinute(String minute) {
    if(minute == null || minute.equals("")) {
      minute = DB_EMPTY_STRING;
    }
    this.minute = truncate(minute, MAX_DB_STRING_LENGTH, "minute");
  }

  /**
   * Return the hour portion of the cron schedule.
   *
   * @return the hour cron field
   */
  public String getHour() {
    return this.hour;
  }

  /**
   * Set the hour portion of the cron schedule.
   *
   * @param hour this hour portion of the schedule
   */
  public void setHour(String hour) {
    if(hour == null || hour.equals("")) {
      hour = DB_EMPTY_STRING;
    }
    this.hour = truncate(hour, MAX_DB_STRING_LENGTH, "hour");
  }

  /**
   * Return the month portion of the cron schedule.
   *
   * @return the month cron field
   */
  public String getMonth() {
    return this.month;
  }

  /**
   * Set the month portion of the cron schedule.
   *
   * @param month the month portion of the schedule
   */
  public void setMonth(String month) {
    if(month == null || month.equals("")) {
      month = DB_EMPTY_STRING;
    }
    this.month = truncate(month, MAX_DB_STRING_LENGTH, "month");
  }

  /**
   * Return the mday portion of the cron schedule.
   *
   * @return the month day cron field
   */
  public String getMday() {
    return this.mday;
  }

  /**
   * Set the month day portion of the schedule.
   *
   * @param mday the month day portion of the schedule
   */
  public void setMday(String mday) {
    if(mday == null || mday.equals("")) {
      mday = DB_EMPTY_STRING;
    }
    this.mday = truncate(mday, MAX_DB_STRING_LENGTH, "mday");
  }

  /**
   * Return the wday portion of the cron schedule.
   *
   * @return the week day cron field.
   */
  public String getWday() {
    return this.wday;
  }

  /**
   * Set the week day portion of the schedule.
   *
   * @param wday the week day portion of the schedule
   */
  public void setWday(String wday) {
    if(wday == null || wday.equals("")) {
      wday = DB_EMPTY_STRING;
    }
    this.wday = truncate(wday, MAX_DB_STRING_LENGTH, "wday");
  }

  /**
   * Returns the type of schedule.
   *
   * @return the type of schedule
   */
  public String getType() {
    return this.type;
  }

  /**
   * Set the type of schedule.  Current recognized values are "cron" and
   * "immediate".
   *
   * @param type
   */
  public void setType(String type) {
    if(type == null || type.equals("")) {
      type = DB_EMPTY_STRING;
    }
    this.type = truncate(type, MAX_DB_STRING_LENGTH, "schedule type");
  }

  /**
   * Null implies unlimited.
   *
   * @return the number of times the schedule will be executed.
   */
  public Integer getNumOccurs() {
    return numOccurs;
  }

  /**
   * Set the number of times the schedule should be run before being
   * discarded.  Null indicates unlimited.
   * @param numOccurs
   */
  public void setNumOccurs(Integer numOccurs) {
    this.numOccurs = numOccurs;
  }

  /**
   * Returns whether or not further execution has been suspended pending
   * a user request to resume.
   * @return the suspension status
   */
  public boolean getSuspended() {
    return this.suspended;
  }

  /**
   * Indicates whether or not further execution should be suspended pending
   * a user request to resume.
   * @param suspended the suspension status
   */
  public void setSuspended(boolean suspended) {
    this.suspended = suspended;
  }

  /**
   * Returns a Inca schema XmlBean Schedule object that contains information
   * equivalent to this object.
   *
   * @return an XmlBean Schedule object that contains equivalent information
   */
  public XmlObject toBean() {
    edu.sdsc.inca.dataModel.util.Schedule result =
      edu.sdsc.inca.dataModel.util.Schedule.Factory.newInstance();
    if(this.getType().equals("cron")) {
      edu.sdsc.inca.dataModel.util.Cron cron = result.addNewCron();
      cron.setMday(this.getMday());
      cron.setHour(this.getHour());
      cron.setMin(this.getMinute());
      cron.setMonth(this.getMonth());
      cron.setWday(this.getWday());
      cron.setNumOccurs(BigInteger.valueOf(
        this.getNumOccurs() == null ? -1 : this.getNumOccurs().intValue()
      ));
      cron.setSuspended(this.getSuspended());
    }
    return result;
  }

  public String toString() {
    String result = this.getType();
    if(result.equals("cron")) {
      result += " " + this.getMinute() +
                " " + this.getHour() +
                " " + this.getMonth() +
                " " + this.getMday() +
                " " + this.getWday();
    }
    if(this.getNumOccurs() != null) {
      result += " " + this.getNumOccurs();
    }
    result += " " + this.getSuspended();
    return result;
  }

  /**
   * Override of the default equals method.
   */
  public boolean equals(Object o) {
    return this.toString().equals(o.toString());
  }

}
