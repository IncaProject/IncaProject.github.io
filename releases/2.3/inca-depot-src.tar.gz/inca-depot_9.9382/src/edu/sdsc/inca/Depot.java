package edu.sdsc.inca;

import edu.sdsc.inca.protocol.MessageHandlerFactory;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.util.ConfigProperties;
import java.util.Enumeration;
import java.util.Properties;
import org.jboss.logging.Logger;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.hibernate.HibernateException;

/**
 * The main depot object.
 * <p/>
 * This object is responsible for retrieving configuration information,
 * starting and cleaning up after the server as well as shutdown.
 * <p/>
 * Configuration is handled by default using inca.properties in the classpath.
 */
public class Depot extends Server {

  static {
    MessageHandlerFactory.registerMessageHandler
      (Protocol.INSERT_COMMAND, "edu.sdsc.inca.depot.commands.Insert");
    MessageHandlerFactory.registerMessageHandler
      (Protocol.QUERY_DB_COMMAND, "edu.sdsc.inca.depot.commands.Query");
    MessageHandlerFactory.registerMessageHandler
      (Protocol.QUERY_GUIDS_COMMAND, "edu.sdsc.inca.depot.commands.Query");
    MessageHandlerFactory.registerMessageHandler
      (Protocol.QUERY_HQL_COMMAND, "edu.sdsc.inca.depot.commands.Query");
    MessageHandlerFactory.registerMessageHandler
      (Protocol.QUERY_INSTANCE_COMMAND, "edu.sdsc.inca.depot.commands.Query");
    MessageHandlerFactory.registerMessageHandler
      (Protocol.QUERY_SERIES_COMMAND, "edu.sdsc.inca.depot.commands.Query");
    MessageHandlerFactory.registerMessageHandler
      (Protocol.QUERY_SQL_COMMAND, "edu.sdsc.inca.depot.commands.Query");
    MessageHandlerFactory.registerMessageHandler
      (Protocol.QUERY_SUITE_COMMAND, "edu.sdsc.inca.depot.commands.Query");
    MessageHandlerFactory.registerMessageHandler
      (Protocol.SUITE_UPDATE_COMMAND,
       "edu.sdsc.inca.depot.commands.SuiteUpdate");
  }

  // Protected class variables
  protected static final Logger logger = Logger.getLogger(Depot.class);

  // Command-line options
  protected static final String DEPOT_OPTS =
    ConfigProperties.mergeValidOptions(
      SERVER_OPTS,
      "d|dbinit null init depot DB tables\n" +
      "r|remove null remove depot DB tables\n",
      true
    );

  // Instance configuration variables
  protected boolean initDb = false;
  protected boolean rmDb = false;

  /**
   * Default Constructor.
   */
  public Depot() {
    super();
  }

  /**
   * Initialize the Inca database.
   *
   * @throws HibernateException on database error
   */
  public void initializeDatabase() throws HibernateException {
    Configuration cfg = new Configuration();
    cfg.configure();
    SchemaExport export = new SchemaExport(cfg);
    logger.info("Creating Inca database");
    export.create(false, true);
  }

  /**
   * Delete the Inca database.
   *
   * @throws HibernateException on database error
   */
  public void removeDatabase() throws HibernateException {
    Configuration cfg = new Configuration();
    cfg.configure();
    SchemaExport export = new SchemaExport(cfg);
    logger.info("Removing Inca database");
    export.drop(false, true);
  }

  /**
   * A convenience function for setting multiple configuration properties at
   * once.  In addition to the keys recognized by the superclass, recognizes:
   * "dbinit", a command to initialize the database; "remove", a command to
   * delete the DB.
   *
   * @param config contains client configuration values
   * @throws ConfigurationException on a faulty configuration property value
   */
  public void setConfiguration(Properties config) throws ConfigurationException{
    super.setConfiguration(config);
    if(config.getProperty("dbinit") != null) {
      this.initDb = true;
    }
    if(config.getProperty("remove") != null) {
      this.rmDb = true;
    }
    // TODO: Hack to get properties to Input command class via System
    // properties. Design a better way.
    for(Enumeration e = config.keys(); e.hasMoreElements(); ) {
      String key = (String)e.nextElement();
      System.setProperty("inca.depot." + key, config.getProperty(key));
      logger.info("inca.depot." + key + "=>" + config.getProperty(key));
    }
  }

  /**
   * Start the depot from the command line.
   *
   * @param args
   */
  public static void main(String[] args) {
    Depot d = new Depot();
    try {
      configComponent
        (d, args, DEPOT_OPTS, "inca.depot.", "edu.sdsc.inca.Depot",
         "inca-depot-version");
    } catch(Exception e) {
      logger.fatal("Configuration error: " + e);
      System.err.println("Configuration error: " + e);
      System.exit(1);
    }
    // process special commands that are run before/in lieu of the sever
    try {
      if(d.rmDb) {
        d.removeDatabase();
        if(!d.initDb) {
          return;
        }
      }
      if(d.initDb) {
        d.initializeDatabase();
        return;
      }
    } catch(HibernateException e) {
      logger.error("Database command failed: " + e);
      System.exit(1);
    }
    try {
      d.runServer();
      while(d.isRunning()) {
        Thread.sleep(1000);
      }
    } catch(Exception e) {
      logger.fatal("Server error: ", e);
      System.err.println("Server error: " + e);
      System.exit(1);
    }
  }

}
