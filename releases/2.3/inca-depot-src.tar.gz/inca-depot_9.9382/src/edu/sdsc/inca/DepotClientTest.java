package edu.sdsc.inca;

import junit.framework.TestCase;

import edu.sdsc.inca.depot.persistent.Suite;
import edu.sdsc.inca.depot.persistent.SuiteDAO;
import edu.sdsc.inca.depot.persistent.Series;
import edu.sdsc.inca.util.ConfigProperties;
import edu.sdsc.inca.dataModel.suite.SuiteDocument;
import edu.sdsc.inca.dataModel.report.ReportDocument;
import edu.sdsc.inca.dataModel.util.Report;
import edu.sdsc.inca.DepotClient;
import edu.sdsc.inca.queryResult.ReportSummaryDocument;
import edu.sdsc.inca.dataModel.reportDetails.ReportDetailsDocument;

import java.io.IOException;
import java.util.Calendar;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;


/**
 * Created by IntelliJ IDEA.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class DepotClientTest extends TestCase {

  private Logger logger = Logger.getLogger( this.getClass().getName() );
  private static final int CONFIG_COUNT = 4;
  private static final String SUITE_GUID = "RA:GUID";

  public void testQueryInstance() throws Exception {

    Depot d = null;
    try {
      d = startDepot();
    } catch ( Exception e ) {
      logger.error( "Depot couldn't start ", e );
      fail(e.toString());
    }

    Suite suite = Suite.generate(SUITE_GUID, CONFIG_COUNT);
    String suiteXml = suite.toXml();
    DepotClient dc = null;
    String stderr = "ls: blech: No such file or directory";
    try {
      dc = connectDepotClient("localhost", d.getPort());

      logger.debug( "SENDING SUITE" );
      dc.updateSuite( suiteXml );

      logger.debug( "SENDING FIRST REPORT" );
      Series series = suite.getSeriesConfig(0).getSeries();
      String report = series.generateReport();
   
      dc.insertReport(
        series.getResource(),
        report,
        "cpu_secs=12\nwall_secs=13\nmemory_mb=14\n",
        stderr,
        series.getContext());

      logger.info( "SLEEPING 3 SECONDS TO ALLOW INSERT TO COMPLETE");
      Thread.sleep(3000);
      String[] basicResult = dc.querySuite(SUITE_GUID);
      logger.debug( "CHECKING BASICRESULTS" );
      assertEquals
        ("num of basic results correct", CONFIG_COUNT, basicResult.length);
      for(int i = 0; i < basicResult.length; i++) {
        ReportSummaryDocument sum = ReportSummaryDocument.Factory.parse(
          basicResult[i]
        );
        if(sum.getReportSummary().getHostname().equals(series.getResource())) {
          assertTrue( series.getContext() + " has body",
            sum.getReportSummary().isSetBody() );
          ReportDetailsDocument result = dc.queryInstance(
            sum.getReportSummary().getInstanceId(),
            sum.getReportSummary().getSeriesConfigId()
          );
          assertNotNull( series.getContext() + " instance has report",
            result.getReportDetails().getReport() );
          assertEquals( series.getContext() + " has stderr",
                        stderr,
                        result.getReportDetails().getStderr() );
        }
      }
      dc.close();
    } finally {
      stopDepot(d);
    }

  }

  public void testQuerySuite() throws XmlException {

    Depot d = null;
    try {
      d = startDepot();
    } catch ( Exception e ) {
      logger.error( "Depot couldn't start ", e );
    }

    Suite suite = Suite.generate(SUITE_GUID, CONFIG_COUNT);
    String suiteXml = suite.toXml();
    SuiteDocument suiteDoc = SuiteDocument.Factory.parse(suiteXml);
    String[] REPORTS = new String[CONFIG_COUNT];
    for(int i = 0; i < CONFIG_COUNT; i++) {
      REPORTS[i] = suite.getSeriesConfig(i).getSeries().generateReport();
    }
    ReportDocument[] reports = new ReportDocument[REPORTS.length];
    for ( int i = 0; i < reports.length; i++ ) {
      reports[i] = ReportDocument.Factory.parse(REPORTS[i]);
    }

    DepotClient dc;
    String failMsg = null;
    Calendar firstReportTime0 = null;
    Calendar firstReportTime1 = null;
    try {
      dc = connectDepotClient("localhost", d.getPort());

      logger.debug( "SENDING SUITE" );
      dc.updateSuite( suiteXml );

      logger.debug( "SENDING REPORT 0" );
      Series series = suite.getSeriesConfig(0).getSeries();
      dc.insertReport(
        series.getResource(),
        REPORTS[0],
        "cpu_secs=12\nwall_secs=13\nmemory_mb=14\n",
        null,
        series.getContext());

      logger.info( "SLEEPING 3 SECONDS TO ALLOW INSERT TO COMPLETE");
      Thread.sleep(3000);
      String[] basicResult = dc.querySuite(SUITE_GUID);
      logger.debug( "CHECKING BASICRESULTS" );
      assertEquals
        ("num of basic results correct", CONFIG_COUNT, basicResult.length );
      for(int i = 0; i < basicResult.length; i++) {
        ReportSummaryDocument sum = ReportSummaryDocument.Factory.parse(
          basicResult[i]
        );
        if(sum.getReportSummary().getHostname().equals(series.getResource())) {
          assertTrue( series.getContext() + " has body",
            sum.getReportSummary().isSetBody() );
          ReportDetailsDocument result = dc.queryInstance(
            sum.getReportSummary().getInstanceId(),
            sum.getReportSummary().getSeriesConfigId()
          );
          firstReportTime0 = result.getReportDetails().getReport().getGmt();
        }
      }

      logger.debug( "SENDING REPORT 1" );
      series = suite.getSeriesConfig(1).getSeries();
      dc.insertReport(
        series.getResource(),
        REPORTS[1],
        "cpu_secs=12\nwall_secs=13\nmemory_mb=14\n",
        null,
        series.getContext());

      logger.info( "SLEEPING 3 SECONDS TO ALLOW INSERT TO COMPLETE");
      Thread.sleep(3000);
      logger.debug( "CHECKING BASICRESULTS" );
      basicResult = dc.querySuite( suiteDoc.getSuite().getGuid() );
      assertEquals
        ("num of basic results correct", CONFIG_COUNT, basicResult.length);
      for(int i = 0; i < basicResult.length; i++) {
        ReportSummaryDocument sum = ReportSummaryDocument.Factory.parse(
          basicResult[i]
        );
        if(sum.getReportSummary().getHostname().equals(series.getResource())) {
          assertTrue( series.getContext() + " has report",
            sum.getReportSummary().isSetBody() );
          ReportDetailsDocument result = dc.queryInstance(
            sum.getReportSummary().getInstanceId(),
            sum.getReportSummary().getSeriesConfigId()
          );
          assertNotNull("Instance not found", result);
          firstReportTime1 = result.getReportDetails().getReport().getGmt();
        }
      }

      logger.debug( "INSERTING " + REPORTS.length + " NEW REPORTS IN DB");
      for(int i = 0; i < REPORTS.length; i++) {
        series = suite.getSeriesConfig(i).getSeries();
        logger.debug( "INSERTING REPORT " + i );
        dc.insertReport(
          series.getResource(),
          REPORTS[i],
          "cpu_secs=12\nwall_secs=13\nmemory_mb=14\n",
          null,
          series.getContext());
        logger.info( "SLEEPING 3 SECONDS TO ALLOW INSERT TO COMPLETE");
        Thread.sleep(3000);
      }

      logger.debug( "CHECKING BASICRESULTS" );

      basicResult = dc.querySuite(suiteDoc.getSuite().getGuid());
      assertEquals
        ("number of basic results correct", CONFIG_COUNT, basicResult.length );
      for(int i = 0; i < basicResult.length; i++) {
        ReportSummaryDocument sum = ReportSummaryDocument.Factory.parse(
          basicResult[i]
        );
        logger.debug( basicResult[i] );
        assertTrue( sum.getReportSummary().getHostname() + " has report",
                    sum.getReportSummary().isSetBody() );
        ReportDetailsDocument result = dc.queryInstance(
          sum.getReportSummary().getInstanceId(),
          sum.getReportSummary().getSeriesConfigId()
        );
        Report report = result.getReportDetails().getReport();
        if(report.getName().equals(suite.getSeriesConfig(0).getSeries().getResource())) {
          Calendar reportTime = report.getGmt();
          assertTrue( "Received last report for 0",
            reportTime.after(firstReportTime0) );
        }
        if ( report.getName().equals(suite.getSeriesConfig(1).getSeries().getResource())) {
          Calendar reportTime = report.getGmt();
          assertTrue( "Received last report for 1",
            reportTime.after(firstReportTime1) );
        }
      }
      dc.close();
    } catch(Exception e) {
      failMsg = "unexpected exception " + e;
      logger.error( failMsg, e );
    } finally {
      stopDepot(d);
    }
    if(failMsg != null) {
      fail(failMsg);
    }
  }

  public void testQuerySeries() throws Exception {

    Depot d = null;
    try {
      d = startDepot();
    } catch ( Exception e ) {
      logger.error( "Depot couldn't start ", e );
    }

    Suite suite = Suite.generate(SUITE_GUID, CONFIG_COUNT);
    String suiteXml = suite.toXml();
    SuiteDocument suiteDoc = SuiteDocument.Factory.parse(suiteXml);
    String[] REPORTS = new String[CONFIG_COUNT];
    for(int i = 0; i < CONFIG_COUNT; i++) {
      REPORTS[i] = suite.getSeriesConfig(i).getSeries().generateReport();
    }
    ReportDocument[] reports = new ReportDocument[REPORTS.length];
    for ( int i = 0; i < reports.length; i++ ) {
      reports[i] = ReportDocument.Factory.parse(REPORTS[i]);
    }

    DepotClient dc;
    String failMsg = null;

    try {

      dc = connectDepotClient("localhost", d.getPort());
      logger.debug( "SENDING SUITE" );
      dc.updateSuite( suiteXml );
      logger.info( "SLEEPING 3 SECONDS TO ALLOW INSERT TO COMPLETE");
      Thread.sleep(3000);
      suite = SuiteDAO.load(suite);

      logger.debug( "INSERTING " + REPORTS.length + " NEW REPORTS IN DB");
      for(int i = 0; i < REPORTS.length; i++) {
        Series series = suite.getSeriesConfig(i).getSeries();
        logger.debug( "INSERTING REPORT " + i );
        dc.insertReport(
          series.getResource(),
          REPORTS[i],
          "cpu_secs=12\nwall_secs=13\nmemory_mb=14\n",
          null,
          series.getContext());
        logger.info( "SLEEPING 3 SECONDS TO ALLOW INSERT TO COMPLETE");
        Thread.sleep(3000);
      }

      int sampleConfigIndex = REPORTS.length >= 2 ? 1 : 0;
      // Retrieve by id ...
      ReportDetailsDocument[] rdd = dc.querySeries
        (suite.getSeriesConfig(sampleConfigIndex).getId().longValue());
      assertEquals(1, rdd.length);
      // ... and by nickname
      rdd =
        dc.querySeries(suite.getSeriesConfig(sampleConfigIndex).getNickname());
      assertEquals(1, rdd.length);

      dc.close();

    } catch(Exception e) {
      failMsg = "unexpected exception " + e;
      e.printStackTrace();
      logger.error( failMsg, e );
    } finally {
      stopDepot(d);
    }

    if(failMsg != null) {
      fail(failMsg);
    }

  }

  private Depot startDepot() throws Exception {
    Depot result = new Depot();
    ConfigProperties config = new ConfigProperties();
    config.putAllTrimmed(System.getProperties(), "inca.depot.");
    config.loadFromResource("inca.properties", "inca.depot.");
    config.setProperty("auth", "no");
    config.setProperty("password", "");
    result.setConfiguration(config);
    result.removeDatabase();
    result.initializeDatabase();
    result.runServer();
    return result;
  }

  private DepotClient connectDepotClient(String server, int port)
    throws ConfigurationException, IOException {
    DepotClient result = new DepotClient();
    ConfigProperties config = new ConfigProperties();
    result.setServer(server, port);
    config.putAllTrimmed(System.getProperties(), "inca.depot.");
    config.loadFromResource("inca.properties", "inca.depot.");
    config.setProperty("auth", "no");
    config.setProperty("password", "");
    result.setConfiguration(config);
    result.connect();
    return result;
  }

  private void stopDepot(Depot d) {
    if(d == null) {
      return;
    }
    try {
      logger.debug( "Trying to shutdown depot" );
      d.shutdown();
      logger.debug( "Shutdown complete" );
    } catch(InterruptedException e) {
      // empty
    }
  }

}
