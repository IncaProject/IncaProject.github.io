package edu.sdsc.inca.depot.persistent;

import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * This is the base class for the depot DAOs--classes that transfer objects
 * between memory and the depot database.  Since child DAO classes will each
 * deal with a different DB class, this class doesn't define abstract methods
 * for children to override.  Instead, the set of methods that child classes
 * should define is described in comments below.  Which methods from this set
 * a child class actually implements depends on which are needed; the
 * description is intended to provide a convention to follow.
 *
 * @author cmills
 * @author jhayes
 */
public abstract class DAO {

  /* Description of child class methods: */

  /*
   * Returns an object from the DB with the same field values as one specified,
   * null if no such object appears in the DB.
   *
   * @param o an object that contains field values used in the retrieval
   * @return an object from the DB that contains the same values
   * @throws PersistenceException on err
   *
  public static DBObject load(DBObject o) throws PersistenceException;
   */

  /*
   * Returns an object from the DB with the id specified, null if no such
   * object appears in the DB.
   *
   * @param id the id of the object to be retrieved
   * @return an object from the DB marked with the given id
   * @throws PersistenceException on err
  public static DBObject load(Long id) throws PersistenceException;
   */

  /*
   * Returns an object from the DB with the same field values as one specified,
   * or the saved version of the specified object if no such object appears in
   * the DB.  Synchronized to avoid race conditions that could result in DB
   * duplicates.
   *
   * @param o an object that contains field values used in the retrieval
   * @return an object from the DB that contains the same values
   * @throws PersistenceException on err
   *
  public static synchronized DBObject loadOrSave(DBObject o)
    throws PersistenceException;
   */

  /*
   * A wrapper around DAO.update that handles the necessary casting.
   *
   * @param o the object to store
   * @return o for convenience
   * @throws PersistenceException on error
   *
  public static DBObject update(DBObject o) throws PersistenceException;
   */

  protected static Logger logger = Logger.getLogger(DAO.class);
  protected static Logger verboseLogger = Logger.getLogger("edu.sdsc.inca.verbose");

  /**
   * Return the unique object selected by a Hibernate query.
   *
   * @param query the Hibernate query; see Hibernate doc for format
   * @param params a set of objects to plug into the query in spots marked
   *               as :p0, :p1, etc.  May be null if the query has no params.
   * @return the object selected by the query; null if none
   * @throws PersistenceException on error
   */
  public static Object selectUnique(String query, Object[] params)
    throws PersistenceException {
    List l = DAO.selectMultiple(query, params);
    if(l.size() > 1) {
      logger.warn("Unique query returned " + l.size() + " objects");
    }
    return l.isEmpty() ? null : l.get(0);
  }

  /**
   * Return the set of objects selected by a Hibernate query.
   *
   * @param query the Hibernate query; see Hibernate doc for format
   * @param params a set of objects to plug into the query in spots marked
   *               as :p0, :p1, etc.  May be null if the query has no params.
   * @return the (possibly empty) set of objects selected by the query
   * @throws PersistenceException on error
   */
  public static List selectMultiple(String query, Object[] params)
    throws PersistenceException {
    Session session = HibernateUtil.getCurrentSession();
    Query q = session.createQuery(query);
    if(params != null) {
      for(int i = 0; i < params.length; i++) {
        Object param = params[i];
        String name = "p" + i;
        if(param instanceof Boolean) {
          q.setBoolean(name, ((Boolean)param).booleanValue());
        } else if(param instanceof Integer) {
          q.setInteger(name, ((Integer)param).intValue());
        } else if(param instanceof Long) {
          q.setLong(name, ((Long)param).longValue());
        } else if(param instanceof String) {
          q.setString(name, (String)param);
        } else {
          q.setEntity(name, param);
        }
      }
    }
    try {
      List result = q.list();
      StringBuffer paramImages = new StringBuffer();
      if(params != null) {
        for(int i = 0; i < params.length; i++) {
          paramImages.append((i == 0 ? "" : ", ") + "'" + params[i] + "'");
        }
      }
      paramImages.append("]");
      logger.debug("Query '" + q + "'[" + paramImages + "] located " +
                   result.size() + " objects");
      // JJH: Commented to cut down on excess log size
      //for(int i = 0; i < result.size(); i++) {
      //  verboseLogger.debug(result.get(i).toString());
      //}
      return result;
    } catch(HibernateException e) {
      logger.error("Query '" + query + "' threw exception: " + e);
      throw new PersistenceException("DB access exception: " + e);
    }
  }

  /**
   * Stores an object that has not previously been saved in the database.
   *
   * @param o the object to store
   * @return o, for convenience
   * @throws PersistenceException on error
   */
  public static Object save(Object o) throws PersistenceException {
    logger.debug("save '" + o.toString() + "'");
    Session session = HibernateUtil.getCurrentSession();
    HibernateUtil.beginTransaction();
    try {
      session.save(o);
      HibernateUtil.commitTransaction();
    } catch(HibernateException e) {
      HibernateUtil.rollbackTransaction();
      HibernateUtil.closeSession();
      throw new PersistenceException("DB save exception: " + e);
    }
    return o;
  }

  /**
   * Updates an object that has previously been saved in the database.
   *
   * @param o the object to store
   * @return o, for convenience
   * @throws PersistenceException on error
   */
  public static Object update(Object o) throws PersistenceException {
    logger.debug("update '" + o.toString() + "'");
    Session session = HibernateUtil.getCurrentSession();
    HibernateUtil.beginTransaction();
    try {
      session.update(o);
      HibernateUtil.commitTransaction();
    } catch(HibernateException e) {
      HibernateUtil.rollbackTransaction();
      HibernateUtil.closeSession();
      throw new PersistenceException("DB update exception: " + e);
    }
    return o;
  }

  /**
   * Performs an HQL UPDATE command.
   *
   * @param update, the HQL UPDATE command to perform.
   * @return the number of affected rows
   * @throws PersistenceException on error
   */
  public static int runUpdate(String update) throws PersistenceException {
    logger.debug("runUpdate " + update);
    int result = 0;
    Session session = HibernateUtil.getCurrentSession();
    Query q = session.createQuery(update);
    HibernateUtil.beginTransaction();
    try {
      result = q.executeUpdate();
      HibernateUtil.commitTransaction();
    } catch(HibernateException e) {
      HibernateUtil.rollbackTransaction();
      HibernateUtil.closeSession();
      throw new PersistenceException("DB update exception: " + e);
    }
    return result;
  }

}
