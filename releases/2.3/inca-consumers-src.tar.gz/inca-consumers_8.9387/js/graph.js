function validate(form){
  var err = "";
  var checked = 0;
  var testName = "";
  var resourceName = "";
  var seriesLabel = "";
  for(i=0; i<form.series.length; i++){
    var mySeries = form.series[i];
    if(mySeries.checked==true){
      checked++;
      if (/,/.test(mySeries.value)){
        temp = mySeries.value.split(",");
        testName += temp[0];
        resourceName += temp[1];
        seriesLabel += temp[2];
        testName += ",";
        resourceName += ",";
        seriesLabel += ",";
      }
    }
  }

  form.testName.value = testName;
  form.resourceName.value = resourceName;
  form.seriesLabel.value = seriesLabel;
  if(checked < 1){
    err += "\nSelect series to graph\n";
  }

  var validdate  = /(^\d{6}$)/;
  var mindate = form.xmin.value;
  if(!validdate.test(mindate) && mindate != ""){
    err += "\nStart date is invalid\n";
  }

  var maxdate = form.xmax.value;
  if(!validdate.test(maxdate) && maxdate != ""){
    err += "\nEnd date is invalid\n";
  }

  var validcolor  = /(^#.{6}$)/;
  var color = form.bgcolor.value;
  if(!validcolor.test(color) && color != ""){
    err += "\nBackground color is invalid\n";
  }

  var validsize  = /(^\d+$)/;
  var width = form.width.value;
  if(!validsize.test(width)){
    err += "\nWidth is invalid\n";
  }

  var height = form.height.value;
  if(!validsize.test(height)){
    err += "\nHeight is invalid\n";
  }

  if(err != ""){
    alert(err);
    return false;
  }
  return true;
}

function checkAll(field){
  for (i = 0; i < field.length; i++)
    field[i].checked = true ;
}

function uncheckAll(field){
  for (i = 0; i < field.length; i++)
    field[i].checked = false ;
}

function flip(form, suiteName, match, cells, checkVal){
  end = '$';
  if (cells == 'COL'){
    end = '-ROW-.*$';
  }
  re = new RegExp('^-SUITE-' + suiteName + '.*-' + cells + '-' + match + end);
  for(i = 0; i < form.elements.length; i++){
    elm = form.elements[i];
    if (elm.type == 'checkbox' && re.test(elm.id)){
      elm.checked = checkVal;
    }
  }
}
