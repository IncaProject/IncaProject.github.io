package edu.sdsc.inca.consumer.dataproducer;

import de.laures.cewolf.DatasetProduceException;
import de.laures.cewolf.DatasetProducer;
import de.laures.cewolf.links.XYItemLinkGenerator;
import de.laures.cewolf.tooltips.XYToolTipGenerator;
import edu.sdsc.inca.consumer.tag.Util;
import edu.sdsc.inca.dataModel.graphSeries.GraphInstance;
import edu.sdsc.inca.util.StringMethods;
import org.apache.log4j.Logger;
import org.jfree.data.time.Minute;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;

import javax.servlet.jsp.JspWriter;
import java.io.Serializable;
import java.io.IOException;
import java.util.Date;
import java.util.Map;
import java.util.Vector;
import java.util.regex.Pattern;

/**
 * A dataset producer for a timeseries cewolf chart.  A dataset (corresponding
 * to a line on the graph) is created for each configID in a Hashtable and its
 * GraphInstance objects (the configID's value in the Hashtable).
 *
 * Example call from JSP:
 *
 * TimeSeriesData data = new TimeSeriesData();
 * data.setGraphInstanceHash(hash);
 * data.setConfigIDs(configIDs);
 * data.setSeriesLabels(seriesLabels);
 * data.createTimeSeriesCollection();
 * pageContext.setAttribute("data", data);
 * ...
 * <cewolf:data>
 *  <cewolf:producer id="data"/>
 * </cewolf:data>
 *
 * @author  Kate Ericson
 */

public class TimeSeriesData implements DatasetProducer,
    XYToolTipGenerator, XYItemLinkGenerator, Serializable  {

  private TimeSeriesCollection collection;
  private GraphInstanceHash graphInstanceHash;
  private String[][] links;
  private static Logger logger = Logger.getLogger(TimeSeriesData.class);
  private String[] resourceNames;
  private String[] seriesLabels;
  private int[] seriesPercPass;
  private int[] seriesTotalFail;
  private int[] seriesTotalPass;
  private String[] testNames;
  private String[][] tooltips;

  /**
   * Default constructor.  Create dataset producer for time series data where
   * the y-axis is pass/fail status information.
   */
  public TimeSeriesData( ) {    
  }

  /**
   * Creates dataset producer for time series data based on Inca instance
   * data.  The resource for each
   *
   * @param graphInstances  Contains arrays of pass/fail information referenced
   * by the test and resource name.
   *
   */
  public TimeSeriesData( GraphInstanceHash graphInstances ) {
    this.graphInstanceHash = graphInstances;
    this.testNames = graphInstances.getTestNames();
    this.resourceNames = graphInstances.getResourceNames();
  }

  /**
   * Create a jfree dataset of pass/fail statuses and
   * timestamps appropriate to graph.  Store the results internally
   * into the member variable collection
   */
  public void createTimeSeriesCollection() {
    long startTime = Util.getTimeNow();
    int numConfigs = testNames.length;

    // create new timeseries *collection* for multiple sets of x,y data
    TimeSeriesCollection tsc = new TimeSeriesCollection();

    // mouseover and href arrays for graph's image map
    tooltips = new String[numConfigs][];
    links = new String[numConfigs][];

    // pass/fail totals for series
    seriesTotalPass = new int[numConfigs];
    seriesPercPass = new int[numConfigs];
    seriesTotalFail = new int[numConfigs];

    // process data for each test and resource
    for (int i=0; i < numConfigs; i++) {
      String test = testNames[i];
      String resource = resourceNames[i];
      Vector gis = graphInstanceHash.get(test,resource);
      // create timeseries for this configID
      TimeSeries ts = new TimeSeries(seriesLabels[i], Minute.class);
      Vector tooltipsVector = new Vector();
      Vector linksVector = new Vector();
      int seriesPass = 0;
      int seriesFail = 0;
      // add data to this configID's time series
      for (int j=0; j<gis.size(); j++) {
        GraphInstance gi = (GraphInstance)gis.get(j);
        Date date = StringMethods.convertDateString(gi.getCollected(),
            "yyyy-MM-dd HH:mm:ss.S");
        int ts_result = addInstanceToTimeSeries(gi, ts, date );
        if (ts_result == 1){
          seriesPass++;
        }
        if (ts_result == 0){
          seriesFail++;
        }
        if (ts_result != -1){
          tooltipsVector.addElement
            ( GraphInstanceHash.formatStringAsTooltip( gi.getExitMessage() ) +
              " ("+date.toString()+")" );
          linksVector.addElement( "xslt.jsp?xsl=instance.xsl&instanceID="+
              gi.getInstanceId() + "&configID="+ gi.getConfigId() +
              "&resourceName="+ resource);
        } else { // remove it from the list if it was skipped
          gis.remove( j );
          j--; // removing element reduces size of array
        }      
      }
      seriesTotalPass[i] = seriesPass;
      seriesTotalFail[i] = seriesFail;
      float percPass =  (float)seriesPass/(seriesPass+seriesFail)*100;
      seriesPercPass[i] = (int)percPass;
      // add this configID's time series to the collection
      tsc.addSeries(ts);
      tooltips[i] = (String[]) tooltipsVector.toArray
        ( new String [tooltipsVector.size()] );
      links[i] = (String[]) linksVector.toArray
        ( new String [linksVector.size()] );
    }
    setCollection(tsc);
    Util.printElapsedTime( startTime, "GRAPH: total time" );
  }

  /**
   * Hyperlink for datapoint
   *
   * @param data  Jfree Dataset object to add href to.
   *
   * @param series  Integer for the jfree chart series to link.
   *
   * @param item  Integer for the item to add href to
   *              (e.g. an XY point in a chart series).
   *
   * @return  Hyperlink string
   */
  public String generateLink(Object data, int series, int item) {
    return links[series][item];
  }

  /**
   * Text to display when datapoint is moused over
   *
   * @param data  Jfree XYDataset object to add mouseover text to.
   *
   * @param series  Integer for the jfree chart series to add mouseover text to.
   *
   * @param item  Integer for the item to add mouseover text to
   *              (e.g. an XY point in a chart series).
   *
   * @return  Mouseover text string
   */
  public String generateToolTip(XYDataset data, int series, int item) {
    return tooltips[series][item];
  }

  /**
   * Return a TimeSeriesCollection with timestamp/value data for each configID.
   *
   * @return TimeSeriesCollection with timestamp/value data for each configID.
   */
  public TimeSeriesCollection getCollection() {
    return collection;
  }

  /**
   * Return a hash of configIDs and their associated GraphInstance objects
   * (one for each instance in the configID's history).
   *
   * @return A hash of configIDs and their associated GraphInstance objects.
   */
  public GraphInstanceHash getGraphInstanceHash() {
    return graphInstanceHash;
  }


  /**
   * Return array of hyperlinks that corresponds to an array of configIDs.
   *
   * @return Array of hyperlinks that corresponds to an array of configIDs.
   */
  public String[][] getLinks() {
    return links;
  }

  /**
   * Returns a unique ID for this DatasetProducer
   */
  public String getProducerId() {
    return "inca timeseries";
  }

  /**
   * Get a string array of resourceNames (used for ordering the hashtable)
   *
   * @return A list of the series resource names
   */
  public String[] getResourceNames() {
    return resourceNames;
  }

  /**
   * Return array of labels used for each configID in the graph legend.
   *
   * @return Array of labels used for each configID in the graph legend.
   */
  public String[] getSeriesLabels() {
    return seriesLabels;
  }

  /**
   * Return percentage of tests passed for each configID being graphed.
   *
   * @return Percentage of tests passed for each configID being graphed.
   */
  public int[] getSeriesPercPass() {
    return seriesPercPass;
  }

  /**
   * Return total tests failed for each configID being graphed.
   *
   * @return Total tests failed for each configID being graphed.
   */
  public int[] getseriesTotalFail() {
    return seriesTotalFail;
  }

  /**
   * Return total tests passed for each configID being graphed.
   *
   * @return Total tests passed for each configID being graphed.
   */
  public int[] getseriesTotalPass() {
    return seriesTotalPass;
  }

  /**
   * Get a string array of testNames (used for ordering the hashtable)
   *
   * @return a list of series test names
   */
  public String[] getTestNames() {
    return testNames;
  }

  /**
   * Return array of mouseover text that corresponds to an array of configIDs.
   *
   * @return Array of mouseover text that corresponds to an array of configIDs.
   */
  public String[][] getTooltips() {
    return tooltips;
  }

  /**
   * This method influences Cewolf's caching behaviour.
   *
   * Example of invalid data after a day (86,400 seconds):
   *   log.debug(getClass().getName() + "hasExpired()");
   *   return (System.currentTimeMillis() - since.getTime()) > 86400000;
   */
  public boolean hasExpired(Map params, Date since) {
    return true;
  }

  /**
   * Print out the counts of passes/failures in a HTML table.
   *
   * @param out  Printer to a JSP page
   *
   * @throws IOException if trouble writing to JSP page
   */
  public void printCountsInTable( JspWriter out ) throws IOException {

    out.println( "<table class=\"header\">" );
    for ( int i = 0; i < resourceNames.length; i++ ) {
      float totalTests = this.seriesTotalFail[i] + this.seriesTotalPass[i];
      int totalTestsInt = (int)totalTests;
      int passRate = Math.round( (this.seriesTotalPass[i] / totalTests) * 100 );
      String totalStats = ":  passed " + this.seriesTotalPass[i] + " out of " +
                          totalTestsInt + " tests ( " + passRate + "% )";
      out.println(
        "<tr>\n" +
        "  <td class=\"header\" colspan=\"3\"><b>"+this.seriesLabels[i]+"</b>" +
        "   " + totalStats + "</td>\n" +
        "</tr><tr>\n" +
        "  <td class=\"subheader\">Error Type</td>\n" +
        "  <td class=\"subheader\">Error Count</td>\n" +
        "  <td class=\"subheader\">Error Message</td>\n" +
        "  </tr>");
        out.println
          ( "<tr><td colspan=\"3\" class=\"clear\"><i>no errors found</i></td></tr>" );  
    }
    out.println("</table> " );
  }

  /**
   * Create jfree dataset of pass/fail statuses and timestamps from
   * a set of GraphInstance objects.
   *
   * @param params  Additional params for the dataset production.
   *                All elements of this HashMap are of type
   *                java.io.Serializable.
   *
   * @return jfree  A jfree TimeSeriesCollection object
   *                with data and timeestamps.
   *
   * @throws DatasetProduceException
   */
  public Object produceDataset(Map params) throws DatasetProduceException {
    return this.getCollection();
  }

  /**
   * Set a TimeSeriesCollection with timestamp/value data for each configID.
   *
   * @param collection  TimeSeriesCollection with timestamp/value data
   *                    for each configID.
   */
  public void setCollection(TimeSeriesCollection collection) {
    this.collection = collection;
  }

  /**
   * Set a hash of configIDs and their associated GraphInstance objects
   * (one for each instance in the configID's history).
   *
   * @param graphInstanceHash    A hash of configIDs and their
   *                          associated GraphInstance objects.
   */
  public void setGraphInstanceHash(GraphInstanceHash graphInstanceHash) {
    this.graphInstanceHash = graphInstanceHash;
  }

  /**
   * Set array of hyperlinks that corresponds to an array of configIDs.
   *
   * @param links   Array of hyperlinks that corresponds
   *                to an array of configIDs.
   */
  public void setLinks(String[][] links) {
    this.links = links;
  }

  /**
   * Set a string array of resourceNames (used for ordering the hashtable)
   *
   * @param resourceNames   An array of resourceNames for ordering the hashtable
   */
  public void setResourceNames(String[] resourceNames) {
    this.resourceNames = resourceNames;
  }

  /**
   * Set array of labels used for each configID in the graph legend.
   *
   * @param seriesLabels    Array of labels used for each configID
   *                        in the graph legend.
   */
  public void setSeriesLabels(String[] seriesLabels) {
    this.seriesLabels = seriesLabels;
  }

  /**
   * Set percentage of tests passed for each configID being graphed.
   *
   * @param seriesPercPass    Percentage of tests passed
   *                          for each configID being graphed.
   */
  public void setSeriesPercPass(int[] seriesPercPass) {
    this.seriesPercPass = seriesPercPass;
  }

  /**
   * Set total tests failed for each configID being graphed.
   *
   * @param seriesTotalFail   Total tests failed
   *                          for each configID being graphed.
   */
  public void setseriesTotalFail(int[] seriesTotalFail) {
    this.seriesTotalFail = seriesTotalFail;
  }

  /**
   * Set total tests passed for each configID being graphed.
   *
   * @param seriesTotalPass   Total tests passed
   *                          for each configID being graphed.
   */
  public void setseriesTotalPass(int[] seriesTotalPass) {
    this.seriesTotalPass = seriesTotalPass;
  }

  /**
   * Set a string array of testNames (used for ordering the hashtable)
   *
   * @param testNames   An array of testNames for ordering the hashtable
   */
  public void setTestNames(String[] testNames) {
    this.testNames = testNames;
  }

  /**
   * Set array of mouseover text that corresponds to an array of configIDs.
   *
   * @param tooltips    Array of mouseover text that corresponds
   *                    to an array of configIDs.
   */
  public void setTooltips(String[][] tooltips) {
    this.tooltips = tooltips;
  }

  /**
   * @see java.lang.Object#finalize()
   */
  protected void finalize() throws Throwable {
    super.finalize();
    logger.debug(this + " finalized.");
  }

  /**
   * Add values from a GraphInstance object to a TimeSeries object.
   *
   * @param gi  GraphInstance object
   *
   * @param ts  Jfree TimeSeries object
   *
   * @param date  Date object
   *
   * @return 0 if failure, 1 if success, and -1 if error to add (usually if
   * there is a duplicate)
   */
  private int addInstanceToTimeSeries(GraphInstance gi, TimeSeries ts,
                                      Date date ){
    boolean testResult = GraphInstanceHash.getResult(gi);
    int result = testResult ? 1 : 0;
    if ( Pattern.matches( "Unable to fetch proxy for reporter execution", 
                          gi.getExitMessage() ) ) {
      return -1;
    }
    try{
      // add x,y data to this timeseries (x=date, y=exitStatus)
      ts.add(new Minute(date), result);
    } catch(Exception e) {
      result = -1;
    }
    return result;
  }

 

}