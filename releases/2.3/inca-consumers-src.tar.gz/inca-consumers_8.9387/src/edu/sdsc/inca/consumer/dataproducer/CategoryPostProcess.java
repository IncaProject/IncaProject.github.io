package edu.sdsc.inca.consumer.dataproducer;

import java.util.Map;

import org.apache.log4j.Logger;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.plot.CategoryPlot;
import de.laures.cewolf.ChartPostProcessor;

/**
 * A post-processor for an Category cewolf chart
 *
 * Example call from JSP:
 *
 * <cewolf:chartpostprocessor id="postprocess"/>
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */

public class CategoryPostProcess implements ChartPostProcessor {
  private static Logger logger = Logger.getLogger(TimeSeriesPostProcess.class);

  /**
   * Set the ytick to integers
   *
   * @param chart   The chart object
   * @param params  A hash array of parameters
   */
  public void processChart(Object chart, Map params) {
    CategoryPlot plot = ((JFreeChart) chart).getCategoryPlot();
    NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
    rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
  }

}