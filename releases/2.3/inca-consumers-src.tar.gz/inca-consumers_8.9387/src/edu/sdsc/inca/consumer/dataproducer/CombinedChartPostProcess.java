package edu.sdsc.inca.consumer.dataproducer;

import de.laures.cewolf.ChartPostProcessor;
import edu.sdsc.inca.util.StringMethods;
import org.apache.log4j.Logger;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.plot.CombinedDomainXYPlot;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;

import java.util.List;
import java.util.Map;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Pattern;

/**
 * A post-processor for an XY cewolf chart
 *
 * Example call from JSP:
 *
 * <cewolf:chartpostprocessor id="postprocess">
 *   <cewolf:param name="xmin" value="<%=xmin%>"/>
 *   <cewolf:param name="xmax" value="<%=xmax%>"/>
 *   <cewolf:param name="ymin" value="<%=ymin%>"/>
 *   <cewolf:param name="ymax" value="<%=ymax%>"/>
 *   <cewolf:param name="ytick" value="<%=ytick%>"/>
 * </cewolf:chartpostprocessor>
 *
 * @author Kate Ericson
 */

public class CombinedChartPostProcess implements ChartPostProcessor {
  private static Logger logger = Logger.getLogger(CombinedChartPostProcess.class);

  public void processChart(Object chart, Map params) {
    try {
      CombinedDomainXYPlot plot = (CombinedDomainXYPlot)
        ((JFreeChart) chart).getXYPlot();
      List subplots = plot.getSubplots();
      for ( int i = 0; i < subplots.size(); i++ ) {
        XYPlot subplot = (XYPlot)subplots.get(i);

        // show filled shapes at each data point.
        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
        renderer.setShapesVisible(true);
        renderer.setShapesFilled(true);
        subplot.setRenderer( renderer );

        // format xaxis date and max/min values
        DateAxis xaxis = (DateAxis)subplot.getDomainAxis();
        xaxis.setVerticalTickLabels( true );
        String xmin = (String)params.get("xmin");
        String xmax = (String)params.get("xmax");
        String dateformat = "MMddyy";
        String regex = "\\d{6}";
        if (xmin != null && Pattern.matches(regex, xmin)){
          xaxis.setMinimumDate(StringMethods.convertDateString(xmin, dateformat));
        }
        if (xmax != null && Pattern.matches(regex, xmax)){
          // roll the end date by 1 day so data shows better          
          Date endDate = StringMethods.convertDateString(xmax, dateformat);
          Calendar cal = Calendar.getInstance();
          cal.setTime( endDate );
          cal.add( Calendar.DATE, 1 );
          xaxis.setMaximumDate( cal.getTime() );
        }
        TimeSeriesPostProcess.formatDateTicks(xaxis);

        // format yaxis max/min values
        NumberAxis yaxis = (NumberAxis)subplot.getRangeAxis();
        String ymin = (String)params.get("ymin");
        String ymax = (String)params.get("ymax");
        String ytick = (String)params.get("ytick");
        if (ymin != null){
          yaxis.setLowerBound(Double.parseDouble(ymin));
        }
        if (ymax != null){
          yaxis.setUpperBound(Double.parseDouble(ymax));
        }

        // set number between yaxis tick marks
        NumberTickUnit tick = new NumberTickUnit(Double.parseDouble(ytick));
        yaxis.setTickUnit(tick);
      }
    } catch (Throwable t) {
      t.printStackTrace();
    }
  }



}
