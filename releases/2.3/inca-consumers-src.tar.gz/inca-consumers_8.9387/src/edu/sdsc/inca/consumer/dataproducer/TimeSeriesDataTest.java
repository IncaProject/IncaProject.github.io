package edu.sdsc.inca.consumer.dataproducer;

import junit.framework.TestCase;
import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;
import edu.sdsc.inca.dataModel.graphSeries.GraphInstance;
import edu.sdsc.inca.dataModel.graphSeries.GraphSeries;
import edu.sdsc.inca.util.StringMethods;

import java.util.Date;
import java.util.Calendar;

/**
 * Created by IntelliJ IDEA.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class TimeSeriesDataTest extends TestCase {
  private static Logger log = Logger.getLogger( TimeSeriesDataTest.class );


  public void testConvertDate() throws Exception {
    String[] xml = {
        "    <object>\n" +
            "      <instanceId>15</instanceId>\n" +
            "      <collected>2007-10-16 18:41:03.0</collected>\n" +
            "      <exit_status>true</exit_status>\n" +
            "      <exit_message></exit_message>\n" +
            "      <comparisonResult></comparisonResult>\n" +
            "    </object>\n",

        "    <object>\n" +
            "      <instanceId>43</instanceId>\n" +
            "      <collected>2007-10-16 18:51:02.0</collected>\n" +
            "      <exit_status>true</exit_status>\n" +
            "      <exit_message></exit_message>\n" +
            "      <comparisonResult></comparisonResult>\n" +
            "    </object>\n",

        "    <object>\n" +
            "      <instanceId>75</instanceId>\n" +
            "      <collected>2007-10-16 19:01:03.0</collected>\n" +
            "      <exit_status>true</exit_status>\n" +
            "      <exit_message></exit_message>\n" +
            "      <comparisonResult></comparisonResult>\n" +
            "    </object>" };
    for ( int i = 0; i < xml.length; i++ ) {
      GraphSeries gs = GraphSeries.Factory.newInstance();
      try {
        gs.set( GraphSeries.Factory.parse( xml[i].trim() ) );
        GraphInstance gi = gs.getObject();
        Date date = StringMethods.convertDateString(gi.getCollected(),
            "yyyy-MM-dd HH:mm:ss.S");
        System.out.println( "TIME: " + date);
      } catch ( XmlException e ) {
        System.out.println( "Unable to parse graphInstance " + e );
      }
    }

  }
}
