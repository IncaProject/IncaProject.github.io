package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;

import org.apache.log4j.Logger;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.consumer.Queries;

/**
 * Jsp tag to add a named query to the Inca data consumer.
 * Required parameter: name, hql
 * Optional parameter: period
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class AddQuery extends TagSupport {
  private static Logger logger = Logger.getLogger( AddQuery.class );
  private String hql = null;
  private String name = null;
  private int period = 0;

  public int doEndTag(){
    return EVAL_PAGE;
  }

  /**
   * Called when the jsp tag is referenced in a JSP document.
   * Will return XML HQL query results or an error
   * (expressed in XML -- &lt;error&gt;...&lt;/error&gt;)
   *
   * @return SKIP_BODY as required
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {
    if ( this.getHql() == null ) {
      pageContext.setAttribute(this.getVar(), "Missing hql attribute");
      return SKIP_BODY;
    } else if ( this.getName() == null ){
      pageContext.setAttribute(this.getVar(),"Missing name attribute");
      return SKIP_BODY;
    }

    Queries queries = Consumer.getGlobalConsumer().getQueries();
    if ( queries.hasQuery(this.getName()) ) {
      pageContext.setAttribute
        ( this.getVar(),"Query name '" + this.getName() +
                        "' already taken.  Please choose another name." );
      return SKIP_BODY;
    }
    boolean result = false;
    if ( period > 0 ) {
      result = queries.add( this.getName(), this.getHql(), period );
    } else {
      result = queries.add( this.getName(), this.getHql() );
    }
    pageContext.setAttribute( this.getVar(), Boolean.toString( result ));

    return SKIP_BODY;
  }

  /**
   * Get the query string for the hql (will be called by a jsp page)
   * @return An hql string
   */
  public String getHql() {
    return hql;
  }

  /**
   * Return the name of the query that will be sent to the depot.
   *
   * @return  The name of the query whose results will be fetched.
   */
  public String getName() {
    return name;
  }


  /**
   * Return the period.  If period is greater than zero, the query results will
   * be cached; otherwise the query will just be stored.
   *
   * @return  The period in seconds in between prefetching or zero if no
   * prefetching is done.
   */
  public String getPeriod() {
    return Integer.toString( period );
  }

  /**
   * Set the query string for the hql (will be called by a jsp page)
   * @param hql  An hql string
   */
  public void setHql(String hql) {
    this.hql = hql;
  }

  /**
   * Set the name of the query that will be sent to the depot.
   *
   * @param name  The name of the query whose results will be fetched.
   */
  public void setName( String name ) {
    this.name = name;
  }

  /**
   * Return the period.  If period is greater than zero, the query results will
   * be cached; otherwise the query will just be stored.
   *
   * @param period  The period in seconds in between prefetching or zero if no
   * prefetching is done.
   */
  public void setPeriod( String period ) {
    this.period = Integer.parseInt( period );;
  }
}
