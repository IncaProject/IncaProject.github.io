package edu.sdsc.inca.consumer;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;
import edu.sdsc.inca.statusReport.StatusReportDocument;
import edu.sdsc.inca.statusReport.Series;
import edu.sdsc.inca.util.XmlWrapper;

/**
 * Convenience class for getting data from status report xml
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class StatusReport extends XmlWrapper {
  private static Logger logger = Logger.getLogger(StatusReport.class);
  private StatusReportDocument doc;

  /**
   * Create a wrapper class for StatusReport xml
   *
   * @param xml  A string containing XML complying to the Status Report schema
   *
   * @throws XmlException if problem reading xml
   */
  public StatusReport( String xml ) throws XmlException {
    this.doc = StatusReportDocument.Factory.parse( xml );
    validate( this.doc ); 
  }

  /**
   * Get the number of graph rows to create
   *
   * @return  The number of graph rows
   */
  public int getGraphCount() {
    return doc.getStatusReport().getGraphArray().length;
  }

  /**
   * Get the height for the graphs
   *
   * @return  the height to use on the graphs
   */
  public int getHeight( ) {
    return doc.getStatusReport().getHeight().intValue();
  }
  
  /**
   * Get the number of series that should be created in the ith graph.
   *
   * @param graphId  The ith graph number
   *
   * @return  the number of series for a graph
   */
  public int getSeriesCount( int graphId ) {
    return doc.getStatusReport().getGraphArray(graphId).getSeriesArray().length;
  }

  /**
   * Return the series labels for the ith graph
   *
   * @param graphId   the ith graph id
   *
   * @return  an array of series labels
   */
  public String[] getSeriesLabels( int graphId ) {
    Series[] series =
      doc.getStatusReport().getGraphArray(graphId).getSeriesArray();
    String[] labels = new String[series.length];
    for ( int i = 0; i < series.length; i++ ) {
      labels[i] = series[i].getLabel();
    }
    return labels;
  }

  /**
   * Get the list of series nicknames for the ith graph.
   *
   * @param graphId The ith graph id
   *
   * @return  An array of series nicknames for the graph row
   */
  public String[] getSeriesNicknames( int graphId ) {
    Series[] series =
      doc.getStatusReport().getGraphArray(graphId).getSeriesArray();
    String[] nicknames = new String[series.length];
    for ( int i = 0; i < series.length; i++ ) {
      nicknames[i] = series[i].getNickname();
    }
    return nicknames;
  }

  /**
   * Get the list of series resource names for the ith graph row
   *
   * @param graphId  The ith graph row id
   *
   * @return  an array of series resource names
   */
  public String[] getSeriesResources( int graphId ) {
    Series[] series =
      doc.getStatusReport().getGraphArray(graphId).getSeriesArray();
    String[] resources = new String[series.length];
    for ( int i = 0; i < series.length; i++ ) {
      resources[i] = series[i].getResource();
    }
    return resources;
  }

  /**
   * Get the title to use for the graph row
   *
   * @param graphId  The ith graph id
   *
   * @return  The title to use for the graph row
   */
  public String getSeriesTitle( int graphId ) {
    return doc.getStatusReport().getGraphArray(graphId).getTitle();
  }

  /**
   * Get the width for the graphs
   *
   * @return The width to use on the graphs.
   */
  public int getWidth( ) {
    return doc.getStatusReport().getWidth().intValue();
  }

}
