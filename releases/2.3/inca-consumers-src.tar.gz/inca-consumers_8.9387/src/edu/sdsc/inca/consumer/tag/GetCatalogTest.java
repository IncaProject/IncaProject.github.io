package edu.sdsc.inca.consumer.tag;

import junit.framework.TestCase;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.ConsumerTest;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.util.ConfigProperties;
import edu.sdsc.inca.util.Constants;

import org.apache.log4j.Logger;

import java.net.InetAddress;
import java.util.regex.Pattern;

/*
*
*  Test class for GetCatalog jsp tag
*
* @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
*/

public class GetCatalogTest extends TestCase {
  private static Logger logger = Logger.getLogger(GetCatalogTest.class);

  public void testGetCatalog() throws Exception {
    ConsumerTest.ConsumerTester tester = new ConsumerTest.ConsumerTester(2, 1);
    try {
      tester.start();
      GetCatalog catalog = new GetCatalog();
      String catalogXml = catalog.getCatalog();
      assertNotNull( "result returned", catalogXml );
      logger.info( catalogXml );
      assertTrue(
        "path found",
        Pattern.compile("<name>name</name>").matcher(catalogXml).find()
      );
    } finally {
      tester.stop();
    }
  }
}
