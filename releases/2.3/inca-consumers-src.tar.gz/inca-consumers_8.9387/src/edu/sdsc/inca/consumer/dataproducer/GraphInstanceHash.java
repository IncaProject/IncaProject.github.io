package edu.sdsc.inca.consumer.dataproducer;

import edu.sdsc.inca.consumer.tag.QueryHQL;
import edu.sdsc.inca.consumer.tag.Util;
import edu.sdsc.inca.dataModel.graphSeries.GraphSeries;
import edu.sdsc.inca.dataModel.graphSeries.GraphInstance;
import edu.sdsc.inca.util.XmlWrapper;
import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;
import java.util.Calendar;
import java.util.regex.Pattern;


public class GraphInstanceHash extends Hashtable {

  public static final int TOOLTIP_MAX_STRING_LENGTH = 120;
  private static Logger logger = Logger.getLogger(TimeSeriesData.class);
  private String[] testNames;
  private String[] resourceNames;

  /**
   * Get a hashtable of configIDs and their corresponding
   * GraphInstance objects, one for each instance in the configID's history.
   *
   * @param testNames       An array of series nicknames that will be
   *                        used to query the depot.
   *
   * @param resourceNames   An array of resource names that will be
   *                        used to query the depot.
   *
   * @param startDate       A start date to limit the earliest data
   *                        returned from the depot.
   *
   * @param endDate         An end date to limit the latest data
   *                        returned from the depot.
   */
  public GraphInstanceHash(String[] testNames, String[] resourceNames,
                           Date startDate, Date endDate){
    this.testNames = testNames;
    this.resourceNames = resourceNames;
    for (int i=0; i < testNames.length; i++){
      String test = testNames[i];
      String resource = resourceNames[i];
      Vector gis = getGraphInstances(test,resource,startDate,endDate);
      put(test, resource, gis);
    }
  }

  /**
   * Return a list of series test names
   *
   * @return  a list of series test names
   */
  public String[] getTestNames() {
    return testNames;
  }

  /**
   * Return a list of series resource names
   *
   * @return a list of series resource names
   */
  public String[] getResourceNames() {
    return resourceNames;
  }

  /**
   * Format text for a tooltip (jfreechart doesn't like ' or long  strings.
   * We also take out \n to make it easier to see.
   *
   * @param tooltipText  A string to use for a tooltip text.
   *
   * @return  A formatted tooltip string that can be used with jfreechart.
   */
  public static String formatStringAsTooltip( String tooltipText ) {
    String newTooltipText = XmlWrapper.escape( tooltipText );
    newTooltipText = newTooltipText.replaceAll("\n","").replaceAll("'", "");
    if ( newTooltipText.length() > TOOLTIP_MAX_STRING_LENGTH ) {
      newTooltipText = newTooltipText.substring(0, TOOLTIP_MAX_STRING_LENGTH);
    }
    return newTooltipText;
  }

  /**
   * Get hash value with test/resource key
   *
   * @param test      Test name for hash key
   *
   * @param resource  Resource name for hash key
   *
   * @return vector of GraphInstance containing instances for the particular
   * test/resource pair
   */
  public Vector get(String test, String resource){
    return (Vector)this.get(test+","+resource);
  }

  /**
   * Get GraphInstance objects for a test and resource.  Do the query in
   * 2 parts.  The first query grabs all of the instances for a test/resource
   * pair.  Then a second query grabs all of the comparison results and matches
   * them with the correct instances.  This is better than doing an extra join.
   *
   * @param testName        Series nickname used to query the depot.
   *
   * @param resourceName    Resource name used to query the depot.
   *
   * @param startDate       A start date to limit the earliest data
   *                        returned from the depot.
   *
   * @param endDate         An end date to limit the latest data
   *                        returned from the depot.
   *
   * @return gs             An vector of GraphInstance objects,
   *                        one for each instance in the test's history.
   */
  private Vector getGraphInstances( String testName, String resourceName,
                                    Date startDate, Date endDate) {

    // to get the query to be inclusive of the end date, we add 1 day
    SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
    String query =
        "SELECT ii.id as instanceId, " +
            "   r.id as reportId, " +
            "   sc.id as configId, " +
            "   ii.collected as collected, " +
            "   r.exit_status as exit_status, " +
            "   r.exit_message as exit_message " +
            "FROM SeriesConfig sc, " +
            "     Report r, " +
            "     InstanceInfo ii " +
            "WHERE r.series.id = sc.series.id AND " +
            "      ii.reportId = r.id AND " +
            "      sc.nickname = '" + testName + "' AND " +
            "      sc.series.resource = '" + resourceName + "'";
    String crQuery =
      "SELECT cr.reportId as reportId, cr.result as comparisonResult " +
        "FROM SeriesConfig sc, ComparisonResult cr " +
        "WHERE sc.nickname = '" + testName + "' " +
        "      AND sc.series.resource = '" + resourceName + "' " +
        "      AND cr.seriesConfigId = sc.id";
    if (startDate != null){
      query += " AND ii.collected >= '" + fmt.format(startDate) + "' ";
    }
    if (endDate != null){
      Calendar cal = Calendar.getInstance();
      cal.setTime( endDate );
      cal.add( Calendar.DATE, 1 );
      endDate = cal.getTime();      
      query += " AND ii.collected <= '" + fmt.format(endDate) + "' ";
    }
    query += " ORDER BY ii.collected";

    logger.debug( "GRAPH: starting queryHQL");
    long queryHqlTime;
    String[] results = new String[0];
    String[] crs = new String[0];
    try {
      queryHqlTime = Util.getTimeNow();
      results = QueryHQL.queryDepot(query);
      crs = QueryHQL.queryDepot(crQuery);
      Util.printElapsedTime( queryHqlTime, "GRAPH: queryHQL" );
    } catch (Exception c){
      logger.warn( "Problem querying depot: " + c );
    }
    Hashtable crsByReportId = new Hashtable();
    for ( int i = 0; i < crs.length; i++ ) {
      try {
        GraphSeries gs = GraphSeries.Factory.parse( crs[i].trim() );
        crsByReportId.put( gs.getObject().getReportId(),
                           gs.getObject().getComparisonResult() );
      } catch ( XmlException e ) {
        logger.error( "Unable to parse CR " + e );
      }
    }
    Vector gis = new Vector();
    queryHqlTime = Util.getTimeNow();
    for ( int i = 0; i < results.length; i++ ) {
      GraphSeries gs = GraphSeries.Factory.newInstance();
      try {
        gs.set( GraphSeries.Factory.parse( results[i].trim() ) );        
        String result = (String)crsByReportId.get(gs.getObject().getReportId());
        gs.getObject().setComparisonResult( result == null ? "" : result );
        gis.add( gs.getObject() );
      } catch ( XmlException e ) {
        logger.debug( "Unable to parse graphInstance " + e );
      }
    }
    logger.debug( "GRAPH: Returning " + gis.size() + " instances" );
    Util.printElapsedTime( queryHqlTime, "GRAPH: parse HQL" );
    return gis;
  }

  /**
   * Determine pass/fail status for a test based on error message and
   * comparison result.
   *
   * @param gi  A single test result.
   *
   * @return  True if completed is true of the comparison result is Success.
   * False if comparison is Failure or completed is false.
   */
  static public boolean getResult( GraphInstance gi ) {
    boolean result;
    String cr = gi.getComparisonResult();
    String pass = "^Success.*$";
    String fail = "^Failure.*$";
    if (cr != null && Pattern.matches(pass, cr)){
      result = true;
    }else if (cr != null && Pattern.matches(fail, cr)){
      result = false;
    }else{
      result = gi.getExitStatus();
    }
    return result;
  }

  /**
   * Set hash value with test/resource key
   *
   * @param test      Test name for hash key
   *
   * @param resource  Resource name for hash key
   *
   * @param gis     Vector of GraphInstance objects for hash value
   */
  public void put(String test, String resource, Vector gis){
    this.put(test+","+resource, gis);
  }

}
