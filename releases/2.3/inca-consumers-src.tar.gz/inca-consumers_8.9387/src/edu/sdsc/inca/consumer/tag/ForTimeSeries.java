package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;
import org.apache.log4j.Logger;

import edu.sdsc.inca.consumer.dataproducer.GraphInstanceHash;
import edu.sdsc.inca.consumer.dataproducer.TimeSeriesData;

/**
 * Create individual TimeSeriesData objects from GraphInstanceHash object to
 * be used in a combo time series.
 *
 * Required params:
 *
 * data   The name of the GraphInstanceHash object to draw data from
 *
 * labels The labels to use for the series data
 *
 * var    the name of the variable that the new TimeSeriesData will be
 *        placed
 *
 * yaxisLabel  The label to use on the middle graph (so it doesn't overlap)
 *
 * yaxisLabelVar   Will be blank for some graphs but will be the value of
 *                 yaxisLabel so that seems like it applies to all graphs.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class ForTimeSeries extends TagSupport {
  private static Logger logger = Logger.getLogger(GetCatalog.class);
  private String data = null;
  private String labels = null;
  private int iterator = 0;
  private int numSeries = 0;
  private String yaxisLabel = null;
  private String yaxisLabelVar = null;

  /**
   * For each series in GraphInstanceHash, do a for loop over each series
   * and create GraphInstanceHash that can be used in a combo plot.
   * @return EVAL_BODY_INCLUDE
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {
    if ( this.getVar() == null ){
      pageContext.setAttribute(
        "suite",
        "<error>Missing return attribute name</error>"
      );
      return SKIP_BODY;
    }
    iterator = 0;
    if ( setTimeSeries() ) {
      return EVAL_BODY_INCLUDE;
    } else {
      return SKIP_BODY;

    }
  }

  /**
   * Iterate through the time series
   *
   * @return  EVAL_BODY_AGAIN if there is more to iterate on or SKIP_BODY if
   *          done
   *
   * @throws JspTagException If trouble iterating thru the time series
   */
  public int doAfterBody() throws JspTagException {
    if ( setTimeSeries() ) {
      return EVAL_BODY_AGAIN;
    } else {
      return SKIP_BODY;
    }
  }

  /**
   * Get the series data to use in this time series object
   *
   * @return a GraphInstanceHash object
   */
  public String getData() {
    return data;
  }

  /**
   * The list of labels in the series.
   *
   * @return An array of labels
   */
  public String getLabels() {
    return labels;
  }

  /**
   * Set the value of the yaxis label
   *
   * @return  the label to you on the yaxis
   */
  public String getYaxisLabel() {
    return yaxisLabel;
  }

  /**
   * Set a variable of whether the label should be put on this plot.  Blank
   * will mean the label will be placed on another plot and a string means
   * the yaxislabel should be places on this plot
   *
   * @return  The name of the attribute to set the yaxis label value
   */
  public String getYaxisLabelVar() {
    return yaxisLabelVar;
  }

  /**
   * Set the data to draw data from.
   *
   * @param data  A GraphInstanceHash object
   */
  public void setData(String data) {
    this.data = data;
  }

  /**
   * Set the labels to use on the series.
   *
   * @param labels  An array of labels.
   */
  public void setLabels(String labels) {
    this.labels = labels;
  }

  /**
   * Set the label to use on the yaxis.
   *
   * @param yaxisLabel  A string to use on the yaxis for one of the plots
   */
  public void setYaxisLabel(String yaxisLabel) {
    this.yaxisLabel = yaxisLabel;
  }

  /**
   * Set the name of the variable to use for storing the yaxis label
   *
   * @param yaxisLabelVar  A string to use for the yaxis label
   */
  public void setYaxisLabelVar(String yaxisLabelVar) {
    this.yaxisLabelVar = yaxisLabelVar;
  }

  /* PRIVATE FUNCTIONS */

  /**
   * Create a TimeSeriesData object for the current iteration
   *
   * @return  True if this is the last series or false if there are more to
   * iterate on.
   */
  private boolean setTimeSeries() {
    GraphInstanceHash instances =
      (GraphInstanceHash)pageContext.getAttribute( this.getData() );
    this.numSeries = instances.getTestNames().length;
    if ( iterator >= this.numSeries ) {
      return false;
    }

    String[] testNames = instances.getTestNames();
    String[] resourceNames = instances.getResourceNames();
    String[] labels = (String[])pageContext.getAttribute( this.getLabels() );

    TimeSeriesData timeSeries = new TimeSeriesData( instances );
    timeSeries.setTestNames( new String[] {testNames[iterator]} );
    timeSeries.setResourceNames( new String[] {resourceNames[iterator]} );
    timeSeries.setSeriesLabels( new String[]{ labels[iterator] } );
    timeSeries.createTimeSeriesCollection();
    pageContext.setAttribute( this.getVar(), timeSeries);
    if ( iterator == this.numSeries/2 ) {
      pageContext.setAttribute
        ( this.getYaxisLabelVar(), this.getYaxisLabel() );
    } else {
      pageContext.setAttribute( this.getYaxisLabelVar(), "" );
    }
    iterator++;
    return true;
  }

}