package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;

import org.apache.log4j.Logger;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.consumer.Queries;

/**
 * Jsp tag to list the stored queries in the Inca data consumer.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class ListQueries extends TagSupport {
  private static Logger logger = Logger.getLogger( ListQueries.class );

  public int doEndTag(){
    return EVAL_PAGE;
  }

  /**
   * Called when the jsp tag is referenced in a JSP document.
   * Will return XML query store document or an error
   * (expressed in XML -- &lt;error&gt;...&lt;/error&gt;)
   *
   * @return SKIP_BODY as required
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {
    if ( this.getVar() == null ){
      pageContext.setAttribute(
        "resources",
        "<error>Missing return attribute name</error>"
      );
      return SKIP_BODY;
    }

    Queries queries = Consumer.getGlobalConsumer().getQueries();
    if ( queries == null ) {
      pageContext.setAttribute
         (this.getVar(), "<error>Unable to get queries object</error>");

    }
    pageContext.setAttribute
      ( this.getVar(), queries.listXml() );

    return SKIP_BODY;
  }
}