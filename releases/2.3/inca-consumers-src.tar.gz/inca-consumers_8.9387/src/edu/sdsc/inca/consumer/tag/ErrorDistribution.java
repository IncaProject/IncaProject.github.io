package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;
import org.apache.log4j.Logger;

import edu.sdsc.inca.consumer.dataproducer.ErrorDistributionData;
import edu.sdsc.inca.consumer.dataproducer.GraphInstanceHash;

/**
 * Create a ErrorDistributionData object from GraphInstanceHash object.
 *
 * Required params:
 *
 * data   The name of the GraphInstanceHash object to draw data from
 *
 * labels The labels to use for the series data
 *
 * var    the name of the variable that the new ErrorDistributionData will be
 *        placed
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class ErrorDistribution extends TagSupport {
  private static Logger logger = Logger.getLogger(GetCatalog.class);
  private String data = null;
  private String labels = null;

  /**
   * Creates a ErrorDistributionData data object that can be used in graphs
   *
   * @return SKIP_BODY
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {
    if ( this.getVar() == null ){
      pageContext.setAttribute(
        "suite",
        "<error>Missing return attribute name</error>"
      );
      return SKIP_BODY;
    }

    GraphInstanceHash instances =
      (GraphInstanceHash)pageContext.getAttribute( this.getData() );
    ErrorDistributionData errorDist = new ErrorDistributionData();
    errorDist.setGraphInstances(instances);
    errorDist.setSeriesLabels
      ( (String[])pageContext.getAttribute( this.getLabels() ));
    errorDist.createDataset();
    pageContext.setAttribute( this.getVar(), errorDist);

    return SKIP_BODY;
  }

  /**
   * Get the series data to use in this error distribution object
   *
   * @return a GraphInstanceHash object
   */
  public String getData() {
    return data;
  }

  /**
   * The list of labels in the series.
   *
   * @return An array of labels
   */
  public String getLabels() {
    return labels;
  }

  /**
   * Set the data to draw data from.
   *
   * @param data  A GraphInstanceHash object
   */
  public void setData(String data) {
    this.data = data;
  }

  /**
   * Set the labels to use on the series.
   *
   * @param labels  An array of labels.
   */
  public void setLabels(String labels) {
    this.labels = labels;
  }
}