package edu.sdsc.inca.consumer;

import org.apache.log4j.Logger;

import java.util.Hashtable;
import java.io.IOException;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.DepotClient;
import edu.sdsc.inca.AgentClient;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.consumer.tag.Util;

/**
 * Thread used to periodically download the latest suites from the depot and
 * cache them. Suites can then be retrieved directly from the cache without
 * contacting the depot (and thus reduce the load time for a web page).
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class SuiteCache extends Thread {
  private static Logger logger = Logger.getLogger( SuiteCache.class );

  private Hashtable suites = new Hashtable();  // used to cache the suites

  /**
   * Create a new SuiteCache object.
   */
  public SuiteCache() {
  }

  /**
   * Return the specified cached suite document with a maximum wait time.
   *
   * @param name   The name of the suite to fetch from the configured depot.
   * @param maxWait The maximum time in milliseconds to wait for the specified
   *                suite to be initially loaded into the cache.
   *
   * @return  An array of report summaries or null if the maxWait is exceeded
   */
  public synchronized String[] getSuite( String name, int maxWait ) {
    // get uri of agent client to create guid -- agent client resolves localhost
    AgentClient agentClient = new AgentClient();
    try {
      agentClient.setConfiguration
        ( Consumer.getGlobalConsumer().getClientConfiguration() );
    } catch ( ConfigurationException e ) {
      logger.error( "Unable to retrieve agent uri" );
      return null;
    }
    String guid = agentClient.getUri() + "/" + name;

    long startTime = Util.getTimeNow();
    try {
      Object result = null;
      // we will be notified every time a new suite is loaded into the cache
      // so when notified, we check to see if it's the one we're waiting for.
      // If not, we continue to wait (if we haven't exceeded the maxWait yet).
      while( Util.getTimeNow() - startTime <= maxWait ) {
        result = suites.get( guid );
        if ( result == null ) {
          long thisMaxWait = maxWait - (Util.getTimeNow() - startTime);
          logger.debug(
            "Waiting for suite " + guid + " to load; maxWait " + thisMaxWait
          );
          this.wait( thisMaxWait );
        } else {
          break;
        }
      }
      return result == null ? null : (String[])result;
    } catch ( InterruptedException e ) {
      logger.warn( "Interrupted while waiting to get suite " + name );
      return null;
    }
  }

  /**
   * The functionality of the thread.  Periodically, will fetch the list of
   * suite names from the depot.  For each suite name, will then fetch suite xml
   * from the depot and cache in hashtable suites.  Will use the configured
   * cache reload period to wait in between iterations.
   */
  public void run() {
    logger.info( "Starting cache thread for suites" );
    while ( true ) {
      try {
        querySuites();
        logger.debug(
          "Suite cache thread sleeping " +
          Consumer.getGlobalConsumer().getCacheReloadPeriod() + " millis"
        );
      } catch ( Exception e ) {
        logger.error( "Unable to retrieve suites", e );
      } finally {
        try {
          Thread.sleep( Consumer.getGlobalConsumer().getCacheReloadPeriod() );
        } catch ( InterruptedException e ) {
          logger.info( "Interrupting cache thread for suites" );
          break;
        }

      }
    }
    logger.info( "Exitting cache thread for suites" );
  }

  // Private Functions

  /**
   * Will first fetch the list of suite names from the depot.  For each suite
   * name, will then fetch suite xml from the depot and cache in hashtable
   * suites.
   *
   * @throws ConfigurationException
   * @throws IOException
   * @throws ProtocolException
   */
  private void querySuites()
    throws ConfigurationException, IOException, ProtocolException {

    String[] results = new String[0];
    String[] guids = new String[0];
    // because the depot client is global in the consumer and because tags such
    // as GetInstance also query the depot, we need to synchronize our use of
    // the depot client so that our communications don't interfere with each
    // other.
    DepotClient depotClient = new DepotClient();
    depotClient.setConfiguration
      ( Consumer.getGlobalConsumer().getClientConfiguration() );
    long totalStartTime = Util.getTimeNow();
    long startTime = Util.getTimeNow();
    logger.info( "Contacting depot " + depotClient.getUri() );
    depotClient.connect();
    Util.printElapsedTime( startTime, "query connect" );
    guids = depotClient.queryGuids();
    for ( int i = 0; i < guids.length; i++ ) {
      if ( Consumer.IMMEDIATE_PATTERN.matcher(guids[i]).find() ) continue;
      logger.info( "Query suite " + guids[i] );
      startTime = Util.getTimeNow();
      results = depotClient.querySuite( guids[i] );
      Util.printElapsedTime( startTime, "query depot" );
      logger.info(
        "Suite query for " + guids[i] + ": " + results.length +
        " results returned"
      );
      if ( results != null ) {
        synchronized( this ) {
          logger.debug( "Updating cache for suite " + guids[i] );
          suites.put( guids[i], results );
          this.notifyAll(); // in case anybody is waiting for this suite to load
        }
      } else {
        logger.error( "Received a null suite" );
      }
    }
    depotClient.close();
    Util.printElapsedTime( totalStartTime, "total query depot" );

  }


}
