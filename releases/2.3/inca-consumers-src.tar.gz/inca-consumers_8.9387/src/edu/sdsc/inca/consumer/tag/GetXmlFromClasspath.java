package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;
import org.apache.log4j.Logger;

import java.io.IOException;


/**
 * Jsp tag that will locate a XML file from the classpath and return its
 * contents
 *
 * @author Shava Smallen
 */
public class GetXmlFromClasspath extends TagSupport {
  Logger logger = Logger.getLogger(GetXmlFromClasspath.class);

  private String xmlFile;

  /**
   * Called when the jsp tag is referenced in a JSP document.  Will return
   * a software stack status xml document or an error (expressed in XML --
   * &lt;error&gt;...&lt;/error&gt;)
   *
   * @return SKIP_BODY as required
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {

    if ( this.getVar() == null ){
      pageContext.setAttribute(
        "xml",
        "<error>Missing return attribute name</error>"
      );
      return SKIP_BODY;
    }

    if ( this.xmlFile == null ){
      pageContext.setAttribute(
        this.getVar(),
        "<error>Missing xml filename</error>"
      );
      return SKIP_BODY;
    }

    try {
      long startTime = Util.getTimeNow();
      pageContext.setAttribute(
        this.getVar(),
        Util.getXMLFromClasspath(this.xmlFile)
      );
      Util.printElapsedTime( startTime, "GetXmlFromClasspath" );
    } catch ( IOException e ) {
      String error =
        "<error>Unable to retrieve xml file " + this.xmlFile +
        " from classpath: " + e + "</error>";
      pageContext.setAttribute( this.getVar(), error );
    }

    return SKIP_BODY;
  }

 /**
   * Return the name of the xml file that will be searched for in the classpath
   * and returned with the software stack status xml file.
   *
   * @return The name of a xml file expected to be found in the classpath.
   */
  public String getXmlFile() {
    return xmlFile;
  }


  /**
   * Set the name of the xml file that will be searched for in the classpath
   * and returned with the software stack status xml file.
   *
   * @param xmlFile The name of a xml file expected to be found in the
   * classpath.
   */
  public void setXmlFile(String xmlFile) {
    this.xmlFile = xmlFile;
  }
}
