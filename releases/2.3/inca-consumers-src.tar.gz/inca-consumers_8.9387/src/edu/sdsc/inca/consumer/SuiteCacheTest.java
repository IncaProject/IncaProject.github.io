package edu.sdsc.inca.consumer;

import junit.framework.TestCase;
import org.apache.log4j.Logger;
import edu.sdsc.inca.ConsumerTest;
import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.consumer.tag.Util;
import edu.sdsc.inca.util.Constants;

import java.util.Properties;
import java.net.InetAddress;

/**
 * Test the suite cache thread
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class SuiteCacheTest extends TestCase {
  private static Logger logger = Logger.getLogger( SuiteCacheTest.class );

  /**
   * Tests the ability for suites to be loaded into the cache.  First tests
   * timeout feature of getCache and then waits long enough for a successful
   * retrieval.
   * 
   * @throws Exception
   */
  public void testSuiteCache() throws Exception {
    // configure the depot client
    int depotPort = 8998;
    String localhost = InetAddress.getLocalHost().getHostName();
    String agentUri = "inca://" + localhost + ":8999";
    Properties props = new Properties();
    props.setProperty( "depot", "inca://localhost:" + depotPort );
    props.setProperty( "agent", agentUri );
    props.setProperty( "auth", "false" );
    Consumer.getGlobalConsumer().setClientConfiguration( props );

    // configure our mock depot. load it up with 2 suites.
    String xml = Util.getXMLFromClasspath( "reportSummary.xml" );
    String result = xml.replaceAll("<\\?xml.*\\?>", "");
    ConsumerTest.MockDepot depot = new ConsumerTest.MockDepot( 1, depotPort );
    depot.addSuite(
      agentUri + "/TestSuiteLocal2",
      Util.suiteToSummaries( result ),
      1 * Constants.MILLIS_TO_SECOND
    );
    depot.addSuite(
      agentUri + "/TestSuiteLocal1",
      Util.suiteToSummaries( result ),
      10 * Constants.MILLIS_TO_SECOND
    );
    depot.start();

    // create a suite cache and start it
    SuiteCache cache = new SuiteCache();
    cache.start();

    // test the timeout feature, TestSuiteLocal1 should load after 11 seconds
    // so we should timeout after 5 seconds
    long startTime = Util.getTimeNow();
    String[] suite = cache.getSuite( "TestSuiteLocal1", 5 * Constants.MILLIS_TO_SECOND );
    assertTrue( "timed out after 5 seconds", Util.getTimeNow() - startTime < (7 * Constants.MILLIS_TO_SECOND) );
    assertNull( "suite is null when timeout", suite );

    // at least 5 seconds have passed, sleep another 10 seconds and now
    // TestSuiteLocal should be there.
    Thread.sleep(10*Constants.MILLIS_TO_SECOND);
    suite = cache.getSuite( "TestSuiteLocal1", 5 * Constants.MILLIS_TO_SECOND );
    assertNotNull( "suite is null when timeout", suite );

    // cleanup
    cache.interrupt();
    cache.join();
    depot.interrupt();
    depot.join();

  }
}
