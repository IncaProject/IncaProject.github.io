package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;

import org.apache.log4j.Logger;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.consumer.Queries;

/**
 * Jsp tag to change a named query to the Inca data consumer.
 * Required parameter: newName, oldName, hql
 * Optional parameter: period
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class ChangeQuery extends TagSupport {
  private static Logger logger = Logger.getLogger( ChangeQuery.class );
  private String hql = null;
  private String oldName = null;
  private String newName = null;
  private int period = 0;

  public int doEndTag(){
    return EVAL_PAGE;
  }

  /**
   * Called when the jsp tag is referenced in a JSP document.
   * Will return string containing true if change is successful or an error
   * in the supplied var attribute.
   *
   * @return SKIP_BODY as required
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {
    if ( this.getHql() == null ) {
      pageContext.setAttribute(this.getVar(), "Missing hql attribute");
      return SKIP_BODY;
    } else if ( this.getOldName() == null ){
      pageContext.setAttribute(this.getVar(),"Missing oldName attribute");
      return SKIP_BODY;
    } else if ( this.getNewName() == null ){
      pageContext.setAttribute(this.getVar(),"Missing newName attribute");
      return SKIP_BODY;
    }

    Queries queries = Consumer.getGlobalConsumer().getQueries();
    if ( ! queries.hasQuery(this.getOldName()) ) {
      pageContext.setAttribute
        ( this.getVar(),"Query '" + this.getOldName() + "' does not exist" );
      return SKIP_BODY;
    }
    boolean result = false;
    if ( ! queries.delete(this.getOldName()) ) {
      pageContext.setAttribute
        ( this.getVar(),"Unable to delete '" + this.getOldName() + "'" );
      return SKIP_BODY;
    }
    if ( period > 0 ) {
      result = queries.add( this.getNewName(), this.getHql(), period );
    } else {
      result = queries.add( this.getNewName(), this.getHql() );
    }
    pageContext.setAttribute( this.getVar(), Boolean.toString( result ));

    return SKIP_BODY;
  }

  /**
   * Get the query string for the hql to be stored.
   * @return An hql string
   */
  public String getHql() {
    return hql;
  }

  /**
   * Return the new name of the stored query.
   *
   * @return  The new name of the stored query.
   */
  public String getNewName() {
    return newName;
  }

  /**
   * Return the name of the stored query that will changed.
   *
   * @return  The name of the query that will be changed.
   */
  public String getOldName() {
    return oldName;
  }


  /**
   * Return the period.  If period is greater than zero, the query results will
   * be cached; otherwise the query will just be stored.
   *
   * @return  The period in seconds in between prefetching or zero if no
   * prefetching is done.
   */
  public String getPeriod() {
    return Integer.toString( period );
  }

  /**
   * Set the query string for the hql (will be called by a jsp page)
   * @param hql  An hql string
   */
  public void setHql(String hql) {
    this.hql = hql;
  }

  /**
   * Set the new name of the stored query.
   *
   * @param newName  The new name of the stored query.
   */
  public void setNewName( String newName ) {
    this.newName = newName;
  }

  /**
   * Set the name of the query that will be sent to the depot.
   *
   * @param oldName  The name of the query whose results will be fetched.
   */
  public void setOldName( String oldName ) {
    this.oldName = oldName;
  }

  /**
   * Return the period.  If period is greater than zero, the query results will
   * be cached; otherwise the query will just be stored.
   *
   * @param period  The period in seconds in between prefetching or zero if no
   * prefetching is done.
   */
  public void setPeriod( String period ) {
    this.period = Integer.parseInt( period );;
  }
}
