package edu.sdsc.inca.consumer.tag;

import junit.framework.TestCase;

import edu.sdsc.inca.ConsumerTest;
import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.util.Constants;

import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.Calendar;


/**
 * Test class for JSP tag GetSuiteLatestInstances
 */
public class GetSuiteLatestInstancesTest extends TestCase {
  private static Logger logger = Logger.getLogger(GetSuiteLatestInstancesTest.class);

  /**
   * Test the ability to retrieve suites from the consumer cache.  The first
   * fetch should timeout and the second should succeed.
   * @throws Exception
   */
  public void testGetSuiteLatestInstances() throws Exception {

    ConsumerTest.ConsumerTester tester = new ConsumerTest.ConsumerTester(1, 1);
    try {

      String xml = Util.getXMLFromClasspath( "reportSummary.xml" );
      String result = xml.replaceAll("<\\?xml.*\\?>", "");
      tester.depot.addSuite(
        tester.agent.getUri() + "/TestSuiteLocal1",
        Util.suiteToSummaries( result ),
        10 * Constants.MILLIS_TO_SECOND
      );
      tester.depot.addSuite(
        tester.agent.getUri() + "/TestSuiteLocal2",
        Util.suiteToSummaries( result ),
        10 * Constants.MILLIS_TO_SECOND
      );
      tester.depot.addSuite(
        tester.agent.getUri() + "/TestSuiteLocal3",
        Util.suiteToSummaries( result ),
        10 * Constants.MILLIS_TO_SECOND
      );
      Consumer.getGlobalConsumer().setCacheMaxWaitPeriod
        ( 25 * Constants.MILLIS_TO_SECOND );

      tester.start();
      // create the jsp tag
      GetSuiteLatestInstances suite = new GetSuiteLatestInstances();
      suite.debug = false; // set to false to query real depot
      suite.setSuiteName( "TestSuiteLocal3" );

      // first fetch should fail because of timeout
      try {
        xml = suite.getSuiteLatestInstances();
        fail( "didn't timeout after 25 seconds" );
      } catch ( IOException e ) {
      }

      // at least 25 seconds have passed; wait another 10 and TestSuiteLocal
      // should be loaded
      Thread.sleep( 10 * Constants.MILLIS_TO_SECOND );
      long startTime = Calendar.getInstance().getTimeInMillis();
      xml = suite.getSuiteLatestInstances();
      logger.debug( "time elapased " + (Calendar.getInstance().getTimeInMillis() - startTime) );
      assertNotNull( "result returned", xml );
      assertEquals( "Equivalent to orig", result.trim(), xml.trim() );
    } finally {
      tester.stop();
    }

  }
}
