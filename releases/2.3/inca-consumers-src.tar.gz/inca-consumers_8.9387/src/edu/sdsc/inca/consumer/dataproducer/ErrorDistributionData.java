package edu.sdsc.inca.consumer.dataproducer;

import de.laures.cewolf.DatasetProduceException;
import de.laures.cewolf.DatasetProducer;
import de.laures.cewolf.tooltips.CategoryToolTipGenerator;
import edu.sdsc.inca.dataModel.graphSeries.GraphInstance;
import org.apache.log4j.Logger;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.servlet.jsp.JspWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.*;
import java.util.regex.Pattern;


/**
 * A dataset producer for graphing error distributions.  A category dataset
 * is created for each test/resource pair and its associated errors and
 * error counts.
 *
 * Example call from JSP:
 *
 * ErrorDistributionData errorDist = new ErrorDistributionData();
 * errorDist.setGraphInstances(hash);
 * errorDist.setTestNames(testNames);
 * errorDist.setResourceNames(resourceNames);
 * errorDist.setSeriesLabels(seriesLabels);
 * errorDist.createDataset();
 * pageContext.setAttribute("errorDist", errorDist);
 * ...
 * <cewolf:data>
 *  <cewolf:producer id="errorDist"/>
 * </cewolf:data>
 *
 * @author  Kate Ericson
 */

public class ErrorDistributionData implements DatasetProducer,
  CategoryToolTipGenerator, Serializable  {

  private GraphInstanceHash graphInstances;
  private DefaultCategoryDataset distribution;
  private String[] allErrorTypes; // holds all unique error messages
  private static Logger logger = Logger.getLogger(ErrorDistributionData.class);
  private String[] resourceNames;
  private String[] seriesLabels;
  private boolean showGraph = false;
  private Vector skipInstances;
  private String[] testNames;

  /**
   * Count the number of errors from a series of test instances.  Also
   * populates global variable allErrorTypes.
   *
   * @param gis An object of GraphInstanceHash containing instances for a
   * particular test/resource pair.
   *
   * @return  An array of hashtables for each series config (test/resource pair)
   * For each hashtable, the keys are the error messages and the values
   * are the number of occurrences of errors.
   */
  public Hashtable[] countErrors( GraphInstanceHash gis ) {

    int numConfigs = testNames.length;
    Hashtable[] errors = new Hashtable[ numConfigs ];

    Integer errorIndex = new Integer( 0 );
    Hashtable errorMap = new Hashtable(); // unique error messages

    for (int i=0; i < numConfigs; i++) {
      errors[i] = new Hashtable();
      String test = testNames[i];
      String resource = resourceNames[i];

      // add GraphInstance data to this configID's errors
      Vector instances = gis.get(test, resource);
      for ( int j=0; j < instances.size(); j++ ) {
        GraphInstance gi = (GraphInstance)instances.get(j);
        if ( ! GraphInstanceHash.getResult(gi) ) {
          String errorMessage = gi.getExitMessage();
          // Error message string should not be empty and the instance id should
          // not appear in skipIinstances
          if ( ! Pattern.matches("^\\s*$", errorMessage) ){
            // Add error the test/resource hash.  If the error message is in the
            // hash already, increment message count.
            if (!errors[i].containsKey(errorMessage)){
              errors[i].put( errorMessage, new Integer(1) );
            } else {
              Integer oldCount = (Integer)errors[i].get(errorMessage);
              int newCount = oldCount.intValue() + 1;
              Integer count = new Integer(newCount);
              errors[i].put(errorMessage, count);
            }
            // Add error to total unique errors and give it a id
            if ( ! errorMap.containsKey(errorMessage) ) {
              errorMap.put( errorMessage, errorIndex );
              errorIndex = new Integer( errorIndex.intValue() + 1 );
            }
          }
        }
      }
    }
    // get columns (error types) for graph; convert errorMap to array
    allErrorTypes = new String[ errorMap.size() ];
    for( Enumeration errIter = errorMap.keys(); errIter.hasMoreElements(); ) {
      String error = (String)errIter.nextElement();
      Integer errIndex = (Integer)errorMap.get( error );
      allErrorTypes[errIndex.intValue()] = error;
    }

    return errors;
  }

  /**
   * Create a jfree category dataset of error counts appropriate to graph.
   * Store the results internally into the member variable collection
   */
  public void createDataset() {
    DefaultCategoryDataset hd = new DefaultCategoryDataset();
    int numConfigs = testNames.length;

    // mouseover and error arrays for graph's image map and table

    Hashtable[] allErrors = countErrors( graphInstances );

    // process GraphInstance data for each test/resource pair
    for (int i=0; i < numConfigs; i++) {
      String test = testNames[i];
      String resource = resourceNames[i];

      Hashtable errors = allErrors[i];

      // If the hash of error messages isn't empty, add it to the distribution.
      for ( int j = 0; j < allErrorTypes.length; j++ ) {
        String error = allErrorTypes[j];
        Integer count;
        if ( errors.containsKey(error) ) {
          setShowGraph(true);          
          count = (Integer)errors.get(error);
        } else {
          count = new Integer( 0 );
        }
        try {
          hd.addValue
            (count.floatValue(), seriesLabels[i], new Integer(j) );
        } catch (Throwable t) {
          logger.error
            ( "Unable to add error count " + count + " for error '" + error +
              "' occurring in " + test + ", "  + resource );
        }
      }
    }

    setDistribution(hd);
  }



  /**
   * Text to display when datapoint is moused over
   *
   * @param data  Jfree CategoryDataset object to add mouseover text to.
   *
   * @param series  Integer for the jfree chart series to add mouseover text to.
   *
   * @param error  Error message for the item to add mouseover text to
   *              (e.g. a error bar).
   *
   * @return  Mouseover text string
   */
  public String generateToolTip(CategoryDataset data, int series, int error) {
   return GraphInstanceHash.formatStringAsTooltip( allErrorTypes[error] );
  }

  /**
   * Get the list of unique errors in a group of series.
   *
   * @return   An array of unique error messages
   */
  public String[] getErrorTypes() {
    return allErrorTypes;
  }
  
  /**
   * Return a hash of configIDs and their associated GraphInstance objects
   * (one for each instance in the configID's history).
   *
   * @return A hash of configIDs and their associated GraphInstance objects.
   */
  public GraphInstanceHash getGraphInstances() {
    return graphInstances;
  }

  /**
   * Return a category dataset of error messages and their frequencies.
   *
   * @return A category dataset of error messages and their frequencies.
   */
  public CategoryDataset getDistribution() {
    return distribution;
  }

  /**
   * Returns a unique ID for this DatasetProducer
   */
  public String getProducerId() {
    return "inca error distribution";
  }

  /**
   * Get a string array of resourceNames (used for ordering the hashtable)
   *
   * @return a list of series resource names
   */
  public String[] getResourceNames() {
    return resourceNames;
  }

  /**
   * Return array of labels used for each configID in the graph legend.
   *
   * @return Array of labels used for each configID in the graph legend.
   */
  public String[] getSeriesLabels() {
    return seriesLabels;
  }

  /**
   * Vector of instanceIDs to exclude from graph.
   *
   * @return An array of instance ids
   */
  public Vector getSkipInstances() {
    return skipInstances;
  }

  /**
   * Get a string array of testNames (used for ordering the hashtable)
   *
   * @return a list of series test names
   */
  public String[] getTestNames() {
    return testNames;
  }

  /**
   * This method influences Cewolf's caching behaviour.
   *
   * Example of invalid data after a day (86,400 seconds):
   *   log.debug(getClass().getName() + "hasExpired()");
   *   return (System.currentTimeMillis() - since.getTime()) > 86400000;
   */
  public boolean hasExpired(Map params, Date since) {
    return true;
  }

  /**
   * Print count of pass/failures and the number of occurrences of failures
   * by series.
   *
   * @param out   a writer to a JSP page
   * @param failData array of failure counts for series
   * @param passData  arrayo of pass counts for series
   *
   * @throws IOException if trouble writing to a JSP page
   */
  public void printCountsInTable(JspWriter out, int[] failData, int[] passData)
    throws IOException {

    out.println( "<table class=\"header\">" );
    int i = 0;
    for ( Iterator testIterator = distribution.getRowKeys().iterator();
          testIterator.hasNext(); i++ ) {
      String testResourcePair = (String)testIterator.next();
      float totalTests = failData[i] + passData[i];
      int totalTestsInt = (int)totalTests;
      int passRate = Math.round( (passData[i] / totalTests) * 100 );
      String totalStats = ":  passed " + passData[i] + " out of " +
                          totalTestsInt + " tests ( " + passRate + "% )";
      out.println(
        "<tr>\n" +
        "  <td class=\"header\" colspan=\"3\"><b>"+seriesLabels[i]+"</b>" +
        "   " + totalStats + "</td>\n" +
        "</tr><tr>\n" +
        "  <td class=\"subheader\">Error Type</td>\n" +
        "  <td class=\"subheader\">Error Count</td>\n" +
        "  <td class=\"subheader\">Error Message</td>\n" +
        "  </tr>");
      boolean errorsFound = false;
      for ( Iterator errorIterator = distribution.getColumnKeys().iterator();
            errorIterator.hasNext(); ) {
        Integer error = (Integer)errorIterator.next();
        Number errCount = distribution.getValue(testResourcePair, error);
        if ( errCount != null && errCount.intValue() > 0 ) {
          errorsFound = true;
          out.println
            ( "<tr><td class=\"clear\">" + error +
              "</td><td class=\"clear\">" + errCount.intValue() + "</td>" +
              "<td class=\"clear\"><pre>" + allErrorTypes[error.intValue()] +
              "</pre></td></tr>" );
        }
      }
      if ( ! errorsFound ) {
        out.println
          ( "<tr><td colspan=\"3\" class=\"clear\"><i>no errors found</i></td></tr>" );
      }
    }
    out.println("</table> " );
  }

  /**
   * Create jfree category dataset of error message counts from
   * a set of GraphInstance objects.
   *
   * @param params  Additional params for the dataset production.
   *                All elements of this HashMap are of type
   *                java.io.Serializable.
   *
   * @return jfree  A jfree CategoryDataset object
   *                with error message counts.
   *
   * @throws DatasetProduceException
   */
  public Object produceDataset(Map params) throws DatasetProduceException {
    return this.getDistribution();
  }

  /**
   * Set a hash of configIDs and their associated GraphInstance objects
   * (one for each instance in the configID's history).
   *
   * @param graphInstances    A hash of configIDs and their
   *                             associated GraphInstance objects.
   */
  public void setGraphInstances(GraphInstanceHash graphInstances) {
    this.graphInstances = graphInstances;
    this.testNames = graphInstances.getTestNames();
    this.resourceNames = graphInstances.getResourceNames();
  }

  /**
   * Set a category dataset of error messages and their frequencies.
   *
   * @param distribution     A category dataset of error messages
   *                      and their frequencies.
   */
  public void setDistribution(DefaultCategoryDataset distribution) {
    this.distribution = distribution;
  }

  /**
   * Set a string array of resourceNames (used for ordering the hashtable)
   *
   * @param resourceNames   An array of resourceNames for ordering the hashtable
   */
  public void setResourceNames(String[] resourceNames) {
    this.resourceNames = resourceNames;
  }

  /**
   * Set array of labels used for each configID in the graph legend.
   *
   * @param seriesLabels    Array of labels used for each configID
   *                        in the graph legend.
   */
  public void setSeriesLabels(String[] seriesLabels) {
    this.seriesLabels = seriesLabels;
  }

  /**
   * Set boolean for jsp to show bar graph if there are error messages to graph.
   *
   * @param showGraph     Boolean for jsp to show bar graph
   *                     if there are error messages to graph.
   */
  public void setShowGraph(boolean showGraph) {
    this.showGraph = showGraph;
  }

  /**
   * Set vector of instanceIDs to exclude from graph.
   *
   * @param skipInstances    Vector of instanceIDs to exclude from graph.
   */
  public void setSkipInstances(Vector skipInstances) {
    this.skipInstances = skipInstances;
  }

  /**
   * Set a string array of testNames (used for ordering the hashtable)
   *
   * @param testNames   An array of testNames for ordering the hashtable
   */
  public void setTestNames(String[] testNames) {
    this.testNames = testNames;
  }

  /**
   * Boolean for jsp to show bar graph if there are error messages to graph.
   *
   * @return true if we have data for an error distribution graph; otherwise
   * return false if no errors to report
   */
  public boolean showGraph() {
    return showGraph;
  }

}
