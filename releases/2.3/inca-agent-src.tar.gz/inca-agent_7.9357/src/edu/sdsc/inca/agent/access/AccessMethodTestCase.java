package edu.sdsc.inca.agent.access;

import junit.framework.TestCase;

import java.util.regex.Pattern;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;

import edu.sdsc.inca.agent.AccessMethodOutput;
import edu.sdsc.inca.agent.AccessMethod;
import edu.sdsc.inca.agent.AccessMethodException;
import edu.sdsc.inca.util.StringMethods;
import org.apache.log4j.Logger;

/**
 * Base class for implementing access method tests (i.e., run the same tests
 * consistently on each method).  To use,
 *
 * 1) implement hasRequirements which can be used to check for specific
 *    prerequisites before a test is run (default is to always run test)
 *
 * 2) set checkResult to specify whether results should be checked or not
 *    (e.g., we don't for Manual).  Default is to always check.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public abstract class AccessMethodTestCase extends TestCase {
  protected static Logger logger = Logger.getLogger(AccessMethodTestCase.class);

  protected AccessMethod[] procs = new AccessMethod[0];
  protected boolean checkResult = true;

  public class TmpPasswordFilter implements FilenameFilter {
    public boolean accept( File dir, String name ) {
      return Pattern.matches( "inca.*tmp", name );
    }
  }


  /**
   * Check for any requirements for running a test using the specific access
   * method.
   *
   * @return  True if all requirements are met and it's okay to run the test;
   * false otherwise.
   */
  public boolean hasRequirements() {
    return true;
  }

  /**
   * Run thru a set of transfer tests using the specified access method
   *
   * @throws Exception  if problem executing test
   */
  public void testTransfer() throws Exception {
    if ( ! hasRequirements() ) return;

    for ( int i = 0; i < procs.length; i++ ) {
      execTransfers( procs[i] );
    }
  }

  /**
   * Run thru a set of execution tests using the specified access method
   *
   * @throws Exception if problem executing test
   */
  public void testRun() throws Exception {
    if ( ! hasRequirements() ) return;

    for ( int i = 0; i < procs.length; i++ ) {
      execRun( procs[i] );
    }
  }

  /**
   * Need to make sure access methods are throwing InterruptedExceptions
   * when they get interrupted
   *
   * @throws Exception  if problem executing test
   */
  public void testRunInterrupt() throws Exception {
    if ( ! hasRequirements() || ! checkResult ) return;

    class RunSleepCommand extends Thread {
      public AccessMethod a;
      public boolean done = false;
      public boolean amException = false;
      public boolean iException = false;

      public void run() {
        AccessMethodOutput out = null;
        try {
          logger.info( "Starting sleep" );
          out = a.run( "/bin/sleep", new String[]{ "60"}, null, null );
          logger.info( "Finished sleep" );
        } catch (AccessMethodException e) {
          logger.warn( "Caught access method exception", e );
          amException = true;
        } catch (InterruptedException e) {
          logger.warn( "Caught interrupted method exception" + e );
          iException = true;
        } finally {
          logger.info( "Thread done" );
          if ( out != null ) {
            logger.info( "STDERR: " + out.getStderr() );
            logger.info( "STDOUT: " + out.getStdout() );
          }
          done = true;
        }
      }
    }
    for ( int i = 0; i < procs.length; i++ ) {
      RunSleepCommand a = new RunSleepCommand();
      a.a = procs[i];
      a.start();
      try {
        logger.info( "Waiting for thread to start" );
        Thread.sleep( 5000 );
        logger.info( "Interrupting thread" );
        a.interrupt();
        a.join();
        logger.info( "Thread joined" );
        assertTrue( "Thread caught interrupted exception", a.iException );
      } catch ( InterruptedException e ) {
        // empty
      }
    }

  }

  /**
   * Test that we can get the remote home directory
   * 
   * @throws Exception  if problem executing test
   */
  public void testHome() throws Exception {

    File file = File.createTempFile( "incatest", "tmp" );
    FileWriter writer = new FileWriter( file );
    writer.write(
      "#!/bin/sh\n" +
      "\n" +
      "echo hello\n"
    );
    writer.close();
    logger.info( "temp file " + file.getAbsolutePath() );
    Runtime.getRuntime().exec( "chmod u+x " + file.getAbsolutePath() );
    String testDir = ".inca.test";
    for ( int i = 0; i < procs.length; i++ ) {
      StringMethods.deleteDirectory(
        new File( System.getProperty("user.home") + File.separator + testDir )
      );
      procs[i].put(file.getAbsolutePath(), procs[i].prependHome(testDir));
      AccessMethodOutput result = procs[i].run(
        "/bin/sh",
        new String[]{
          procs[i].prependHome(testDir) + File.separator + file.getName()
        }
      );
      if ( checkResult ) {
        assertTrue(
          procs[i].getClass().getName() + " home works",
          Pattern.matches( "(?m)(?s)hello\n?", result.getStdout())
        );
      }
      result = procs[i].run(
        "/bin/sh",
        new String[]{ file.getName() },
        null,
        procs[i].prependHome( testDir )
      );
      if ( checkResult ) {
        assertTrue(
          procs[i].getClass().getName() + " home works",
          Pattern.matches( "(?m)(?s)hello\n?", result.getStdout())
        );
      }

    }
    file.delete();
  }

  /**
   * Run thru a set of start/stop process tests using the specified access
   * method
   *
   * @throws Exception  if problem executing test
   */
  public void testStartStop() throws Exception {
    if ( ! hasRequirements() ) return;

    for ( int i = 0; i < procs.length; i++ ) {
      execStartStop( procs[i] );
    }
  }

  /**
   * Check to see if there are any temporary files leftover
   */
  private void checkForTempFiles() {
    File tmpdir = new File( "/tmp" );
    File [] tmpFilesLeftover = tmpdir.listFiles( new TmpPasswordFilter() );
    if ( tmpFilesLeftover.length > 0 ) {
      for( int i = 0; i < tmpFilesLeftover.length; i++ ) {
        logger.debug( "File:  " + tmpFilesLeftover[i].getAbsolutePath() );
      }
    }
    assertEquals( "no tempfiles leftover", 0, tmpFilesLeftover.length );
  }

  /**
   * Test a simple executable 'echo hello' with and without directory specified.
   *
   * @param proc  A configured access method object
   *
   * @throws Exception   if problem executing run tests
   */
  private void execRun( AccessMethod proc )
    throws Exception {

    // test bad exec and see if files are cleaned up
    try {
      proc.run( "/bin/cat38323", new String[]{}, "hello", null );
    } catch ( AccessMethodException e ) {
      // empty
    }
    checkForTempFiles();
    
    // without stdin
    String [] args = new String[] { "-c", "echo hello" };
    AccessMethodOutput result = proc.run( "/bin/sh", args );
    if ( checkResult ) {
      assertTrue(
        proc.getClass().getName() + " run works",
        Pattern.matches( "(?m)(?s)hello\n?", result.getStdout())
      );
    }
    checkForTempFiles();

    // with stdin
    result = proc.run( "/bin/cat", new String[]{}, "hello", null );
    if ( checkResult ) {
      assertTrue(
        proc.getClass().getName() + " run works with stdin",
        Pattern.matches( "(?m)(?s)hello\n?", result.getStdout())
      );
    }
    checkForTempFiles();

    result = proc.run( "/bin/sh", args, null, "/tmp" );
    if ( checkResult ) {
      assertTrue(
        proc.getClass().getName() + " run works with dir specified",
        Pattern.matches( "(?m)(?s)hello\n?", result.getStdout())
      );
    }
    checkForTempFiles();
  }

  /**
   * Test the start of a process (very simple sleep for a minute) and then
   * stop it.  Also test stdin.
   *
   * @param proc  A configured access method object
   *
   * @throws Exception   if problem running non-blocking remote command
   */
  private void execStartStop( AccessMethod proc )
    throws Exception {

    // no stdin
    String [] args = { "60" };
    proc.start( "/bin/sleep", args, null );
    if ( checkResult ) {
      assertEquals( "local start works", true, proc.isActive() );
    }
    Thread.sleep(5000);
    proc.stop();
    Thread.sleep(2000);
    if ( checkResult ) {
      assertEquals( "local stop works", false, proc.isActive() );
    }
    checkForTempFiles();

    // with stdin
    File tmpFile = File.createTempFile( "inca", "tmp" );
    proc.start( "/usr/bin/tee", new String[]{ tmpFile.getAbsolutePath()},
                "test" );
    Thread.sleep(5000);

    if ( checkResult ) {
      assertEquals( "tee no longer working", false, proc.isActive() );
      assertTrue( "tmpFile created", tmpFile.exists() );
      BufferedReader reader = new BufferedReader( new FileReader(tmpFile) );
      String data = reader.readLine();
      reader.close();
      assertTrue( "test in file", data.matches( "test") );
    }
    tmpFile.delete();
    checkForTempFiles();
  }

  /**
   * Test the transfer of one and multiple files
   *
   * @param proc  A configured access method object
   *
   * @throws Exception  if problem executing transfers
   */
  private void execTransfers( AccessMethod proc )
    throws Exception {

    // check transfers of single file
    File file = new File( "/tmp/build.xml" );
    if ( file.exists() ) {
      file.delete();
    }
    proc.put( "./build.xml", "/tmp");
    if ( checkResult ) {
      assertTrue( "file copy works", file.exists() );
    }
    file.delete();
    proc.get( System.getProperty("user.dir") + "/build.xml", "/tmp" );
    if ( checkResult ) {
      assertTrue( "file copy works", file.exists() );
    }
    file.delete();

    // check transfers of multiple files
    File file2 = new File( "/tmp/build-common.xml" );
    if ( file2.exists() ) {
      file2.delete();
    }
    proc.put( new String[] { "build.xml", "etc/common/build-common.xml"},
                   "/tmp" );
    if ( checkResult ) {
      assertTrue(proc.getClass().getName() + " file copy works", file.exists());
      assertTrue(proc.getClass().getName() + " file copy works",file2.exists());
    }
    file.delete(); file2.delete();
    proc.get( new String[] {
      System.getProperty("user.dir") + "/build.xml",
      System.getProperty("user.dir") + "/etc/common/build-common.xml" },
      "/tmp" );
    if ( checkResult ) {
      assertTrue(proc.getClass().getName() + " file copy works", file.exists());
      assertTrue(proc.getClass().getName() + " file copy works",file2.exists());
    }
    file.delete(); file2.delete();

    // test ability to transfer files to non-yet created directories
    StringMethods.deleteDirectory( new File("/tmp/tmpa") );
    file = new File( "/tmp/tmpa/tmpb/build.xml" );
    if ( checkResult ) {
      assertFalse(proc.getClass().getName() + " dir not there", file.exists() );
    }
    proc.put( "build.xml", "/tmp/tmpa/tmpb" );
    if ( checkResult ) {
      assertTrue(proc.getClass().getName() + "file copy works", file.exists() );
    }
    StringMethods.deleteDirectory( new File("/tmp/tmpa") );
    proc.get( System.getProperty("user.dir") + "/build.xml", "/tmp/tmpa/tmpb" );
    if ( checkResult ) {
      assertTrue(proc.getClass().getName() + "file copy works", file.exists() );
    }
    StringMethods.deleteDirectory( new File("/tmp/tmpa") );

    // test ability to put files to user's home directory
    String homeDir =
      System.getProperty("user.home") + File.separator + ".tmpa/tmpb";
    StringMethods.deleteDirectory( new File( homeDir ) );
    file = new File( homeDir + File.separator + "build.xml" );
    logger.info( "file=" + file.getAbsolutePath() );
    proc.put( "build.xml", proc.prependHome(".tmpa/tmpb") );
    if ( checkResult ) {
      assertTrue(proc.getClass().getName() + "file copy works", file.exists() );
    }
    file.delete();
    proc.get( proc.prependHome(".bashrc"), "/tmp" );
    file = new File( "/tmp/.bashrc" );
    if ( checkResult ) {
      assertTrue(proc.getClass().getName() + "file copy works", file.exists() );
    }
    file.delete();
  }

}
