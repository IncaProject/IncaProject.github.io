package edu.sdsc.inca.depot.commands;

import edu.sdsc.inca.dataModel.report.ReportDocument;
import edu.sdsc.inca.depot.persistent.*;
import edu.sdsc.inca.depot.util.Comparitor;
import edu.sdsc.inca.depot.util.HibernateMessageHandler;
import edu.sdsc.inca.depot.util.Notifier;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.protocol.Statement;
import java.util.Hashtable;
import java.util.Iterator;
import org.apache.xmlbeans.XmlException;

/**
 * The task that will take a report and insert it to the database.
 * the REPORT command is supported by this class.
 */
public class Insert extends HibernateMessageHandler {

  private static Hashtable cachedClasses = new Hashtable();
  private static ClassLoader cl = Insert.class.getClassLoader();

  /**
   * Execute the insert task.
   *
   * @throws Exception
   */
  public void executeHibernateAction(ProtocolReader reader,
                                     ProtocolWriter writer) throws Exception {

    String command = null;
    String context = null;
    String resource = null;
    String stderr = null;
    String stdout = null;
    Statement stmt = null;
    String sysusage = null;

    // read everything needed from the socket
    stmt = reader.readStatement();
    String[] pieces = new String(stmt.getData()).split("\\s+", 2);
    resource = pieces[0];
    context = pieces[1];
    command = reader.peekCommand();

    if(command != null && command.equals(Protocol.INSERT_STDERR_COMMAND)) {
      stmt = reader.readStatement();
      stderr = new String(stmt.getData());
      command = reader.peekCommand();
    }

    if(command == null || !command.equals(Protocol.INSERT_STDOUT_COMMAND)) {
      throw new ProtocolException("STDOUT section missing from REPORT message");
    }
    stmt = reader.readStatement();
    stdout = new String(stmt.getData());
    command = reader.peekCommand();

    if(command == null || !command.equals(Protocol.INSERT_SYSUSAGE_COMMAND)) {
      throw new ProtocolException
        ("SYSUSAGE section missing from REPORT message");
    }
    stmt = reader.readStatement();
    sysusage = new String(stmt.getData());

    Report dbReport = null;
    RunInfo dbRunInfo = null;
    Series dbSeries = null;
    edu.sdsc.inca.dataModel.util.Report report = null;

    try {
      ReportDocument doc = ReportDocument.Factory.parse(stdout);
      if(!doc.validate()) {
        throw new XmlException("Invalid report XML '" + stdout + "'");
      }
      report = doc.getReport();
    } catch(XmlException e) {
      throw new ProtocolException("Unable to parse report XML: " + e);
    }

    // Construct the four database entities contained in the text of the
    // report--a Series, a Report, an InstanceInfo, and a RunInfo.
    Series s = new Series().fromBean(report);
    s.setResource(resource);
    s.setContext(context);
    Report r = new Report().fromBean(report);
    r.setStderr(stderr);
    InstanceInfo ii = new InstanceInfo(report.getGmt().getTime(), sysusage);
    if(report.getLog() != null) {
      ii.setLog(report.getLog().xmlText());
    }
    RunInfo ri = new RunInfo().fromBean(report);

    // Retrieve them from (existing) or store them in (new) the DB.
    if((dbSeries = SeriesDAO.load(s)) == null) {
      logger.warn
        ("Report of " + s.getReporter() + " unattached to any DB series");
      logger.debug("Auto-add new series to DB");
      dbSeries = SeriesDAO.loadOrSave(s);
    }
    dbRunInfo = RunInfoDAO.loadOrSave(ri);
    r.setSeries(dbSeries);  // ReportDAO.load depends on these being set
    r.setRunInfo(dbRunInfo);
    if((dbReport = ReportDAO.load(r)) == null) {
      logger.debug("Auto-add new report to DB");
      dbReport = ReportDAO.loadOrSave(r);
    }
    dbSeries.addReport(dbReport);
    SeriesDAO.update(dbSeries);
    ReportDAO.update(dbReport);
    logger.debug("Add new instance to DB");
    ii.setReportId(dbReport.getId());
    InstanceInfoDAO.loadOrSave(ii);

    // Let the client know everything went well.
    writer.write(Statement.getOkStatement(context));

    // Update all related SeriesConfigs
    if(dbSeries.getSeriesConfigs().size() < 1) {
      logger.warn
        ("Series of " + s.getReporter() + " unattached to any DB config");
    }

    for(Iterator i = dbSeries.getSeriesConfigs().iterator(); i.hasNext(); ) {

      SeriesConfig dbSc = (SeriesConfig)i.next();
      // If multiple configs feed into the same series, we could receive
      // reports attached to deactivated series.  Do no processing for these.
      if(dbSc.getDeactivated() > dbSc.getActivated()) {
        continue;
      }

      // Update the SeriesConfig's latest instance field
      dbSc.setLatestInstanceId(ii.getId());
      try {
        SeriesConfigDAO.update(dbSc);
      } catch(PersistenceException e) {
        logger.error("Error storing report series config:" + e);
      }

      // Generate and save any comparison the SeriesConfig specifies
      AcceptedOutput ao = dbSc.getAcceptedOutput();
      if(ao == null) {
        continue;
      }
      String comparitor = ao.getComparitor();
      if(comparitor == null || comparitor.equals("") ||
         comparitor.equals(PersistentObject.DB_EMPTY_STRING)) {
        continue;
      }
      Comparitor c = (Comparitor)getInstance(comparitor);
      if(c == null) {
        logger.error("Unable to retrieve comparitor " + comparitor);
        continue;
      }

      String result = c.compare(ao, dbReport);
      ComparisonResult cr = new ComparisonResult();
      cr.setResult(result);
      cr.setReportId(dbReport.getId());
      cr.setSeriesConfigId(dbSc.getId());
      ComparisonResult dbCr = null;
      try {
        dbCr = ComparisonResultDAO.loadOrSave(cr);
      } catch(Exception e) {
        logger.error("Error storing comparison result:" + e);
      }

      // Update the id in the SeriesConfig if the comparison result changed
      Long priorComparisonId = dbSc.getLatestComparisonId();
      if(dbCr.getId().longValue() == priorComparisonId.longValue()) {
        continue;
      }
      try {
        dbSc.setLatestComparisonId(dbCr.getId());
        SeriesConfigDAO.update(dbSc);
      } catch(Exception e) {
        logger.error("Error updating series config:" + e);
      }
      Notification dbN = ao.getNotification();
      if(dbN == null) {
        continue;
      }
      // Notify only if the result text of the new comparison diffs from the
      // old (as opposed to a new report generating the same result text).
      ComparisonResult priorCr = ComparisonResultDAO.load(priorComparisonId);
      if(priorCr != null && result.equals(priorCr.getResult())) {
        continue;
      }
      String notifier = dbN.getNotifier();
      if(notifier == null || notifier.equals("") ||
         notifier.equals(PersistentObject.DB_EMPTY_STRING)) {
        continue;
      }
      Notifier n = (Notifier)getInstance(notifier);
      if(n == null) {
        logger.error("Unable to retrieve notifier " + notifier);
        continue;
      }
      String name = dbSc.getNickname();
      if(name == null || name.equals("") ||
         name.equals(PersistentObject.DB_EMPTY_STRING)) {
        name = dbSeries.getReporter();
      }
      n.notify(ao.getComparitor(), ao.getComparison(), name,
               dbSeries.getResource(), dbReport.getExit_message(),
               ao.getNotification().getTarget(), result);

    }

  }

  /**
   * Return an instance of a class retrieved from the classpath.
   *
   * @param name the comparitor class name
   * @return an instance of the named class
   */
  protected static Object getInstance(String name) {
    if(cachedClasses.get(name) != null) {
      logger.debug("Found instance of " + name + " in cache");
      return cachedClasses.get(name);
    }
    Object result = null;
    try {
      result = cl.loadClass(name).newInstance();
      logger.debug("Loaded instance of " + name);
    } catch(Exception e) {
      // empty
    }
    if(result == null && name.indexOf(".") < 0) {
      try {
        result = cl.loadClass("edu.sdsc.inca.depot.util." + name).newInstance();
        logger.debug("Loaded instance of edu.sdsc.inca.depot.util." + name);
      } catch(Exception e) {
        // empty
      }
    }
    if(result != null) {
      cachedClasses.put(name, result);
    }
    return result;
  }

}
