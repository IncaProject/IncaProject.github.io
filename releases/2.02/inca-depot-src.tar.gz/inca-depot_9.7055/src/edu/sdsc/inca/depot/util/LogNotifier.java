package edu.sdsc.inca.depot.util;

import org.apache.log4j.Logger;
import java.io.File;
import java.io.FileWriter;

/**
 * A Notifier that writes to a log file.
 *
 * @author jhayes
 */
public class LogNotifier implements Notifier {

  private static Logger logger = Logger.getLogger(LogNotifier.class);

  /**
   * Writes to a target log file about an AcceptedOutput state change.
   *
   * @param comparitor the name of the class that did the test
   * @param comparison the test that changed state
   * @param series the name of the series generating the output
   * @param resource the resource where the reporter ran
   * @param error an optional error message that accompanies a failure
   * @param target The email address notify
   * @param state A string indicating the new AO state
   */
  public void notify(String comparitor, String comparison,
                     String series, String resource, String error,
                     String target, String state) {
    String log = "Test '" + comparison + "' on output of series " + series +
                 " on " + resource + " now produces '" + state + "'\n";
    // Check to see if the file has either a temporary directory or the working
    // directory as an ancestor; other paths are disallowed for security.
    // Check target for initial /tmp, but check cononical path for wd to avoid
    // potential problems with ../ in path.
    try {
      String targetPath = new File(target).getCanonicalPath();
      String workingDir =
        new File(System.getProperty("user.dir")).getCanonicalPath();
      if(!target.startsWith("/tmp") && !targetPath.startsWith(workingDir)) {
        logger.error("Invalid log file path '" + targetPath + "'");
        return;
      }
    } catch(Exception e) {
      logger.error("Error examining log path: " + e);
      return;
    }
    try {
      FileWriter fw = new FileWriter(target, true);
      fw.write(log);
      fw.close();
    } catch(Exception e) {
      logger.error("Exception writing log: " + e);
    }
  }

}
