package edu.sdsc.inca.depot.util;

import edu.sdsc.inca.util.StringMethods;

/**
 * A Notifier that sends email to its target.
 *
 * @author jhayes
 */
public class EmailNotifier implements Notifier {

  /**
   * Emails a target email address about an AcceptedOutput state change.
   *
   * @param comparitor the name of the class that did the test
   * @param comparison the test that changed state
   * @param series the name of the series generating the output
   * @param resource the resource where the reporter ran
   * @param error an optional error message that accompanies a failure
   * @param target The email address notify
   * @param state A string indicating the new AO state
   */
  public void notify(String comparitor, String comparison,
                     String series, String resource, String error,
                     String target, String state) {
    String[] emails = target.split("[\\s,;]+");
    boolean fail = state.startsWith(Comparitor.FAILURE_RESULT);
    String messageBody =
      "This is notification from the Inca system that results of the test\n\n" +
      comparison + "\n\n" +
      "on the output of series " + series + " on " + resource +
      " have changed.\n\n" +
      "Comparitor message: " + state + "\n\n";
    String messageSubject =
      "Inca Notification: " + series + " on " + resource + " " +
      (fail ? "FAIL" : "PASS");
    if(error != null && !error.trim().equals("")) {
      messageBody += "Error message: " + error + "\n";
    }
    for(int i = 0; i < emails.length; i++) {
      String[] pieces = emails[i].split(":");
      if(pieces.length == 1 || fail == pieces[0].startsWith("Fail")) {
        StringMethods.sendEmail
          (pieces[pieces.length == 1 ? 0 : 1], messageSubject, messageBody);
      }
    }
  }

}
