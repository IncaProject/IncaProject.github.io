package edu.sdsc.inca.util;

import junit.framework.TestCase;
import org.apache.log4j.Logger;

import java.util.regex.Pattern;
import java.io.File;

import edu.sdsc.inca.dataModel.util.SeriesConfig;
import edu.sdsc.inca.dataModel.util.Schedule;
import edu.sdsc.inca.dataModel.util.Args;

/**
 * Test XMLWrapper abstract class functions
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class XmlWrapperTest extends TestCase {
  private static Logger logger = Logger.getLogger( XmlWrapperTest.class );
  String password = "superSecret";
  String[] samples = {
    "<name>passphrase</name>\n" +
    "<value>" + password + "</value>\n",

    "<name>aPassphrase</name>\n" +
    "<value>" + password + "</value>\n",

    "<name>password</name>\n" +
    "<value>" + password + "</value>\n",

    "<name>aPassword</name>\n" +
    "<value>" + password + "</value>\n",

    "<name>passphrase</name>\n" +
    "<value>" + password + "</value>\n" +
    "<name>server</name>\n" +
    "<value>localhost</value>\n" +
    "<name>password</name>\n" +
    "<value>" + password + "</value>\n",

    "<name>server</name>\n" +
    "<value>localhost</value>\n" +
    "<name>password</name>\n" +
    "<value>" + password + "</value>\n" +
    "<name>passphrase</name>\n" +
    "<value>" + password + "</value>\n" +
    "<name>passphrase</name>\n" +
    "<value>" + password + "</value>\n" +
    "<name>server</name>\n" +
    "<value>localhost</value>\n" +
    "<name>password</name>\n" +
    "<value>" + password + "</value>\n" +
    "<name>server</name>\n" +
    "<value>localhost</value>\n",

    "<name>server</name>\n" +
    "<value>localhost</value>\n" +
    "<name>password</name>\n" +
    "<value>" + password + "</value>\n" +
    "<name>server</name>\n" +
    "<value>localhost</value>\n"
  };

  public void testConfigEquals() throws Exception {
    SeriesConfig config = SeriesConfig.Factory.newInstance();
    config.addNewSeries().addNewArgs();
    Args.Arg arg = config.getSeries().getArgs().addNewArg();
    arg.setName( "arg1" );
    arg.setValue( "value1" );
    arg = config.getSeries().getArgs().addNewArg();
    arg.setName( "arg2" );
    arg.setValue( "value2" );
    Schedule schedule = config.addNewSchedule();
    schedule.addNewCron().setMin( "?" );
    schedule.getCron().setHour( "?/5" );
    schedule.getCron().setMday( "*" );
    schedule.getCron().setWday( "*" );
    schedule.getCron().setMonth( "*" );
    class SomeWrapper extends XmlWrapper {
    };
    SomeWrapper wrapper = new SomeWrapper();
    assertTrue(
      "configEquals workd for true case",
      wrapper.configEqual( config, config )
    );

    SeriesConfig config2 = (SeriesConfig)config.copy();
    assertTrue(
      "configEquals workd when exactly the same",
      wrapper.configEqual( config, config2 )
    );
    config2.getSeries().getArgs().setArgArray( new Args.Arg[0] );
    arg = config2.getSeries().getArgs().addNewArg();
    arg.setName( "arg2" );
    arg.setValue( "value2" );
    arg = config2.getSeries().getArgs().addNewArg();
    arg.setName( "arg1" );
    arg.setValue( "value1" );
    logger.debug( ">> config2" + config2 );
    assertTrue(
      "configEquals works when args out of order",
      wrapper.configEqual( config, config2 )
    );
    config2.setSchedule(
      SuiteStagesWrapper.chooseSchedule(config2.getSchedule())
    );
    assertTrue(
      "configEquals workd for true case",
      wrapper.configEqual( config, config2 )
    );
    config.getSchedule().getCron().setMin( "5");
    assertFalse(
      "configEquals workd for false case",
      wrapper.configEqual( config, config2 )
    );

    // check to see if chooseSchedule will not pick new schedule if already
    // selected
    SeriesConfig config3 = (SeriesConfig)config2.copy();
    config3.setSchedule(
      SuiteStagesWrapper.chooseSchedule(config3.getSchedule())
    );
    assertEquals(
      "configEquals workd for true case",
      config2.xmlText(),
      config3.xmlText() 
    );


  }

  /**
   * Test crypSensitive function
   *
   * @throws Exception
   */
  public void testCryptSensitive() throws Exception {
    for ( int i = 0; i < samples.length; i++) {
      logger.debug( "\nORIG " + samples[i] );
      System.out.println("Before '" + samples[i] + "'");
      String encrypted = XmlWrapper.cryptSensitive(
        samples[i], "topSecret!", false
      );
      System.out.println("After '" + encrypted + "'");
      assertFalse(
        "password not found",
        Pattern.compile(password).matcher(encrypted).find()
      );
      String decrypted = XmlWrapper.cryptSensitive(
        encrypted, "topSecret!", true
      );
      assertEquals( "got back the original text", decrypted, samples[i] );
    }
  }

  /**
   * Test read and save functions
   *
   * @throws Exception
   */
  public void testReadSave() throws Exception {
    File tempFile = File.createTempFile( "inca", ".xml" );
    XmlWrapper.save( samples[6], tempFile.getAbsolutePath(), "topSecret!" );
    String xml = XmlWrapper.read( tempFile.getAbsolutePath(), "topSecret!" );
    assertEquals( "restored text", samples[6], xml );
    xml = XmlWrapper.read( tempFile.getAbsolutePath(), "" );
    assertFalse(
        "password not found",
        Pattern.compile(password).matcher(xml).find()
    );
    tempFile.delete();
  }
}
