package edu.sdsc.inca.util;

import junit.framework.Assert;
import junit.framework.TestCase;
import org.apache.log4j.Logger;

/**
 * @author Jim Hayes
 */
public class StringMethodsTest extends TestCase {

  private static Logger logger = Logger.getLogger(StringMethodsTest.class);
  protected String tableRow(String tag, String[] cells) {
    StringBuffer result = new StringBuffer("<tr>");
    for(int i = 0; i < cells.length; i++) {
      result.append("<" + tag + ">").append(cells[i]).append("</" + tag + ">");
    }
    result.append("</tr>");
    return result.toString();
  }

  protected static final String TABLE_END = "</table>";
  protected static final String TABLE_START = "<table[^>]*>";

  public void testXmlContentToHtml() throws Exception {
    String html = StringMethods.xmlContentToHtml("<a>7</a>", "").
                  replaceAll(">\\s+", ">");
    String pat =
      TABLE_START +
      tableRow("th", new String[] {"a"}) +
      tableRow("td", new String[] {"7"}) +
      TABLE_END;
    assertTrue(html.matches(pat));
    html = StringMethods.xmlContentToHtml("<a>8</a><b>9</b>", "").
           replaceAll(">\\s+", ">");
    pat =
      TABLE_START +
      tableRow("th", new String[] {"a", "b"}) +
      tableRow("td", new String[] {"8", "9"}) +
      TABLE_END;
    assertTrue(html.matches(pat));
    html = StringMethods.xmlContentToHtml("<z><a>10</a><b>11</b></z>", "").
           replaceAll(">\\s+", ">");
    pat =
      TABLE_START +
      tableRow("th", new String[] {"z"}) +
      tableRow("td", new String[] {
        TABLE_START +
          tableRow("th", new String[] {"a", "b"}) +
          tableRow("td", new String[] {"10", "11"}) +
        TABLE_END
      }) +
      TABLE_END;
    assertTrue(html.matches(pat));
    html = StringMethods.xmlContentToHtml("<a>12</a><a>13</a>", "").
           replaceAll(">\\s+", ">");
    pat =
      TABLE_START +
      tableRow("th", new String[] {"a"}) +
      tableRow("td", new String[] {
        TABLE_START +
          tableRow("td", new String[] {"12"}) +
          tableRow("td", new String[] {"13"}) +
        TABLE_END
      }) +
      TABLE_END;
    assertTrue(html.matches(pat));
    html = StringMethods.xmlContentToHtml
      ("<z><a>14</a><b>15</b></z><z><a>16</a><b>17</b></z>", "").
           replaceAll(">\\s+", ">");
    pat =
      TABLE_START +
      tableRow("th", new String[] {"z"}) +
      tableRow("td", new String[] {
        TABLE_START +
        tableRow("td", new String[] {
          TABLE_START +
            tableRow("th", new String[] {"a", "b"}) +
            tableRow("td", new String[] {"14", "15"}) +
          TABLE_END
        }) +
        tableRow("td", new String[] {
          TABLE_START +
            tableRow("th", new String[] {"a", "b"}) +
            tableRow("td", new String[] {"16", "17"}) +
          TABLE_END
        }) +
        TABLE_END
      }) +
      TABLE_END;
    assertTrue(html.matches(pat));
  }

}
