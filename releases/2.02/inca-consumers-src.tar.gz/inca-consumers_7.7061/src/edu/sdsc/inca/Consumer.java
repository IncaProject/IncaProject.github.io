package edu.sdsc.inca;

import edu.sdsc.inca.util.ConfigProperties;
import edu.sdsc.inca.util.Constants;
import edu.sdsc.inca.util.ResourcesWrapper;
import edu.sdsc.inca.consumer.IncaConfigCache;
import edu.sdsc.inca.consumer.SuiteCache;
import edu.sdsc.inca.protocol.Protocol;
import org.mortbay.http.SocketListener;
import org.mortbay.http.NCSARequestLog;
import org.mortbay.http.ajp.AJP13Listener;
import org.mortbay.jetty.servlet.WebApplicationContext;

import java.util.Properties;
import java.util.regex.Pattern;
import java.net.URL;
import java.io.File;

/**
 * Starts up a Jetty server to server our JSP pages. Also starts threads
 * to periodically load and cache the resources (from agent) and suites (from
 * depot).
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class Consumer extends Component {
  // Constants
  final public static Pattern IMMEDIATE_PATTERN = Pattern.compile(
    Protocol.IMMEDIATE_SUITE_NAME
  );
  final private String JETTY_DIR = "jetty";
  final private String JETTY_ACCESS = JETTY_DIR + File.separator + "access.log";
  final private int    JETTY_LOGLIMIT = 30; // days
  final private String ROOT_WAR = "root.war";

  // Static variables
  private static Properties clientConfig = null;
  private static int cacheMaxWaitPeriod = Constants.MILLIS_TO_MINUTE;
  private static int cacheReloadPeriod = 5 * Constants.MILLIS_TO_MINUTE;
  private static IncaConfigCache icCache = new IncaConfigCache();
  private static SuiteCache suiteCache = new SuiteCache();
  private static String url = null;

  // Member variables
  private int ajp13Port = -1;
  private int port = 8080;
  org.mortbay.jetty.Server server = null;
  private String tempPath = null;
  private String webapp = "inca-consumers.war";

  // Configuration options
  public static final String CONSUMER_OPTS = ConfigProperties.mergeValidOptions(
    Component.COMPONENT_OPTS,
    "a|agent       str  URI to the Inca agent\n" +
    "A|ajp13Port   int  Jetty AJP13 connector port\n" +
    "d|depot       str  URI to the Inca depot\n" +
    "m|maxWait     int  Max wait time a JSP tag should wait on a cached item\n"+
    "p|port        int  Server listening port\n" +
    "r|reload      int  Reload period for cached objects (e.g., suites)\n" +
    "v|var         path Path to temporary directory\n" +
    "w|webapp      str  Path to consumer war file\n",
    true
  );


  /**
   * Returns configuration properties for clients (e.g., agent and depot).
   *
   * @return a list of configuration properties for clients
   */
  public static Properties getClientConfiguration() {
    return clientConfig;
  }

  /**
   * Return the resources with a maximum wait time.
   *
   * @param maxWait The maximum time in milliseconds to wait for the resources
   *                to be initially loaded into the cache.
   *
   * @return  The resources as a ResourceWrapper or null if the maxWait is
   * exceeded
   */
  public static String[] getRepositories( int maxWait ) {
    return icCache.getRepositories( maxWait );
  }

  /**
   * Return the specified cached suite document with a maximum wait time.
   *
   * @param name   The name of the suite to fetch from the configured depot.
   * @param maxWait The maximum time in milliseconds to wait for the specified
   *                suite to be initially loaded into the cache.
   *
   * @return  An array of report summaries or null if the maxWait is exceeded
   */
  public static String[] getSuite( String name, int maxWait ) {
    return suiteCache.getSuite( name, maxWait );
  }

  /**
   * Return the resources with a maximum wait time.
   *
   * @param maxWait The maximum time in milliseconds to wait for the resources
   *                to be initially loaded into the cache.
   *
   * @return  The resources as a ResourceWrapper or null if the maxWait is
   * exceeded
   */
  public static String getSuiteConfigs( int maxWait ) {
    return icCache.getSuites( maxWait );
  }

  /**
   * Returns the path where the server stores temporary files.
   *
   * @return the temp directory path
   */
  public String getTempPath() {
    return this.tempPath;
  }

  /**
   * Return the resources with a maximum wait time.
   *
   * @param maxWait The maximum time in milliseconds to wait for the resources
   *                to be initially loaded into the cache.
   *
   * @return  The resources as a ResourceWrapper or null if the maxWait is
   * exceeded
   */
  public static ResourcesWrapper getResourceConfig( int maxWait ) {
    return icCache.getResourceConfig( maxWait );
  }

  /**
   * Return the port for the Jetty AJP13 connector
   *
   * @return the port for the Jetty AJP13 connector
   */
  public int getAjp13Port() {
    return ajp13Port;
  }

  /**
   * Return the amount of time (milliseconds) a JSP tag should wait for a suite
   * or resources before timing out.
   *
   * @return  the number of milliseconds a JSP tag should wait for a cached
   * object to return.
   */
  public static int getCacheMaxWaitPeriod() {
    return cacheMaxWaitPeriod;
  }

  /**
   * Return the period of refresh for the suite and resources in the
   * Consumer's cache.
   *
   * @return  the number of milliseconds in between reloads of cached
   * objects.
   */
  public static int getCacheReloadPeriod() {
    return cacheReloadPeriod;
  }

  /**
   * Return the port of the Jetty server.
   *
   * @return the port number the Jetty server is running on.
   */
  public int getPort() {
    return port;
  }

  /**
   * Return the url for the container (i.e., Jetty).
   *
   * @return
   */
  public static String getUrl() {
    return url;
  }

  /**
   * Return the war file of the Inca JSP pages.
   *
   * @return  path to the war file
   */
  public String getWebApp() {
    return webapp;
  }

  public synchronized boolean isRunning() {
    return this.server != null && this.server.isStarted();
  }

  /**
   * Runs a Jetty server.
   */
  public void startConsumer() {
    this.server = new org.mortbay.jetty.Server();
    // set the port for the jetty server to listen on
    SocketListener listener = new SocketListener();
    listener.setPort(port); server.addListener(listener);

    // optionally set an Jetty AJP13 connector -- requested by Gerson
    if ( this.getAjp13Port() > 0 ) {
      AJP13Listener ajp13Listener = new AJP13Listener();
      ajp13Listener.setPort( this.getAjp13Port() );
      server.addListener(  ajp13Listener );
      logger.info
        ( "Configured Jetty AJP13 connector on port " + this.getAjp13Port() );
    }

    // add the inca-consumer web app
    URL webapp_url = ClassLoader.getSystemClassLoader().getResource( webapp );
    if(webapp_url == null) {
      logger.error( "web app '" + webapp + "' not found in classpath" );
      return;
    }
    logger.info( "Deploying webapp " + webapp_url.getFile() );

    // configure the web app
    WebApplicationContext context;
    try {
      context =
        server.addWebApplication( "/inca", webapp_url.getFile() );
    } catch(Exception e) {
      logger.error("Problem adding application", e);
      return;
    }
    // store the jetty dir in var; if it's in tmp, it could get erased
    context.setTempDirectory(
      new File( this.getTempPath() + File.separator + JETTY_DIR )
    );
    // will unjar the webapp into temp dir
    context.setExtractWAR( true );
    // log all requests to jetty access log
    NCSARequestLog jettyLogger = new NCSARequestLog();
    jettyLogger.setAppend( true );
    jettyLogger.setFilename(
      this.getTempPath() + File.separator + JETTY_ACCESS
    );
    jettyLogger.setRetainDays( JETTY_LOGLIMIT );
    jettyLogger.setExtended( true );  // NCSA extended log format
    jettyLogger.setIgnorePaths( new String[]{"/css/*", "/img/*", "/*.ico"});
    context.setRequestLog( jettyLogger );
    // not sure what this prints out yet  but stats are good
    context.setStatsOn(true);

    // redirect root to /inca
    URL rootUrl = ClassLoader.getSystemClassLoader().getResource( ROOT_WAR );
    if(rootUrl == null) {
      logger.error( "root web app not found in classpath" );
      return;
    }
    logger.debug( "Deploying root " + rootUrl.getFile() );
    try {
      server.addWebApplication( "/", rootUrl.getFile() );
    } catch(Exception e) {
      logger.error("Problem with jetty url", e);
      return;
    }

    // start up server
    logger.info( "Starting Jetty server on port " + port );
    this.url = listener.getDefaultScheme() + "://" + listener.getHost() + ":" +
              listener.getPort();
    try {
      logger.debug("Starting jetty server");
      this.server.start();
      logger.debug("Jetty server started");
    } catch(Exception e) {
      logger.error("Unable to start jetty server", e);
      return;
    }
    icCache.start();
    suiteCache.start();

  }

  public synchronized void shutdown() {
    if ( server.isStarted() ) {
      try {
        server.stop(); // JJH Is this safe?  Why not interrupt()?
      } catch ( InterruptedException e1 ) {
        logger.error( "Shutdown process interrupted", e1 );
      }
    }
    icCache.interrupt();
    suiteCache.interrupt();
    logger.info( "Shutdown complete" );
  }

  /**
   * Read in the configuration for the consumer from the specified properties
   * list.
   *
   * @param config  A list of configuration options for the consumer
   *
   * @throws ConfigurationException
   */
  public void setConfiguration(Properties config) throws ConfigurationException{
    super.setConfiguration( config );
    String prop;

    // check that agent and depot are specified and save the configuratioin
    if((prop = config.getProperty("agent")) == null) {
      throw new ConfigurationException( "No agent URI specified" );
    }
    if((prop = config.getProperty("depot")) == null) {
      throw new ConfigurationException( "No depot URI specified" );
    }
    config.remove( "logfile" ); // so log does not get initialized in client
    Consumer.setClientConfiguration( config );

    // configure consumer
    if((prop = config.getProperty("ajp13Port")) != null) {
      this.setAjp13Port( new Integer(prop).intValue() );
    }
    if((prop = config.getProperty("maxWait")) != null) {
      Consumer.setCacheMaxWaitPeriod(
        (new Integer(prop)).intValue() * Constants.MILLIS_TO_SECOND
      );
    }
    if((prop = config.getProperty("port")) != null) {
      this.setPort((new Integer(prop)).intValue());
    }
    if((prop = config.getProperty("reload")) != null) {
      Consumer.setCacheReloadPeriod(
        (new Integer(prop)).intValue() * Constants.MILLIS_TO_SECOND
      );
    }
    if((prop = config.getProperty("var")) != null) {
      this.setTempPath(prop);
    }
    if((prop = config.getProperty("webapp")) != null) {
      this.setWebApp( prop );
    }
  }

  /**
   * Set the port for the Jetty AJP13 connector.
   *
   * @param ajp13Port  Port for the Jetty AJP13 connector
   */
  public void setAjp13Port( int ajp13Port ) {
    this.ajp13Port = ajp13Port;
  }

  /**
   * Set the amount of time (milliseconds) a JSP tag should wait for a suite
   * or resources before timing out.
   *
   * @param period the number of milliseconds a JSP tag should wait for a cached
   * object to return.
   */
  public static void setCacheMaxWaitPeriod( int period ) {
    Consumer.cacheMaxWaitPeriod = period;
  }

  /**
   * Set the period of refresh for the suite and resources in the
   * Consumer's cache.
   *
   * @param period the number of milliseconds in between reloads of cached
   * objects
   */
  public static void setCacheReloadPeriod( int period ) {
    Consumer.cacheReloadPeriod = period;
  }

  /**
   * Sets the configuration properties for clients (e.g., agent and depot).
   *
   * @param props   a list of configuration properties for clients
   */
  public static void setClientConfiguration( Properties props ) {
    logger.debug( "Setting client configuration" );
    clientConfig = props;
  }

  /**
   * Set the port number for the Jetty server.
   *
   * @param port A port number the Jetty server can be started on.
   */
  public void setPort( int port ) {
    this.port = port;
  }

  /**
   * Sets the directory path where the Server stores temporary files.
   *
   * @param path the temporary directory path
   * @throws ConfigurationException if the path can't be read from the classpath
   */
  public void setTempPath(String path) throws ConfigurationException {
    File tempPath = new File(path);
    if (!tempPath.exists() && !tempPath.mkdir()) {
      throw new ConfigurationException
        ("Unable to create temporary dir '" + path + "'");
    }
    this.tempPath = tempPath.getAbsolutePath();
    logger.info("Placing temporary files in " + this.tempPath);
  }

  /**
   * Set the path to the war file containing the Inca JSP pages.
   *
   * @param webapp  Path to the war file.
   */
  public void setWebApp( String webapp ) {
    this.webapp = webapp;
  }

  /**
   * Start up the consumer server.
   *
   * @param args  array of command line arguments to configure the consumer.
   */
  public static void main(final String[] args) {

    Consumer consumer = new Consumer();
    try {
      configComponent(
        consumer, args, CONSUMER_OPTS, "inca.consumer.", "edu.sdsc.inca.Consumer",
        "inca-consumers-version"
      );
      consumer.startConsumer();
      while(consumer.isRunning()) {
        Thread.sleep(2000);
      }
    } catch(Exception e) {
      logger.fatal("Configuration error: ", e);
      System.err.println("Configuration error: " + e);
      System.exit(1);
    }
  }
}
