package edu.sdsc.inca.consumer;

import junit.framework.TestCase;
import org.apache.log4j.Logger;
import edu.sdsc.inca.ConsumerTest;
import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.util.Constants;
import edu.sdsc.inca.util.ResourcesWrapper;
import edu.sdsc.inca.consumer.tag.Util;
import edu.sdsc.inca.dataModel.resourceConfig.ResourceConfigDocument;

import java.util.Properties;

/**
 * Test the resource config cache thread
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class IncaConfigCacheTest extends TestCase {
  private static Logger logger = Logger.getLogger( IncaConfigCacheTest.class );

  /**
   * Tests the ability for resources to be loaded into the cache.  First tests
   * timeout feature of getCache and then waits long enough for a successful
   * retrieval.

   * @throws Exception
   */
  public void testResourceConfigCache() throws Exception {

    // configure agent
    int agentPort = 8998;
    Properties props = new Properties();
    props.setProperty( "agent", "inca://localhost:" + agentPort );
    props.setProperty( "auth", "false" );
    Consumer.setClientConfiguration( props );

    // configure mock agent server to server the resourceConfig.xml
    ConsumerTest.MockAgent agent = new ConsumerTest.MockAgent( 1, agentPort );
    String xml = Util.getXMLFromClasspath( "resourceConfig.xml" );
    ResourceConfigDocument rcDoc = ResourceConfigDocument.Factory.parse(xml);
    agent.setResourceConfig( rcDoc.getResourceConfig() );
    agent.setDelay( 10 * Constants.MILLIS_TO_SECOND );
    agent.start();

    // start up the cache
    IncaConfigCache cache = new IncaConfigCache();
    cache.start();

    // test the timeout feature, resources should load after 10 seconds
    // so we should timeout after 5 seconds
    long startTime = Util.getTimeNow();
    ResourcesWrapper resources = cache.getResourceConfig(
      5 * Constants.MILLIS_TO_SECOND
    );
    assertTrue(
      "timed out after 5 seconds",
      Util.getTimeNow() - startTime < (7 * Constants.MILLIS_TO_SECOND)
    );
    assertNull( "resources is null when timeout", resources );

    // at least 5 seconds have passed so we wait another 10 for resources
    // to load, then get the document.
    Thread.sleep(10*Constants.MILLIS_TO_SECOND);
    resources = cache.getResourceConfig( 0 );
    assertNotNull( "resources is null when timeout", resources );

    // cleanup
    cache.interrupt();
    cache.join();
    agent.interrupt();
    agent.join();
  }
}
