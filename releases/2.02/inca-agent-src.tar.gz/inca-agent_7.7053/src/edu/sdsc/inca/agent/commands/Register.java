package edu.sdsc.inca.agent.commands;

import java.io.IOException;

import edu.sdsc.inca.protocol.MessageHandler;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.protocol.Statement;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.Agent;

/**
 * Handles the REGISTER command.  This command is sent by a remote reporter
 * manager to indicate that it's ready to accept commands from the agent.
 * This task thread will persist and keep the socket open to the reporter
 * manager.  See the ReporterManagerController's register function for more information.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class Register extends MessageHandler {
  public void execute(ProtocolReader reader,
                      ProtocolWriter writer) throws ProtocolException {
    Statement statement = null;
    try {
      statement = reader.readStatement();
      String resource = new String( statement.getData() );
      logger.info("Reporter Manager '" + resource + "' registering");
      // Reply it is OK and register this stream with the reporter manager
      // so the agent can continue to communicate with it.
      Statement response = new Statement(
        Protocol.SUCCESS_COMMAND.toCharArray()
      );
      writer.write(response);
      Agent.getGlobalAgent().registerReporterManager(resource, reader, writer);
    } catch (IOException e) {
      logger.error("Reporter Manager registering failed", e);
    }
  }
}
