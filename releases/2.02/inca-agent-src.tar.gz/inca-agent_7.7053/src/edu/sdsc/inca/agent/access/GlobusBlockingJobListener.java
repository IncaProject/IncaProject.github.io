package edu.sdsc.inca.agent.access;

import org.globus.gram.GramJob;
import org.globus.gram.GramJobListener;

/**
 * Subclass of GramJobListener that can be used to create a blocking GRAM
 * request.  For example,
 *
 * <pre>
 *   GramJob job = new GramJob( rslString );
 *   GlobusBlockingJobListener listener = new GlobusBlockingJobListener();
 *   job.addListener( listener );
 *   job.request( gramContact );
     listener.waitFor();
 * </pre>
 *
 * Based on Java COG code for globusrun.
 *
 * @hidden
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GlobusBlockingJobListener implements GramJobListener {

  // Member variables
  private int status = 0;

  /**
   * Get the status code for the Globus GRAM job.  Should be called after the
   * job is finished.
   *
   * @return A constant from the GramJob class indicating the status of the job.
   */
  public int getStatus() {
    return status;
  }

  /**
   * Returns true if the job has finished.
   *
   * @return  Returns true if the job status is either done or failed; false
   * otherwise.
   */
  public boolean hasFinished() {
    return (status == GramJob.STATUS_DONE || status == GramJob.STATUS_FAILED);
  }

  /**
   * Check for failure status of job.
   *
   * @return Returns true if the job status is failed.
   */
  public boolean hasFailed() {
    return status == GramJob.STATUS_FAILED;
  }

  /**
   * Set the status code for the Globus GRAM job.
   *
   * @param status  A constant from the GramJob class indicating the status of
   * the job.
   */
  private void setStatus( int status ) {
    this.status = status;
  }

  /**
   * This function is called by the COG API after the job.request call whenever
   * the job status changes.
   *
   * @param job A pointer to the job that is running so the status can be
   * retrieved.
   */
  public synchronized void statusChanged(GramJob job) {
    setStatus( job.getStatus() );
    if (status == GramJob.STATUS_DONE) {
      notify();
    } else if (status == GramJob.STATUS_FAILED) {
      notify();
    }
  }

  /**
   * Wait for the job to finish.  Blocks until another thread notifies it and
   * then checks the job status and returns if finished.
   *
   * @throws InterruptedException
   */
  public synchronized void waitFor() throws InterruptedException {
    while ( !hasFinished() ) {
      wait();
    }
  }

}

