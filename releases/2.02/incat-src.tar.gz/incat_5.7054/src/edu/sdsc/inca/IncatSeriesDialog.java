package edu.sdsc.inca;

import edu.sdsc.inca.util.ExpandablePattern;
import edu.sdsc.inca.util.ExprEvaluator;
import edu.sdsc.inca.util.StringMethods;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;

/**
 * A Dialog window that allows the user to edit a series.
 */
public class IncatSeriesDialog extends JDialog implements ActionListener {

  protected JTextField acceptedExpr;
  protected JTextField acceptedEmail;
  protected JPanel argsPanel;
  protected Hashtable argWidgets;
  protected ContextDocument context;
  protected JComboBox cronFrom;
  protected JTextField cronSpec;
  protected JComboBox cronStep;
  protected JComboBox cronUnit;
  protected JLabel description;
  protected JTextField limitCpu;
  protected JTextField limitMemory;
  protected JTextField limitWall;
  protected ActionListener listener;
  protected JTextField nickname;
  protected IncatList reporter;
  protected IncatList resource;
  protected ButtonGroup versionButtonGroup;
  protected JRadioButton versionLatest;
  protected JRadioButton versionSpecific;

  /** Reporter descriptions longer than this will be elided. */
  public static final int MAX_REPORTER_DOC_LENGTH = 80;

  /** Maximum and minimum values for the 5 cron units. */
  public static String[] CRON_UNIT_MAX =
    new String[] {"59", "23", "31", "12", "6"};
  public static String[] CRON_UNIT_MIN = new String[] {"0", "0", "1", "1", "0"};

  /**
   * A ContextDocument that treats specially the context marker within the
   * document text.
   */
  public class ContextDocument extends DefaultStyledDocument {

    protected Style EDITABLE;
    protected Style UNEDITABLE;
    protected int uneditableStart = 0;
    protected int uneditableEnd = 0;

    /**
     * Constructs a new ContextDocument.
     */
    public ContextDocument() {
      Style dephault = StyleContext.getDefaultStyleContext().
                       getStyle(StyleContext.DEFAULT_STYLE);
      EDITABLE = this.addStyle("editable", dephault);
      UNEDITABLE = this.addStyle("uneditable", dephault);
      StyleConstants.setFontFamily(UNEDITABLE, "serif");
      StyleConstants.setBold(UNEDITABLE, true);
      StyleConstants.setItalic(UNEDITABLE, true);
    }

    /**
     * Returns the content of the document.
     *
     * @return the document content
     */
    public String getText() {
      try {
        String text = this.getText(0, this.getLength());
        return text.substring(0, this.uneditableStart) + "@@" +
               text.substring(this.uneditableEnd + 1);
      } catch(Exception e) {
        return "";
      }
    }

    /**
     * See Document.
     */
    public void insertString(int offset, String str, AttributeSet a)
      throws BadLocationException {
      if(offset <= this.uneditableStart) {
        super.insertString(offset, str, EDITABLE);
        this.uneditableStart += str.length();
        this.uneditableEnd += str.length();
      } else if(offset > this.uneditableEnd) {
        super.insertString(offset, str, EDITABLE);
      }
    }

    /**
     * See Document.
     */
    public void remove(int offset, int length) throws BadLocationException {
      int end = offset + length - 1;
      if(end < this.uneditableStart) {
        super.remove(offset, length);
        this.uneditableStart -= length;
        this.uneditableEnd -= length;
      } else if(offset > this.uneditableEnd) {
        super.remove(offset, length);
      }
    }

    /**
     * Sets the content of the document.
     *
     * @param text the new document content
     * @param reporter the reporter name to show in lieu of the context marker
     */
    public void setText(String text, String reporter) {
      if(text == null) {
        text = "";
      }
      try {
        super.remove(0, this.getLength());
        // Find @@ in the text, taking care not to match adjacent macro
        // references (e.g., find the two at the end of "@a@@b@@@")
        int pos;
        for(pos = text.indexOf("@");
            pos >= 0 && !text.substring(pos).startsWith("@@");
            pos = text.indexOf("@", pos + 1)) {
          if(text.substring(pos).matches("@[\\w\\.\\-]+@.*")) {
            // Skip macro reference
            pos = text.indexOf("@", pos + 1);
          }
        }
        if(pos >= 0) {
          super.insertString(this.getLength(), text.substring(0,pos), EDITABLE);
        }
        this.uneditableStart = this.getLength();
        super.insertString(this.getLength(), reporter + " -args", UNEDITABLE);
        this.uneditableEnd = this.getLength() - 1;
        if(pos >= 0) {
          super.insertString(this.getLength(), text.substring(pos+2), EDITABLE);
        }
      } catch(Exception e) {
        // empty
      }
    }

  }

  /**
   * Constructs a new IncatSeriesDialog.
   *
   * @param listener the listener to invoke when OK or cancel is pressed
   * @param okCommand the command to send when OK is pressed
   * @param cancelCommand the command to send when Cancel is pressed
   */
  public IncatSeriesDialog(ActionListener listener,
                           String okCommand,
                           String cancelCommand) {
    this.acceptedExpr = IncatComponents.JTextFieldFactory(20, okCommand, this);
    this.acceptedEmail = IncatComponents.JTextFieldFactory(20, okCommand, this);
    this.argWidgets = new Hashtable();
    this.argsPanel = new JPanel();
    String[] cronAmounts = new String[60];
    for(int i = 0; i < cronAmounts.length; i++) {
      cronAmounts[i] = i + "";
    }
    this.cronStep = new JComboBox(cronAmounts);
    this.cronStep.removeItemAt(0); // Get rid of the 0
    this.cronStep.addActionListener(this);
    this.cronStep.setActionCommand("cronwidgetchange");
    this.cronFrom = new JComboBox(cronAmounts);
    this.cronFrom.insertItemAt("random", 0);
    this.cronFrom.addActionListener(this);
    this.cronFrom.setActionCommand("cronwidgetchange");
    String[] cronUnits = new String[] {
      "minutes", "hours", "days", "months", "weekdays"
    };
    this.cronUnit = new JComboBox(cronUnits);
    this.cronUnit.addActionListener(this);
    this.cronUnit.setActionCommand("cronunitchange");
    this.cronSpec =
      IncatComponents.JTextFieldFactory(10, "cronspecchange", this);
    // For context, wrap a JTextPane in an invisible JScrollPane to get the
    // same 3d shadowing that a JTextField has.
    this.context = new ContextDocument();
    JTextPane contextPane = new JTextPane();
    JTextField spacer = new JTextField(40);
    contextPane.setPreferredSize(spacer.getPreferredSize());
    contextPane.setMinimumSize(spacer.getPreferredSize());
    contextPane.setStyledDocument(this.context);
    JScrollPane contextScroll = new JScrollPane(contextPane);
    contextScroll.setVerticalScrollBarPolicy
      (JScrollPane.VERTICAL_SCROLLBAR_NEVER);
    contextScroll.setPreferredSize(contextPane.getPreferredSize());
    this.description = new JLabel("");
    this.limitCpu = IncatComponents.JTextFieldFactory(5, okCommand, this);
    this.limitMemory = IncatComponents.JTextFieldFactory(5, okCommand, this);
    this.limitWall = IncatComponents.JTextFieldFactory(5, okCommand, this);
    this.nickname = IncatComponents.JTextFieldFactory(20, okCommand, this);
    this.reporter = new IncatList("reporterchange", "reportershow", this);
    this.resource = new IncatList(null, null);
    this.versionButtonGroup = new ButtonGroup();
    this.versionLatest = new JRadioButton("Use Latest Version");
    this.versionSpecific = new JRadioButton("Use Specific Version");
    versionButtonGroup.add(this.versionSpecific);
    versionButtonGroup.add(this.versionLatest);
    JPanel reporterPanel = IncatComponents.JPanelFactory(new JComponent[] {
      this.reporter, null,
      new JLabel("Reporter *"), null,
      this.versionSpecific, this.versionLatest, null
    });
    JPanel resourcePanel = IncatComponents.JPanelFactory(new JComponent[] {
      this.resource, null,
      new JLabel("Resource Group *"), null
    });
    JPanel topHalf = IncatComponents.JPanelFactory(new JComponent[] {
      reporterPanel, resourcePanel, this.argsPanel, null,
      this.description, null,
      new JLabel(" "), null, // vertical spacing
      IncatComponents.JPanelFactory(new JComponent[] {
        new JLabel("Run Every"), this.cronStep, this.cronUnit,
        new JLabel("From"), this.cronFrom, this.cronSpec,
        null
      }), null,
    }, false);
    JPanel bottomHalf = IncatComponents.JPanelFactory(new JComponent[] {
      new JLabel("Nickname "), this.nickname, null,
      new JLabel("Context "), contextScroll, null,
      new JLabel("Limits "),
      IncatComponents.JPanelFactory(new JComponent[] {
        new JLabel("CPU (Secs) "), this.limitCpu,
        new JLabel(" Wall (Secs) "), this.limitWall,
        new JLabel(" Memory (MB) "), this.limitMemory, null
      }), null,
      new JLabel("Comparison "), this.acceptedExpr, null,
      new JLabel("Notification Email "), this.acceptedEmail, null,
      IncatComponents.JPanelFactory(new JComponent[] {
        IncatComponents.JButtonFactory("Cancel", cancelCommand, listener),
        IncatComponents.JButtonFactory("Ok", okCommand, this), null
      })
    }, false);
    this.setContentPane(IncatComponents.JPanelFactory(new JComponent[] {
      topHalf, null,
      new JSeparator(), null,
      bottomHalf, null
    }));
    this.setTitle("Incat Series Dialog");
    this.pack();
    this.listener = listener;
  }

  /**
   * Copies information from the series dialog into a specified series.
   *
   * @param series the series to update
   */
  public void getSeries(WrapSeries series) {
    String prop;
    WrapReporter reporter = (WrapReporter)this.reporter.getSelectedElement();
    prop = this.acceptedExpr.getText();
    if(prop.equals("")) {
      series.setAcceptedComparitor(null);
      series.setAcceptedComparison(null);
      series.setAcceptedTarget(null);
    } else {
      series.setAcceptedComparitor("ExprComparitor");
      series.setAcceptedComparison(prop);
      prop = this.acceptedEmail.getText();
      series.setAcceptedTarget(prop.equals("") ? null : prop);
    }
    series.setCron(this.cronSpec.getText());
    series.setNickname(this.nickname.getText());
    prop = this.limitCpu.getText();
    series.setCpuLimit(prop.equals("") ? 0 : Float.parseFloat(prop));
    prop = this.limitMemory.getText();
    series.setMemoryLimit(prop.equals("") ? 0 : Float.parseFloat(prop));
    prop = this.limitWall.getText();
    series.setWallClockLimit(prop.equals("") ? 0 : Float.parseFloat(prop));
    series.setReporter(reporter.getProperty("name"));
    series.setReporterVersion
      (this.versionLatest.isSelected()?null:reporter.getProperty("version"));
    series.setResource
      (((WrapResource)this.resource.getSelectedElement()).getName());
    series.setContext(this.context.getText());
    Properties args = new Properties();
    for(Enumeration e = this.argWidgets.keys(); e.hasMoreElements(); ) {
      String name = (String)e.nextElement();
      args.setProperty(name, ((ArgPanel)argWidgets.get(name)).getValue());
    }
    series.setArgs(args);
  }

  /**
   * Sets the set of reporters to display in the series dialog.
   *
   * @param reporters the reporters to display
   */
  public void setReporterChoices(Object[] reporters) {
    this.reporter.setElements(reporters);
    this.reporter.sort();
    this.reporter.setSelectedIndex(0);
  }

  /**
   * Sets the set of resources to display in the series dialog.
   *
   * @param resources the resources to display
   */
  public void setResourceChoices(Object[] resources) {
    this.resource.setElements(resources);
    this.resource.sort();
    this.resource.setSelectedIndex(0);
  }

  /**
   * Copies information from the specified series into the series dialog.
   *
   * @param series the series to show
   */
  public void setSeries(WrapSeries series) {

    Properties args = series.getArgs();
    float limitCpu = series.getCpuLimit();
    float limitMemory = series.getMemoryLimit();
    float limitWall = series.getWallClockLimit();
    String seriesReporter = series.getReporter();
    String seriesResource = series.getResource();
    String seriesVersion = series.getReporterVersion();

    this.acceptedExpr.setText(series.getAcceptedComparison());
    this.acceptedEmail.setText(series.getAcceptedTarget());
    this.cronSpec.setText(series.getCron());
    updateCronWidgets();
    this.nickname.setText(series.getNickname());
    this.limitCpu.setText(limitCpu > 0 ? limitCpu + "" : "");
    this.limitMemory.setText(limitMemory > 0 ? limitMemory + "" : "");
    this.limitWall.setText(limitWall > 0 ? limitWall + "" : "");

    // Search for a matching reporter name and, if applicable, version
    int index = 0;
    String unknownMessage = "Unknown reporter " + seriesReporter;
    if(!seriesReporter.equals("")) {
      for(index = this.reporter.getElementCount() - 1; index >= 0; index--) {
        WrapReporter reporter = (WrapReporter)this.reporter.getElementAt(index);
        if(seriesReporter.equals(reporter.getProperty("name"))) {
          if(seriesVersion == null ||
             seriesVersion.equals(reporter.getProperty("version"))) {
            break;
          }
          unknownMessage =
            "Unknown reporter version " + seriesReporter + " " + seriesVersion;
        }
      }
    }
    // Tell the user and add a dummy if no reporter matches
    if(index < 0) {
      JOptionPane.showMessageDialog
        (this, unknownMessage + "\nCreating temporary entry in reporter list",
         "Incat Message", JOptionPane.ERROR_MESSAGE);
      String argsValue = "";
      for(Enumeration e = args.keys(); e.hasMoreElements(); ) {
        argsValue += ";" + (String)e.nextElement() + " .*";
      }
      WrapReporter dummyReporter = new WrapReporter(new Properties());
      dummyReporter.setProperty("arguments", argsValue.substring(1));
      dummyReporter.setProperty("name", seriesReporter);
      dummyReporter.setProperty
        ("version", seriesVersion == null ? "0" : seriesVersion);
      this.reporter.addElement(dummyReporter);
      index = this.reporter.getElementCount() - 1;
    }
    this.reporter.setSelectedIndex(index);
    this.versionSpecific.setSelected(seriesVersion != null);
    this.versionLatest.setSelected(seriesVersion == null);

    // Same search/notification for resource name
    this.resource.setSelectedIndex(0);
    if(!seriesResource.equals("")) {
      for(index = this.resource.getElementCount() - 1; index >= 0; index--) {
        WrapResource resource = (WrapResource)this.resource.getElementAt(index);
        if(seriesResource.equals(resource.getName())) {
          break;
        }
      }
    }
    if(index < 0) {
      JOptionPane.showMessageDialog
        (this, "Unknown resource " + seriesResource +
         "\nCreating temporary entry in resource list",
         "Incat Message", JOptionPane.ERROR_MESSAGE);
      WrapResource dummyResource = new WrapResource();
      dummyResource.setName(seriesResource);
      this.resource.addElement(dummyResource);
      index = this.resource.getElementCount() - 1;
    }
    this.resource.setSelectedIndex(index);

    this.context.setText(series.getContext(), "");
    updateReporterInfo();
    for(Enumeration e = args.keys(); e.hasMoreElements(); ) {
      String name = (String)e.nextElement();
      ArgPanel widget = (ArgPanel)this.argWidgets.get(name);
      if(widget != null) {
        widget.setValue(args.getProperty(name));
      }
    }

  }

  /**
   * An action listener that checks for required fields on dialog exit and
   * modifies the dialog when reporter or cron changes.
   */
  public void actionPerformed(ActionEvent ae) {
    String action = ae.getActionCommand();
    if(action.equals("argreset")) {
      for(Enumeration e = this.argWidgets.keys(); e.hasMoreElements(); ) {
        ((ArgPanel)argWidgets.get((String)e.nextElement())).resetValue();
      }
    } else if(action.equals("cronspecchange")) {
      updateCronWidgets();
    } else if(action.equals("cronunitchange")) {
      updateCronSpec(true);
    } else if(action.equals("cronwidgetchange")) {
      updateCronSpec(false);
    } else if(action.equals("reporterchange")) {
      updateReporterInfo();
    } else if(action.equals("reportershow")) {
      showReporterSource();
    } else {
      // Only required fields are combo boxes, so can't be blank
      // Check to make sure any AcceptedOutput expression is parsable.
      String prop = this.acceptedExpr.getText();
      if(!prop.equals("")) {
        // Turn macro references into simple symbol references
        prop = prop.replaceAll("@", " ");
        String err = ExprEvaluator.eval(prop, new Properties(), "");
        if(err != null && !err.startsWith(ExprEvaluator.FAIL_EXPR_FAILED)) {
          JOptionPane.showMessageDialog
            (this, "Bad expression for output test: " + err,
             "Incat Message", JOptionPane.ERROR_MESSAGE);
          return;
        }
      }
      // Check that any limits are valid float values
      String[] limits = new String[] {
        this.limitCpu.getText(), this.limitMemory.getText(),
        this.limitWall.getText()
      };
      for(int i = 0; i < limits.length; i++) {
        if(!limits[i].equals("")) {
          try {
            Float.parseFloat(limits[i]);
          } catch(Exception e) {
            JOptionPane.showMessageDialog
              (this, "Limit '" + limits[i] + "' is not a valid float value",
               "Incat Message", JOptionPane.ERROR_MESSAGE);
            return;
          }
        }
      }
      this.listener.actionPerformed(ae);
    }
  }

  /**
   * Displays the source of the currently-selected reporter.
   */
  protected void showReporterSource() {
    try {
      IncatRepositoryDialog dialog = new IncatRepositoryDialog();
      dialog.setReporter(this.reporter.getSelectedElement().toString());
      dialog.show();
    } catch(Exception e) {
      // empty
    }
  }

  /**
   * Updates the cron text spec based on the values of the cron widgets.
   *
   * @param unitChange indicates whether or not the method is responding to a
   *                   change in the cron units widget
   */
  protected void updateCronSpec(boolean unitChange) {
    String from = (String)this.cronFrom.getSelectedItem();
    String step = (String)this.cronStep.getSelectedItem();
    int unit = this.cronUnit.getSelectedIndex();
    String[] spec = new String[] {"*", "*", "*", "*", "*"};
    for(int i = 0; i < unit; i++) {
      spec[i] = "?";
    }
    // Since different units have different lower bounds, we treat 0 and 1 as
    // equivalent and make adjustments when the unit changes
    if(unitChange && (from.equals("0") || from.equals("1"))) {
      from = CRON_UNIT_MIN[unit];
    }
    if(!from.equals(CRON_UNIT_MIN[unit])) {
      spec[unit] =
        (from.equals("random") ? "?" : from) + "-" + CRON_UNIT_MAX[unit];
    }
    if(!step.equals("1")) {
      spec[unit] += "/" + step;
    }
    this.cronSpec.setText(StringMethods.join(" ", spec));
  }

  /**
   * Updates the cron widgets based on the values of the cron text spec.
   */
  protected void updateCronWidgets() {
    String spec = this.cronSpec.getText();
    String[] pieces = spec.split(" ");
    // NOTE: invoking setSelectedIndex on a JComboBox apparently fires its
    // action listeners, so we have to temporarily remove the action from the
    // cron widgets to avoid invoking updateCronSpec.
    this.cronFrom.setActionCommand("");
    this.cronStep.setActionCommand("");
    this.cronUnit.setActionCommand("");
    String unrepresentable = "";
    int unit;
    for(unit = 0;
        unit < pieces.length - 1 && pieces[unit].matches("^(\\?|[0-9]+)$");
        unit++) {
      // empty
    }
    this.cronUnit.setSelectedIndex(unit);
    String piece = pieces[unit];
    int pos;
    if((pos = piece.indexOf("/")) >= 0) {
      IncatComponents.setJComboBoxSelectedString
        (this.cronStep, piece.substring(pos + 1));
      piece = piece.substring(0, pos);
    } else {
      IncatComponents.setJComboBoxSelectedString(this.cronStep, "1");
    }
    if((pos = piece.indexOf(",")) >= 0) {
      piece = piece.substring(0, pos);
      unrepresentable += ", lists";
    }
    if(piece.equals("*")) {
      piece = CRON_UNIT_MIN[unit];
    } else if((pos = piece.indexOf("-")) >= 0) {
      String max = piece.substring(pos + 1);
      piece = piece.substring(0, pos);
      if(!max.equals(CRON_UNIT_MAX[unit])) {
        unrepresentable += ", upper range bound";
      }
    } else {
      unrepresentable += ", run once";
    }
    IncatComponents.setJComboBoxSelectedString
      (this.cronFrom, piece.equals("?") ? "random" : piece);
    if(!unrepresentable.equals("")) {
      unrepresentable = unrepresentable.substring(2); // Trim leading ", "
      JOptionPane.showMessageDialog
        (this, "Note: the cron textbox uses crontab features that cannot " +
               "be represented in the pull-down components: " + unrepresentable,
         "Incat Message", JOptionPane.INFORMATION_MESSAGE);
    }
    this.cronFrom.setActionCommand("cronwidgetchange");
    this.cronStep.setActionCommand("cronwidgetchange");
    this.cronUnit.setActionCommand("cronunitchange");
  }

  /**
   * Updates the arg, nickname, and description widgets based on the value of
   * the reporter widget.
   */
  protected void updateReporterInfo() {

    final String hiddenArgs = "help verbose version";
    this.argsPanel.removeAll();
    this.argWidgets = new Hashtable();
    WrapReporter reporter = (WrapReporter)this.reporter.getSelectedElement();
    if(reporter != null) {
      String prop = reporter.getProperty("description");
      if(prop == null) {
        prop = "";
      } else if(prop.length() > MAX_REPORTER_DOC_LENGTH) {
        prop = prop.substring(0, MAX_REPORTER_DOC_LENGTH - 3) + "...";
      }
      this.description.setText("(" + prop + ")");
      prop = reporter.getProperty("name");
      this.context.setText(this.context.getText(), prop);
      prop = reporter.getProperty("version");
      if(prop == null) {
        prop = "0";
      }
      this.versionSpecific.setText("Use Version " + prop + " Only");
      String nickname = this.nickname.getText();
      if(nickname.equals("") ||
         this.reporter.findMatchingElement(nickname) >= 0) {
        this.nickname.setText(reporter.toString());
      }
      prop = reporter.getProperty("arguments");
      if(prop != null) {
        String[] args = prop.split(";");
        ArrayList widgets = new ArrayList();
        for(int i = 0; i < args.length; i++) {
          String[] pieces = args[i].split(" ");
          String argName = pieces[0];
          String argPat = pieces[1];
          String dephault = pieces.length <= 2 ? "" : pieces[2];
          // See if we can list all the choices the argument pattern accepts.
          String[] choices = null;
          try {
            choices = (String [])
              (new ExpandablePattern(argPat).expand().toArray(new String[0]));
            Arrays.sort(choices);
          } catch(Exception e) {
            // empty
          }
          JPanel widget =  new ArgPanel(argName, choices, dephault);
          this.argWidgets.put(argName, widget);
          if(hiddenArgs.indexOf(argName) < 0) {
            widgets.add(widget);
            widgets.add(null); // Put each widget in a separate row
          }
        }
        this.argsPanel.removeAll();
        this.argsPanel.add(IncatComponents.JPanelFactory(new JComponent[] {
          IncatComponents.JPanelFactory(
            (JComponent[])widgets.toArray(new JComponent[widgets.size()]), false
          ), null,
          IncatComponents.JPanelFactory(new JComponent[] {
            IncatComponents.JButtonFactory("Reset to Defaults","argreset",this), null,
            new JLabel("Arguments", JLabel.CENTER), null
          }), null
        }));
      }
    }
    this.pack();

  }

  /**
   * A JPanel for displaying and allowing the user to change the value of a
   * single reporter argument.
   */
  public class ArgPanel extends JPanel {

    private String dephault;
    private JComponent widget;

    /**
     * Constructs a new ArgPanel.
     *
     * @param name the name of the argument
     * @param choices the list of valid argument values; null for text args
     * @param dephault the default value for the argument
     */
    public ArgPanel(String name, String[] choices, String dephault) {
      super(new BorderLayout());
      if(choices == null) {
        this.widget = new JTextField(20);
      } else {
        this.widget = new JComboBox(choices);
      }
      this.add(IncatComponents.JPanelFactory(new JComponent[] {
        new JLabel(name + " "), this.widget, null
      }, false), BorderLayout.WEST);
      this.dephault = dephault;
      this.resetValue();
    }

    /**
     * Returns the selected value of the argument.
     *
     * @return the argument value
     */
    public String getValue() {
      return this.widget instanceof JComboBox ?
        (String)((JComboBox)widget).getSelectedItem() :
        ((JTextField)widget).getText();
    }

    /**
     * Sets the argument value to its default.
     */
    public void resetValue() {
      this.setValue(this.dephault);
    }

    /**
     * Sets the argument value to a specific value.
     *
     * @param value the new argument value
     */
    public void setValue(String value) {
      if(this.widget instanceof JComboBox) {
        IncatComponents.setJComboBoxSelectedString
          ((JComboBox)this.widget, value);
      } else {
        ((JTextField)this.widget).setText(value);
      }
    }

  }

}
