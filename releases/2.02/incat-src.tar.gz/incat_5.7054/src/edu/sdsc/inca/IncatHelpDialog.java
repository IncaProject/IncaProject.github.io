package edu.sdsc.inca;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.LinkedList;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

/**
 * A Dialog window that gives help information about the incat tool.
 */
public class IncatHelpDialog extends JDialog
  implements ActionListener, HyperlinkListener {

  public static final String INCAT_SECTION = "USERGUIDE-INCAT";
  public static final String REPOSITORIES_SECTION = INCAT_SECTION + "-REPOS";
  public static final String RESOURCE_EDITOR_SECTION =
    INCAT_SECTION + "-RESOURCE-EDITOR";
  public static final String RESOURCES_SECTION = INCAT_SECTION + "-RESOURCES";
  public static final String SERIES_EDITOR_SECTION =
    INCAT_SECTION + "-SERIES-EDITOR";
  public static final String SUITES_SECTION = INCAT_SECTION + "-SUITES";
  
  protected static final String BACKUP_HELP_FILE =
    "edu/sdsc/inca/incahelp.html";
  protected static final String USERGUIDE_URL =
    "http://inca.sdsc.edu/releases/latest/guide/userguide.html";

  protected JButton back;
  protected LinkedList backUrls;
  protected JEditorPane editor;
  protected JButton forward;
  protected LinkedList forwardUrls;

  /**
   * Constructs an IncatHelpDialog.
   */
  public IncatHelpDialog() {
    this.back = IncatComponents.JButtonFactory("Back", "back", this);
    this.backUrls = new LinkedList();
    this.editor = new JEditorPane();
    this.editor.addHyperlinkListener(this);
    this.editor.setEditable(false);
    this.forward = IncatComponents.JButtonFactory("Forward", "forward", this);
    this.forwardUrls = new LinkedList();
    JScrollPane scroller = new JScrollPane(this.editor);
    scroller.setPreferredSize(new Dimension(750, 600));
    this.setContentPane(IncatComponents.JPanelFactory(new JComponent[] {
      this.back, this.forward, null,
      scroller
    }));
    this.setTitle("Incat Help");
    this.pack();
    this.setSection(INCAT_SECTION);
  }

  /**
   * If the dialog is visible, fills the editor with the contents of the URL at
   * the tail of backUrls.
   */
  protected void redraw() {
    if(!this.isVisible() || this.backUrls.size() == 0) {
       return;
    }
    String newPage = (String)this.backUrls.getLast();
    try {
      this.editor.setPage(newPage);
    } catch(Exception e) {
      URL helpUrl;
      if(!newPage.startsWith(USERGUIDE_URL)) {
        JOptionPane.showMessageDialog
          (this, "Unable to access " + newPage + ":\n" + e,
           "Incat Message", JOptionPane.ERROR_MESSAGE);
      } else if((helpUrl = ClassLoader.getSystemClassLoader().
                             getResource(BACKUP_HELP_FILE)) == null) {
        JOptionPane.showMessageDialog
          (this, "Unable to open help file:\n" + e,
           "Incat Message", JOptionPane.ERROR_MESSAGE);
      } else {
        JOptionPane.showMessageDialog
          (this, "Online help is unavailable:\n" + e,
           "Incat Message", JOptionPane.INFORMATION_MESSAGE);
        newPage = newPage.replaceFirst(USERGUIDE_URL, helpUrl.toString());
        this.backUrls.removeLast();
        this.backUrls.addLast(newPage);
        this.redraw();
      }
    }
  }

  /**
   * Sets the help display to show a particular section of the incat user doc.
   *
   * @param section one of the section constants defined above
   */
  public void setSection(String section) {
    this.backUrls.addLast(USERGUIDE_URL + "#" + section);
    this.forwardUrls.clear();
    this.redraw();
  }

  /**
   * Makes the help dialog visible or invisible.
   *
   * @param visible true to make the dialog visible; false to make it invisible
   */
  public void setVisible(boolean visible) {
    super.setVisible(visible);
    this.redraw();
  }

  /**
   * Invoked when the user presses either "Back" or "Forward" buttons.
   */
  public void actionPerformed(ActionEvent ae) {
    String command = ae.getActionCommand();
    if(command.equals("back")) {
      if(this.backUrls.size() > 1) {
        this.forwardUrls.addFirst(this.backUrls.removeLast());
        this.redraw();
      }
    } else if(command.equals("forward")) {
      if(this.forwardUrls.size() > 0) {
        this.backUrls.addLast(this.forwardUrls.removeFirst());
        this.redraw();
      }
    }
  }

  /**
   * Invoked when the user presses a hyperlink.
   */
  public void hyperlinkUpdate(HyperlinkEvent he) {
    if(he.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
      this.backUrls.addLast(he.getURL().toString());
      this.forwardUrls.clear();
      this.redraw();
    }
  }

}
