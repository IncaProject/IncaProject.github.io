package edu.sdsc.inca.agent;

import java.util.Vector;
import java.util.Calendar;
import java.io.*;
import java.net.SocketTimeoutException;

import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.Agent;
import edu.sdsc.inca.util.WorkQueue;
import edu.sdsc.inca.util.Constants;
import edu.sdsc.inca.util.StringMethods;
import edu.sdsc.inca.dataModel.util.Series;
import edu.sdsc.inca.dataModel.catalog.PackageType;
import edu.sdsc.inca.dataModel.catalog.CatalogDocument;
import edu.sdsc.inca.dataModel.suite.SuiteDocument;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.ManagerClient;
import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;

/**
 * Manages a reporter manager instance on a remote machine. It maintains
 * a persistent connection to the manager and provides the
 * ability to send packages and suites to the remote reporter manager.  It
 * also has the ability to detect a fault of the reporter manager by regularly
 * pinging it and and restarting it if necessary.
 *
 * @author Shava Smallen
 */
public class ReporterManagerController  {

  // Constants
  final static public int ISREADY_PERIOD = 5 * Constants.MILLIS_TO_SECOND;
  final static private String PING_DATA = "manager";
  final static public int SUITE_CHECK_PERIOD = 5 * Constants.MILLIS_TO_SECOND;

  private static Logger logger = Logger.getLogger(ReporterManagerController.class);

  // Member variables
  protected Agent                agent = null;
  private ReporterManagerStarter rmStarter = null;
  private CatalogDocument        catalog = null;
  private File                   catalogFile = null;
  private boolean                isRunning = false;
  private boolean                needToShutdown = false;
  private ManagerClient          managerClient = new ManagerClient();
  private ReporterManagerProxy   proxy = null;
  private String                 resource = null;
  private boolean                shutdownDetected = false;
  private WorkQueue              work = new WorkQueue();
  private String                 tempDir = null;


  /**
   * Create a reporter manager object which will manage a  instance of a
   * reporter manager on a remote resource.
   *
   * @param resource   Name of the resource (from the resource configuration
   *                   file) to start the reporter manager on.
   * @param agent
   * @throws ConfigurationException  if there is missing configuration information
   * for the resource.
   */
  public ReporterManagerController( String resource, Agent agent )
    throws ConfigurationException {

    // properties read in from agent configuration
    this.resource = resource;
    this.agent = agent;
    this.setTempDir( agent.getTempPath() );
    this.rmStarter = new ReporterManagerStarter( resource, agent );

    // e.g., var/rm/resource
    catalogFile = new File( this.tempDir + File.separator + "catalog.xml" );
    if ( catalogFile.exists() ) {
      try {
        catalog = CatalogDocument.Factory.parse( catalogFile );
        logger.info(
          "Read reporter manager packages list from '" + catalogFile + "'"
        );
      } catch ( Exception e ) {
        logger.error("Unable to read existing packages file for " + resource,e);
      }
    } else {
      catalog = CatalogDocument.Factory.newInstance();
      catalog.addNewCatalog();
      catalogFile.getParentFile().mkdirs();
      try {
        XmlOptions xmloptions = new XmlOptions();
        xmloptions.setSavePrettyPrint();
        catalog.save( catalogFile, xmloptions );
      } catch ( IOException e ) {
        throw new ConfigurationException(
          "Cannot create packages file '" + catalogFile.getAbsolutePath() + "'",
          e );
      }
      logger.info("Creating new packages file for resource '" + resource + "'");
    }

    try {
      this.setProxy (new ReporterManagerProxy(resource, agent.getResources()));
    } catch ( ConfigurationException e ) {
      logger.debug
        ( "Proxy renewal turned off for resource '" + resource + "': " + e );
    }
  }

  /**
   * Create a new reporter manager object, whose configuration is identical to
   * rm, which will manage an instance of a reporter manager on a remote resource.
   *
   * @param rm  A reporter manager object that will be used to configure this
   * reporter manager object.
   */
  public ReporterManagerController( ReporterManagerController rm ) {

    this.agent = rm.agent;
    this.catalog = rm.catalog;
    this.catalogFile = rm.catalogFile;
    this.proxy = rm.proxy;
    this.resource = rm.resource;
    this.rmStarter = new ReporterManagerStarter(rm.getReporterManagerStarter());
    this.tempDir = rm.tempDir;
  }

  /**
   * Add the specified package to the work queue so that the register
   * thread can pick it up and send it to the reporter manager.
   *
   * @param packageName  The name of the package to send to the remote reporter
   * manager.
   */
  public void addPackage( String packageName ) {
    logger.info(
      "Adding package " + packageName + " to the queue for " + resource
    );
    this.work.addWork( packageName );
    logger.info( "Package " + packageName + " added to queue for " + resource );
  }


  /**
   * Add the specified suite to the work queue so that the register
   * thread can pick it up and send it to the reporter manager.
   *
   * @param suite  A suite document to send to the reporter manager.
   */
  public void addSuite( SuiteDocument suite ) {
    logger.info( "Adding suite to the queue for " + resource );
    this.work.addWork( suite );
    logger.info( "Suite added to queue for " + resource );
  }

  /**
   * Extract the reporters from the specified suite document
   * which do not already exist on the remote reporter manager.
   *
   * @param s  A suite document that will be sent to the reporter manager
   *
   * @return  An array of reporter packages that exist in the suite and
   * do not exist on the remote reporter manager.
   */
  public PackageType[] extractReportersFromSuite( SuiteDocument s ){
    Vector packages = new Vector();
    XmlObject[] result = s.selectPath( "//series" );
    for ( int i = 0; i < result.length; i++) {
      Series series = (Series)result[i];
      if ( ! this.hasPackage(series.getName(), series.getVersion()) ) {
        // don't add the same package to packages twice
        int j = 0;
        for ( ; j < packages.size(); j++ ) {
          PackageType pkgToAdd = (PackageType)packages.get(j);
          if ( series.getName().equals(pkgToAdd.getName()) ) {
            if ( series.isSetVersion() ) {
              if ( series.getVersion().equals(pkgToAdd.getVersion()) ) break;
            } else {
              if ( pkgToAdd.isSetLatestVersion() ) break;
            }
          }
        }
        if ( j >= packages.size() ) {
          PackageType pkgToSend = this.agent.getRepositoryCache().getPackage(
            series.getName(), series.getVersion()
          );
          if ( pkgToSend != null ) {
            packages.add( pkgToSend );
          } else {
            logger.error
              ( "Unable to find reporter " + series.getName() + ", version= " +
                series.getVersion() + " in reporter cache");
          }
        }
      }
    }
    return (PackageType[])packages.toArray( new PackageType[packages.size()] );
  }

  /**
   * Return the client connection to the remote reporter manager.
   *
   * @return  The manager client object connected to the remote reporter
   * manager.
   */
  public ManagerClient getManagerClient() {
    return managerClient;
  }

  /**
   * Return the packages that are installed on the reporter manager.
   *
   * @return A property list of packages that are installed on the reporter
   * manager where the package names are the "name" and package versions are
   * the "value".
   */
  public PackageType[] getPackages() {
    return catalog.getCatalog().getPackageArray();
  }

  /**
   * Return the proxy object for this resource.
   *
   * @return A ReporterManagerProxy object containing the proxy information
   * for this resource or null if it does not exist.
   */
  public ReporterManagerProxy getProxy() {
    return this.proxy;
  }

  /**
   * Return the name of this resource.
   *
   * @return The name of the resource the reporter manager will execute on.
   */
  public String getResource() {
    return resource;
  }

  /**
   * Return true if the reporter manager is currently registered and running.
   *
   * @return  True if the reporter manager is currently registered and running
   * and false otherwise.
   */
  public boolean isRunning() {
    return isRunning;
  }

  public ReporterManagerStarter getReporterManagerStarter() {
    return rmStarter;
  }

  /**
   * Gets the directory path where the temporary files can be stored.
   *
   * @return  A path to a local directory.
   */
  public String getTemporaryDirectory() {
    return tempDir;
  }

  /**
   * Return true if the manager has been sent the given package; otherwise
   * return false.
   *
   * @param name      The name of the package to check for.
   *
   * @param version   The version of the package to check for.
   *
   * @return  true if the manager has been sent the given package; otherwise
   * return false.
   */
  public boolean hasPackage( String name, String version ) {

    PackageType[] pkgs = catalog.getCatalog().getPackageArray();
    for ( int i = 0; i < pkgs.length; i++) {
      if ( name.equals(pkgs[i].getName())  ) {
        if ( version == null ) {
          if ( pkgs[i].isSetLatestVersion() ) {
            return true;
          }
        } else {
          if ( version.equals(pkgs[i].getVersion()) ) {
            return true;
          }
        }
      }
    }
    return false;
  }

  /**
   * Return whether or not proxy information is listed for this resource.
   *
   * @return True if proxy information is available for this resource; otherwise
   * false.
   */
  public boolean hasProxy() {
    return this.proxy != null;
  }

  /**
   * Pings the reporter manager to check whether it is still running on the
   * remote resource and returns the status.
   *
   * @return  True if the reporter manager responded to the ping and false
   * otherwise.
   */
  public boolean isRemoteManagerAlive() throws SocketTimeoutException {
    try {
      this.managerClient.commandPing( PING_DATA  + " " + resource );
    } catch ( SocketTimeoutException e ) {
      throw new SocketTimeoutException(
        "Socket timeout caught during ping of manager"
      );
    } catch ( IOException e ) {
      logger.error(
        "Unable to ping reporter manager '" + resource + "' assuming down: " + e
      );
      return false;
    } catch ( ProtocolException e ) {
      logger.error(
        "Unexpected response to ping of reporter manager '" + resource +
        "': " +  e + "; continuing operation"
      );
      // let's see if we can still continue
      return true;
    }
    return true;
  }

  /**
   * Register the specified reporter manager with the agent so that the
   * agent can send it commands.  Holds a socket connection open to the reporter
   * manager and loops indefinitely (until a shutdown) to send requests to the
   * reporter manager. Initially, the agent will retrieve any existing
   * suites for the reporter manager and empty its work queue (since
   * any pending work should already be incorporated into the suites.
   * Following that requests (currently suites only) are retrieved
   * from a work queue.  Work is added to the work queue, for example, when a
   * client sends the agent a suite request
   *
   * @param reader  the ProtocolReader for reading responses from the remote
   * reporter manager.
   * @param writer  the ProtocolWriter for sending commands to the remote
   */
  public void register(
    ProtocolReader reader, ProtocolWriter writer ) {
    logger.debug( "Entering register for resource " + resource );

    this.managerClient.setReader( reader );
    this.managerClient.setWriter( writer );
    this.setRunning( true );

    this.agent.reinitializeManagerWorkQueue( resource, this.work );

    // now wait for any changes to the schedule
    long lastPingTime = Calendar.getInstance().getTimeInMillis();
    while ( true ) {
      if ( isBeingShutdown() ) break;
      long now = Calendar.getInstance().getTimeInMillis();
      if ( (now - lastPingTime) >= this.agent.getPingPeriod() ) {
        lastPingTime = now;
        try {
          if ( ! isRemoteManagerAlive() ) {
            restart();
            break;
          }
        } catch ( SocketTimeoutException e ) {
          logger.info(
            "Caught socket timeout during ping of manager " + resource
          );
        }
      }
      // wait around until an action needs to be sent to the remote reporter
      // manager
      Object work = null;
      try {
        if ( this.work.isEmpty() ) { // we wait until there is
          Thread.sleep( SUITE_CHECK_PERIOD ); // something in the queue
          continue;
        }
        logger.info("Retrieving work for reporter manager '" + resource + "'" );
        work = this.work.getWork();
      } catch ( InterruptedException e ) {
        logger.info( "Received interrupt in register: " + e );
        break;
      }

      try {
        if ( SuiteDocument.class.isAssignableFrom(work.getClass()) ) {
          this.sendSuite( (SuiteDocument)work );
        } else if ( work.getClass().equals(String.class) ) {
          this.sendPackage(
            this.agent.getRepositoryCache().getPackage(
              (String)work, null
            )
          );
        } else {
          logger.error(
            "Received unknown work " + work.getClass().getName() +
            " for resource " + resource
          );
        }
      } catch ( SocketTimeoutException e ) {
        logger.warn( 
          "Received socket timeout while sending suite for " + resource
        );
      } catch ( IOException e ) {
        logger.error(
          "I/O error '" + e +
          "' detected while trying to send suite to '" + resource +
          "' assuming down" );
        restart();
        break;
      } catch ( InterruptedException e ) {
        logger.info(
          "Caught interrupt in while doing work in reporter manager " + resource
        );
        break;
      }
    }
    logger.debug( "Exitting register for resource " + resource );
  }

  /**
   * Send the specified suite and any needed reporters to the remote
   * reporter manager.  Will pass thru an IOException so that it can be
   * addressed (most likely this means the reporter manager died and we need
   * to restart it).  Catches ProtocolExceptions and logs them as errors but
   * will continue operation.
   *
   * @param suiteDoc The suite to send to the remote reporter manager.
   *
   * @throws IOException
   */
  public void sendSuite( SuiteDocument suiteDoc )
    throws IOException, InterruptedException {

    // now an action is the sending of a suite -- first extract any
    // packages that may need to be sent ahead of time
    sendReporters( extractReportersFromSuite( suiteDoc ) );

    // Dependencies should be filled -- send the xml suite
    this.waitUntilReady();
    try {
      this.managerClient.sendSuite( this.resource, suiteDoc );
    } catch ( ProtocolException e ) {
      logger.error(
        "Unexpected result trying to send suite to '" + resource +
        "'; continuing operation: " + e
      );
    }
  }


  /**
   * Set the client connection to the remote reporter manager.
   *
   * @param managerClient  The manager client object connected to the remote reporter
   * manager.
   *
   */
  public void setManagerClient( ManagerClient managerClient ) {
    this.managerClient = managerClient;
  }

  /**
   * Set the proxy renewal information so it can be passed to the  remote
   * reporter manager on registration.
   *
   * @param proxy Contains MyProxy information that can be used to retrieve
   * a new proxy for the remote reporter manager.
   */
  public void setProxy( ReporterManagerProxy proxy ) {
    this.proxy = proxy;
  }


  /**
   * Set the status of the reporter manager to running and notify any
   * waiting threads.
   *
   * @param isRunning  True indicates the reporter manager is running on the
   * remote machine and available; false otherwise.
   */
  public void setRunning( boolean isRunning ) {
    synchronized(this) {
      logger.debug( "Set reporter manager " + resource + " status to running ");
      this.isRunning = isRunning;
      this.getReporterManagerStarter().setRunning( isRunning );
      notifyAll(); // notify anybody who may be waiting on this
    }
  }

  /**
   * Set the location of the temporary directory.
   *
   * @param tempDir  A path to a directory where temporary files can be stored.
   */
  public void setTempDir( String tempDir ) {
    this.tempDir = tempDir + File.separator + Agent.RMDIR + File.separator +
                   resource;
    File dir = new File( this.tempDir );
    if ( ! dir.exists() ) {
      logger.info( "Creating temporary directory '" + this.tempDir + "'" );
      logger.info( "Directories created: " + dir.mkdirs() );
    }
  }

  /**
   * Cleanly shutdown the reporter manager by signaling the register
   * thread to exit and sending an END statement to the remote reporter manager.
   */
  public synchronized void shutdown() {
    // close connection to reporter manager (i.e., shutdown)
    if ( isRunning ) {
      logger.debug( "Signaling '" + resource + "' to shutdown");
      try {
        this.managerClient.getWriter().close();
        this.managerClient.getReader().close();
      } catch ( IOException e ) {
        logger.error(
          "Problem sending shutdown to reporter manager '" + resource + "'", e
        );
      }
      needToShutdown = true;
    } else {
      logger.warn( "Shutdown requested but manager " + resource + " is not running" );

    }

    // signal register thread to exit.  Since register checks for shutdowns
    // periodically, we wait until we hear back from it before exitting.  That
    // way we'll be sure the task is recycled by the time the general shutdown
    // request is issued and it all can go cleanly.
    boolean shutdownComplete = false;
    do {
      try {
        logger.debug( "Agent waiting for reporter manager thread to exit" );
        wait();
        logger.debug( "Reporter manager thread for " + resource + " exitted" );
      } catch ( InterruptedException e ) {
        logger.info( "waiting for reporter manager to shutdown", e );
      }
      shutdownComplete = shutdownDetected;
    } while( ! shutdownComplete );
  }

  /**
   * The reporter manager has one loop where it accepts commands from the
   * agent, does work, and then reads next command.  Sometimes when the
   * work takes longer than 5 seconds, the agent will get back a socket timeout
   * exception while waiting for the reporter manager to reply.  This function
   * addresses this by pinging the reporter manager
   * and catching socket timeout exceptions until successful or unsuccessful
   * ping and then returns.
   *
   * @throws InterruptedException
   */
  public void waitUntilReady() throws InterruptedException {
    while ( true ) {
      try {
        this.isRemoteManagerAlive();
        logger.debug(
          "Reporter manager " + resource + " ready to accept commands"
        );
        return;
      } catch ( SocketTimeoutException e ) {
        logger.debug(
          "Caught socket timeout exception for " + resource + "...ignoring"
        );
        Thread.sleep( ISREADY_PERIOD );
      }
    }
  }

  /* Protected functions */


  /**
   * Send the specified reporters and their package dependencies to the remote
   * reporter manager.
   *
   * @param reporters  A list of reporters to send to the remote reporter
   * manager.
   *
   * @throws IOException
   */
  protected void sendReporters( PackageType[] reporters )
    throws IOException, InterruptedException {

    logger.debug(
      "Sending " + reporters.length + " reporters to reporter manager "+resource
    );
    for ( int i = 0; i < reporters.length; i++ ) {
      sendPackage( reporters[i] );
    }
  }


  /* Private functions */


  /**
   * Check for a shutdown request and if true, notify any waiting threads.
   *
   * @return True if shutdown has been requested and false otherwise
   */
  private synchronized boolean isBeingShutdown() {
    if ( needToShutdown ) {
      logger.info( "Shutdown detected by reporter manager " + resource );
      shutdownDetected = true;
      this.notifyAll();
      return true;
    } else {
      return false;
    }
  }

  /**
   * Restart this reporter manager.  Since you cannot restart a thread we
   * create a duplicate reporter manager object and execute its start method.
   * We then replace the reporter manager in the reporter manager table.
   */
  private synchronized void restart() {
    logger.info( "Attempting reporter manager restart for " + resource );
    if ( isBeingShutdown() ) return;
    if ( this.agent.getAdminEmail() != null ) {
      StringMethods.sendEmail(
        this.agent.getAdminEmail(),
        "inca reporter manager '" + resource + "' restarted",
        "This is a notification from the Inca system that the reporter manager"
        + " executing on resource " + resource + " has been restarted"
      );
    }
    this.rmStarter = new ReporterManagerStarter( resource, agent );
    this.getReporterManagerStarter().start();
  }

  /**
   * Send the named package to the remote reporter manager along with all of
   * its dependencies.
   *
   * @param pkg  The package to send to the remote reporter manager
   *
   * @throws IOException
   */
  private void sendPackage( PackageType pkg )
    throws IOException, InterruptedException {

    // this check may not be needed if I can figure out how null packages
    // are being sent via this function elsewhere -- problem originated from
    // David Spence's deployment
    if ( pkg == null ) {
      logger.error( "Received null package to send...skipping" );
      return;
    }
    String[] dependencies = new String[0];
    if ( pkg.getDependencies() == null ) {
      logger.warn( "package " + pkg.getName() + " has no dependencies" );
    } else {
      dependencies = pkg.getDependencies().getDependencyArray();
      for ( int i = 0; i < dependencies.length; i++ ) {
        if ( ! this.hasPackage( dependencies[i], null) ) {
          sendPackage( this.agent.getRepositoryCache().getPackage(
            dependencies[i], null)
          );
        }
      }
    }

    // send package to RM
    this.waitUntilReady();
    logger.info(
      "Sending package " + pkg.getName() + ", version=" + pkg.getVersion() +
      " to resource '" + resource +"'"
    );
    String dependsToSend = null;
    if ( dependencies.length > 0 ) {
      dependsToSend = StringMethods.join( " ", dependencies );
    }
    try {
      this.managerClient.sendPackage(
        pkg.getFilename(),
        pkg.getInstallPath(),
        pkg.getName(),
        this.agent.getRepositoryCache().getPackageContent(
          pkg.getName(), pkg.getVersion()
        ),
        pkg.getPermissions(),
        dependsToSend,
        pkg.getVersion()
      );
      //update our package listing for this reporter
      int newIndex = catalog.getCatalog().sizeOfPackageArray();
      catalog.getCatalog().insertNewPackage( newIndex );
      catalog.getCatalog().setPackageArray( newIndex, (PackageType)pkg.copy() );
      XmlOptions xmloptions = new XmlOptions();
      xmloptions.setSavePrettyPrint();
      catalog.save( catalogFile, xmloptions );
    } catch ( ProtocolException e ) {
      logger.error(
        "Unexpected result trying to send package " + pkg.getName() + " to '" + resource
        + "'; continuing operation: " + e
      );
    }

  }

 }
