package edu.sdsc.inca.agent.access;

import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.AgentTest;
import edu.sdsc.inca.Agent;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.dataModel.resourceConfig.ResourceConfigDocument;
import edu.sdsc.inca.dataModel.util.Resource;
import edu.sdsc.inca.dataModel.util.Macros;
import edu.sdsc.inca.dataModel.util.Macro;
import edu.sdsc.inca.util.ResourcesWrapper;
import edu.sdsc.inca.util.ResourcesWrapperTest;

import java.util.Hashtable;
import java.util.Iterator;
import java.net.InetAddress;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;


/**
 * Test the Globus class.
 */
public class GlobusTest extends AccessMethodTestCase {
  Logger logger = Logger.getLogger(this.getClass().toString());
  private String resource = null;

  public void setUp() throws Exception {
    resource = AgentTest.TEST_RESOURCE + "-globus";
    logger.info( "Looking for resource " + resource );
    ResourcesWrapper resources = ResourcesWrapperTest.createSampleResources();
    if ( resources.getResources(resource,true).length < 1 ) {
      throw new ConfigurationException(
        "Resource '" + resource + "' not in resource file '" +
        AgentTest.RESOURCES_FILE + "'"
      );
    }
    procs = new Globus[] {
      new Globus( resource, resources, "/tmp", "GT2" ),  // with proxy
      new Globus( resource, resources, "/tmp", "GT2" )  // w/o proxy
    };
    ((Globus)procs[1]).setProxy( null);
    InetAddress addr = InetAddress.getLocalHost();
    System.setProperty( Agent.GLOBUS_IP_PROPERTY, addr.getHostAddress() );
  }

  public boolean hasRequirements() {
    return AgentTest.hasGlobusServer();
  }

  /*
  * Test the constructor
  */
  public void testConfiguration() throws Exception {
    // normal
    ResourcesWrapper resources = ResourcesWrapperTest.createSampleResources();
    new Globus( resource, resources, "/tmp", "GT2" );

    // cases
    String resourceName = "testGlobus";
    Hashtable macros = new Hashtable();
    checkContact(
      resourceName,
      macros,
      resourceName + ":" + Protocol.GLOBUS_SERVER_PORT_MACRO_DEFAULT + "/"
      + Protocol.GRAM_SERVICE_MACRO_DEFAULT
    );

    macros.put( Protocol.GRAM_SERVICE_MACRO, "jobmanager-fork" );
    checkContact(
      resourceName,
      macros,
      resourceName + ":" + Protocol.GLOBUS_SERVER_PORT_MACRO_DEFAULT + "/"
      + "jobmanager-fork"
    );

    macros.put( Protocol.COMPUTE_PORT_MACRO, "2118" );
    checkContact( resourceName, macros, resourceName + ":2118/jobmanager-fork");

    macros.put( Protocol.GRAM_DN_MACRO, "/mydn" );
    checkContact
      ( resourceName, macros, resourceName + ":2118/jobmanager-fork:/mydn");
  }

  // Private Functions

  /**
   * Verify that the gram contact string is valid given the defined macros
   *
   * @param resource  The name of the test resource
   *
   * @param macros   A hashtable containing the defined gram macros
   * 
   * @param expected  The expected gram contact string
   *
   * @throws XmlException
   * @throws ConfigurationException
   */
  private void checkContact(String resource, Hashtable macros, String expected)
    throws XmlException, ConfigurationException {

    ResourcesWrapper resources;
    Globus globus;
    resources = genResources( resource, macros );
    globus = new Globus( resource, resources, "/tmp", "GT2" );
    assertEquals( "gram contact ok", expected, globus.gramContact );
  }

  /**
   * Generate a resource config file with one resource and the macros contained
   * in the provided input hashtable.
   *
   * @param resourceName   The name of the resource
   *
   * @param macros  A hashtable of macro names and values
   *
   * @return A ResourcesWrapper object containing the generated resource
   * config file
   *
   * @throws XmlException
   */
  private ResourcesWrapper genResources( String resourceName, Hashtable macros )
    throws XmlException {

    ResourceConfigDocument rcDoc = ResourceConfigDocument.Factory.newInstance();
    Resource resourceObj =
      rcDoc.addNewResourceConfig().addNewResources().addNewResource();
    resourceObj.setName( resourceName );
    Macros rMacros = resourceObj.addNewMacros();
    Iterator macroIterator = macros.keySet().iterator();
    while( macroIterator.hasNext() ) {
      String macroToAdd = (String)macroIterator.next();
      Macro macro = rMacros.addNewMacro();
      macro.setName( macroToAdd );
      macro.setValueArray( new String[] { (String)macros.get(macroToAdd) } );
    }
    return new ResourcesWrapper( rcDoc );
  }
}
