package edu.sdsc.inca.agent.commands;

import edu.sdsc.inca.protocol.MessageHandler;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.protocol.Statement;
import edu.sdsc.inca.repository.Repositories;
import edu.sdsc.inca.repository.Repository;
import edu.sdsc.inca.Agent;
import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Properties;
import org.apache.log4j.Logger;

public class RepositoryCommands extends MessageHandler {

  Logger logger = Logger.getLogger(this.getClass().toString());

  /**
   * Execute the get/putrepositories command.
   */
  public void execute(ProtocolReader reader,
                      ProtocolWriter writer) {

    try {

      Statement reply = null;
      Statement request = null;

      try {
        request = reader.readStatement();
      } catch(ProtocolException e) {
        logger.error("Protocol exeception " + e + " on command read");
        return;
      }
      String command = new String(request.getCmd());

      if(command.equals(Protocol.CATALOG_GET_COMMAND)) {
        Agent agent = Agent.getGlobalAgent();
        StringBuffer catalog = new StringBuffer();
        Properties[] reporters = new Properties[0];
        String url = new String(request.getData());
        if(url.equals("")) {
          // Force test for reporter updates
          agent.setRepositories(agent.getRepositories().getRepositories());
          reporters = agent.getRepositories().getCatalog();
        } else {
          try {
            reporters = new Repository(new URL(url)).getCatalog();
          } catch(Exception e) {
            logger.error("Unable to read repository " + url);
            reply = Statement.getErrorStatement
              ("Unable to read repository " + url);
          }
        }
        if(reply == null) {
          for(int i = 0; i < reporters.length; i++) {
              Enumeration e = reporters[i].propertyNames();
              while(e.hasMoreElements()) {
                String key = (String)e.nextElement();
                catalog.append(key).append(":");
                catalog.append(reporters[i].get(key)).append("\n");
              }
              catalog.append("\n");
          }
          reply = Statement.getOkStatement(catalog.toString());
        }
      } else {
        logger.error("Received unrecognized message");
        reply = Statement.getErrorStatement("Unknown command " + command);
      }

      writer.write(reply);

    } catch(IOException e) {
      logger.error("Reply failed", e);
    }

  }

}
