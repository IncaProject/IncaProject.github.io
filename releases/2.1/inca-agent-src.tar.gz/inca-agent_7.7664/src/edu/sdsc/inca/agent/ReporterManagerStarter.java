package edu.sdsc.inca.agent;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;
import org.bouncycastle.openssl.PEMWriter;
import org.bouncycastle.x509.X509V3CertificateGenerator;
import org.bouncycastle.x509.extension.SubjectKeyIdentifierStructure;
import org.bouncycastle.x509.extension.AuthorityKeyIdentifierStructure;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.asn1.x509.BasicConstraints;
import org.bouncycastle.asn1.x509.KeyUsage;

import java.util.Vector;
import java.util.Calendar;
import java.util.regex.Pattern;
import java.io.IOException;
import java.io.File;
import java.io.OutputStreamWriter;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.SecureRandom;
import java.security.PrivateKey;
import java.security.GeneralSecurityException;
import java.security.KeyPairGenerator;
import java.security.KeyPair;
import java.security.cert.X509Certificate;
import java.security.cert.Certificate;
import java.math.BigInteger;

import edu.sdsc.inca.agent.access.Manual;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.Statement;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.util.StringMethods;
import edu.sdsc.inca.util.Constants;
import edu.sdsc.inca.util.ResourcesWrapper;
import edu.sdsc.inca.util.SuiteWrapper;
import edu.sdsc.inca.util.SuiteStagesWrapper;
import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.Component;
import edu.sdsc.inca.Agent;
import edu.sdsc.inca.ManagerClient;
import edu.sdsc.inca.dataModel.suite.SuiteDocument;

/**
 * Handles the creation of a remote reporter manager process on a specified
 * resource.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class ReporterManagerStarter extends Thread {

  // Constants -- directories and temporary files
  final static public String RMBUILDSCRIPT = "buildRM.sh";
  final static public String RMCERT = "rmcert.pem";
  final static public String RMDIST = "Inca-ReporterManager.tar.gz";
  final static public String RMKEY = "rmkey.pem";
  final static public String RMTRUSTED = "trusted";
  final static public String LAST_CHANGE = "suiteChange.xml";
  final static public String CURRENT_SUITE = "updatedSuite.xml";

  // Constants -- cert/key creation
  final static private String SIGNATURE_ALGORITHM = "md5WithRSAEncryption";
  final static private String KEY_ALGORITHM = "RSA";
  final static private String ENC_ALGORITHM = "DESEDE";
  final static private String PROVIDER = "BC"; // BouncyCastle

  final static protected int MANUAL_WAIT_PERIOD = 5*Constants.MILLIS_TO_SECOND;
  private static Logger logger = Logger.getLogger(ReporterManagerStarter.class);

  // Member variables -- to start remote reporter manager
  private Agent             agent = null;
  private String            bashLoginOption = null;
  private String[]          equivHosts = new String[0];
  private String            host = null;
  private int               hostId = 0;
  private boolean           isRunning = false;
  private AccessMethod      processHandle = null;
  private String            resource = null;
  private String            rmRootPath = null;
  private String            tempDir = null;
  private int               waitCheckPeriod =
    Integer.parseInt(Protocol.CHECK_PERIOD_MACRO_DEFAULT);

  // Member variables -- cert/key creation
  private BigInteger      caSerialNumber = BigInteger.ONE; //uniq certificate #

  private Certificate     rmCert = null; // manager
  private PrivateKey      rmKey = null;   // manager

  /**
   * Create a new reporter manager starter object for a resource.
   *
   * @param resource   Name of the resource (from the resource configuration
   *                   file) to start the reporter manager on.
   * @param agent    Path to a location where temporary/state files can be
   */
  public ReporterManagerStarter( String resource, Agent agent ) {
    // name the thread
    super( resource );

    this.resource = resource;
    this.agent = agent;
    this.setTempDir( agent.getTempPath() );
    this.refreshHosts();
  }

  /**
   * Create a new reporter manager starter object, whose configuration is
   * identical to rmStarter
   *
   * @param rmStarter  A reporter manager starter object that will be used to
   * configure this reporter manager starter object.
   */
  public ReporterManagerStarter( ReporterManagerStarter rmStarter ) {
    // name the thread
    super( rmStarter.resource );

    this.agent = rmStarter.agent;
    this.bashLoginOption = rmStarter.bashLoginOption;
    this.caSerialNumber = rmStarter.caSerialNumber;
    this.equivHosts = rmStarter.equivHosts;
    this.host = rmStarter.host;
    this.hostId = rmStarter.hostId;
    isRunning = rmStarter.isRunning;
    this.processHandle = rmStarter.processHandle;
    this.resource = rmStarter.resource;
    this.rmCert = rmStarter.rmCert;
    this.rmKey = rmStarter.rmKey;
    this.rmRootPath = rmStarter.rmRootPath;
    this.tempDir = rmStarter.tempDir;
    this.waitCheckPeriod = rmStarter.waitCheckPeriod;
    this.refreshHosts();
  }

  /**
   * Start the reporter manager process on the remote resource using the
   * method specified in the resource configuration file.
   *
   * @throws AccessMethodException
   */
  public void create( ) throws AccessMethodException {

    Vector arguments = new Vector();
    arguments.add( this.bashLoginOption );
    arguments.add( "sbin/inca" );
    arguments.add( "reporter-manager" );
    arguments.add( "-l var/reporter-manager.log" );
    String[] depots = this.agent.getDepots();
    for ( int j = 0; j < depots.length; j++ ) {
      arguments.add( "-d " + depots[j] );
    }
    if ( this.agent.hasCredentials() )  {
      arguments.add( "-c etc/" + RMCERT );
      arguments.add( "-k etc/" + RMKEY );
      arguments.add( "-t etc/" + RMTRUSTED );
    }
    arguments.add( "-e bin/inca-null-reporter" );
    arguments.add( "-r var/reporter-packages" );
    arguments.add( "-R sbin/reporter-instance-manager" );
    arguments.add( "-v var" );
    arguments.add( "-w " + waitCheckPeriod );
    arguments.add( "-i " + resource );
    arguments.add( "-a " + this.agent.getUri() );
    arguments.add( "-L " + Logger.getRootLogger().getLevel().toString() );

    String passphraseToUse = null;
    if ( this.agent.getPassword() != null &&
         ! this.agent.getPassword().equals("")){
      arguments.add( "-P true" );
      passphraseToUse = this.agent.getPassword() + "\n"; // to terminate password in stdin for sbin/inca
    } else {
      arguments.add( "-P false" );
    }

    String[] argArrayType = new String[arguments.size()];
    String[] argStringArray = (String[]) arguments.toArray(argArrayType);
    logger.info( "Creating reporter manager process on '" + resource + "'" );
    processHandle.start("/bin/bash", argStringArray, passphraseToUse, rmRootPath);
    if ( processHandle.isActive() ) {
      return;
    }
    throw new AccessMethodException( "Reporter manager is not active");
  }

  /**
   * Test for the bash login shell option on the reporter manager resource.
   * Since we're not guaranteed that all access methods will source the users's
   * initialization file and we invoke processes that rely on the user's
   * environment (e.g., to find the openssl the user has specified in their
   * initialization file), we invoke these processes with bash using the login
   * shell option.  Since the bash login option is not portable (i.e., -l or
   * --login), we have to test each option by running a small echo command and
   * checking the result.
   *
   * @throws ReporterManagerException
   */
  public void findBashLoginShellOption() throws ReporterManagerException {
    String[] loginOpts = { "-l", "--login" };
    if ( this.isManual() ) {
      return;  // in manual, the user will be using a login shell
    }
    logger.info( "Testing for -l or --login" );
    for ( int i = 0; i < loginOpts.length; i++ ) {
      AccessMethodOutput result = null;
      try {
        result = processHandle.run(
          "/bin/bash", new String[] { loginOpts[i], "-c", "echo inca" }
        );
        logger.info( "Stderr='" + result.getStderr() + "'");
        logger.info( "Stdout='" + result.getStdout() + "'");
        if ( Pattern.matches("(?m)(?s).*inca.*", result.getStdout()) ) {
          logger.info( "Bash option " + loginOpts[i] + " succeeded");
          this.bashLoginOption = loginOpts[i];
          return;
        } else {
          logger.info( loginOpts[i] + " failed");
        }
      } catch ( AccessMethodException e ) {
        logger.info( "Bash login option " + loginOpts[i] + " failed" );
        logger.debug( "Bash login option " + loginOpts[i] + " failed", e );
      }

    }
    throw new ReporterManagerException( "All bash login options failed" );
  }

  /**
   * Returns the currently selected host (chosen by the run method when the
   * reporter manager is started).
   *
   * @return  The host that the reporter manager is currently executing on.
   */
  public String getCurrentHost() {
    return host;
  }

  /**
   * Returns the equivalent hosts for this resource.
   *
   * @return  The list of equivalent hosts for this resource
   */
  public String[] getEquivalentHosts() {
    return this.equivHosts;
  }

  /**
   * Return the path to the remote reporter manager installation directory.
   *
   * @return  The path to the root reporter manager directory
   */
  public String getRmRootPath() {
    return rmRootPath;
  }

  /**
   * Gets the directory path where the temporary files can be stored.
   *
   * @return  A path to a local directory.
   */
  public String getTemporaryDirectory() {
    return tempDir;
  }

  /**
   * Return whether  the reporter manager is being controlled manually (and not
   * by the agent)
   *
   * @return  True if the reporter manager is being controlled manually and
   * false if it is not.
   */
  public boolean isManual() {
    return processHandle.getClass().equals(Manual.class);
  }

  /**
   * Return true if the reporter manager is currently registered and running.
   *
   * @return  True if the reporter manager is currently registered and running
   * and false otherwise.
   */
  public boolean isRunning() {
    return isRunning;
  }

  /**
   * Checks to see if the reporter manager is available and installed on the
   * machine.
   *
   * @return  True if the reporter manager distribution is found on the machine.
   */
  public boolean isStaged()  {
    boolean staged = true;

    Vector args = new Vector();
    args.add( "sbin/inca" );
    args.add( "reporter-manager" );
    args.add( "-l var/reporter-manager.log" );
    args.add( "-T" );
    args.add( "-P false" );
    String[] argArray = (String[])args.toArray(new String[args.size()]);
    logger.info( "Checking reporter manager install on '" + resource + "'" );
    AccessMethodOutput testOutput = new AccessMethodOutput();
    AccessMethodOutput tailOut = null;
    try {
      testOutput = processHandle.run( "/bin/sh", argArray, "", rmRootPath );
      argArray = new String[]{
        "-c",
        "tail -4 var/reporter-manager.log"
      };
      tailOut = processHandle.run( "/bin/sh", argArray, "", rmRootPath );
    } catch ( Exception e ) {
      logger.error( "Test of reporter manager failed on " + resource, e );
      staged = false;
    }
    if ( staged && ! Pattern.matches( "(?m)(?s).*Testing XML parsing.*",
                                      tailOut.getStdout().trim() ) ) {
      logger.error( "Test of reporter-manager failed on " + resource );
      logger.error( "Stdout = '" + testOutput.getStdout() );
      logger.error( "Stderr = '" + testOutput.getStderr() );
      staged = false;
    }
    if ( staged && ! Pattern.matches( "(?m)(?s).*XML::Simple working.*",
                                      tailOut.getStdout().trim() ) ) {
      logger.error( "Perl XML libraries not installed");
      staged = false;
    }
    if ( staged && this.agent.hasCredentials() )  {
      if ( ! Pattern.matches("(?m)(?s)^.*IO::Socket::SSL working.*$",
                             tailOut.getStdout().trim() ) ) {
        logger.error( "Perl SSL libraries not installed");
        staged = false;
      }
    }
    if ( staged ) {
      return true;
    }

    return false;
  }

  /**
   * Assume the current host is not reachable and try the next host in the
   * list (if there is one)
   *
   * @throws ConfigurationException
   */
  public void nextHost() throws ConfigurationException {
    hostId++;
    if ( hostId >= this.equivHosts.length ) {
      hostId = 0;
    }
    this.setHost( hostId );
  }

  /**
   * Starts a thread to create the reporter manager on the remote resource.  If
   * there is more than one host, it will choose the first one that it can
   * successfully create a reporter manager on.  If unable to create a
   * reporter manager on any resource, will wait 10 minutes and then try again.
   */
  public void run() {

    logger.debug( "Start remote reporter manager thread for " + resource );
    try {
      while( true ) {
        boolean atLeastOneCreateAttempt = false;
        logger.debug( "Looking for host to start " + resource + " reporter manager from " + StringMethods.join( " | ", this.equivHosts) );
        for ( int i = 0; i < this.equivHosts.length; i++ ) {
          try {
            if ( i != 0 ) {
              this.nextHost();
            } else {
              this.setHost( 0 );
            }
          } catch ( ConfigurationException e ) {
            logger.error("Host configuration for " + this.host + " failed",e);
            continue;
          }
          String desc = "start reporter manager on " + this.resource +
                        " using host " + this.host;
          logger.info("Attempting to " + desc );
          try {
            if ( this.isManual() ) {
              manualRegister();
            } else {
              if ( this.bashLoginOption == null ) findBashLoginShellOption();
              if ( ! this.isStaged() ) this.stage( false );
              this.create();
            }
            atLeastOneCreateAttempt = true;
            if ( this.waitForReporterManager() ) return;
          } catch ( ReporterManagerException e ) {
            logger.error( "Unable to " + desc + ": " + e, e );
          } catch ( AccessMethodException e ) {
            logger.error( "Unable to " + desc + ": " + e, e );
          }
        }
        if ( ! atLeastOneCreateAttempt ) {
          synchronized( this ) {
            logger.info(
              "Tried all equivalent hosts for resource " + resource +
              "...waiting " + this.agent.getStartAttemptWaitPeriod() +
              " milliseconds before next start attempt"
            );
            this.wait( this.agent.getStartAttemptWaitPeriod() );
          }
        }
      }
    } catch ( InterruptedException e ) {
      logger.error(
        "Caught interrupt while attempting to start reporter manager...exitting"
      );
    }
  }

  /**
   * Set the resources document referenced by the reporter manager. 
   */
  public void refreshHosts( ) {

    String[] hosts = new String[0];
    this.hostId = 0;
    try {
      hosts = this.agent.getResources().getResources( resource, false );
      if ( hosts.length == 0 ) {
        hosts = new String[] {resource};
      }
      this.equivHosts = hosts;
      this.setHost( this.hostId );
    } catch ( ConfigurationException e ) {
      logger.error(
        "Problem reading resource configuration for " + this.resource, e
      );
    }
  }

  /**
   * Set the status of the reporter manager to running and notify any
   * waiting threads.
   *
   * @param isRunning  True indicates the reporter manager is running on the
   * remote machine and available; false otherwise.
   */
  public void setRunning( boolean isRunning ) {
    synchronized(this) {
      logger.debug( "Set reporter manager " + resource + " status to running ");
      this.isRunning = isRunning;
      notifyAll(); // notify anybody who may be waiting on this
    }
  }

  /**
   * Set the location of the temporary directory.
   *
   * @param tempDir  A path to a directory where temporary files can be stored.
   */
  public void setTempDir( String tempDir ) {
    this.tempDir = tempDir + File.separator + Agent.RMDIR + File.separator +
                   resource;
    File dir = new File( this.tempDir );
    if ( ! dir.exists() ) {
      logger.info( "Creating temporary directory '" + this.tempDir + "'" );
      logger.info( "Directories created: " + dir.mkdirs() );
    }
  }

  /**
   * Stage the Reporter Manager distribution over to the remote resource.
   * Will first transfer over the reporter manager tarball and build script,
   * invoke the build script, and wait for completion.
   *
   * @param upgrade
   */
  public void stage( boolean upgrade ) throws ReporterManagerException {
    if ( upgrade && ! isStaged() ) {
      throw new ReporterManagerException(
        "Cannot upgrade reporter manager on resource '" + resource + "': " +
        "no existing installation found"
      );
    }

    // The reporter manager distribution and build script are stored in the
    // classpath (more specifically in inca-agent.jar).  So, we need to
    // extract them in order to have a valid path to give to the access method
    // copy functions
    String tmpRmDistPath = null;
    String tmpRmBuildScriptPath = null;
    try {
      tmpRmDistPath = writeClasspathResourceToFile( RMDIST, this.tempDir );
      tmpRmBuildScriptPath = writeClasspathResourceToFile(
        RMBUILDSCRIPT, this.tempDir
      );
    } catch ( IOException e ) {
      throw new ReporterManagerException(
        "Problem writing reporter manager dist files to temporary directory", e
      );
    }

    Vector files = new Vector();
    files.add( tmpRmDistPath );
    files.add( tmpRmBuildScriptPath );
    if ( this.agent.hasCredentials() )  {
      logger.info(
        "Generating credentials for reporter manager '" + resource + "'"
      );
      String[] authFiles = null;
      try {
        authFiles = generateAuthFiles();
      } catch ( Exception e ) {
        throw new ReporterManagerException(
          "Unable to generate credentials for remote reporter manager " +
          resource, e
        );
      }
      for ( int j = 0; j < authFiles.length; j++ ) {
        files.add( authFiles[j] );
      }
    }
    String[] stringType = new String[files.size()];
    String[] filenames = new String[files.size()];
    filenames = (String[])files.toArray( stringType );
    logger.info( "Tranferring over reporter manager distribution" );
    for ( int j = 0; j < filenames.length; j++ ) {
      logger.debug( filenames[j] );
    }
    try {
      processHandle.transfer( filenames, rmRootPath );
      build( upgrade );
    } catch ( AccessMethodException e ) {
      String errorMsg = "Unable to stage reporter manager to " + host;
      logger.error( errorMsg, e );
      throw new ReporterManagerException( errorMsg, e );
    }
    if ( this.agent.hasCredentials() )  {
      cleanupAuthFiles();
    }
  }

  // Private Functions

  /**
   * Run the build script on the remote resource using the method specified
   * in the resource configuration file.  The call to the build script is as
   * follows:
   *
   * <pre>
   * /bin/bash &lt;buildScript&gt; &lt;rmRootPath&gt; &lt;rmDistTarball&gt;
   * </pre>
   *
   * If the string "SUCCEEDED" is not returned by the build script, we consider
   * it failed and an exception is thrown.
   *
   * @throws AccessMethodException
   */
  private void build( boolean upgrade ) throws AccessMethodException {
    String[] arguments = {
      this.bashLoginOption,
      rmRootPath + "/" + RMBUILDSCRIPT,
      "-u",
      Boolean.toString( upgrade ),
      rmRootPath,
      RMDIST,
    };
    logger.info( "Invoking build script on '" + resource + "'" );
    AccessMethodOutput result = processHandle.run( "/bin/bash", arguments );
    if ( ! this.isManual() && ! isStaged() ) {
      throw new AccessMethodException(
        "Stage of reporter manager to " + resource +
        " failed: build script didn't return success: \n" +
        "stderr = ' " + result.getStderr() + "'\n" +
        "stdout = ' " + result.getStdout() + "'"
      );
    }
    logger.info( "Build script completed on '" + resource + "'" );
  }

  /**
   * Remove the public and private key for the remote reporter manager.
   */
  private void cleanupAuthFiles() {
    if ( this.isManual() ) {
      logger.warn(
        "Skipping cleanup of authorization files for '" + resource + "'"
      );
      return;
    }
    File rmCertFile = new File(
      getTemporaryDirectory() + File.separator + RMCERT
    );
    rmCertFile.delete();
    File rmKeyFile = new File(
      getTemporaryDirectory() + File.separator + RMKEY
    );
    rmKeyFile.delete();
    File rmTrustedDir = new File(
      getTemporaryDirectory() + File.separator + RMTRUSTED
    );
    File[] trustedCertFiles = rmTrustedDir.listFiles();
    for ( int i = 0; i < trustedCertFiles.length; i++ ) {
      trustedCertFiles[i].delete();
    }
    rmTrustedDir.delete();
    File resourceTmpDir = new File( getTemporaryDirectory() );
    resourceTmpDir.delete();
  }

  /**
   * To be used after the function create in order to wait for the remote
   * reporter manager process to start up and connect to the agent.  Will
   * wait up to startAttemptWaitPeriod milliseconds before returning false.
   *
   * @return True if the remote reporter manager has registered and false
   * if startAttemptWaitPeriod milliseconds have passed and the remote
   * reporter manager has still not registered.
   *
   * @throws InterruptedException
   */
  public boolean waitForReporterManager() throws InterruptedException {
    long startTime = Calendar.getInstance().getTimeInMillis();
    long elapsedTime = 0;
    while( true ) {
      long waitTimeLeft = this.agent.getStartAttemptWaitPeriod() - elapsedTime;
      logger.info(
        "Waiting up to " + (waitTimeLeft/Constants.MILLIS_TO_SECOND) +
        " secs for reporter manager " + resource + " to checkin"
      );
      synchronized( this ) {
        this.wait( waitTimeLeft );
      }
      if ( this.isRunning() ) {
        logger.info(
          "Remote reporter manager registered for " + resource +
          "; start up thread complete"
        );
        return true;
      }
      elapsedTime = Calendar.getInstance().getTimeInMillis() - startTime;
      if ( elapsedTime > this.agent.getStartAttemptWaitPeriod() ) {
        logger.debug(
          "Reporter manager " + resource + " has not checked in after " +
          + (this.agent.getStartAttemptWaitPeriod()/Constants.MILLIS_TO_SECOND)
          + " secs; trying again"
        );
        return false;
      } else {
        logger.debug(
          "Reporter manager " + resource +
          " received notify but reporter manager not yet running"
        );
      }
    }

  }

  /**
   * Generate a public and private key for a reporter manager.
   *
   * @return  The directory where the public and private key are stored.
   *
   */
  protected String[] generateAuthFiles( )
    throws GeneralSecurityException, IOException {

    // Get valid and expiration dates
    Calendar now = Calendar.getInstance();
    Calendar yearLater = Calendar.getInstance();yearLater.add(Calendar.YEAR, 1);

    // Generate a new key pair
    KeyPairGenerator  keypairGenerator = KeyPairGenerator.getInstance(
      KEY_ALGORITHM, PROVIDER
    );
    keypairGenerator.initialize(1024, new SecureRandom());
    KeyPair rmKeyPair = keypairGenerator.generateKeyPair();
    rmKey = rmKeyPair.getPrivate();

    // Configure certificate generator
    X509Certificate cert = (X509Certificate)
      this.agent.getCertificate();
    X509V3CertificateGenerator certGenerator = new X509V3CertificateGenerator();
    certGenerator.setIssuerDN( cert.getSubjectX500Principal() );
    certGenerator.setSerialNumber( caSerialNumber.add(BigInteger.ONE) );
    certGenerator.setNotBefore( now.getTime() );
    certGenerator.setNotAfter( yearLater.getTime() );
    certGenerator.setSubjectDN(
      new X509Name(
        true,
        "CN=" + resource + ", " + cert.getSubjectDN().toString()
      )
    );
    certGenerator.setSignatureAlgorithm( SIGNATURE_ALGORITHM );
    certGenerator.setPublicKey( rmKeyPair.getPublic() );
    // some extensions I saw in code samples
    certGenerator.addExtension(
      X509Extensions.SubjectKeyIdentifier,
      false,
      new SubjectKeyIdentifierStructure(rmKeyPair.getPublic())
    );
    certGenerator.addExtension(
      X509Extensions.AuthorityKeyIdentifier,
      false,
      new AuthorityKeyIdentifierStructure(cert)
    );
    certGenerator.addExtension
      ( X509Extensions.BasicConstraints, false, new BasicConstraints(false) );
    certGenerator.addExtension(
      X509Extensions.KeyUsage,
      false,
      new KeyUsage(KeyUsage.dataEncipherment | KeyUsage.digitalSignature )
    );

    // generate the certificate and save it
    rmCert = certGenerator.generateX509Certificate(
      this.agent.getKey().getPrivate(),
      PROVIDER, new java.security.SecureRandom()
    );
    return writeAuthFilesToTempDir();
  }

  /**
   * Allow for a reporter manager on a resource to be controlled manually
   * rather than by the Inca agent.  This function simulates a remote reporter
   * manager and emails suite changes to an Inca administrator. All other
   * commmands like package and ping are just replied to.
   *
   * Note:  may want to spin this into a class if it gets too unseemly
   *
   * @throws ReporterManagerException
   * @throws InterruptedException
   */
  private void manualRegister()
    throws ReporterManagerException, InterruptedException {

    Thread.sleep( MANUAL_WAIT_PERIOD ); // give time for wait to be called
    try {
      this.generateAuthFiles();
    } catch ( GeneralSecurityException e ) {
      logger.error( "Unable to create credentials for " + this.resource );
      return;
    } catch ( IOException e ) {
      logger.error( "Unable to create credentials for " + this.resource );
      return;
    }
    ManagerClient mclient = new ManagerClient();
    mclient.setCertificatePath( this.agent.getCertificatePath() );
    mclient.setPassword( this.agent.getPassword() );
    mclient.setKeyPath( this.agent.getKeyPath() );
    mclient.setTrustedPath( this.agent.getTrustedPath() );
    mclient.setServer( this.agent.getUri(), 0 );
    try {
      mclient.connect();
    } catch ( IOException e ) {
      throw new ReporterManagerException
        ("Unable to connect to agent for manual resource " + this.resource );
    } catch ( ConfigurationException e ) {
      throw new ReporterManagerException
        ("Unable to connect to agent for manual resource " + this.resource );
    }
    ProtocolWriter writer = mclient.getWriter();
    ProtocolReader reader = mclient.getReader();
    try {
      writer.write( new Statement(Protocol.REGISTER_COMMAND, this.resource) );
      Statement stmt = reader.readStatement();
      String cmd = new String( stmt.getCmd() );
      if ( ! cmd.equals(Protocol.SUCCESS_COMMAND) ) {
        throw new ReporterManagerException
          ("Received '" + cmd + "' after manual register of " + this.resource );
      }
      logger.debug
        ( "Manual thread for " + this.resource + " connected to agent " +
          this.agent.getUri() );
    } catch ( IOException e ) {
      throw new ReporterManagerException
        ("Unable to register manual resource " + this.resource, e );
    } catch ( ProtocolException e ) {
      throw new ReporterManagerException
        ("Unable to register manual resource " + this.resource, e );
    }
    Statement stmt = null;
    while( mclient.isConnected() ) {
      try {
        stmt = reader.readStatement();
        if ( stmt == null )  continue;
        String cmd = new String( stmt.getCmd() );
        if ( cmd.equals(Protocol.SUITE_UPDATE_COMMAND) ) {
          SuiteDocument suiteChanges = SuiteDocument.Factory.parse
            ( new String(stmt.getData()) );
          manualSendSuite( suiteChanges );
          String suiteGuid = suiteChanges.getSuite().getGuid();
          writer.write( Statement.getOkStatement( suiteGuid ) );
        } else if ( cmd.equals(Protocol.PING_COMMAND) ) {
          writer.write( Statement.getOkStatement(new String(stmt.getData())) );
        } else if ( cmd.equals(Protocol.PACKAGE_COMMAND ) ) {
          String pkgName = new String( stmt.getData() );
          stmt = reader.readStatement(); // FILENAME SP name CRLF
          stmt = reader.readStatement(); // VERSION SP version CRLF
          stmt = reader.readStatement(); // INSTALLPATH SP path CRLF
          stmt = reader.readStatement(); // [PERMISSION SP oct CRLF]
          cmd = new String( stmt.getData() );
          if ( cmd.equals(Protocol.PACKAGE_PERMISSIONS_COMMAND) ) {
            stmt = reader.readStatement(); // CONTENT SP packageContent CRLF
          }
          writer.write( Statement.getOkStatement(pkgName) );
        } else {
          logger.debug
            ( "Manual thread for " + this.resource + " received command " + cmd );
        }
      } catch ( IOException e ) {
        logger.error( "Error in manual reporter manager for " + resource, e );
        continue;
      } catch ( ProtocolException e ) {
        logger.error( "Error in manual reporter manager for " + resource, e );
        continue;
      } catch ( ConfigurationException e ) {
        logger.error( "Error in manual reporter manager for " + resource, e );
        continue;
      } catch ( XmlException e ) {
        logger.error( "Error in manual reporter manager for " + resource, e );
        continue;
      }
    }
  }

  /**
   * Send the specified suite changes to the Inca administrator of this
   * resource.
   *
   * @param suiteChanges   The changes that should be propogated.
   *
   * @throws IOException
   * @throws ConfigurationException
   */
  private void manualSendSuite( SuiteDocument suiteChanges )
    throws IOException, ConfigurationException {

    String suiteName = suiteChanges.getSuite().getName();

    // ignore run now requests
    if ( Pattern.matches( Protocol.IMMEDIATE_SUITE_NAME, suiteName ) ) {
      return;
    }
    logger.info( "Received change for suite " + suiteName +
                 " for manual resource " + resource );

    // 1. First save the latest changes to disk
    File suiteChangesFile = new File( tempDir + File.separator + LAST_CHANGE );
    logger.debug
      ( "Saving suite changes to " + suiteChangesFile.getAbsolutePath() );
    suiteChanges.save( suiteChangesFile );

    // 2. Next combine all suites for this resource into a single suite and
    // write to disk -- this is the current suite the manual reporter manager
    // should be running
    File currentSuiteFile = new File(tempDir + File.separator + CURRENT_SUITE );
    SuiteWrapper currentSuite = new SuiteWrapper();
    currentSuite.getSuiteDocument().getSuite().setName( "manualSuite" );
    currentSuite.getSuiteDocument().getSuite().setGuid
      ( agent.getUri() + "/manualSuite" );
    String[] currentSuites = agent.getSuites().getNames();
    for( int i = 0; i < currentSuites.length; i++ ) {
      SuiteStagesWrapper suite = agent.getSuites().getSuite( currentSuites[i] );
      if ( suite.getResourceSuites().containsKey(resource) ) {
        SuiteWrapper rSuite =
          (SuiteWrapper)suite.getResourceSuites().get(resource);
        for ( int j = 0; j < rSuite.getSeriesConfigCount(); j++ ) {
          currentSuite.appendSeriesConfig( rSuite.getSeriesConfig(j) );
        }
      }
      logger.debug
        ( "Saving current suite to " + currentSuiteFile.getAbsolutePath() );
      currentSuite.save( currentSuiteFile );
    }

    // 3.  Email the differences and the updated suite
    String suiteGuid = suiteChanges.getSuite().getGuid();
    String adminEmail = this.agent.getResources().getValue
      ( resource, Protocol.EMAIL_MACRO );
    if ( adminEmail == null ) {
      adminEmail = System.getProperty("user.name") + "@localhost";
    }
    try {
      StringMethods.sendEmail(
        adminEmail,
        "[inca notification] change to suite " + suiteGuid +
        " for resource " + resource,
        StringMethods.fileContentsFromClasspath( "manualEmail.txt" ),
        new File[] { suiteChangesFile, currentSuiteFile },
        new String[] { "text/xml", "text/xml" }
      );
    } catch ( Exception e ) {
      throw new IOException( "Problems sending email: " + e );
    }
  }

  /**
   * Select the specified host for the resource and set the reporter manager
   * attributes accordingly.
   *
   * @param hostId  The host id to select to execute the reporter manager on.
   *
   * @throws ConfigurationException
   */
  protected void setHost( int hostId ) throws ConfigurationException {

    this.host = this.equivHosts[hostId];
    logger.info(
      "Selecting host '" + this.host + "' for resource " + this.resource
    );

    // properties read in from resource configuration file
    ResourcesWrapper resources = this.agent.getResources();
    this.processHandle = AccessMethod.create(
      host, resources, this.getTemporaryDirectory()
    );

    this.rmRootPath = resources.getValue( host, Protocol.WORKING_DIR_MACRO );
    if ( this.rmRootPath == null ) {
      this.rmRootPath = Protocol.WORKING_DIR_MACRO_DEFAULT;
    }
    if ( ! this.rmRootPath.startsWith(File.separator) ) {
      this.rmRootPath = this.processHandle.prependHome( this.rmRootPath );
    }

    String checkPeriodString = resources.getValue(
      host, Protocol.CHECK_PERIOD_MACRO
    );
    if ( checkPeriodString != null ) {
      waitCheckPeriod = Integer.parseInt( checkPeriodString );
    }

  }

  /**
   * Write the reporter manager certificate, key, and trusted certificates
   * to disk.
   *
   * @return The directory where the files are stored.
   *
   * @throws IOException
   * @throws java.io.FileNotFoundException
   */
  private String[] writeAuthFilesToTempDir()
    throws IOException {

    String certPath = tempDir + File.separator + RMCERT;
    String keyPath = tempDir + File.separator + RMKEY;
    logger.info( "Writing rm certificate to " + certPath );
    PEMWriter writer = new PEMWriter(
      new OutputStreamWriter(new FileOutputStream(certPath))
    );
    writer.writeObject( rmCert );
    writer.close();
    writer = new PEMWriter(
      new OutputStreamWriter(new FileOutputStream(keyPath))
    );
    if (this.agent.getPassword() != null&&!this.agent.getPassword().equals("")){
      logger.info( "Writing encrypted rm key to " + keyPath );
      writer.writeObject(
        rmKey,
        ENC_ALGORITHM,
        this.agent.getPassword().toCharArray(),
        new SecureRandom()
      );
    } else {
      logger.info( "Writing rm key to " + keyPath );
      writer.writeObject( rmKey );
    }

    writer.close();

    // send out trusted certs too for transfer
    File trustedTmpDir  = new File( tempDir + File.separator + RMTRUSTED );
    trustedTmpDir.mkdir();
    Certificate[] trusted = this.agent.getTrustedCertificates();
    String[] filenames = new String[2 + trusted.length]; // plus key and cert
    filenames[0] = certPath;
    filenames[1] = keyPath;
    for ( int i = 0; i < trusted.length; i++ ) {
      String trustedPath = trustedTmpDir.getPath() + File.separator + "trusted"
                           + i + ".pem";
      filenames[i+2] = trustedPath;
      logger.info( "Writing rm trusted cert to " + trustedPath );
      writer = new PEMWriter(
        new OutputStreamWriter(new FileOutputStream( trustedPath ) )
      );
      writer.writeObject( trusted[i] );
      writer.close();
    }
    return filenames;
  }

  /**
   * Extract a file from the classpath and write it to a temporary file.  Useful
   * for when a file is packed into a jar file.
   *
   * @param filename   The name of the file to locate in the classpath.
   * @param dir        The directory to where the file should be written to.
   *
   * @return The path to the file.
   *
   * @throws IOException
   */
  private String writeClasspathResourceToFile( String filename, String dir )
    throws IOException {

    String path = dir + File.separator + filename;
    InputStream resourceStream = Component.openResourceStream( filename );
    if ( resourceStream == null ) {
      throw new IOException( filename + " not found in classpath" );
    }
    logger.info( "Writing " + filename + " to " + dir );
    FileOutputStream tmpResourceStream = new FileOutputStream( path );
    byte[] buffer = new byte[2048];
    for (;;)  {
      int nBytes = resourceStream.read(buffer);
      if (nBytes <= 0) break;
      tmpResourceStream.write(buffer, 0, nBytes);
    }
    tmpResourceStream.flush();
    tmpResourceStream.close();
    resourceStream.close();
    return path;
  }

}
