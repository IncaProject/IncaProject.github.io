package edu.sdsc.inca.agent;

import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.util.ResourcesWrapper;
import edu.sdsc.inca.agent.access.Globus;
import edu.sdsc.inca.agent.access.Local;
import edu.sdsc.inca.agent.access.Manual;
import edu.sdsc.inca.agent.access.Ssh;
import edu.sdsc.inca.protocol.Protocol;
import org.apache.log4j.Logger;

/**
 * An abstract class used to represent methods for transferring files and
 * running processes on resources.  Supported methods include
 * Globus, Local (exec), Manual, and SSH currently. The classes that implement
 * each of these methods exist in the 'access' directory.
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
abstract public class AccessMethod  {
  static final private Logger logger = Logger.getLogger( AccessMethod.class );

  /**
   * Scan the resource configuration specified in resources and use the
   * remoteInvocationMethod value for the resource to create the appropriate
   * subclass of AccessMethod.
   *
   * @param resource  The name of the resource to start the process on
   *
   * @param resources  The resource configuration information
   *
   * @param temp      Path to a directory for temporary files to be stored

   * @return  An object of a AccessMethod subclass
   *
   * @throws ConfigurationException
   */
  static public AccessMethod create( String resource,
                                     ResourcesWrapper resources,
                                     String temp )
    throws ConfigurationException {

    String method = resources.getValue(resource, Protocol.COMPUTE_METHOD_MACRO);
    AccessMethod process = null;
    if ( method == null ) {
      method = Protocol.COMPUTE_METHOD_MACRO_DEFAULT;
    }
    logger.info(
      "Using invocation method '" + method + "' for resource '" + resource + "'"
    );    
    if ( method.equals("globus2") ) {
      process = new Globus( resource, resources, temp, "GT2" );
    } else if ( method.equals("ssh") ) {
      process = new Ssh( resource, resources );
    } else if ( method.equals("local") ) {
      process = new Local( resource, resources );
    } else if ( method.equals("manual") ) {
      process = new Manual( resource, resources );
    } else {
      throw new ConfigurationException(
        "Uknown remote process invocation method '" + method +
        "' specified for reporter manager"
      );
    }
    return process;
  }

  /**
   * Checks to see if the process started by start() is active.
   *
   * @return true if the process is running; false otherwise.
   * @throws AccessMethodException
   */
  abstract public boolean isActive() throws AccessMethodException;

  /**
   * Given a path relative to the home directory, prepend the home signifier
   * for the given access method to the path and return the new string.
   *
   * @param path   A path relative to the user's home directory
   *
   * @return  A new string that contains the home signifier prepended to the
   * provided path.
   */
  public String prependHome( String path ) {
    // most access methods recognize a path w/o a starting / as being relative
    // to the home dir.
    return path;
  }

  /**
   * Run a process on a remote machine.
   *
   * @param executable  Path to the remote executable.
   * @param arguments   Contains the arguments that should be passed to the
   *                    executable
   * @return The stdout and stderr of the executed process in
   * RemoteProcessObject.
   */
  public AccessMethodOutput run(String executable, String[] arguments)
    throws AccessMethodException {

    return run(executable, arguments, null);
  }

  /**
   * Run a process on a remote machine.
   *
   * @param executable  Path to the remote executable.
   * @param arguments   Contains the arguments that should be passed to the
   *                    executable
   * @param stdin       A string that will be passedd in as stdin to the process
   *                    when it is started
   * @return The stdout and stderr of the executed process in
   * RemoteProcessObject.
   */
  public AccessMethodOutput run(String executable, String[] arguments, 
                                String stdin )
    throws AccessMethodException {

    return run(executable, arguments, stdin, null);
  }


  /**
   * Execute the specified process on the remote resource.  This call will block
   * until the process has completed.
   *
   * @param executable Path to the remote executable.
   * @param arguments  Contains the arguments that should be passed to the
   *                   executable
   * @param stdin      A string that will be passedd in as stdin to the process
   *                   when it is started
   * @param directory  Path to the directory where the process will be executed
   *                   from
   * @return The stdout and stderr of the executed process in
   * RemoteProcessObject.
   */
  abstract public AccessMethodOutput run( String executable,
                                          String[] arguments,
                                          String stdin,
                                          String directory )
    throws AccessMethodException;

  /**
   * Start a process on a remote machine.  This is a non-blocking call.
   *
   * @param executable  Path to the remote executable.
   * @param arguments   Contains the arguments that should be passed to the
   *                    executable
   */
  public void start(String executable, String[] arguments )
    throws AccessMethodException {
    start(executable, arguments, null, null);
  }

  /**
   * Start a process on a remote machine.  This is a non-blocking call.
   *
   * @param executable  Path to the remote executable.
   * @param arguments   Contains the arguments that should be passed to the
   *                    executable
   * @param stdin       A string that will be passedd in as stdin to the process
   *                    when it is started
   */
  public void start(String executable, String[] arguments, String stdin)
    throws AccessMethodException {
    start(executable, arguments, stdin, null);
  }

  /**
   * Start a process on a remote machine.  This is a non-blocking call.
   *
   * @param executable  Path to the remote executable.
   * @param arguments   Contains the arguments that should be passed to the
   *                    executable
   * @param in          A string that will be passedd in as stdin to the process
   *                    when it is started
   * @param directory  Path to the directory where the process will be executed
   *                   from
   */
  abstract public void start(String executable, String[] arguments, String in,
                             String directory)
    throws AccessMethodException;

  /**
   * Stop the currently running process started by start().
   * 
   * @throws AccessMethodException
   */
  abstract public void stop() throws AccessMethodException;

  /**
   * Transfer a file to a directory on a remote machine.
   *
   * @param localFile      contains a path to the file on the local file system
   * @param remoteDirPath contains a path to a directory/file on a remote
   *        machine
   */
  public void transfer ( String localFile, String remoteDirPath )
    throws AccessMethodException {

    /* this assumes the implementing class has implemented the other transfer
    method */
    transfer( new String[] { localFile }, remoteDirPath );
  }

  /**
   * Transfer a list of files to a directory on a remote machine.
   *
   * @param localFiles    list of paths to files on the local file system
   * @param remoteDirPath contains a path to a directory/file on a remote
   *        machine
   */
  public void transfer ( String[] localFiles, String remoteDirPath )
    throws AccessMethodException {

    /* this assumes the implementing class has implemented the other transfer
    method */
    for ( int i = 0; i < localFiles.length; i++ ) {
      transfer( localFiles[i], remoteDirPath );
    }
  }


}
