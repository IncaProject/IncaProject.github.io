package edu.sdsc.inca;

import junit.framework.TestCase;

import java.io.*;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.regex.Pattern;
import java.util.zip.GZIPOutputStream;
import java.util.zip.GZIPInputStream;

import edu.sdsc.inca.dataModel.suite.Suite;
import edu.sdsc.inca.dataModel.suite.SuiteDocument;
import edu.sdsc.inca.dataModel.inca.IncaDocument;
import edu.sdsc.inca.dataModel.resourceConfig.ResourceConfigDocument;
import edu.sdsc.inca.dataModel.util.Macro;
import edu.sdsc.inca.dataModel.util.Resource;
import edu.sdsc.inca.dataModel.util.Resources;
import edu.sdsc.inca.agent.*;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.util.ConfigProperties;
import edu.sdsc.inca.util.ResourcesWrapper;
import edu.sdsc.inca.util.ResourcesWrapperTest;
import edu.sdsc.inca.util.Constants;
import edu.sdsc.inca.util.StringMethods;
import edu.sdsc.inca.repository.Repositories;
import edu.sdsc.inca.repository.RepositoriesTest;
import edu.sdsc.inca.repository.Repository;
import org.apache.log4j.Logger;

/**
 * A unit test driver for the Agent and AgentClient classes.
 */
public class AgentClientTest extends TestCase {

  private static final String CWD = System.getProperty("user.dir");
  private static final String SEP = File.separator;
  private static final String REPOSITORY_PATH1 = CWD + SEP + "rep1";
  private static final String REPOSITORY_PATH2 = CWD + SEP + "rep2";
  private static final String REPOSITORY_URL1 = "file://" + REPOSITORY_PATH1;
  private static final String REPOSITORY_URL2 = "file://" + REPOSITORY_PATH2;
  static private Logger logger = Logger.getLogger( AgentClientTest.class );

  private AgentClient client = null;
  private Agent server = null;
  private AgentTest.MockDepot depot = null;
  private static int port = 3456;
  private static Repositories sampleRepository = null;
  private static ResourcesWrapper sampleResources = null;

  private static final String[] REPORTER_FILENAMES = {
    "cluster.os.kernel.version.rpt",
    "cluster.filesystem.gpfs.version.rpt",
    "cluster.java.sun.version.rpt",
    "grid.security.gsi.version.rpt",
    "cluster.compiler.gcc.version",
    "Reporter.pm",
    "cluster.security.openssl.version"
  };
  private static final String[] REPORTER_ATTRS = {
    "name", "kernel", "version", "1.7", "file", REPORTER_FILENAMES[0], "dependencies", "",
    "name", "gpfs", "version", "1.2", "file", REPORTER_FILENAMES[1], "dependencies", "",
    "name", "java", "version", "1.5", "file", REPORTER_FILENAMES[2],"dependencies", "",
    "name", "gsi", "version", "0.1", "file", REPORTER_FILENAMES[3], "dependencies", "",
    "name", "gcc", "version", "1.5", "file", REPORTER_FILENAMES[4], "dependencies", "Test::Inca::Reporter",
    "name", "Test::Inca::Reporter", "version", "1.0", "file", REPORTER_FILENAMES[5], "dependencies", "",
    "name", "openssl", "version", "1.3", "file", REPORTER_FILENAMES[6], "dependencies", ""
  };
  public static final int ATTRIBUTE_COUNT = 4;
  public static final String[] REPORTER_BODIES = {

    "#!/usr/bin/perl\n" +
    "use strict;\n" +
    "use warnings;\n" +
    "use Inca::Reporter::Version;\n" +
    "my $reporter = new Inca::Reporter::Version(\n" +
    "  version => 1.7,\n" +
    "  description => 'Reports the os kernel release info',\n" +
    "  url => 'http://www.linux.org',\n" +
    "  package_name => 'kernel'\n" +
    ");\n" +
    "$reporter->processArgv(@ARGV);\n" +
    "$reporter->setVersionByExecutable('uname -r');\n" +
    "$reporter->print();\n",

    "#!/usr/bin/perl\n" +
    "use strict;\n" +
    "use warnings;\n" +
    "use Inca::Reporter::Version;\n" +
    "my $reporter = new Inca::Reporter::Version(\n" +
    "  version => 1.2,\n" +
    "  description => 'Reports the version of GPFS',\n" +
    "  url => 'http://www.almaden.ibm.com/cs/gpfs.html',\n" +
    "  package_name => 'gpfs'\n" +
    ");\n" +
    "$reporter->processArgv(@ARGV);\n" +
    "$reporter->setVersionByRpmQuery('gpfs');\n" +
    "$reporter->print();\n",

    "#!/usr/bin/perl\n" +
    "use strict;\n" +
    "use warnings;\n" +
    "use Inca::Reporter::Version;\n" +
    "my $reporter = new Inca::Reporter::Version(\n" +
    "  version => 1.5,\n" +
    "  description => 'Reports the version of java',\n" +
    "  url => 'http://java.sun.com',\n" +
    "  package_name => 'java'\n" +
    ");\n" +
    "$reporter->processArgv(@ARGV);\n" +
    "$reporter->setVersionByExecutable('java -version', 'java version \"(.+)\"');\n" +
    "$reporter->print();\n",

    "#!/usr/bin/perl\n" +
    "use strict;\n" +
    "use warnings;\n" +
    "use Inca::Reporter::Version;\n" +
    "my $reporter = new Inca::Reporter::Version(\n" +
    "  version => 0.1,\n" +
    "  description => 'Reports the version of GSI client tools',\n" +
    "  url => 'http://www.globus.org/gsi',\n" +
    "  package_name => 'gsi'\n" +
    ");\n" +
    "$reporter->processArgv(@ARGV);\n" +
    "$reporter->setVersionByGptQuery('globus_gsi_cert_utils');\n" +
    "$reporter->print();\n",

    "#!/usr/bin/perl\n" +
    "\n" +
    "use strict;\n" +
    "use warnings;\n" +
    "use Inca::Reporter::Version;\n" +
    "\n" +
    "my $reporter = new Inca::Reporter::Version(\n" +
    "  version => 1.5,\n" +
    "  description => 'Reports the version of gcc',\n" +
    "  url => 'http://gcc.gnu.org',\n" +
    "  package_name => 'gcc'\n" +
    ");\n" +
    "$reporter->processArgv(@ARGV);\n" +
    "\n" +
    "$reporter->setVersionByExecutable('gcc -dumpversion');\n" +
    "$reporter->print();",

    "package Inca::Reporter;" + "\n",
    "# empty",

    "#!/usr/bin/perl\n" +
    "\n" +
    "use strict;\n" +
    "use warnings;\n" +
    "use Inca::Reporter::Version;\n" +
    "\n" +
    "my $reporter = new Inca::Reporter::Version(\n" +
    "  version => 1.3,\n" +
    "  description => 'Reports the version of openssl',\n" +
    "  url => 'http://www.openssl.org',\n" +
    "  package_name => 'openssl'\n" +
    ");\n" +
    "$reporter->processArgv(@ARGV);\n" +
    "\n" +
    "$reporter->setVersionByExecutable('echo version | openssl', 'OpenSSL (\\S+)');\n" +
    "$reporter->print();"

  };

  /**
    * Generate a sample reporter repository using the global reporters in this
    * file.
    *
    * @param path    The destination of the reporter repository.
    *
    * @param first   The start index of the reporters to include in the
    * repository
    *
    * @param last    The end index of the reporters to include in the repository
    *
    * @throws IOException
    */
   public static void makeRepository(String path, int first, int last)
     throws IOException {
     new File(path).mkdir();
     String catalogPath = path + SEP + "Packages.gz";
     OutputStreamWriter output = new OutputStreamWriter(
       new GZIPOutputStream(new FileOutputStream(catalogPath))
     );
     for(int i = first, offset = first * ATTRIBUTE_COUNT * 2; i <= last; i++) {
       for(int j = 0; j < ATTRIBUTE_COUNT; j++) {
         String attribute = REPORTER_ATTRS[offset++];
         String value = REPORTER_ATTRS[offset++];
         output.write(attribute + ": " + value + "\n");
       }
       OutputStreamWriter fout = new OutputStreamWriter(
         new FileOutputStream(path + SEP + REPORTER_FILENAMES[i])
       );
       fout.write(REPORTER_BODIES[i]);
       fout.close();
       output.write("\n");
     }
     output.close();
   }

  /**
   * Start up an Inca agent server and a client for testing
   *
   * @throws Exception
   */
  public void setUp() throws Exception {
    // NOTE: For reasons unclear, reusing the same port for all these tests
    // fails with bind errors.
    System.setProperty("inca.agent.depot", "inca://localhost:8343");
    System.setProperty("inca.agent.port", "" + port++);
    server = startAgent();
    assertFalse( "agent shtudwon correct", server.ranShutdown );
    client = startClient("localhost", server.getPort());
    makeRepository(REPOSITORY_PATH1, 0, 2);
    makeRepository(REPOSITORY_PATH2, 2, 3);
  }

  /**
   * Shutdown the global client and agent server.
   *
   * @throws Exception
   */
  public void tearDown() throws Exception {
    client.close();
    stopAgent(server);
    ReporterManagerControllerTest.deleteDirectory(new File(REPOSITORY_PATH1));
    ReporterManagerControllerTest.deleteDirectory(new File(REPOSITORY_PATH2));
  }


  /**
   * Tests whether the agent can send a catalog w/no reporters.
   */
  public void testCatalogEmpty() {
    try {
      Properties[] props = client.getCatalog(null);
      if(props.length != 0) {
        fail("Non-empty catalog with " + props.length + " entries");
      }
      String cat = client.getCatalogAsXml(null);
      cat = cat.replaceAll("\\s", "");
      assertEquals("<catalog></catalog>", cat);
    } catch(Exception e) {
      fail("unexpected exception " + e);
    }
  }

  /**
   * Tests whether the agent can sent a catalog from a single repository.
   */
  public void testCatalogSingle() {
    try {
      setConfig(new String[] {REPOSITORY_URL1}, null, null);
      Properties[] props = client.getCatalog(null);
      assertEquals(3, props.length);
      String cat = client.getCatalogAsXml(null).replaceAll("\\s", "");
      int endIndex = 3 * ATTRIBUTE_COUNT * 2;
      for(int i = 0; i < props.length; i++) {
        Enumeration e = props[i].propertyNames();
        while(e.hasMoreElements()) {
          String attr = (String)e.nextElement();
          String value = props[i].getProperty(attr);
          String xml = "<name>" + attr + "</name><value>" + value + "</value>";
          assertTrue(cat.indexOf(xml) >= 0);
          int j;
          for(j = 0 * ATTRIBUTE_COUNT * 2;
              j < endIndex &&
              (!attr.equals(REPORTER_ATTRS[j]) ||
               !value.equals(REPORTER_ATTRS[j + 1]));
              j += 2) {
            // empty
          }
          if(j >= endIndex) {
            fail("Spurious attribute '" + attr + "=" + value + "'");
          }
        }
      }
    } catch(Exception e) {
      fail("unexpected exception " + e);
    }
  }

  /**
   * Tests whether the agent refreshes its repository cache when asked for its
   * combined catalog.
   */
  public void testCatalogRefresh() {
    try {
      setConfig(new String[] {REPOSITORY_URL1, REPOSITORY_URL2}, null, null);
      Properties[] props = client.getCatalog(null);
      for(int i = 0; i < props.length; i++) {
        logger.info("Reporter #" + i + " has name " + props[i].getProperty("name"));
      }
      assertEquals(5, props.length);
      makeRepository(REPOSITORY_PATH1, 0, 2);
      makeRepository(REPOSITORY_PATH2, 2, 4);
      props = client.getCatalog(null);
      for(int i = 0; i < props.length; i++) {
        logger.info("Reporter #" + i + " has name " + props[i].getProperty("name"));
      }
      assertEquals(6, props.length);
    } catch(Exception e) {
      fail("unexpected exception " + e);
    }
  }

  /**
    * Test agent resource transmission.
    */
   public void testConfigCommand() throws Exception {
     Resource[] sent = ResourcesWrapperTest.createSampleResources().
       getResourceConfigDocument().getResourceConfig().getResources().
       getResourceArray();
     setConfig(null, sent, null);
     IncaDocument doc = getIncaDocument();
     assertNotNull(doc);
     assertNotNull(doc.getInca());
     assertNotNull(doc.getInca().getResourceConfig());
     assertNotNull(doc.getInca().getResourceConfig().getResources());
     Resource[] received =
       doc.getInca().getResourceConfig().getResources().getResourceArray();
     assertNotNull(received);
     assertEquals(sent.length, received.length);
     for(int i = 0; i < sent.length; i++) {
       boolean found = false;
       for(int j = 0; j < received.length; j++) {
         if(sent[i].getName().equals(received[j].getName())) {
           found = true;
         }
       }
       assertTrue(found);
     }
   }

  /**
   * Tests that the agent can report and process an empty configuration.
   */
  public void testConfigEmpty() {

    try {

      // Check the initial configuration
      IncaDocument doc = getIncaDocument();
      assertNotNull(doc);
      IncaDocument.Inca inca = doc.getInca();
      assertNotNull(inca);
      assertNotNull(inca.getRepositories());
      assertEquals(0, inca.getRepositories().getRepositoryArray().length);
      assertNotNull(inca.getResourceConfig());
      assertNotNull(inca.getResourceConfig().getResources());
      assertEquals
        (0, inca.getResourceConfig().getResources().getResourceArray().length);
      assertNotNull(inca.getSuites());
      assertEquals(0, inca.getSuites().getSuiteArray().length);

      // Send an empty configuration
      setConfig(null, null, null);

      // Check the new configuration
      doc = getIncaDocument();
      assertNotNull(doc);
      inca = doc.getInca();
      assertNotNull(inca);
      assertNotNull(inca.getRepositories());
      assertEquals(0, inca.getRepositories().getRepositoryArray().length);
      assertNotNull(inca.getResourceConfig());
      assertNotNull(inca.getResourceConfig().getResources());
      assertEquals
        (0, inca.getResourceConfig().getResources().getResourceArray().length);
      assertNotNull(inca.getSuites());
      assertEquals(0, inca.getSuites().getSuiteArray().length);

    } catch(Exception e) {
      logger.error( "unexpected exception", e );
      fail("unexpected exception " + e);
    }

  }

  /**
   * Tests whether the agent can shorten its repository list.
   */
  public void testRepositoryDelete() {
    try {
      String[] repos = {REPOSITORY_URL1, REPOSITORY_URL2};
      setConfig(repos, null, null);
      repos = new String[] {REPOSITORY_URL2};
      setConfig(repos, null, null);
      IncaDocument doc = getIncaDocument();
      assertNotNull(doc);
      assertNotNull(doc.getInca());
      assertNotNull(doc.getInca().getRepositories());
      repos = doc.getInca().getRepositories().getRepositoryArray();
      if(repos.length == 0) {
        fail("Empty repository list");
      } else if(repos.length > 1) {
        fail("Long repository list");
      } else if(repos[0].indexOf(REPOSITORY_PATH2) < 0) {
        fail("Invalid repository list '" + repos[0] + "'");
      }
    } catch(Exception e) {
      fail("unexpected exception " + e);
    }
  }

  /**
   * Tests whether the agent can process a valid repository.
   */
  public void testRepositorySingle() {
    try {
      String[] repos = {REPOSITORY_URL1};
      setConfig(repos, null, null);
      IncaDocument doc = getIncaDocument();
      assertNotNull(doc);
      assertNotNull(doc.getInca());
      assertNotNull(doc.getInca().getRepositories());
      repos = doc.getInca().getRepositories().getRepositoryArray();
      if(repos.length == 0) {
        fail("Empty repository list");
      } else if(repos.length > 1) {
        fail("Long repository list");
      } else if(repos[0].indexOf(REPOSITORY_PATH1) < 0) {
        fail("Invalid repository list '" + repos[0] + "'");
      }
    } catch(Exception e) {
      fail("unexpected exception " + e);
    }
  }

  /**
   * Tests whether the agent can process multiple valid repositories.
   */
  public void testRepositoryMultiple() {
    try {
      String[] repos = {REPOSITORY_URL1, REPOSITORY_URL2};
      setConfig(repos, null, null);
      IncaDocument doc = getIncaDocument();
      assertNotNull(doc);
      assertNotNull(doc.getInca());
      assertNotNull(doc.getInca().getRepositories());
      repos = doc.getInca().getRepositories().getRepositoryArray();
      if(repos.length == 0) {
        fail("Empty repository list");
      } else if(repos.length < 2) {
        fail("Short repository list");
      } else if(repos.length > 2) {
        fail("Long repository list");
      } else if((repos[0].indexOf(REPOSITORY_PATH1) < 0 &&
                 repos[1].indexOf(REPOSITORY_PATH1) < 0) ||
                (repos[0].indexOf(REPOSITORY_PATH2) < 0 &&
                 repos[1].indexOf(REPOSITORY_PATH2) < 0)) {
        fail("Invalid repository list '"+repos[0]+"' '"+repos[1]+"'");
      }
    } catch(Exception e) {
      fail("unexpected exception " + e);
    }
  }

  /**
   * Test Agent suite manipulation.
   * This test starts up a MockDepot and waits for 2 reports to be sent
   * to it before moving on.  This test could take a couple minutes to
   * complete.
   */
  public void testSuiteCommands() throws Exception {
    if ( AgentTest.isRunningTest() == false) return;
    try {
      submitSuite(
        new String[]{"test/samplesuitelocal.xml"},
        2, new String[]{ "gcc", "openssl"}
      );
      submitSuite(
        new String[]{"test/delete_samplesuitelocal.xml"},
        1, new String[]{"openssl"}
      );

      Thread.sleep(10 * Constants.MILLIS_TO_SECOND );
      startMockDepot( 1, 0 );
      logger.info( "Restarting agent" );
      stopAgent( server );
      startAgent( false );
      waitForReports( new String[]{"openssl"} );
    } catch(Exception e) {
      fail("Unexpected exception " + e);
    }
  }

  /**
   * Test the ability for agent to send proxy information.
   */
  public void testSuitesProxy() {

    if ( AgentTest.isRunningTest() == false) return;
    if ( ! AgentTest.hasMyProxyServer() ) return;

    try {
      sampleResources = ResourcesWrapperTest.createSampleResources();
      ReporterManagerControllerTest.storeProxy( sampleResources );
      submitSuite(
        new String[]{"test/gridsuitelocal.xml"},
        1, new String[]{ "validproxy" }
      );
    } catch(Exception e) {
      fail("Unexpected exception" + e);
    }

  }

  /**
   * Test the ability for agent to send proxy information.
   */
  public void testSuitesProxyBad() {

    if ( AgentTest.isRunningTest() == false) return;

    try {
      sampleResources = ResourcesWrapperTest.createSampleResources();
      submitSuite(
        new String[]{"test/gridsuitelocalbad.xml"},
        1, new String[]{ "Unable to fetch proxy" }
      );
    } catch(Exception e) {
      fail("Unexpected exception" + e);
    }

  }


  /**
   * Test the setConfig and getConfig commands with a mock depot.
   */
  public void testSuitesMultiple() {

    if ( AgentTest.isRunningTest() == false) return;

    try {
      submitSuite(
        new String[]{"test/samplesuitelocal.xml", "test/samplesuitelocal2.xml"},
        3, new String[]{ "gcc", "openssl", "user"}
      );

      // changes a macro in the localhost resource
      startMockDepot( 3, 1 );
      ResourceConfigDocument rcd = sampleResources.getResourceConfigDocument();
      Object[] result = rcd.selectPath(
        "//resource[name='localhost']//macro[name='verbose']"
      );
      assertEquals( "got verbose macro", 1, result.length );
      ((Macro)result[0]).setValueArray( 0, "25" );
      setConfig(
        new String[] {sampleRepository.getRepositories()[0].getURL().toString()},
        rcd.getResourceConfig().getResources().getResourceArray(),
        null
      );
      waitForReports
        ( new String[]{ "gcc", "openssl", "user", "<value>25</value>"} );
    } catch(Exception e) {
      logger.error( "Unexpected exception", e );
      fail("Unexpected exception" + e);
    }

  }

  /**
   * The repository cache will check for package updates periodically or
   * whenever the Agent's setRepositories function is invoked.  This test
   * will first set the package check update period frequency to every 30
   * seconds and then update the version of the gcc version reporter to "10".
   * To verify, it will wait for the next report and check it's version.  Once
   * verified, we set the update frequency to every 4 hours (the default) and
   * then update the version of the gcc version reporter to "20".  Then we
   * invoke the Agent's setRepository function and verify the update was
   * made in the next report that is received.

   * @throws Exception
   */
  public void testSuiteWithPackageUpdate() throws Exception {
    if ( AgentTest.isRunningTest() == false) return;

    sampleRepository = RepositoriesTest.createSampleRepository(null);

    String reporterName = "cluster.compiler.gcc.version";
    String reporterVersion = "1.5";

    // No updates available for gcc reporter
    assertFalse(
      "package not updated",
      sampleRepository.hasPackageUpdated( reporterName, reporterVersion )
    );

    // Run the suite containing the gcc reporter
    submitSuite(
      new String[]{"test/samplesuitelocal.xml"},
      2, new String[]{ "gcc", "openssl" }
    );
    logger.info( "Received first set of reports --------" );

    // Update the version of the reporter to 10 and let the repository
    // auto-refresh
    updateVersionInCatalog( sampleRepository, reporterName, "10" );
    updateVersionInReporter( reporterName,"10" );

    // Wait for next reports to come in - should have updated gcc report
    startMockDepot( 2, 1 );
    waitForReports( new String[]{"openssl", "gcc", "<version>10</version>"});
    logger.info( "Received second set of reports --------" );

    // Make sure auto-refresh doesn't update the reporter
    logger.info( "Setting refresh frequency to 4 hours" );
    Agent.getGlobalAgent().getRepositoryCache().setUpdatePeriod(
      4 * Constants.MILLIS_TO_HOUR
    );

    // Update the version of the reporter to 20
    logger.info( "Updating repository" );
    updateVersionInCatalog( sampleRepository, reporterName, "20" );
    updateVersionInReporter( reporterName,"20" );

    // Force the agent to check for updates
    startMockDepot( 2, 1 );
    Agent.getGlobalAgent().setRepositories( sampleRepository.getRepositories() );

    // Wait for the next set of reports to come in - gcc should now contain 20
    waitForReports( new String[]{"openssl", "gcc", "<version>20</version>"});
  }

  /**
   * Change the version of a reporter in the reporter repository.
   *
   * @param repositories  A list of reporter repositories
   *
   * @param reporterName  The name of the reporter to change the version on
   *
   * @param version       The new version of the reporter.
   *
   * @throws IOException
   */
  static public void updateVersionInCatalog(
    Repositories repositories, String reporterName, String version )
    throws IOException {

    Repository repo = repositories.getRepositoryForPackage
      ( reporterName, null );
    assertNotNull( "repository found for " + reporterName, repo );
    logger.info( "repository url is " + repo.getURL().toString() );
    Properties[] props = repo.getPropertiesByLookup( "name", reporterName );
    assertNotNull( "properties found for gcc reporter", props );

    File packagesGz = new File(
      repo.getURL().getPath() + File.separator + "Packages.gz"
    );
    assertTrue( "Package.gz found", packagesGz.exists() );
    BufferedReader input = new BufferedReader(
      new InputStreamReader(
        new GZIPInputStream(new FileInputStream(packagesGz))
      )
    );
    File packagesGzNew = new File(
      repo.getURL().getPath() + File.separator + "Packages.gz.new"
    );
    OutputStreamWriter output = new OutputStreamWriter(
      new GZIPOutputStream(new FileOutputStream(packagesGzNew))
    );
    String s;
    boolean nextVersionGcc = false;
    while( (s = input.readLine()) != null ) {
      if ( Pattern.compile("name: " + reporterName).matcher(s).find() ) {
        nextVersionGcc = true;
      }
      if ( nextVersionGcc && Pattern.compile("^version:").matcher(s).find() ) {
        nextVersionGcc = false;
        logger.debug( "Updating catalog entry '" + s + "' to " + version );
        output.write( "version: " + version + "\n");
      } else {
        output.write(s + "\n");
      }
    }
    output.close();
    input.close();
    packagesGzNew.renameTo( packagesGz );
    packagesGzNew.deleteOnExit();
    assertTrue( "Packages.gz exists", packagesGz.exists() );
    assertFalse( "Packages.gz.new does not exist", packagesGzNew.exists() );
  }

  // Private functions

  /**
   * Retrieve the configuration from the Agent server
   *
   * @return An Inca document showing the configuration of the agent server.
   *
   * @throws IOException
   * @throws ProtocolException
   */
  private IncaDocument getIncaDocument() throws IOException, ProtocolException {
    String xml = client.getConfig();
    try {
      return IncaDocument.Factory.parse(xml);
    } catch(Exception e) {
      throw new ProtocolException(e.toString());
    }
  }

  /**
   * Send a new Inca configuration to the Inca agent server.
   *
   * @param repositories  The new list of reporter repositories.
   *
   * @param resources     The new resource configuration.
   *
   * @param suites        Changes to the suites.
   *
   * @throws IOException
   * @throws ProtocolException
   */
  private void setConfig(String[] repositories,
                        Resource[] resources,
                        Suite[] suites) throws IOException, ProtocolException {

    IncaDocument doc = IncaDocument.Factory.newInstance();
    IncaDocument.Inca inca = doc.addNewInca();
    IncaDocument.Inca.Suites docSuites = inca.addNewSuites();
    if(repositories != null) {
      IncaDocument.Inca.Repositories docRepositories=inca.addNewRepositories();
      for(int i = 0; i < repositories.length; i++) {
        docRepositories.addRepository(repositories[i]);
      }
    }
    if(resources != null) {
      Resources docResources = inca.addNewResourceConfig().addNewResources();
      for(int i = 0; i < resources.length; i++) {
        docResources.addNewResource();
        docResources.setResourceArray(i, resources[i]);
      }
    }
    if(suites != null) {
      for(int i = 0; i < suites.length; i++) {
        docSuites.addNewSuite();
        docSuites.setSuiteArray(i, suites[i]);
      }
    }
    client.setConfig(doc.xmlText());
  }

  /**
   * Start a new agent server.
   *
   * @return A new Agent object.
   *
   * @throws ConfigurationException
   * @throws IOException
   */
  private Agent startAgent()
    throws ConfigurationException, IOException {
    return startAgent( true );
  }

  /**
    * Start a new agent server.
    *
    * @return A new Agent object.
    *
    * @throws ConfigurationException
    * @throws IOException
    */
  private Agent startAgent( boolean fresh )
    throws ConfigurationException, IOException {

    if ( fresh ) {
      File tempFile = new File("var");
      ReporterManagerControllerTest.deleteDirectory(tempFile);
    }
    Agent agent = new Agent();
    ConfigProperties config = new ConfigProperties();
    config.loadFromResource("inca.properties", "inca.agent.");
    config.putAllTrimmed(System.getProperties(), "inca.agent.");
    config.setProperty( "auth", "false" );
    config.setProperty( "password", "" );
    config.setProperty( "refreshPkgs", "30" );
    agent.setConfiguration(config);
    Agent.setGlobalAgent( agent );
    agent.runServer();
    return agent;
  }

  /**
   * Start up a new Inca agent client.
   *
   * @param server  The hostname of the agent server
   *
   * @param port    The port of the agent server
   *
   * @return A new AgentClient object
   *
   * @throws ConfigurationException
   * @throws IOException
   */
  private AgentClient startClient(String server, int port)
    throws ConfigurationException, IOException {
    AgentClient result = new AgentClient();
    ConfigProperties config = new ConfigProperties();
    config.putAllTrimmed(System.getProperties(), "inca.agent.");
    config.loadFromResource("inca.properties", "inca.agent.");
    config.setProperty( "auth", "false" );
    result.setConfiguration(config);
    result.setServer(server, port);
    result.connect();
    return result;
  }

  /**
   * Start up a new mock depot server to receive a specified number of reports
   * and suite updates.
   *
   * @param numReports  The number of reports to expect.
   * @param numSuites   The number of suite updates to expect
   */
  private void startMockDepot( int numReports, int numSuites ) {
    depot = new AgentTest.MockDepot(8343, numReports);
    depot.numSuitesExpected = numSuites;
    depot.start();
    Agent.getGlobalAgent().setDepots( new String[]{"inca://localhost:8343"} );
  }

  /**
   * Stop the agent server.
   *
   * @param a   The agent to shutdown.
   */
  private void stopAgent(Agent a) {
    if(a == null) {
      return;
    }
    try {
      logger.debug( "Trying to shutdown agent" );
      a.shutdown();
      logger.debug( "Shutdown complete" );
    } catch(InterruptedException e) {
      // empty
    }
  }

  /**
   * Submit a specified number of suite documents to the Inca agent and then
   * wait for a specified number of reports to be received.  Also retrieves
   * the configuration on the agent server and checks the results.
   *
   * @param suiteFiles  The suite files to submit to the agent server.
   * @param numReports  The number of reports to expect from the suites.
   * @param patterns    The patterns that be searched for in the received
   *                    reports indicating successful submission.
   *
   * @throws Exception
   */
  private void submitSuite(
    String[] suiteFiles, int numReports, String[] patterns )
    throws Exception {

    logger.debug
      ("------------ " + StringMethods.join(", ",suiteFiles) + " ----------- ");
    if ( sampleRepository == null ) {
      sampleRepository = RepositoriesTest.createSampleRepository(null);
    }

    // Launch a mock depot
    startMockDepot( numReports, suiteFiles.length );

    // Read in resources
    if ( sampleResources == null ) {
      sampleResources = ResourcesWrapperTest.createSampleResources();
    }
    ResourceConfigDocument rcd = sampleResources.getResourceConfigDocument();

    // Read in suite
    Suite[] suites =  new Suite[suiteFiles.length];
    Hashtable suiteNames = new Hashtable();
    for ( int i = 0; i < suites.length; i++ ) {
      suites[i]=SuiteDocument.Factory.parse(new File(suiteFiles[i])).getSuite();
      suiteNames.put( suites[i].getName(), "" );
    }
    String[] uniqSuiteNames = (String[])suiteNames.keySet().toArray
      ( new String[suiteNames.size()]);

    // Submit to agent.
    setConfig(
      new String[] {sampleRepository.getRepositories()[0].getURL().toString()},
      rcd.getResourceConfig().getResources().getResourceArray(),
      suites
    );

    logger.debug( "Config sent...waiting for " + numReports + " reports" );
    waitForReports( patterns );

    // Read back the configuration from the agent and check the suite guid
    IncaDocument doc = getIncaDocument();
    assertNotNull( "Inca document retrieved from agent", doc );
    assertNotNull( "Inca document has content", doc.getInca() );
    assertNotNull( "Inca document has suites", doc.getInca().getSuites());
    suites = doc.getInca().getSuites().getSuiteArray();
    assertEquals(
      "Contains " + uniqSuiteNames.length + " suites",
      suites.length, uniqSuiteNames.length
    );
    String[] receivedSuiteNames = new String[suites.length];
    for ( int i = 0; i < suites.length; i++ ) {
      receivedSuiteNames[i] = suites[i].getName();
      assertEquals(
        "Guid set",
        suites[i].getGuid(), server.getUri() + "/" + receivedSuiteNames[i]
      );
    }
    Arrays.sort( receivedSuiteNames );
    Arrays.sort( uniqSuiteNames );
    for ( int i = 0; i < suites.length; i++ ) {
      assertEquals(
        "Suite " + uniqSuiteNames[i] + " exists on agent",
        receivedSuiteNames[i], uniqSuiteNames[i]
      );
    }
  }

  /**
   * Update the version of the reporter (i.e., code).
   *
   * @param reporterName  The name of the reporter to update.
   *
   * @param version       The new version of the reporter
   *
   * @throws IOException
   */
  private void updateVersionInReporter( String reporterName, String version )
    throws IOException {

    Repository repo = sampleRepository.getRepositoryForPackage
      ( reporterName, null );
    assertNotNull( "repository found for " + reporterName, repo );
    logger.info( "repository url is " + repo.getURL().toString() );
    Properties[] props = repo.getPropertiesByLookup( "name", reporterName );
    assertNotNull( "properties found for gcc reporter", props );
    String reporterText = new String(repo.getReporter(reporterName));

    BufferedReader input;
    OutputStreamWriter output;
    String s;

    File reporter = new File(
      repo.getURL().getPath() + File.separator + reporterName
    );
    input = new BufferedReader(
      new InputStreamReader(new FileInputStream(reporter))
    );
    File reporterNew = new File(
      repo.getURL().getPath() + File.separator + reporterName + ".new"
    );
    output = new OutputStreamWriter(
      new FileOutputStream(reporterNew)
    );
    while( (s = input.readLine()) != null ) {
      if ( Pattern.compile("version =>").matcher(s).find() ) {
        output.write( "version => " + version + ",\n");
      } else {
        output.write(s + "\n");
      }
    }
    output.close();
    input.close();
    reporterNew.renameTo( reporter );
    reporterNew.deleteOnExit();
    assertFalse(
      "package updated",
      reporterText.equals(
        new String(repo.getReporter(reporterName))
      )
    );

  }

  /**
   * Wait for the reports to be received by the mock depot server and check
   * that the specifed patterns have been found.
   *
   * @param patterns   Patterns that should be found in the received reports
   *                   indicating a successul configuration.
   *
   * @throws InterruptedException
   */
  private void waitForReports( String[] patterns ) throws InterruptedException {
    depot.join();
    assertTrue(
      "all patterns found in reports",
      depot.checkReportsForPatterns( patterns )
    );
  }


}
