package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;
import org.apache.log4j.Logger;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;

import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.dataModel.all2all.All2AllSummariesDocument;
import edu.sdsc.inca.dataModel.all2all.Resource;
import edu.sdsc.inca.dataModel.all2all.Resources;
import edu.sdsc.inca.dataModel.all2all.TestSummary;
import edu.sdsc.inca.dataModel.all2all.TestSummaries;
import edu.sdsc.inca.dataModel.all2all.Failures;
import edu.sdsc.inca.dataModel.all2all.Failure;
import edu.sdsc.inca.queryResult.ReportSummaryDocument;

import java.io.IOException;
import java.util.Properties;
import java.util.Arrays;
import java.util.Vector;
import java.util.Hashtable;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.math.BigInteger;

/**
 * Jsp tag that will query the configured Inca agent for the specified latest
 * suite instances containing all-to-all tests and will return a summary.  It
 * will pick out all-to-all tests by looking for nicknames matching this
 * pattern:
 *
 * all2all:(\S+)_to_(\S+)
 *
 * The first parameter will be taken as the all-to-all test name and the
 * second will be taken as the resource.  The summary will contain for each
 * resource, the number of successes (numSuccesses), the number of at-fault
 * failures (numAtFaultFailures), the number of not-at-fault failures
 * numNotAtFaultFailures, and list of failed
 * tests (e.g., ssh_to_B, ssh_to_D).  The xml will be formatted as:
 *
 * &lt;all2all-test-summary&gt;
 *   &lt;resource&gt;
 *     &lt;testname&gt;
 *       &lt;numSuccesses&gt;
 *       &lt;numAtFaultFailures&gt;
 *       &lt;numNotAtFaultFailures&gt;
 *       &lt;failures&gt;
 *         &lt;nickname&gt;
 *         ...
 *       &lt;/failures&gt;
 *     &lt;/testname&gt;
 *   ...
 *   &lt;/resource&gt;
 * ...
 * &lt;/all2all-test-summary&gt;

 *
 * Required parameters are:
 *
 * suiteName
 * retAttrName
 *
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GetAll2AllSummary extends TagSupport {
  public static Logger logger = Logger.getLogger(GetAll2AllSummary.class);

  // types of test results
  public static int MISSING = -1;
  public static int FAILURE = 0;
  public static int SUCCESS = 1;

  // summary stats
  public static int NUM_STATS = 3;
  public static int SUCCESSES = 0;
  public static int NAF_FAILURES = 1;
  public static int AF_FAILURES = 2;

  // member variables
  private String suiteName = null;

  // convert report summaries into a R X R matrix of results that can be
  // manipulated
  public class TestData {
    public String[] resources = new String[0];
    public int[][] rawResults = new int[0][0];
    public ReportSummaryDocument[] docs = new ReportSummaryDocument[0];
  }

  public class TestSummaryResults {
    public int[][] summary = new int[0][0];
    public int[][] failures = new int[0][0];
  }


  /**
   * Called when the jsp tag is referenced in a JSP document.  Will return
   * a resources xml document or an error (expressed in XML --
   * &lt;error&gt;...&lt;/error&gt;)
   *
   * @return SKIP_BODY as required
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {
    if ( this.getRetAttrName() == null ){
      pageContext.setAttribute(
        "resources",
        "<error>Missing return attribute name</error>"
      );
      return SKIP_BODY;
    }

    try {
      String s = getAll2AllSiteSummaryXml();
      if ( s == null ) {
        String error = "<error>Unable to retrieve suite config xml</error>";
        pageContext.setAttribute( this.getRetAttrName(), error );
      } else {
        pageContext.setAttribute( this.getRetAttrName(), s );
      }
    } catch ( IOException e ) {
      String error =
        "<error>Unable to retrieve suite config xml: " + e + "</error>";
      pageContext.setAttribute( this.getRetAttrName(), error );
    }

    return SKIP_BODY;
  }

  /**
   * Compute the number of successes and failures for each resource
   * given an R X R array of all-to-all integer test results where
   *
   * R = set of resources
   *
   * r[i][j] = 1 if the test from the ith resource to jth resource succeeds,
   * r[i][j] = 0 if test from the ith resource to jth resource fails,
   * r[i][j] = -1 if the result of the test from the ith resource to jth
   * resource is missing
   *
   * The following rules will be used to count the number of successes and
   * failures:
   *
   * 1) if r[i][j] == 1, a success is added to resource i and resource j
   * 2) if r[i][j] == 0, a failure is added to resource i if i == j or
   *    r[k][j] == 1 where resource k != i and k != j or
   *    it's the only result so far (i.e., if a resource is testing to itself
   *    or if at least one other resource successfully tests to resource j or
   *    it's the only result so far, then we assume the failure is
   *    on resource i).
   * 3) if r[i][j] == 0, a failure is added to resource j if r[i][k] == 1 where
   *    k != j and k != i or it's the only result so far (i.e., if resource i
   *    successfully tests to at least one other
   *    resource, then we assume the failure is on resource j).
   *
   * @param results     An R X R array of all-to-all boolean test results.
   *
   * @return  An R X 3 array of summary results S, where
   * s[i][0] = number of i successes for resource j
   * s[i][1] = number of i not-at-fault failures for resource j
   * s[i][2] = number of i at fault failures for resource j
   */
  public TestSummaryResults computeSummary( int [][] results ) {

    // initialized to 0's
    TestSummaryResults summaryResults = new TestSummaryResults();
    summaryResults.summary = new int[results.length][NUM_STATS];
    Vector[] failures = new Vector[results.length];
    for ( int i = 0; i < failures.length; i++ ) failures[i] = new Vector();

    // if r[i][j] == 1, a success is added to resource i and resource j
    for( int i = 0; i < results.length; i++ ) {
      for( int j = 0; j < results[i].length; j++ ) {
        if ( results[i][j] == SUCCESS ) {
          summaryResults.summary[i][SUCCESSES]++;
          if ( i != j ) summaryResults.summary[j][SUCCESSES]++;
        }
      }
    }

    for( int j = 0; j < results.length; j++ ) {
      // if r[i][j] == 0, a failure is added to resource i if i == j or
      // r[k][j] == 1 where resource k != i and k != j or
      // it's the only result so far
      boolean oneSuccess = false;
      int numResults = 0;
      for( int i = 0; i < results[j].length; i++ ) {
        if ( results[i][j] == SUCCESS && i != j) oneSuccess = true;
        if ( results[i][j] != MISSING && i != j ) numResults++;
      }
      for( int i = 0; i < results[j].length; i++ ) {
        if ( results[i][j] == FAILURE ) {
          if ( numResults < 2 || oneSuccess || i == j ) {
            logger.debug(
              "jloop at fault failure added to " + i + " for " + i + "," + j
            );
            summaryResults.summary[i][AF_FAILURES]++;
            failures[i].add( BigInteger.valueOf(i * results.length + j) );
          } else {
            logger.debug(
              "jloop not at fault failure added to " + i + " for " + i + "," + j
            );
            summaryResults.summary[i][NAF_FAILURES]++;
          }
        }
      }
    }

    for( int i = 0; i < results.length; i++ ) {
      // if r[i][j] == 0, a failure is added to resource j if r[i][k] == 1 where
      // k != j and k != i or it's the only result so far
      boolean oneSuccess = false;
      int numResults = 0;
      for( int j = 0; j < results[i].length; j++ ) {
        if ( results[i][j] == SUCCESS ) oneSuccess = true;
        if ( results[i][j] != MISSING && i != j ) numResults++;
      }
      for( int j = 0; j < results[i].length; j++ ) {
        if ( results[i][j] == FAILURE ) {
          if ( numResults < 2  || oneSuccess || i == j ) {
            // if to itself, let's only count in once in above loop
            if ( i != j ) {
              logger.debug(
                "iloop at fault failure added to " + j + " for " + i + "," + j
              );
              summaryResults.summary[j][AF_FAILURES]++;
              failures[j].add( BigInteger.valueOf(i * results.length + j) );
            }
          } else {
            logger.debug(
              "iloop not at fault failure added to " + j + " for " + i + "," + j
            );
            summaryResults.summary[j][NAF_FAILURES]++;
          }
        }
      }
    }

    summaryResults.failures = new int[results.length][];
    for ( int i = 0; i < results.length; i++ ) {
      summaryResults.failures[i] = new int[failures[i].size()];
      for ( int j = 0; j < failures[i].size(); j++ ) {
        summaryResults.failures[i][j] =
        ((BigInteger)failures[i].get(j)).intValue();
      }
    }
    return summaryResults;
  }

  /**
   * Retrieves the suite configuration from the consumer cache, finds all
   * all-to-all test results, and returns a summary of the results per resource.
   *
   * @return A string containing the summary of all-to-all test results per
   * resources.
   *
   * @throws java.io.IOException
   */
  synchronized public String getAll2AllSiteSummaryXml()
    throws IOException {

    try {
      // query agent for resource configuration document
      String[] suite = Consumer.getSuite(
        this.getSuiteName(),
        Consumer.getCacheMaxWaitPeriod()
      );
      if ( suite == null ) {
        logger.error( "Retrieved null suite from consumer cache" );
        return null;
      }
      logger.debug( "Searching latest suite instances for all-to-all tests" );
      ReportSummaryDocument[] summaries = stringsToSummaries( suite );
      String[] all2alls = getAll2AllTestNames( summaries );
      Hashtable resourceTotals = new Hashtable();
      for ( int i = 0; i < all2alls.length; i++ ) {
        TestData testData = getTestData( all2alls[i], summaries );
        TestSummaryResults summaryResults = computeSummary(testData.rawResults);
        for ( int j = 0; j < summaryResults.summary.length; j++ ) {
          if ( !resourceTotals.containsKey(testData.resources[j]) ) {
            resourceTotals.put(
              testData.resources[j],
              TestSummaries.Factory.newInstance()
            );
          }
          TestSummaries resourceSummaries =
            (TestSummaries)resourceTotals.get( testData.resources[j] );
          TestSummary testSummary = resourceSummaries.addNewTestSummary();
          testSummary.setName( all2alls[i] );
          testSummary.setNumSuccesses(
            BigInteger.valueOf(summaryResults.summary[j][SUCCESSES])
          );
          testSummary.setNumAtFaultFailures(
            BigInteger.valueOf(summaryResults.summary[j][AF_FAILURES])
          );
          testSummary.setNumNotAtFaultFailures(
            BigInteger.valueOf(summaryResults.summary[j][NAF_FAILURES])
          );
          Failures failures = testSummary.addNewFailures();
          for ( int m = 0; m < summaryResults.failures[j].length; m++ ) {
            ReportSummaryDocument sum =
              testData.docs[summaryResults.failures[j][m]];
            Failure failure = failures.addNewFailure();
            failure.setNickname( sum.getReportSummary().getNickname() );
            failure.setInstanceId( sum.getReportSummary().getInstanceId() );
            failure.setSeriesConfigId(
              sum.getReportSummary().getSeriesConfigId()
            );
          }
          resourceTotals.put( testData.resources[j], resourceSummaries );
        }
      }
      String[] resourceNames = Util.setToArray( resourceTotals.keySet() );
      All2AllSummariesDocument sumDoc =
        All2AllSummariesDocument.Factory.newInstance();
      sumDoc.addNewAll2AllSummaries();
      Resources resources = sumDoc.getAll2AllSummaries().addNewResources();
      for ( int i = 0; i < resourceTotals.size(); i++ ) {
        Resource resource = resources.addNewResource();
        resource.setName( resourceNames[i] );
        resource.setTestSummaries(
          (TestSummaries)resourceTotals.get( resourceNames[i] )
        );
      }
      return sumDoc.toString();
    } catch ( Exception e ) {
      logger.error( "Unable to retrieve suite configs xml", e );
      throw new IOException(
        "Unable to retrieve suite configuration from agent: " + e
      );
    }
  }

  /**
   * Extract the list of all-to-all test names found in the provided report
   * summaries.
   *
   * @param sums  A list of report summaries retrieved from the depot.
   *
   * @return  An array of strings containing the all-to-all test names.
   */
  public String[] getAll2AllTestNames( ReportSummaryDocument[] sums ) {
    Properties testNames = new Properties();
    for ( int i = 0; i < sums.length; i++ ) {
      if ( sums[i].getReportSummary() == null ) continue;
      String testName = findValue(
        "all2all:(\\S+)_to_\\S+",
        sums[i].getReportSummary().getNickname()
      );
      if ( testName != null ) testNames.setProperty( testName, "" );
    }
    return Util.setToArray( testNames.keySet() );
  }

  /**
   * Return the name of the suite where all-2-all summary results will be
   * extracted from.
   *
   * @return the name of a suite.
   */
  public String getSuiteName() {
    return suiteName;
  }

  /**
   * Search the given report summaries for those that match our test name
   * and create a R X R matrix of test results, where R is the set of
   * resources involved in the all-to-all test.
   *
   * @param testName  The name of the all-to-all test running on the set of
   * resources R.
   * @param sums   The report summaries containing the all-to-all test results.
   *
   * @return  The matrix of test results and array of resources returned in a
   * TestData object.
   */
  public TestData getTestData( String testName, ReportSummaryDocument[] sums ) {

    Properties resources = new Properties();
    Vector testSummaries = new Vector();
    for ( int i = 0; i < sums.length; i++ ) {
      String server = findValue(
        "all2all:"+testName+"_to_(\\S+)",
        sums[i].getReportSummary().getNickname()
      );
      if ( server != null ) resources.setProperty( server, "" );
      String client = sums[i].getReportSummary().getHostname();
      if ( client != null ) resources.setProperty( client, "" );
      if ( server != null && client != null ) testSummaries.add( sums[i] );
    }
    TestData testData = new TestData();
    testData.resources = Util.setToArray( resources.keySet() );
    Arrays.sort( testData.resources );

    testData.rawResults =
    new int[testData.resources.length][testData.resources.length];
    testData.docs = new ReportSummaryDocument[
      testData.resources.length*testData.resources.length
      ];
    for ( int i = 0; i < testData.resources.length; i++ ) {
      Arrays.fill( testData.rawResults[i], MISSING );
    }
    for ( int i = 0; i < testSummaries.size(); i++ ) {
      ReportSummaryDocument sum = (ReportSummaryDocument)testSummaries.get(i);
      String server = findValue(
        "all2all:"+testName+"_to_(\\S+)",
        sum.getReportSummary().getNickname()
      );
      int serverIndex = Arrays.binarySearch( testData.resources, server );
      String client = sum.getReportSummary().getHostname();
      int clientIndex = Arrays.binarySearch( testData.resources, client );
      testData.docs[(clientIndex*testData.resources.length)+serverIndex] = sum;

      XmlOptions xmlOptions = new XmlOptions();
      xmlOptions.setSaveOuter();
      if ( sum.getReportSummary().isSetInstanceId() ) {
        if ( sum.getReportSummary().isSetBody() ) {
          String body = sum.getReportSummary().getBody().xmlText(xmlOptions);
          if ( body.matches( "^<body[^>]*/>$") ) {
            testData.rawResults[clientIndex][serverIndex] = FAILURE;
          } else {
            testData.rawResults[clientIndex][serverIndex] = SUCCESS;
          }
        }
      }
    }

    return testData;
  }

  /**
   * Set the name of the suite where all-2-all summary results will be
   * extracted from.
   *
   * @param suiteName  the name of a suite
   */
  public void setSuiteName( String suiteName ) {
    this.suiteName = suiteName;
  }

  /**
   * Converts the array of strings into an array of ReportSummaryDocuments.
   *
   * @param summaryXml   An array of strings containing report summary xml.
   *
   * @return an array of ReportSummaryDocuments.
   *
   * @throws XmlException
   */
  public ReportSummaryDocument[] stringsToSummaries( String[] summaryXml )
    throws XmlException {

    ReportSummaryDocument [] summaries =
      new ReportSummaryDocument[summaryXml.length];
    for ( int i = 0; i < summaries.length; i++ ) {
      summaries[i] = ReportSummaryDocument.Factory.parse( summaryXml[i] );
    }
    return summaries;
  }

  // Private Functions

  /**
   * Extract a value from the provided string using the provided pattern.
   *
   * @param pattern    A pattern containing one group.
   * @param searchString  A string containing the desired value.
   *
   * @return The value of the matched pattern or null if it is not found.
   */
  private static String findValue( String pattern, String searchString ) {

    Pattern thePattern = Pattern.compile(pattern);
    Matcher theMatcher = thePattern.matcher( searchString );
    if ( theMatcher.find() ) {
      return theMatcher.group(1);
    } else {
      return null;
    }
  }

}
