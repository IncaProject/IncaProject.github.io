package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;
import org.apache.log4j.Logger;

import java.io.IOException;


/**
 * Jsp tag that will return a single XML document that contains the results of
 * the following:
 *
 * (1) query results to the configured Inca depot for report summaries for
 *     a given suite,
 * (2) query results to the configured Inca agent for a resource configuration
 *     document, and
 * (3) the contents of a software stack XML definition located in the classpath
 *
 * Required parameters are:
 *
 * suiteName
 * resourceID
 * xmlFile
 *
 *  Author:  Kate Ericson, kericson@sdsc.edu
 */
public class GetXmlFromClasspath extends TagSupport {
  Logger logger = Logger.getLogger(GetXmlFromClasspath.class);

  private String xmlFile;

  /**
   * Called when the jsp tag is referenced in a JSP document.  Will return
   * a software stack status xml document or an error (expressed in XML --
   * &lt;error&gt;...&lt;/error&gt;)
   *
   * @return SKIP_BODY as required
   *
   * @throws javax.servlet.jsp.JspTagException
   */
  public int doStartTag() throws JspTagException {

    if ( this.getRetAttrName() == null ){
      pageContext.setAttribute(
        "xml",
        "<error>Missing return attribute name</error>"
      );
      return SKIP_BODY;
    }

    if ( this.xmlFile == null ){
      pageContext.setAttribute(
        this.getRetAttrName(),
        "<error>Missing sw stack xml filename</error>"
      );
      return SKIP_BODY;
    }

    try {
      long startTime = Util.getTimeNow();
      pageContext.setAttribute(
        this.getRetAttrName(),
        Util.getXMLFromClasspath(this.xmlFile)
      );
      Util.printElapsedTime( startTime, "GetXmlFromClasspath" );
    } catch ( IOException e ) {
      String error =
        "<error>Unable to retrieve xml file " + this.xmlFile +
        " from classpath: " + e + "</error>";
      pageContext.setAttribute( this.getRetAttrName(), error );
    }

    return SKIP_BODY;
  }

 /**
   * Return the name of the xml file that will be searched for in the classpath
   * and returned with the software stack status xml file.
   *
   * @return The name of a xml file expected to be found in the classpath.
   */
  public String getXmlFile() {
    return xmlFile;
  }


  /**
   * Set the name of the xml file that will be searched for in the classpath
   * and returned with the software stack status xml file.
   *
   * @param xmlFile The name of a xml file expected to be found in the
   * classpath.
   */
  public void setXmlFile(String xmlFile) {
    this.xmlFile = xmlFile;
  }
}
