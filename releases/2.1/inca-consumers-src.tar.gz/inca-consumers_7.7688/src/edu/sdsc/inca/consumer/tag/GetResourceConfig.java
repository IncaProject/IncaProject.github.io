package edu.sdsc.inca.consumer.tag;

import javax.servlet.jsp.JspTagException;
import org.apache.log4j.Logger;

import edu.sdsc.inca.dataModel.resourceConfig.ResourceConfigDocument;
import edu.sdsc.inca.dataModel.util.Resources;
import edu.sdsc.inca.dataModel.util.Resource;
import edu.sdsc.inca.dataModel.util.Macros;
import edu.sdsc.inca.Consumer;
import edu.sdsc.inca.ConfigurationException;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.util.ResourcesWrapper;

import java.io.IOException;
import java.util.Properties;

/**
 * Jsp tag that will query the configured Inca agent for a resource
 * configuration document, filter it so only the desired macros and resources
 * remain and returns it in the desired attribute name.
 *
 * Required parameters are:
 *
 * macros
 * retAttrName
 *
 * @author Kate Ericson &lt;kericson@sdsc.edu&gt;
 * @author Shava Smallen &lt;ssmallen@sdsc.edu&gt;
 */
public class GetResourceConfig extends TagSupport {
  public static Logger logger = Logger.getLogger(GetResourceConfig.class);

  private String resourceID;
  private String[] macros = new String[0];

  /**
   * Called when the jsp tag is referenced in a JSP document.  Will return
   * a resources xml document or an error (expressed in XML --
   * &lt;error&gt;...&lt;/error&gt;)
   *
   * @return SKIP_BODY as required
   *
   * @throws JspTagException
   */
  public int doStartTag() throws JspTagException {
    if ( this.getRetAttrName() == null ){
      pageContext.setAttribute(
        "resources",
        "<error>Missing return attribute name</error>"
      );
      return SKIP_BODY;
    }

    if ( this.macros == null ){
      pageContext.setAttribute(
        this.getRetAttrName(),
        "<error>Missing macro names</error>"
      );
      return SKIP_BODY;
    }

    try {
      long startTime = Util.getTimeNow();
      String s = getResourceConfig();
      if ( s == null ) {
        s = "<error>Unable to retrieve resource config xml from agent</error>";
      }
      Util.printElapsedTime( startTime, "getResourceConfig" );
      pageContext.setAttribute(this.getRetAttrName(), Util.stripNamespaces(s));
    } catch ( IOException e ) {
      String error =
        "<error>Unable to retrieve resource config xml: " + e + "</error>";
      pageContext.setAttribute( this.getRetAttrName(), error );
    }

    return SKIP_BODY;
  }

  /**
   * Return the macros the user wants returned in the resource config document
   * for all resources.
   *
   * @return  A string containing the macros space deliminated.
   */
  public String getMacros() {
    String macroString = "";
    for ( int i = 0; i < macros.length; i++ ) {
      macroString += macros[i] + " ";
    }
    return macroString;
  }

  /**
   * Retrieves the resource information from the consumer cache.  Creates
   * a subset of the resource config information that contains only the
   * macros passed into the tag (e.g., getMacros).  If a resource id is
   * also specified, then only members of that resource group are returned.
   * Note, that the __groupname__ for a resource is used as the resource name in
   * the returned XML string.
   *
   * @return
   *
   * @throws IOException
   */
  synchronized public String getResourceConfig()
    throws IOException {

    try {
      // query agent for resource configuration document
      ResourcesWrapper rc = Consumer.getResourceConfig(
        Consumer.getCacheMaxWaitPeriod()
      );
      if ( rc != null ) {
        ResourceConfigDocument newDoc = filterResources( rc );
        return newDoc.toString();
      } else {
        throw new IOException(
          "Error retrieving resources " + this.getResourceID()
        );
      }
    } catch ( Exception e ) {
      logger.error( "Unable to retrieve resource config xml", e );
      throw new IOException(
        "Unable to retrieve resource configuration from agent: " + e
      );
    }
  }

  /**
   * Get the resource group identifier that will be used to filter the
   * resource configuration returned from the agent.
   *
   * @return A resource group identifier.
   */
  public String getResourceID() {
    return resourceID;
  }

  /**
   * Set the macros the user wants returned in the resource config document
   * for all resources.

   * @param macros  A space delimited list of macros.
   */
  public void setMacros( String macros ) {
    this.macros = macros.split( "\\s+" );
  }

  /**
   * Set the resource group identifier that will be used to filter the
   * resource configuration returned from the agent.
   *
   * @param resourceID   A resource group identifier
   */
  public void setResourceID(String resourceID) {
    this.resourceID = resourceID;
  }

  // Private Functions

  /**
   * Create a new document using the __groupname__ as a replacement for the
   * hostname and includes just the passed in macros
   *
   * @param resources  The original resource configuration document
   *
   * @return The processed resource configuration document.
   *
   * @throws ConfigurationException
   */
  private ResourceConfigDocument filterResources(  ResourcesWrapper resources )
    throws ConfigurationException {

    // parse the document
    long startTime = Util.getTimeNow();
    Util.printElapsedTime( startTime, "config parse" );

    String[] resourceNames = new String[0];
    if ( this.getResourceID() == null ) {
      // return all resources -- but don't retrieve the hosts (i.e.,
      // the resources that have a __groupname__ macro)
      Object[] result = resources.getResourceConfigDocument().selectPath(
        "//resource/macros/macro[name='" + Protocol.GROUPNAME_MACRO + "']/../.."
      );
      if ( result != null ) {
        resourceNames = new String[result.length];
        for ( int i = 0; i < result.length; i++ ) {
          resourceNames[i] = ((Resource)result[i]).getName();
        }
      }
    } else {
      resourceNames = resources.getResources( this.getResourceID(), false );
    }
    ResourceConfigDocument newDoc=ResourceConfigDocument.Factory.newInstance();
    newDoc.addNewResourceConfig().addNewResources();
    if ( resourceNames == null || resourceNames.length < 1 ) {
      return newDoc;
    }

    Properties distinctResources = new Properties();
    for (int i = 0; i < resourceNames.length; i++) {
      String shortName = resources.getValue(
        resourceNames[i], Protocol.GROUPNAME_MACRO
      );
      if ( shortName == null ) {
        shortName = resourceNames[i];
      }
      if ( distinctResources.getProperty(shortName) != null ) continue;
      distinctResources.setProperty( shortName, "" );
      logger.debug( "Adding resource " + resourceNames[i] + " with " + shortName + " to config" );
      Resources theseResources = newDoc.getResourceConfig().getResources();
      Resource thisResource = theseResources.addNewResource();
      thisResource.addNewMacros();
      thisResource.setName( shortName );
      logger.debug( "groupname is " + thisResource.getName() );

      for (int j = 0; j < this.macros.length; j++) {
        String[] values = resources.getValues( resourceNames[i], this.macros[j] );
        Macros theseMacros = thisResource.getMacros();
        theseMacros.addNewMacro();
        theseMacros.getMacroArray(j).setName(this.macros[j]);
        theseMacros.getMacroArray(j).setValueArray(values);
      }
    }
    return newDoc;
  }

}
