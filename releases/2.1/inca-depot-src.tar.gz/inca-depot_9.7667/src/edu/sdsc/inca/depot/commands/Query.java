package edu.sdsc.inca.depot.commands;

import edu.sdsc.inca.dataModel.util.AnyXmlSequence;
import edu.sdsc.inca.dataModel.util.Log;
import edu.sdsc.inca.depot.persistent.*;
import edu.sdsc.inca.depot.util.HibernateMessageHandler;
import edu.sdsc.inca.protocol.Protocol;
import edu.sdsc.inca.protocol.ProtocolException;
import edu.sdsc.inca.protocol.ProtocolReader;
import edu.sdsc.inca.protocol.ProtocolWriter;
import edu.sdsc.inca.protocol.Statement;
import edu.sdsc.inca.queryResult.ReportSummaryDocument;
import edu.sdsc.inca.queryResult.ReportDetailsDocument;
import edu.sdsc.inca.util.StringMethods;
import org.apache.xmlbeans.XmlException;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

/**
 */
public class Query extends HibernateMessageHandler {

  private static Logger logger = Logger.getLogger(Query.class);
  private static final Statement S_FINISH =
    new Statement(Protocol.END_QUERY_RESULTS_COMMAND.toCharArray(), null);

  /**
   * Execute queries on the depot.
   *
   * @param reader   Reader to the query request.
   * @param writer   Writer to the remote process making the request.
   * @throws Exception
   */
  public void executeHibernateAction(
    ProtocolReader reader, ProtocolWriter writer) throws Exception {

    Statement queryStatement = null;
    queryStatement = reader.readStatement();
    String cmd = new String(queryStatement.getCmd());
    String data = new String(queryStatement.getData());
    if(cmd.equals(Protocol.QUERY_GUIDS_COMMAND)) {
      getGuidList(writer);
    } else if(cmd.equals(Protocol.QUERY_HQL_COMMAND)) {
      getSelectOutput(writer, data);
    } else if(cmd.equals(Protocol.QUERY_INSTANCE_COMMAND)) {
      getInstance(writer, data);
    } else if(cmd.equals(Protocol.QUERY_SERIES_COMMAND)) {
      getSeriesInstances(writer, data);
    } else if(cmd.equals(Protocol.QUERY_SUITE_COMMAND)) {
      getLatestInstancesForSuite(writer, data);
    }
    if(!cmd.equals(Protocol.QUERY_GUIDS_COMMAND)) {
      writer.write(S_FINISH);
    }

  }

  /**
   * Return a list of the Suite guids in the database.
   *
   * @param writer Writer to the remote process making the request
   * @param request The data packaged with the request
   * @throws Exception
   */
  private void getGuidList(ProtocolWriter writer) throws Exception {
    List suites = DAO.selectMultiple("select s from Suite as s", null);
    String[] guids = new String[suites.size()];
    for(int i = 0; i < guids.length; i++) {
      guids[i] = ((Suite)suites.get(i)).getGuid();
    }
    writer.write(Statement.getOkStatement(StringMethods.join(" ", guids)));
  }

  /**
   * Return a report details document to the client for the given report
   * instance and configuration.
   *
   * @param writer  Writer to the remote process making the request.
   * @param request The instance query request which contains the
   * instance id, followed by a space, and then the report series configuration
   * id.
   *
   * @throws PersistenceException on a failed lookup
   * @throws Exception
   */
  private void getInstance(ProtocolWriter writer, String request)
    throws Exception {
    String[] pieces = request.split(" ");
    Long instanceId = null, configId = null;
    if(pieces.length != 2) {
      throw new ProtocolException
        ("Expected 'instanceId configId', got '" + request + "'");
    }
    try {
      instanceId = Long.valueOf(pieces[0]);
      configId = Long.valueOf(pieces[1]);
    } catch(NumberFormatException e) {
      throw new ProtocolException("Non-numeric id in '" + request + "'");
    }
    SeriesConfig sc = SeriesConfigDAO.load(configId);
    InstanceInfo ii = InstanceInfoDAO.load(instanceId);
    if(sc == null) {
      throw new PersistenceException("Request for unknown config " + configId);
    } else if(ii == null) {
      throw new PersistenceException
        ("Request for unknown instance " + instanceId);
    }
    ComparisonResult cr = ComparisonResultDAO.load(sc.getLatestComparisonId());
    ReportDetailsDocument rdd =
      toBean(sc, ReportDAO.load(ii.getReportId()), ii, cr);
    String response = rdd.toString();
    writer.write(new Statement(Protocol.QUERY_RESULT, response));
  }

  /**
   * Return a report details document to the requester for every instance of
   * a given series.
   *
   * @param writer  Writer to the remote process making the request.
   * @param request The query request that contains the SeriesConfig id.
   * @throws Exception
   */
  private void getSeriesInstances
    (ProtocolWriter writer, String request) throws Exception {
    SeriesConfig sc = null;
    String query = "select sc from SeriesConfig sc where sc.nickname = :p0";
    if(request.matches("^\\d+$")) {
      sc = SeriesConfigDAO.load(Long.valueOf(request));
    } else {
      sc = (SeriesConfig)DAO.selectUnique(query, new Object[] {request});
    }
    if(sc == null) {
      throw new PersistenceException("Request for unknown config " + request);
    }
    query = "select r, ii from Report r, InstanceInfo ii " +
            "where r.series = :p0 and ii.reportId = r.id " +
            "order by ii.collected";
    List results = DAO.selectMultiple(query, new Object[] {sc.getSeries()});
    Statement reply = new Statement(Protocol.QUERY_RESULT, null);
    for(int i = 0; i < results.size(); i++) {
      Object[] result = (Object [])results.get(i);
      Report r = (Report)result[0];
      InstanceInfo ii = (InstanceInfo)result[1];
      ReportDetailsDocument rdd = toBean(sc, r, ii, null);
      String str = rdd.toString();
      char[] chars = str.toCharArray();
      reply.setData(chars);
      writer.write(reply);
    }
  }

  /**
   * Return the output from an HQL query.
   *
   * @param writer  writer to the remote process making the request.
   * @param select the HQL select statement
   * @throws Exception
   */
  private void getSelectOutput
    (ProtocolWriter writer, String select) throws Exception {
    Session session = HibernateUtil.getCurrentSession();
    org.hibernate.Query query = session.createQuery(select);
    List l = null;
    try {
      l = query.list();
    } catch(Exception e) {
      throw new PersistenceException(e.toString());
    }
    Statement reply = new Statement(Protocol.QUERY_RESULT, null);
    for(int i = 0; i < l.size(); i++) {
      PersistentObject po = (PersistentObject)l.get(i);
      String s = po.toXml();
      char[] chars = s.toCharArray();
      reply.setData(chars);
      writer.write(reply);
    }
  }

  /**
   * Return the latest report summaries for all series in a given suite.
   *
   * @param writer  Writer to the remote process making the request.
   * @param suiteGuid A suite GUID string.
   * @throws Exception
   */
  private void getLatestInstancesForSuite(
    ProtocolWriter writer, String suiteGuid) throws Exception {

    String query = "select s from Suite as s where s.guid = :p0";
    Suite suite = (Suite)DAO.selectUnique(query, new Object[] {suiteGuid});
    if(suite == null) {
      throw new PersistenceException("Suite " + suiteGuid + " not found in DB");
    }
    query = "select sc from SeriesConfig sc " +
            "where sc.suite = " + suite.getId() + " " +
              "and sc.deactivated <= sc.activated";
    List scs = DAO.selectMultiple(query, null);
    query = "select cr from SeriesConfig sc, ComparisonResult cr " +
            "where sc.suite = " + suite.getId() + " " +
              "and sc.deactivated <= sc.activated " +
              "and sc.latestComparisonId = cr.id";
    List results = DAO.selectMultiple(query, null);
    Hashtable comparisons = new Hashtable();
    for(int i = 0; i < results.size(); i++) {
      ComparisonResult cr = (ComparisonResult)results.get(i);
      comparisons.put(cr.getId(), cr);
    }
    query = "select ii from SeriesConfig sc, InstanceInfo ii " +
            "where sc.suite = " + suite.getId() + " " +
              "and sc.deactivated <= sc.activated " +
              "and sc.latestInstanceId = ii.id";
    results = DAO.selectMultiple(query, null);
    Hashtable instances = new Hashtable();
    for(int i = 0; i < results.size(); i++) {
      InstanceInfo ii = (InstanceInfo)results.get(i);
      instances.put(ii.getId(), ii);
    }
    query = "select r from SeriesConfig sc, InstanceInfo ii, Report r " +
            "where sc.suite = " + suite.getId() + " " +
              "and sc.deactivated <= sc.activated " +
              "and sc.latestInstanceId = ii.id " +
              "and ii.reportId = r.id";
    results = DAO.selectMultiple(query, null);
    Hashtable reports = new Hashtable();
    for(int i = 0; i < results.size(); i++) {
      Report r = (Report)results.get(i);
      reports.put(r.getId(), r);
    }

    // loop through each item in the list and turn it into a BasicResult
    Statement reply = new Statement(Protocol.QUERY_RESULT, null);
    for(int i = 0; i < scs.size(); i++) {
      SeriesConfig sc = (SeriesConfig)scs.get(i);
      ComparisonResult cr =
        (ComparisonResult)comparisons.get(sc.getLatestComparisonId());
      InstanceInfo ii = (InstanceInfo)instances.get(sc.getLatestInstanceId());
      Report r = ii == null ? null : (Report)reports.get(ii.getReportId());
      ReportSummaryDocument rsd = toBean(sc, cr, ii, r);
      String s = rsd.toString();
      char[] chars = s.toCharArray();
      reply.setData(chars);
      writer.write(reply);
    }
  }

  /**
   * Creates a ReportDetailsDocument by copying fields from a DB SeriesConfig,
   * a DB report, and a DB InstanceInfo.
   *
   * @param sc the SeriesConfig for the document
   * @param r the Report for the document
   * @param ii the latest InstanceInfo for the document
   * @param cr the latest ComparisonResult for the document
   */
  protected static ReportDetailsDocument toBean
    (SeriesConfig sc, Report r, InstanceInfo ii, ComparisonResult cr)
    throws PersistenceException {
    ReportDetailsDocument result =
      ReportDetailsDocument.Factory.newInstance();
    ReportDetailsDocument.ReportDetails rd = result.addNewReportDetails();
    rd.setSuiteId(sc.getSuite().getId().longValue());
    rd.setSeriesConfigId(sc.getId().longValue());
    rd.setSeriesId(r.getSeries().getId().longValue());
    rd.setReportId(r.getId().longValue());
    rd.setInstanceId(ii.getId().longValue());
    rd.setSeriesConfig((edu.sdsc.inca.dataModel.util.SeriesConfig)sc.toBean());
    rd.setReport((edu.sdsc.inca.dataModel.util.Report)r.toBean());
    // Note: apparently getGmt() returns a copy, so the following doesn't work
    //rd.getReport().getGmt().setTime(ii.getCollected());
    GregorianCalendar gmt = new GregorianCalendar();
    gmt.setTime(ii.getCollected());
    rd.getReport().setGmt(gmt);
    String log = ii.getLog();
    if(log != null && !log.equals("") &&
       !log.equals(PersistentObject.DB_EMPTY_STRING)) {
      try {
        rd.getReport().setLog(Log.Factory.parse(log));
      } catch(Exception e) {
        logger.error("Unable to parse log stored in DB:", e);
      }
    }
    if(cr != null) {
      rd.setComparisonResult(cr.getResult());
    }
    rd.setSysusage((edu.sdsc.inca.dataModel.util.Limits)ii.toBean());
    rd.setStderr(r.getStderr());
    return result;
  }

  /**
   * Creates a ReportSummaryDocument by copying fields from a DB SeriesConfig.
   *
   * @param sc the SeriesConfig for the document
   * @param cr the latest comparison result for sc
   * @param ii the latest instance info for sc
   * @param r the latest report for sc
   */
  protected static ReportSummaryDocument toBean
    (SeriesConfig sc, ComparisonResult cr, InstanceInfo ii, Report r)
    throws PersistenceException {
    ReportSummaryDocument result = ReportSummaryDocument.Factory.newInstance();
    ReportSummaryDocument.ReportSummary summary = result.addNewReportSummary();
    Series s = sc.getSeries();
    summary.setHostname(s.getResource());
    summary.setUri(s.getUri());
    summary.setNickname(sc.getNickname());
    summary.setSeriesConfigId(sc.getId().longValue());
    if(ii != null) {
      summary.setInstanceId(ii.getId().longValue());
      GregorianCalendar gmt = new GregorianCalendar();
      gmt.setTime(ii.getCollected());
      summary.setGmt(gmt);
    }
    if(r != null) {
      String bodyText = r.getBody();
      try {
        summary.setBody(AnyXmlSequence.Factory.parse(bodyText));
      } catch(XmlException e) {
        // empty
      }
      summary.setErrorMessage(r.getExit_message());
    }
    if(cr != null) {
      summary.setComparisonResult(cr.getResult());
    }
    return result;
  }

}
